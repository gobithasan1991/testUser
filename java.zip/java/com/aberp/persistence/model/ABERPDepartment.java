package com.aberp.persistence.model;

import java.io.Serializable;

public class ABERPDepartment implements Serializable {

	private static final long serialVersionUID = 220692858358613541L;
	private String deptCode;
	private String deptName;

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

}
