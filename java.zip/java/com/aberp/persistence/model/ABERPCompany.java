package com.aberp.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="company_mast")
public class ABERPCompany implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	private long CID;
	private String CCode;
	private String CName;
	private String IPAddress;
	private String VATNo;
	private String TINNo;
	private String STaxNo;
	private String Status;
	private String CDate;
	private String CreatedBy;
	@Temporal(TemporalType.TIMESTAMP)
	private Date CreatedDate;
	
	public long getCID() {
		return CID;
	}
	public void setCID(long cID) {
		CID = cID;
	}
	public String getCCode() {
		return CCode;
	}
	public void setCCode(String cCode) {
		CCode = cCode;
	}
	public String getCName() {
		return CName;
	}
	public void setCName(String cName) {
		CName = cName;
	}
	public String getIPAddress() {
		return IPAddress;
	}
	public void setIPAddress(String iPAddress) {
		IPAddress = iPAddress;
	}
	public String getVATNo() {
		return VATNo;
	}
	public void setVATNo(String vATNo) {
		VATNo = vATNo;
	}
	public String getTINNo() {
		return TINNo;
	}
	public void setTINNo(String tINNo) {
		TINNo = tINNo;
	}
	public String getSTaxNo() {
		return STaxNo;
	}
	public void setSTaxNo(String sTaxNo) {
		STaxNo = sTaxNo;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getCDate() {
		return CDate;
	}
	public void setCDate(String cDate) {
		CDate = cDate;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getCreatedDate() {
		return CreatedDate;
	}
	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}

}
