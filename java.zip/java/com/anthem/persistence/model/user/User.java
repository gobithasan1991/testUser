package com.anthem.persistence.model.user;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.security.core.userdetails.UserDetails;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.glp.persistence.model.admin.GLPDesignation;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.Company;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.admin.Employee;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.admin.Role;
import com.anthem.persistence.model.common.Default;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
@JsonIgnoreProperties({ "displayName", "designation", "employeeCode" })
public class User extends Default implements UserDetails {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true)
	@NotBlank(message = "Username cannot be empty")
	private String username;
	@NotBlank(message = "Password cannot be empty")
	private String password;

	@NotBlank(message = "Fullname cannot be empty")
	private String fullName;

	private boolean accountNonExpired;
	private boolean accountNonLocked;
	private boolean credentialsNonExpired;
	private String emailId;

	@ManyToMany(cascade = CascadeType.REMOVE)
	@OrderColumn
	private Collection<Role> authorities;

	@Temporal(TemporalType.DATE)
	@LastModifiedDate
	private Date lastPasswordChangedOn;

	@OneToOne(cascade = CascadeType.REMOVE)
	@JoinColumn(unique = true)
	private Employee employee;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Department department;

	@ManyToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY, targetEntity = QMSDepartment.class)
	private List<QMSDepartment> qmsDepartments;
	
	@ManyToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY, targetEntity = GLPDepartment.class)
	private List<GLPDepartment> glpDepartments;
	
	@ManyToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY, targetEntity = GLPDesignation.class)
	private List<GLPDesignation> glpDesignations;

	@ManyToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@OrderColumn
	private List<Branch> branches;

	@OneToOne
	private Company company;

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	/**
	 * 
	 */
	public User() {
		super();
	}

	/**
	 * @param userId
	 */
	public User(Long id) {
		super();
		this.id = id;
	}

	/**
	 * @param username
	 * @param password
	 */
	public User(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public User(Long id, String username, boolean accountNonExpired, boolean accountNonLocked,
			boolean credentialsNonExpired) {
		super();
		this.id = id;
		this.username = username;
		this.accountNonExpired = accountNonExpired;
		this.accountNonLocked = accountNonLocked;
		this.credentialsNonExpired = credentialsNonExpired;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public boolean isAccountNonExpired() {
		return accountNonExpired;
	}

	public void setAccountNonExpired(boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	public void setAccountNonLocked(boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	public boolean isCredentialsNonExpired() {
		return credentialsNonExpired;
	}

	public void setCredentialsNonExpired(boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Collection<Role> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Collection<Role> authorities) {
		this.authorities = authorities;
	}

	public Date getLastPasswordChangedOn() {
		return lastPasswordChangedOn;
	}

	public void setLastPasswordChangedOn(Date lastPasswordChangedOn) {
		this.lastPasswordChangedOn = lastPasswordChangedOn;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<QMSDepartment> getQmsDepartments() {
		return qmsDepartments;
	}

	public void setQmsDepartments(List<QMSDepartment> qmsDepartments) {
		this.qmsDepartments = qmsDepartments;
	}

	public List<GLPDepartment> getGlpDepartments() {
		return glpDepartments;
	}

	public void setGlpDepartments(List<GLPDepartment> glpDepartments) {
		this.glpDepartments = glpDepartments;
	}

	public List<GLPDesignation> getGlpDesignations() {
		return glpDesignations;
	}

	public void setGlpDesignations(List<GLPDesignation> glpDesignations) {
		this.glpDesignations = glpDesignations;
	}

	public List<Branch> getBranches() {
		return branches;
	}

	public void setBranches(List<Branch> branches) {
		this.branches = branches;
	}

	@PrePersist
	public void persistDefaultValues() {
		this.accountNonExpired = true;
		this.accountNonLocked = true;
		this.credentialsNonExpired = true;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
