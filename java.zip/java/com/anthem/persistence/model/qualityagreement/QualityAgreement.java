package com.anthem.persistence.model.qualityagreement;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.anthemerp.Customer;
import com.anthem.persistence.model.anthemerp.Product;
import com.anthem.persistence.model.anthemerp.Project;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.util.qualityagreement.ArchivalStatus;

@Audited
@Entity
public class QualityAgreement extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5891957876995673864L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true)
	private String agreementNumber;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Customer customer;

	private String customerName;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private AgreementType agreementType;

	private String agreementScope;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Project project;

	private String projectName;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus productSpecific;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private Product product;

	private String productName;

	private String fileName;

	@Column(columnDefinition = "integer default 0")
	private Integer versionNo;

	@Temporal(TemporalType.TIMESTAMP)
	private Date effectiveDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date validity;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'ARCHIVED') DEFAULT 'PENDING'")
	private ArchivalStatus archivalStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED', 'RECALLED', 'MAPPED', 'PARTIALLYREVIEWED', 'REVIEWED', 'PARTIALLYAPPROVED', 'APPROVED', 'REJECTED') DEFAULT 'CREATED'")
	private CustomStatus status;

	@Lob
	private String reason;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Branch branch;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAgreementNumber() {
		return agreementNumber;
	}

	public void setAgreementNumber(String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public AgreementType getAgreementType() {
		return agreementType;
	}

	public void setAgreementType(AgreementType agreementType) {
		this.agreementType = agreementType;
	}

	public String getAgreementScope() {
		return agreementScope;
	}

	public void setAgreementScope(String agreementScope) {
		this.agreementScope = agreementScope;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public YesOrNoStatus getProductSpecific() {
		return productSpecific;
	}

	public void setProductSpecific(YesOrNoStatus productSpecific) {
		this.productSpecific = productSpecific;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getValidity() {
		return validity;
	}

	public void setValidity(Date validity) {
		this.validity = validity;
	}

	public ArchivalStatus getArchivalStatus() {
		return archivalStatus;
	}

	public void setArchivalStatus(ArchivalStatus archivalStatus) {
		this.archivalStatus = archivalStatus;
	}

	public CustomStatus getStatus() {
		return status;
	}

	public void setStatus(CustomStatus status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public User getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(User modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "QualityAgreement [id=" + id + ", agreementNumber=" + agreementNumber + ", customer=" + customer
				+ ", customerName=" + customerName + ", agreementType=" + agreementType + ", agreementScope="
				+ agreementScope + ", project=" + project + ", projectName=" + projectName + ", productSpecific="
				+ productSpecific + ", product=" + product + ", productName=" + productName + ", fileName=" + fileName
				+ ", versionNo=" + versionNo + ", effectiveDate=" + effectiveDate + ", validity=" + validity
				+ ", archivalStatus=" + archivalStatus + ", status=" + status + ", reason=" + reason + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate + ", branch=" + branch + "]";
	}

}
