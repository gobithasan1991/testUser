package com.anthem.persistence.model.qualityagreement;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;

@Audited
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "qualityAgreement_id", "agreementRevNo", "user_id",
		"reviewType", "enabledStatus" }))
public class QualityAgreementReviewApproveMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5753347806784893048L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private QualityAgreement qualityAgreement;

	private Long agreementRevNo;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.EAGER)
	private User user;

	private String reviewType;

	@Enumerated(EnumType.STRING)
	@Column(name = "MappingStatus", columnDefinition = "ENUM('MAPPED', 'RECALLED', 'REVIEWED', 'APPROVED', 'REJECTED') DEFAULT 'MAPPED'", insertable = false)
	private CustomStatus mappingStatus;

	private Integer modifyRequestCount;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.EAGER)
	private User cancelledBy;

	private Date cancelledDate;

	@Lob
	private String cancelReason;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QualityAgreement getQualityAgreement() {
		return qualityAgreement;
	}

	public void setQualityAgreement(QualityAgreement qualityAgreement) {
		this.qualityAgreement = qualityAgreement;
	}

	public Long getAgreementRevNo() {
		return agreementRevNo;
	}

	public void setAgreementRevNo(Long agreementRevNo) {
		this.agreementRevNo = agreementRevNo;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public CustomStatus getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(CustomStatus mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public Integer getModifyRequestCount() {
		return modifyRequestCount;
	}

	public void setModifyRequestCount(Integer modifyRequestCount) {
		this.modifyRequestCount = modifyRequestCount;
	}

	public User getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(User cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public Date getCancelledDate() {
		return cancelledDate;
	}

	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

}
