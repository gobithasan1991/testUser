package com.anthem.persistence.model.qualityagreement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;

@Entity
public class ModificationRequestLog extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4529053617056411590L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private QualityAgreement qualityAgreement;

	private boolean keepMappings;

	private Long preAgreementRevNo;

	private Long agreementRevNo;

	@Lob
	private String reason;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QualityAgreement getQualityAgreement() {
		return qualityAgreement;
	}

	public void setQualityAgreement(QualityAgreement qualityAgreement) {
		this.qualityAgreement = qualityAgreement;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Long getAgreementRevNo() {
		return agreementRevNo;
	}

	public void setAgreementRevNo(Long agreementRevNo) {
		this.agreementRevNo = agreementRevNo;
	}

	public boolean isKeepMappings() {
		return keepMappings;
	}

	public void setKeepMappings(boolean keepMappings) {
		this.keepMappings = keepMappings;
	}

	public Long getPreAgreementRevNo() {
		return preAgreementRevNo;
	}

	public void setPreAgreementRevNo(Long preAgreementRevNo) {
		this.preAgreementRevNo = preAgreementRevNo;
	}

}
