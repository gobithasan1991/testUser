package com.anthem.persistence.model.jobdescription;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Entity
public class JobDescriptionApproverMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 758603811533192093L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Branch branch;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@NotNull(message = "Department is Should not Null")
	private QMSDepartment qmsDepartment;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = JobDescriptionApproverUser.class)
	@JoinColumn(name = "jobDescriptionApproverMapping_id")
	private List<JobDescriptionApproverUser> jobDescriptionApproverUsers;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public List<JobDescriptionApproverUser> getJobDescriptionApproverUsers() {
		return jobDescriptionApproverUsers;
	}

	public void setJobDescriptionApproverUsers(List<JobDescriptionApproverUser> jobDescriptionApproverUsers) {
		this.jobDescriptionApproverUsers = jobDescriptionApproverUsers;
	}

}
