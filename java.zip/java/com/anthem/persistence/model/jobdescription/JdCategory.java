package com.anthem.persistence.model.jobdescription;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;

@Entity
public class JdCategory extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8774983833335768734L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "JD Category Code is Should not Null")
	@NotEmpty(message = "JD Category Code is Required")
	private String code;

	@NotNull(message = "JD Category Name is Should not Null")
	@NotEmpty(message = "JD Category Name is Required")
	@Size(min = 3, message = "Invalid JD Category Name")
	private String name;

	/**
	 * 
	 */
	public JdCategory() {
		super();
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

}
