package com.anthem.persistence.model.jobdescription;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
public class JobDescriptionApproverUser extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4542998596549391542L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@NotNull(message = "Employee Should not Null")
	private User user;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private JobDescriptionApproverMapping jobDescriptionApproverMapping;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public JobDescriptionApproverMapping getJobDescriptionApproverMapping() {
		return jobDescriptionApproverMapping;
	}

	public void setJobDescriptionApproverMapping(JobDescriptionApproverMapping jobDescriptionApproverMapping) {
		this.jobDescriptionApproverMapping = jobDescriptionApproverMapping;
	}

}
