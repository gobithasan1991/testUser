package com.anthem.persistence.model.jobdescription;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;

@Entity
public class JdReferenceDocument extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7260515058820957516L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;

	@ManyToOne(fetch = FetchType.LAZY)
	private Document document;

	private String documentVersionNo;

	@Temporal(TemporalType.DATE)
	private Date documentEffectiveDate;

	private Long documentRevNo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public Date getDocumentEffectiveDate() {
		return documentEffectiveDate;
	}

	public void setDocumentEffectiveDate(Date documentEffectiveDate) {
		this.documentEffectiveDate = documentEffectiveDate;
	}

	public Long getDocumentRevNo() {
		return documentRevNo;
	}

	public void setDocumentRevNo(Long documentRevNo) {
		this.documentRevNo = documentRevNo;
	}

	@Override
	public String toString() {
		return "JdReferenceDocument [id=" + id + ", branch=" + branch + ", document=" + document
				+ ", documentVersionNo=" + documentVersionNo + ", documentEffectiveDate=" + documentEffectiveDate
				+ ", documentRevNo=" + documentRevNo + "]";
	}
	
	

}
