package com.anthem.persistence.model.jobdescription;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.common.Default;

@Entity
public class JobResponsibilityItem extends Default{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5969772685776445808L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private JobResponsibilityMaster jobResponsibilityMaster;
	
	@NotBlank(message = "Job Responsibility Should Not Empty")
	@Column(columnDefinition="Text")
	private String jobResponsibility;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@NotNull(message = "JD Category Should not Null")
	private JdCategory jdCategory;

	/**
	 * 
	 */
	public JobResponsibilityItem() {
		super();
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the jobResponsibilityMaster
	 */
	public JobResponsibilityMaster getJobResponsibilityMaster() {
		return jobResponsibilityMaster;
	}

	/**
	 * @param jobResponsibilityMaster the jobResponsibilityMaster to set
	 */
	public void setJobResponsibilityMaster(JobResponsibilityMaster jobResponsibilityMaster) {
		this.jobResponsibilityMaster = jobResponsibilityMaster;
	}

	/**
	 * @return the jobResponsibility
	 */
	public String getJobResponsibility() {
		return jobResponsibility;
	}

	/**
	 * @param jobResponsibility the jobResponsibility to set
	 */
	public void setJobResponsibility(String jobResponsibility) {
		this.jobResponsibility = jobResponsibility;
	}

	/**
	 * @return the jdCategory
	 */
	public JdCategory getJdCategory() {
		return jdCategory;
	}

	/**
	 * @param jdCategory the jdCategory to set
	 */
	public void setJdCategory(JdCategory jdCategory) {
		this.jdCategory = jdCategory;
	}
	
	
}
