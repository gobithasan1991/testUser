package com.anthem.persistence.model.jobdescription;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.jd.JdEmployeeAcceptStatus;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class JdPrepare extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4145010922620855986L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;

	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY)
	private Document jdReference;	
	
	private Long documentRevNo;

	@Column(columnDefinition = "int DEFAULT 1", insertable = false)
	private Integer jdVersionNo;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "jdPrepare")
	private List<JdPrepareJobResponsibility> jdPrepareJobResponsibilities;

	@Temporal(TemporalType.TIMESTAMP)
	private Date employeeAcceptDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approveDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private User approvedBy;

	@ManyToOne(fetch = FetchType.LAZY)
	private User reMappedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date reMappedDate;

	@Lob
	private String employeeReason;

	@Lob
	private String approverReason;
	@Lob
	private String reMapReason;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','APPROVED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ApproveStatus approveStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','ACCEPTED','DECLINED') DEFAULT 'PENDING'", insertable = false)
	private JdEmployeeAcceptStatus jdEmployeeAcceptStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public Document getJdReference() {
		return jdReference;
	}

	public void setJdReference(Document jdReference) {
		this.jdReference = jdReference;
	}

	public Integer getJdVersionNo() {
		return jdVersionNo;
	}

	public void setJdVersionNo(Integer jdVersionNo) {
		this.jdVersionNo = jdVersionNo;
	}

	public List<JdPrepareJobResponsibility> getJdPrepareJobResponsibilities() {
		return jdPrepareJobResponsibilities;
	}

	public void setJdPrepareJobResponsibilities(List<JdPrepareJobResponsibility> jdPrepareJobResponsibilities) {
		this.jdPrepareJobResponsibilities = jdPrepareJobResponsibilities;
	}

	public Date getEmployeeAcceptDate() {
		return employeeAcceptDate;
	}

	public void setEmployeeAcceptDate(Date employeeAcceptDate) {
		this.employeeAcceptDate = employeeAcceptDate;
	}

	public Date getApproveDate() {
		return approveDate;
	}

	public void setApproveDate(Date approveDate) {
		this.approveDate = approveDate;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public JdEmployeeAcceptStatus getJdEmployeeAcceptStatus() {
		return jdEmployeeAcceptStatus;
	}

	public void setJdEmployeeAcceptStatus(JdEmployeeAcceptStatus jdEmployeeAcceptStatus) {
		this.jdEmployeeAcceptStatus = jdEmployeeAcceptStatus;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public String getEmployeeReason() {
		return employeeReason;
	}

	public void setEmployeeReason(String employeeReason) {
		this.employeeReason = employeeReason;
	}

	public String getApproverReason() {
		return approverReason;
	}

	public void setApproverReason(String approverReason) {
		this.approverReason = approverReason;
	}

	public String getReMapReason() {
		return reMapReason;
	}

	public void setReMapReason(String reMapReason) {
		this.reMapReason = reMapReason;
	}

	public User getReMappedBy() {
		return reMappedBy;
	}

	public void setReMappedBy(User reMappedBy) {
		this.reMappedBy = reMappedBy;
	}

	public Date getReMappedDate() {
		return reMappedDate;
	}

	public void setReMappedDate(Date reMappedDate) {
		this.reMappedDate = reMappedDate;
	}

	public Long getDocumentRevNo() {
		return documentRevNo;
	}

	public void setDocumentRevNo(Long documentRevNo) {
		this.documentRevNo = documentRevNo;
	}
	
	
	
	

}
