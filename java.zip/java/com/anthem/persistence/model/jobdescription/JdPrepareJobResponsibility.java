package com.anthem.persistence.model.jobdescription;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class JdPrepareJobResponsibility extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6580291864890497886L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private JobResponsibilityItem jobResponsibilityItem;

	@ManyToOne(fetch = FetchType.LAZY)
	private JdPrepare jdPrepare;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public JobResponsibilityItem getJobResponsibilityItem() {
		return jobResponsibilityItem;
	}

	public void setJobResponsibilityItem(JobResponsibilityItem jobResponsibilityItem) {
		this.jobResponsibilityItem = jobResponsibilityItem;
	}

	public JdPrepare getJdPrepare() {
		return jdPrepare;
	}

	public void setJdPrepare(JdPrepare jdPrepare) {
		this.jdPrepare = jdPrepare;
	}

}
