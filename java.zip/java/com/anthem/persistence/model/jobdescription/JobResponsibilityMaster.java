package com.anthem.persistence.model.jobdescription;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Entity
public class JobResponsibilityMaster extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2094209978226713837L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "Department is Should not Null")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE) 
	private QMSDepartment qmsDepartment;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = JobResponsibilityItem.class)
	@JoinColumn(name = "jobResponsibilityMaster_id")
	private List<JobResponsibilityItem> responsibilityItems;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public List<JobResponsibilityItem> getResponsibilityItems() {
		return responsibilityItems;
	}

	public void setResponsibilityItems(List<JobResponsibilityItem> responsibilityItems) {
		this.responsibilityItems = responsibilityItems;
	}

}
