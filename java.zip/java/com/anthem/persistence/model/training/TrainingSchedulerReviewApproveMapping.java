/**
 * 
 */
package com.anthem.persistence.model.training;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingDocumentStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author ganeshamurthi.r
 *
 */
@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
@JsonIgnoreProperties({ "reason" })
public class TrainingSchedulerReviewApproveMapping extends Default {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@JoinColumn(nullable = false)
	@NotNull(message = "Training Scheduler Should not Null")
	private TrainingScheduler trainingScheduler;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@JoinColumn(nullable = false)
	@NotNull(message = "User Should not Null")
	private User user;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Review/Approve Type Should not Null")
	@Column(columnDefinition = "ENUM('REVIEW','APPROVE') DEFAULT 'REVIEW'")
	private TrainingDocumentStatus reviewApproveType;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','RESCHEDULED','REVIEWED','APPROVED','REJECTED') DEFAULT 'PENDING'")
	private TrainingDocumentStatus reviewApproveStatus;

	private String reviewApproveComment;

	private String prioritylevels;

	public TrainingSchedulerReviewApproveMapping() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingScheduler getTrainingScheduler() {
		return trainingScheduler;
	}

	public void setTrainingScheduler(TrainingScheduler trainingScheduler) {
		this.trainingScheduler = trainingScheduler;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public TrainingDocumentStatus getReviewApproveType() {
		return reviewApproveType;
	}

	public void setReviewApproveType(TrainingDocumentStatus reviewApproveType) {
		this.reviewApproveType = reviewApproveType;
	}

	public TrainingDocumentStatus getReviewApproveStatus() {
		return reviewApproveStatus;
	}

	public void setReviewApproveStatus(TrainingDocumentStatus reviewApproveStatus) {
		this.reviewApproveStatus = reviewApproveStatus;
	}

	public String getReviewApproveComment() {
		return reviewApproveComment;
	}

	public void setReviewApproveComment(String reviewApproveComment) {
		this.reviewApproveComment = reviewApproveComment;
	}

	public String getPrioritylevels() {
		return prioritylevels;
	}

	public void setPrioritylevels(String prioritylevels) {
		this.prioritylevels = prioritylevels;
	}

}
