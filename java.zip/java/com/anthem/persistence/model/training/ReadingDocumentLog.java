package com.anthem.persistence.model.training;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.training.TrainingAttendanceStatus;

@Entity
public class ReadingDocumentLog extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY) 
	@NotNull(message = "Reading Document Master Should not Null") 
	private ReadingDocumentMaster readingDocumentMaster;

	@NotNull(message = "Start Time is Should not Null")
	@Temporal(TemporalType.TIMESTAMP) 
	private Date startTime;

	@NotNull(message = "End Time is Should not Null")
	@Temporal(TemporalType.TIMESTAMP) 
	private Date endTime;
	
	@NotNull(message = "Readed Time is Should not Null")
	@NotEmpty(message = "Readed Time is Required") 
	private String readedTime;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Read Status is Should not Null") 
	@Column(columnDefinition = "ENUM('STARTED','RESUMED') DEFAULT 'STARTED'")
	private TrainingAttendanceStatus startStatus;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Read Status is Should not Null") 
	@Column(columnDefinition = "ENUM('STARTED','RESUMED','PAUSED','STOPPED','COMPLETED') DEFAULT 'STARTED'")
	private TrainingAttendanceStatus endStatus;

	public ReadingDocumentLog() {
		super(); 
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ReadingDocumentMaster getReadingDocumentMaster() {
		return readingDocumentMaster;
	}

	public void setReadingDocumentMaster(ReadingDocumentMaster readingDocumentMaster) {
		this.readingDocumentMaster = readingDocumentMaster;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getReadedTime() {
		return readedTime;
	}

	public void setReadedTime(String readedTime) {
		this.readedTime = readedTime;
	}

	public TrainingAttendanceStatus getStartStatus() {
		return startStatus;
	}

	public void setStartStatus(TrainingAttendanceStatus startStatus) {
		this.startStatus = startStatus;
	}

	public TrainingAttendanceStatus getEndStatus() {
		return endStatus;
	}

	public void setEndStatus(TrainingAttendanceStatus endStatus) {
		this.endStatus = endStatus;
	}

	@Override
	public String toString() {
		return "ReadingDocumentLog [id=" + id + ", readingDocumentMaster=" + readingDocumentMaster + ", startTime="
				+ startTime + ", endTime=" + endTime + ", readedTime=" + readedTime + ", startStatus=" + startStatus
				+ ", endStatus=" + endStatus + "]";
	}
 
}
