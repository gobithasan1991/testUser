package com.anthem.persistence.model.training;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.util.training.TrainingDocumentStatus;
import com.anthem.util.training.TrainingRoomType;

@Entity
public class TrainingRoom extends Default {

	/**
	 * Training Room
	 */
	private static final long serialVersionUID = 3843772072139777447L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional = true)
	private TrainingSession trainingSession;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional = true)
	private TrainingPlannerDocument trainingPlannerDocument;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Document document;

	private String documentVersionNo;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Training Type is Should not Null")
	@Column(columnDefinition = "ENUM('CLASSROOM','SELF') DEFAULT 'SELF'")
	private TrainingRoomType trainingRoomType;

	@NotNull(message = "Start Time is Should not Null")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startTime;

	@NotNull(message = "End Time is Should not Null")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endTime;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Training Status is Should not Null")
	@Column(columnDefinition = "ENUM('PENDING','PARTIALLYCOMPLETED','COMPLETED','MISSED','RESCHEDULED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus trainingStatus;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = TrainingRoomAttendance.class)
	@JoinColumn(name = "trainingRoom_id")
	private List<TrainingRoomAttendance> trainingRoomAttendances;

	public TrainingRoom() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingSession getTrainingSession() {
		return trainingSession;
	}

	public void setTrainingSession(TrainingSession trainingSession) {
		this.trainingSession = trainingSession;
	}

	public TrainingPlannerDocument getTrainingPlannerDocument() {
		return trainingPlannerDocument;
	}

	public void setTrainingPlannerDocument(TrainingPlannerDocument trainingPlannerDocument) {
		this.trainingPlannerDocument = trainingPlannerDocument;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public TrainingRoomType getTrainingRoomType() {
		return trainingRoomType;
	}

	public void setTrainingRoomType(TrainingRoomType trainingRoomType) {
		this.trainingRoomType = trainingRoomType;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public TrainingDocumentStatus getTrainingStatus() {
		return trainingStatus;
	}

	public void setTrainingStatus(TrainingDocumentStatus trainingStatus) {
		this.trainingStatus = trainingStatus;
	}

	public List<TrainingRoomAttendance> getTrainingRoomAttendances() {
		return trainingRoomAttendances;
	}

	public void setTrainingRoomAttendances(List<TrainingRoomAttendance> trainingRoomAttendances) {
		this.trainingRoomAttendances = trainingRoomAttendances;
	}

	@Override
	public String toString() {
		return "TrainingRoom [id=" + id + ", trainingSession=" + trainingSession + ", trainingPlannerDocument="
				+ trainingPlannerDocument + ", document=" + document + ", documentVersionNo=" + documentVersionNo
				+ ", trainingRoomType=" + trainingRoomType + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", trainingStatus=" + trainingStatus + ", trainingRoomAttendances=" + trainingRoomAttendances + "]";
	}
}
