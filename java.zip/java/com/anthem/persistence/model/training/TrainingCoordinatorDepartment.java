package com.anthem.persistence.model.training;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;


@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
@Entity
@Table(uniqueConstraints= @UniqueConstraint(columnNames = {"trainingcoordinator_id","qmsdepartment_id"}) )
public class TrainingCoordinatorDepartment extends Default{

	/**
	 * @author gobithasan.s
	 */
	private static final long serialVersionUID = 5201000256736997065L; 
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;
	 
	@NotNull(message = "Training coordinator should not null")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE) 
	private TrainingCoordinator trainingCoordinator;

	@NotNull(message = "QMS department should not null")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	private QMSDepartment qmsDepartment;

	public TrainingCoordinatorDepartment() {
		super(); 
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingCoordinator getTrainingCoordinator() {
		return trainingCoordinator;
	}

	public void setTrainingCoordinator(TrainingCoordinator trainingCoordinator) {
		this.trainingCoordinator = trainingCoordinator;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	} 
}
