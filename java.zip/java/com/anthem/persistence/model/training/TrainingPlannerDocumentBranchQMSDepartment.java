package com.anthem.persistence.model.training;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
@Entity
@Audited(targetAuditMode=RelationTargetAuditMode.NOT_AUDITED)
public class TrainingPlannerDocumentBranchQMSDepartment extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8767920875801213413L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Training planner document should not empty")
	@ManyToOne(fetch = FetchType.LAZY,optional=false)
	private TrainingPlannerDocument trainingPlannerDocument;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	@NotNull(message = "Branch should not null")
	private Branch branch;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	@NotNull(message = "Department should not null")
	private QMSDepartment qmsDepartment;

	public TrainingPlannerDocumentBranchQMSDepartment() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingPlannerDocument getTrainingPlannerDocument() {
		return trainingPlannerDocument;
	}

	public void setTrainingPlannerDocument(TrainingPlannerDocument trainingPlannerDocument) {
		this.trainingPlannerDocument = trainingPlannerDocument;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	} 
	
	
	
}
