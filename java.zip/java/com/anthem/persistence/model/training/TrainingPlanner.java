package com.anthem.persistence.model.training;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
public class TrainingPlanner extends Default {

	/**
	 * @author gobithasan.s
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id; 
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	@NotNull(message = "Employee is Should not Null")
	private User user;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy="trainingPlanner")
	private List<TrainingPlannerDocument> trainingPlannerDocuments;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy="trainingPlanner")
	private List<TrainingPlannerReviewerApproverMapping> trainingPlannerReviewerApproverMapping;

	public TrainingPlanner() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<TrainingPlannerDocument> getTrainingPlannerDocuments() {
		return trainingPlannerDocuments;
	}

	public void setTrainingPlannerDocuments(List<TrainingPlannerDocument> trainingPlannerDocuments) {
		this.trainingPlannerDocuments = trainingPlannerDocuments;
	}

	public List<TrainingPlannerReviewerApproverMapping> getTrainingPlannerReviewerApproverMapping() {
		return trainingPlannerReviewerApproverMapping;
	}

	public void setTrainingPlannerReviewerApproverMapping(
			List<TrainingPlannerReviewerApproverMapping> trainingPlannerReviewerApproverMapping) {
		this.trainingPlannerReviewerApproverMapping = trainingPlannerReviewerApproverMapping;
	} 
	
}
