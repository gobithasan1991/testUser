package com.anthem.persistence.model.training;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Entity
public class TrainerDepartment extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment qmsDepartment;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private TrainerMaster trainerMaster;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public TrainerMaster getTrainerMaster() {
		return trainerMaster;
	}

	public void setTrainerMaster(TrainerMaster trainerMaster) {
		this.trainerMaster = trainerMaster;
	}
	
	
	

}
