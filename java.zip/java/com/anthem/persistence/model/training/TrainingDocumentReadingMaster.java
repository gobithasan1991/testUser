package com.anthem.persistence.model.training;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.DocumentVideo;
import com.anthem.util.training.TrainingAttendanceStatus;

@Entity
public class TrainingDocumentReadingMaster extends Default {

	/**
	 * @author gobithasan.s
	 */
	private static final long serialVersionUID = 6284930943069360473L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false) 
	@NotNull(message = "Training Room Attendance is Should not Null") 
	private TrainingRoom trainingRoom;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional = true) 
	private TrainingSession trainingSession;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional = true) 
	private TrainingPlannerDocument trainingPlannerDocument;

	@NotNull(message = "Start Date is Should not Null")
	@Temporal(TemporalType.TIMESTAMP) 
	private Date startDate;

	@NotNull(message = "End Date is Should not Null")
	@Temporal(TemporalType.TIMESTAMP) 
	private Date endDate;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Type Of Document is Should not Null") 
	@Column(columnDefinition = "ENUM('DOCUMENT','VIDEO') DEFAULT 'DOCUMENT'")
	private TrainingAttendanceStatus typeOfDocument;

	@NotNull(message = "Readed Time is Should not Null")
	@NotEmpty(message = "Readed Time is Required") 
	private String readedTime;
	
	@NotNull(message = "Minimum Read is Should not Null")
	@NotEmpty(message = "Minimum Read is Required") 
	private String minReadTime;
	
	@NotNull(message = "Maximum Readed is Should not Null")
	@NotEmpty(message = "Maximum Readed is Required") 
	private String maxReaded;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Read Status is Should not Null") 
	@Column(columnDefinition = "ENUM('STARTED','PAUSED','STOPPED','COMPLETED') DEFAULT 'STARTED'")
	private TrainingAttendanceStatus readStatus;

	@ManyToOne(fetch = FetchType.LAZY, optional = true) 
	private DocumentVideo documentVideo;

	public TrainingDocumentReadingMaster() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingRoom getTrainingRoom() {
		return trainingRoom;
	}

	public void setTrainingRoom(TrainingRoom trainingRoom) {
		this.trainingRoom = trainingRoom;
	}

	public TrainingSession getTrainingSession() {
		return trainingSession;
	}

	public void setTrainingSession(TrainingSession trainingSession) {
		this.trainingSession = trainingSession;
	}

	public TrainingPlannerDocument getTrainingPlannerDocument() {
		return trainingPlannerDocument;
	}

	public void setTrainingPlannerDocument(TrainingPlannerDocument trainingPlannerDocument) {
		this.trainingPlannerDocument = trainingPlannerDocument;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public TrainingAttendanceStatus getTypeOfDocument() {
		return typeOfDocument;
	}

	public void setTypeOfDocument(TrainingAttendanceStatus typeOfDocument) {
		this.typeOfDocument = typeOfDocument;
	}

	public String getReadedTime() {
		return readedTime;
	}

	public void setReadedTime(String readedTime) {
		this.readedTime = readedTime;
	}

	public String getMinReadTime() {
		return minReadTime;
	}

	public void setMinReadTime(String minReadTime) {
		this.minReadTime = minReadTime;
	}

	public String getMaxReaded() {
		return maxReaded;
	}

	public void setMaxReaded(String maxReaded) {
		this.maxReaded = maxReaded;
	}

	public TrainingAttendanceStatus getReadStatus() {
		return readStatus;
	}

	public void setReadStatus(TrainingAttendanceStatus readStatus) {
		this.readStatus = readStatus;
	}

	public DocumentVideo getDocumentVideo() {
		return documentVideo;
	}

	public void setDocumentVideo(DocumentVideo documentVideo) {
		this.documentVideo = documentVideo;
	}

}
