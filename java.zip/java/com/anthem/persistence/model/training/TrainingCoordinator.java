package com.anthem.persistence.model.training;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingCoordinatorType;
import com.anthem.web.util.revisions.UpdateRev;

@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
@Entity
@Table(uniqueConstraints= @UniqueConstraint(columnNames = {"user_id","branch_id"}) )
public class TrainingCoordinator extends Default {

	/**
	 * @author gobithasan.s 
	 */ 
	private static final long serialVersionUID = -4913945981693753093L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@NotNull(message = "Training coordinator type should not null")
	@Column(columnDefinition = "ENUM('SPECIFIC','ALL') DEFAULT 'SPECIFIC'")
	private TrainingCoordinatorType trainingCoordinatorType;
	
	@NotNull(message = "Branch should not null")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	private Branch branch; 
	
	@NotNull(message = "Employee is Should not Null")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)	
	private User user; 
	
	@UpdateRev
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL,mappedBy="trainingCoordinator") 
	private List<TrainingCoordinatorDepartment> trainingCoordinatorDepartments;

	public TrainingCoordinator() {
		super(); 
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingCoordinatorType getTrainingCoordinatorType() {
		return trainingCoordinatorType;
	}

	public void setTrainingCoordinatorType(TrainingCoordinatorType trainingCoordinatorType) {
		this.trainingCoordinatorType = trainingCoordinatorType;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<TrainingCoordinatorDepartment> getTrainingCoordinatorDepartments() {
		return trainingCoordinatorDepartments;
	}

	public void setTrainingCoordinatorDepartments(List<TrainingCoordinatorDepartment> trainingCoordinatorDepartments) {
		this.trainingCoordinatorDepartments = trainingCoordinatorDepartments;
	} 
	
}
