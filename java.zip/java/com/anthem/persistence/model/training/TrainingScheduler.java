/**
 * 
 */
package com.anthem.persistence.model.training;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.document.DocumentMapping;
import com.anthem.util.training.TrainingDocumentStatus;

/**
 * @author ganeshamurthi.r
 *
 */
@Entity

public class TrainingScheduler extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "Training Title Should not Null")
	private String trainingTitle;

	@NotNull(message = "Start Date is Should not Null")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@NotNull(message = "Start Date is Should not Null")
	@Temporal(TemporalType.DATE)
	private Date endDate;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Nomination Type is Should not Null")
	@Column(columnDefinition = "ENUM('SELF','NOMINATION') DEFAULT 'SELF'")
	private TrainingDocumentStatus nominationType;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Session Type is Should not Null")
	@Column(columnDefinition = "ENUM('SINGLE','MULTIPLE') DEFAULT 'SINGLE'")
	private TrainingDocumentStatus sessionType;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','MAPPED','REVIEWED','REJECTED','PARTIALLYREVIEWED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus reviewStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','COMPLETED','PARTIALLYCOMPLETED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus trainingStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','MAPPED','APPROVED','REJECTED','PARTIALLYAPPROVED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus approveStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "Branch is Should not Null")
	private Branch branch;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "Document is Should not Null")
	private Document document;
	
	private Long documentRevNo;

	private String documentVersionNo;

	@OneToMany(cascade = { CascadeType.ALL }, targetEntity = TrainingSchedulerDepartment.class)
	@JoinColumn(name = "trainingScheduler_id")
	private List<TrainingSchedulerDepartment> trainingSchedulerDepartments;

	@OneToMany(cascade = { CascadeType.ALL }, targetEntity = TrainingSession.class)
	@JoinColumn(name = "trainingScheduler_id")
	@NotNull(message = "Training Session is Should not Null")
	private List<TrainingSession> trainingSessions;

	@ManyToOne(fetch = FetchType.LAZY)
	private DocumentMapping documentMapping;

	public TrainingScheduler() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTrainingTitle() {
		return trainingTitle;
	}

	public void setTrainingTitle(String trainingTitle) {
		this.trainingTitle = trainingTitle;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public TrainingDocumentStatus getNominationType() {
		return nominationType;
	}

	public void setNominationType(TrainingDocumentStatus nominationType) {
		this.nominationType = nominationType;
	}

	public TrainingDocumentStatus getSessionType() {
		return sessionType;
	}

	public void setSessionType(TrainingDocumentStatus sessionType) {
		this.sessionType = sessionType;
	}

	public TrainingDocumentStatus getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(TrainingDocumentStatus reviewStatus) {
		this.reviewStatus = reviewStatus;
	}

	public TrainingDocumentStatus getTrainingStatus() {
		return trainingStatus;
	}

	public void setTrainingStatus(TrainingDocumentStatus trainingStatus) {
		this.trainingStatus = trainingStatus;
	}

	public TrainingDocumentStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(TrainingDocumentStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public List<TrainingSchedulerDepartment> getTrainingSchedulerDepartments() {
		return trainingSchedulerDepartments;
	}

	public void setTrainingSchedulerDepartments(List<TrainingSchedulerDepartment> trainingSchedulerDepartments) {
		this.trainingSchedulerDepartments = trainingSchedulerDepartments;
	}

	public List<TrainingSession> getTrainingSessions() {
		return trainingSessions;
	}

	public void setTrainingSessions(List<TrainingSession> trainingSessions) {
		this.trainingSessions = trainingSessions;
	}

	public DocumentMapping getDocumentMapping() {
		return documentMapping;
	}

	public void setDocumentMapping(DocumentMapping documentMapping) {
		this.documentMapping = documentMapping;
	}

	public Long getDocumentRevNo() {
		return documentRevNo;
	}

	public void setDocumentRevNo(Long documentRevNo) {
		this.documentRevNo = documentRevNo;
	}
	
	

}
