package com.anthem.persistence.model.training;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.DocumentVideo;
import com.anthem.util.training.TrainingAttendanceStatus;
@Entity
@Table(uniqueConstraints={
	    @UniqueConstraint(columnNames = {"trainingPlannerDocument_id", "documentVideo_id"})
	}) 
public class ReadingDocumentMaster extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id; 

	@NotNull(message = "Training Document Should not Null")
	@ManyToOne(fetch = FetchType.LAZY) 
	private TrainingPlannerDocument trainingPlannerDocument;
	
	private Long trainingPlannerDocumentRev;
	
	private String documentVersionNo;

	@NotNull(message = "Start Date is Should not Null")
	@Temporal(TemporalType.TIMESTAMP) 
	private Date startDate;

	@NotNull(message = "End Date is Should not Null")
	@Temporal(TemporalType.TIMESTAMP) 
	private Date endDate;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Type Of Document is Should not Null") 
	@Column(columnDefinition = "ENUM('DOCUMENT','VIDEO') DEFAULT 'DOCUMENT'")
	private TrainingAttendanceStatus typeOfDocument;

	@NotNull(message = "Readed Time is Should not Null")
	@NotEmpty(message = "Readed Time is Required") 
	private String readedTime; 

	@NotNull(message = "Maximum Readed Hour is Should not Null")
	@NotEmpty(message = "Maximum Readed Hour is Required") 
	private String maxReadedHour;
	
	@NotNull(message = "Maximum Readed Minute And Second is Should not Null")
	@NotEmpty(message = "Maximum Readed is Required") 
	private String maxReadedMinSec;
	
	@NotNull(message = "Maximum Readed is Should not Null")
	@NotEmpty(message = "Maximum Readed is Required") 
	private String maxReaded;
	
	private String totalNeedToRead;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Read Status is Should not Null") 
	@Column(columnDefinition = "ENUM('STARTED','PAUSED','STOPPED','COMPLETED') DEFAULT 'STARTED'")
	private TrainingAttendanceStatus readStatus;

	@ManyToOne(fetch = FetchType.LAZY, optional = true) 
	private DocumentVideo documentVideo;

	public ReadingDocumentMaster() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingPlannerDocument getTrainingPlannerDocument() {
		return trainingPlannerDocument;
	}

	public void setTrainingPlannerDocument(TrainingPlannerDocument trainingPlannerDocument) {
		this.trainingPlannerDocument = trainingPlannerDocument;
	}

	public Long getTrainingPlannerDocumentRev() {
		return trainingPlannerDocumentRev;
	}

	public void setTrainingPlannerDocumentRev(Long trainingPlannerDocumentRev) {
		this.trainingPlannerDocumentRev = trainingPlannerDocumentRev;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public TrainingAttendanceStatus getTypeOfDocument() {
		return typeOfDocument;
	}

	public void setTypeOfDocument(TrainingAttendanceStatus typeOfDocument) {
		this.typeOfDocument = typeOfDocument;
	}

	public String getReadedTime() {
		return readedTime;
	}

	public void setReadedTime(String readedTime) {
		this.readedTime = readedTime;
	}

	public String getMaxReadedHour() {
		return maxReadedHour;
	}

	public void setMaxReadedHour(String maxReadedHour) {
		this.maxReadedHour = maxReadedHour;
	}

	public String getMaxReadedMinSec() {
		return maxReadedMinSec;
	}

	public void setMaxReadedMinSec(String maxReadedMinSec) {
		this.maxReadedMinSec = maxReadedMinSec;
	}

	public String getMaxReaded() {
		return maxReaded;
	}

	public void setMaxReaded(String maxReaded) {
		this.maxReaded = maxReaded;
	}

	public String getTotalNeedToRead() {
		return totalNeedToRead;
	}

	public void setTotalNeedToRead(String totalNeedToRead) {
		this.totalNeedToRead = totalNeedToRead;
	}

	public TrainingAttendanceStatus getReadStatus() {
		return readStatus;
	}

	public void setReadStatus(TrainingAttendanceStatus readStatus) {
		this.readStatus = readStatus;
	}

	public DocumentVideo getDocumentVideo() {
		return documentVideo;
	}

	public void setDocumentVideo(DocumentVideo documentVideo) {
		this.documentVideo = documentVideo;
	}

 
}
