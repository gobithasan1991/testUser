package com.anthem.persistence.model.training;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainerType;

@Entity
public class TrainerMaster extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Trainer Type is Required")
	@Column(columnDefinition = "ENUM('INTERNAL','EXTERNAL')DEFAULT 'INTERNAL'")
	private TrainerType trainerType;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "Employee is Should not Null")
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "Branch is Should not Null")
	private Branch branch;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = TrainerDepartment.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "trainerMaster_id")
	private List<TrainerDepartment> trainerDepartments;

	public TrainerMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public TrainerType getTrainerType() {
		return trainerType;
	}

	public void setTrainerType(TrainerType trainerType) {
		this.trainerType = trainerType;
	}

	public List<TrainerDepartment> getTrainerDepartments() {
		return trainerDepartments;
	}

	public void setTrainerDepartments(List<TrainerDepartment> trainerDepartments) {
		this.trainerDepartments = trainerDepartments;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

}
