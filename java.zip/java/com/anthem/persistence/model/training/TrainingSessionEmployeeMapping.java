/**
 * 
 */
package com.anthem.persistence.model.training;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingDocumentStatus;

/**
 * @author ganeshamurthi.r
 *
 */
@Entity
public class TrainingSessionEmployeeMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "Trining Scheduler is Should not Null")
	private TrainingScheduler trainingScheduler;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "Trining Session is Should not Null")
	private TrainingSession trainingSession;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@NotNull(message = "User is Should not Null")
	private User user;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','MISSED','COMPLETED','PARTIALLYCOMPLETED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus trainingStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private TrainingPlannerDocument trainingPlannerDocument;

	public TrainingSessionEmployeeMapping() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingScheduler getTrainingScheduler() {
		return trainingScheduler;
	}

	public void setTrainingScheduler(TrainingScheduler trainingScheduler) {
		this.trainingScheduler = trainingScheduler;
	}

	public TrainingSession getTrainingSession() {
		return trainingSession;
	}

	public void setTrainingSession(TrainingSession trainingSession) {
		this.trainingSession = trainingSession;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public TrainingDocumentStatus getTrainingStatus() {
		return trainingStatus;
	}

	public void setTrainingStatus(TrainingDocumentStatus trainingStatus) {
		this.trainingStatus = trainingStatus;
	}

	public TrainingPlannerDocument getTrainingPlannerDocument() {
		return trainingPlannerDocument;
	}

	public void setTrainingPlannerDocument(TrainingPlannerDocument trainingPlannerDocument) {
		this.trainingPlannerDocument = trainingPlannerDocument;
	}

	@Override
	public String toString() {
		return "TrainingSessionEmployeeMapping [id=" + id + ", trainingScheduler=" + trainingScheduler
				+ ", trainingSession=" + trainingSession + ", user=" + user + ", trainingStatus=" + trainingStatus
				+ ", trainingPlannerDocument=" + trainingPlannerDocument + "]";
	}
	
	

}
