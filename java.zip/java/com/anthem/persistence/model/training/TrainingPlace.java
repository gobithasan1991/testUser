package com.anthem.persistence.model.training;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "name", "branch_id" }))
public class TrainingPlace extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5359456149942885737L;

	/**
	 * @author gobithasan.s
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "Training Place is Should not Null")
	@NotEmpty(message = "Training Place is Required")
	@Size(min = 3, message = "Invalid Training Place")
	private String name;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	private Branch branch;

	public TrainingPlace() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

}
