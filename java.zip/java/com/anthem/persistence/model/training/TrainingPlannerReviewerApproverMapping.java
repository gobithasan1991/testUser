package com.anthem.persistence.model.training;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingDocumentStatus;

@Entity
public class TrainingPlannerReviewerApproverMapping extends Default {
	/**
	 * @author gobithasan.s
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;
	
	@NotNull(message = "Training planner is should not empty")
	@ManyToOne(fetch = FetchType.LAZY,optional=false) 
	private TrainingPlanner trainingPlanner;
	
	@NotNull(message = "Training Planner Version Should not Null") 
	private Long versionOfPlanner;

	@NotNull(message = "User Training Planner Version Should not Null") 
	private Long versionOfUserPlanner; 

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	@NotNull(message = "Department should not null")
	private QMSDepartment qmsDepartment;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false) 
	@NotNull(message = "User Should not Null") 
	private User user;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Review/Approve Type Should not Null") 
	@Column(columnDefinition = "ENUM('REVIEW','APPROVE') DEFAULT 'REVIEW'")
	private TrainingDocumentStatus reviewApproveType;

	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('PENDING','RESCHEDULED','REVIEWED','APPROVED','REJECTED') DEFAULT 'PENDING'")
	private TrainingDocumentStatus reviewApproveStatus;

	private int prioritylevels;
	
	@Temporal(TemporalType.TIMESTAMP) 
	private Date reviewApproveDate;
	
	@Lob
	private String reviewApproveRemark;
	
	public TrainingPlannerReviewerApproverMapping() {
		super(); 
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainingPlanner getTrainingPlanner() {
		return trainingPlanner;
	}

	public void setTrainingPlanner(TrainingPlanner trainingPlanner) {
		this.trainingPlanner = trainingPlanner;
	}

	public Long getVersionOfPlanner() {
		return versionOfPlanner;
	}

	public void setVersionOfPlanner(Long versionOfPlanner) {
		this.versionOfPlanner = versionOfPlanner;
	}

	public Long getVersionOfUserPlanner() {
		return versionOfUserPlanner;
	}

	public void setVersionOfUserPlanner(Long versionOfUserPlanner) {
		this.versionOfUserPlanner = versionOfUserPlanner;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public TrainingDocumentStatus getReviewApproveType() {
		return reviewApproveType;
	}

	public void setReviewApproveType(TrainingDocumentStatus reviewApproveType) {
		this.reviewApproveType = reviewApproveType;
	}

	public TrainingDocumentStatus getReviewApproveStatus() {
		return reviewApproveStatus;
	}

	public void setReviewApproveStatus(TrainingDocumentStatus reviewApproveStatus) {
		this.reviewApproveStatus = reviewApproveStatus;
	}

	public int getPrioritylevels() {
		return prioritylevels;
	}

	public void setPrioritylevels(int prioritylevels) {
		this.prioritylevels = prioritylevels;
	}

	public Date getReviewApproveDate() {
		return reviewApproveDate;
	}

	public void setReviewApproveDate(Date reviewApproveDate) {
		this.reviewApproveDate = reviewApproveDate;
	}

	public String getReviewApproveRemark() {
		return reviewApproveRemark;
	}

	public void setReviewApproveRemark(String reviewApproveRemark) {
		this.reviewApproveRemark = reviewApproveRemark;
	} 
	
}
