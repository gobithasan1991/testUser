/**
 * 
 */
package com.anthem.persistence.model.training;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingAttendanceStatus;

/**
 * @author mahalingam.s
 *
 */
@Entity
public class TrainingRoomAttendance extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8167844726172305885L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)  
	private Long id;

	@ManyToOne(fetch = FetchType.EAGER)
	@NotNull(message = "User is Should not Null") 
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	@NotNull(message = "Training Room is Should not Null") 
	private TrainingRoom trainingRoom;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Attendance Status is Should not Null") 
	@Column(columnDefinition = "ENUM('ABSENT','PRESENT','SELF','TRAINER') DEFAULT 'ABSENT'") 
	private TrainingAttendanceStatus attendanceStatus;

	public TrainingRoomAttendance() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public TrainingRoom getTrainingRoom() {
		return trainingRoom;
	}

	public void setTrainingRoom(TrainingRoom trainingRoom) {
		this.trainingRoom = trainingRoom;
	}

	public TrainingAttendanceStatus getAttendanceStatus() {
		return attendanceStatus;
	}

	public void setAttendanceStatus(TrainingAttendanceStatus attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}

	@Override
	public String toString() {
		return "TrainingRoomAttendance [id=" + id + ", user=" + user + ", trainingRoom=" + trainingRoom
				+ ", attendanceStatus=" + attendanceStatus + "]";
	}

}
