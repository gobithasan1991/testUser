/**
 * 
 */
package com.anthem.persistence.model.training;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainerType;
import com.anthem.util.training.TrainingDocumentStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author ganeshamurthi.r
 *
 */
@Entity
@JsonIgnoreProperties({ "availableSeats" })
public class TrainingSession extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Session Name is Required")
	private String sessionName;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private TrainingScheduler trainingScheduler;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Trainer Type is Required")
	@Column(columnDefinition = "ENUM('INTERNAL','EXTERNAL')DEFAULT 'INTERNAL'")
	private TrainerType trainerType;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@JoinColumn(nullable = false)
	@NotNull(message = "Trainer is Should not Null")
	private User trainer;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@NotNull(message = "Training Place is Should not Null")
	@JoinColumn(nullable = false)
	private TrainingPlace trainingPlace;

	@NotNull(message = "Start Time is Should not Null")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startTime;

	@NotNull(message = "End Time is Should not Null")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endTime;

	@NotNull(message = "Max Capacity is Should not Empty")
	private long maxCapacity;

	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment trainerDepartment;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','COMPLETED','PARTIALLYCOMPLETED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus trainingStatus;

	@OneToMany(cascade = { CascadeType.ALL }, targetEntity = TrainingSessionAlternateTrainer.class)
	@JoinColumn(name = "trainingSession_id")
	private List<TrainingSessionAlternateTrainer> trainingSessionAlternateTrainers;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User trainingRoomTrainer;

	public TrainingSession() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public TrainingScheduler getTrainingScheduler() {
		return trainingScheduler;
	}

	public void setTrainingScheduler(TrainingScheduler trainingScheduler) {
		this.trainingScheduler = trainingScheduler;
	}

	public TrainerType getTrainerType() {
		return trainerType;
	}

	public void setTrainerType(TrainerType trainerType) {
		this.trainerType = trainerType;
	}

	public User getTrainer() {
		return trainer;
	}

	public void setTrainer(User trainer) {
		this.trainer = trainer;
	}

	public TrainingPlace getTrainingPlace() {
		return trainingPlace;
	}

	public void setTrainingPlace(TrainingPlace trainingPlace) {
		this.trainingPlace = trainingPlace;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public long getMaxCapacity() {
		return maxCapacity;
	}

	public void setMaxCapacity(long maxCapacity) {
		this.maxCapacity = maxCapacity;
	}

	public QMSDepartment getTrainerDepartment() {
		return trainerDepartment;
	}

	public void setTrainerDepartment(QMSDepartment trainerDepartment) {
		this.trainerDepartment = trainerDepartment;
	}

	public TrainingDocumentStatus getTrainingStatus() {
		return trainingStatus;
	}

	public void setTrainingStatus(TrainingDocumentStatus trainingStatus) {
		this.trainingStatus = trainingStatus;
	}

	public List<TrainingSessionAlternateTrainer> getTrainingSessionAlternateTrainers() {
		return trainingSessionAlternateTrainers;
	}

	public void setTrainingSessionAlternateTrainers(
			List<TrainingSessionAlternateTrainer> trainingSessionAlternateTrainers) {
		this.trainingSessionAlternateTrainers = trainingSessionAlternateTrainers;
	}

	public User getTrainingRoomTrainer() {
		return trainingRoomTrainer;
	}

	public void setTrainingRoomTrainer(User trainingRoomTrainer) {
		this.trainingRoomTrainer = trainingRoomTrainer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrainingSession other = (TrainingSession) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TrainingSession [id=" + id + ", sessionName=" + sessionName + ", trainingScheduler=" + trainingScheduler
				+ ", trainerType=" + trainerType + ", trainer=" + trainer + ", trainingPlace=" + trainingPlace
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", maxCapacity=" + maxCapacity
				+ ", trainerDepartment=" + trainerDepartment + ", trainingStatus=" + trainingStatus + "]";
	}

}
