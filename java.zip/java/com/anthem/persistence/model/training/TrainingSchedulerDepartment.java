package com.anthem.persistence.model.training;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

/**
 * @author ganeshamurthi.r
 *
 */
@Entity
public class TrainingSchedulerDepartment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private TrainingScheduler trainingScheduler;

	private Boolean mandatory;

	public TrainingSchedulerDepartment() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public TrainingScheduler getTrainingScheduler() {
		return trainingScheduler;
	}

	public void setTrainingScheduler(TrainingScheduler trainingScheduler) {
		this.trainingScheduler = trainingScheduler;
	}

	public Boolean getMandatory() {
		return mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	@Override
	public String toString() {
		return "TrainingSchedulerDepartments [id=" + id + ", qmsDepartment=" + qmsDepartment + ", trainingScheduler="
				+ trainingScheduler + ", mandatory=" + mandatory + "]";
	}

}
