package com.anthem.persistence.model.training;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.document.DocumentMapping;
import com.anthem.util.training.TrainingDocumentStatus;
import com.anthem.util.training.TrainingRoomType;

@Entity
@Audited(targetAuditMode=RelationTargetAuditMode.NOT_AUDITED)
public class TrainingPlannerDocument extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	@NotNull(message = "Document Mapping is Should not Null")
	private DocumentMapping documentMapping;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	@NotNull(message = "Document is Should not Null")
	private Document document;
	
	@NotNull(message = "Document Version is Should not Null")
	private String documentVersionNo;
	
	@NotNull(message = "Document Revision is Should not Null")
	private Long documentRevNo;

	@NotNull(message = "StartDate is Should not Null")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@NotNull(message = "DueDate is Should not Null")
	@Temporal(TemporalType.DATE)
	private Date dueDate;

	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('CLASSROOM','SELF','ALL') DEFAULT 'ALL'",nullable=false)
	private TrainingRoomType trainingRoomType;

	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('PENDING','PARTIALLYCOMPLETED','COMPLETED','MISSED') DEFAULT 'PENDING'", nullable = false)
	private TrainingDocumentStatus trainingReadingStatus;

	@Temporal(TemporalType.DATE)
	private Date trainingReadingCompletionDate;
	
	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('PENDING','NOTAVAILABLE','AVAILABLE','PARTIALLYCOMPLETED','COMPLETED','MISSED','FAILED') DEFAULT 'PENDING'", nullable = false)
	private TrainingDocumentStatus trainingEvaluationStatus;

	@Temporal(TemporalType.DATE)
	private Date trainingEvaluationCompletionDate;
	
	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('PENDING','PARTIALLYCOMPLETED','COMPLETED','MISSED','RETRAINING') DEFAULT 'PENDING'", nullable = false)
	private TrainingDocumentStatus trainingDocumentStatus;

	@Temporal(TemporalType.DATE)
	private Date trainingDocumentCompletionDate;
	
	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('PENDING','RESCHEDULED','PARTIALLYREVIEWED','REVIEWED','REJECTED') DEFAULT 'PENDING'",nullable=false)
	private TrainingDocumentStatus reviewStatus; 

	@Enumerated(EnumType.STRING) 
	@Column(columnDefinition = "ENUM('PENDING','RESCHEDULED','PARTIALLYAPPROVED','APPROVED','REJECTED') DEFAULT 'PENDING'",nullable=false)
	private TrainingDocumentStatus approvedStatus; 
	
	@NotNull(message = "Training planner is should not empty")
	@ManyToOne(fetch = FetchType.LAZY,optional=false)  
	private TrainingPlanner trainingPlanner;
	
	@NotNull(message = "version Of Planner Should not Null") 
	private Long versionOfPlanner = 1L; 

	@NotNull(message = "User Training Planner Version Should not Null") 
	private Long versionOfUserPlanner;
	
	@NotEmpty(message="Training planner branch and department should not be empty")
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL,mappedBy="trainingPlannerDocument")
	@AuditJoinTable(name="tpd_branch_qmsdepartment_audit_log")
	private List<TrainingPlannerDocumentBranchQMSDepartment> trainingPlannerDocumentBranchQMSDepartments; 
	
	public TrainingPlannerDocument() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public DocumentMapping getDocumentMapping() {
		return documentMapping;
	}

	public void setDocumentMapping(DocumentMapping documentMapping) {
		this.documentMapping = documentMapping;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public Long getDocumentRevNo() {
		return documentRevNo;
	}

	public void setDocumentRevNo(Long documentRevNo) {
		this.documentRevNo = documentRevNo;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public TrainingRoomType getTrainingRoomType() {
		return trainingRoomType;
	}

	public void setTrainingRoomType(TrainingRoomType trainingRoomType) {
		this.trainingRoomType = trainingRoomType;
	}

	public TrainingDocumentStatus getTrainingReadingStatus() {
		return trainingReadingStatus;
	}

	public void setTrainingReadingStatus(TrainingDocumentStatus trainingReadingStatus) {
		this.trainingReadingStatus = trainingReadingStatus;
	}

	public Date getTrainingReadingCompletionDate() {
		return trainingReadingCompletionDate;
	}

	public void setTrainingReadingCompletionDate(Date trainingReadingCompletionDate) {
		this.trainingReadingCompletionDate = trainingReadingCompletionDate;
	}

	public TrainingDocumentStatus getTrainingEvaluationStatus() {
		return trainingEvaluationStatus;
	}

	public void setTrainingEvaluationStatus(TrainingDocumentStatus trainingEvaluationStatus) {
		this.trainingEvaluationStatus = trainingEvaluationStatus;
	}

	public Date getTrainingEvaluationCompletionDate() {
		return trainingEvaluationCompletionDate;
	}

	public void setTrainingEvaluationCompletionDate(Date trainingEvaluationCompletionDate) {
		this.trainingEvaluationCompletionDate = trainingEvaluationCompletionDate;
	}

	public TrainingDocumentStatus getTrainingDocumentStatus() {
		return trainingDocumentStatus;
	}

	public void setTrainingDocumentStatus(TrainingDocumentStatus trainingDocumentStatus) {
		this.trainingDocumentStatus = trainingDocumentStatus;
	}

	public Date getTrainingDocumentCompletionDate() {
		return trainingDocumentCompletionDate;
	}

	public void setTrainingDocumentCompletionDate(Date trainingDocumentCompletionDate) {
		this.trainingDocumentCompletionDate = trainingDocumentCompletionDate;
	}

	public TrainingDocumentStatus getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(TrainingDocumentStatus reviewStatus) {
		this.reviewStatus = reviewStatus;
	} 

	public TrainingDocumentStatus getApprovedStatus() {
		return approvedStatus;
	}

	public void setApprovedStatus(TrainingDocumentStatus approvedStatus) {
		this.approvedStatus = approvedStatus;
	}

	public TrainingPlanner getTrainingPlanner() {
		return trainingPlanner;
	}

	public void setTrainingPlanner(TrainingPlanner trainingPlanner) {
		this.trainingPlanner = trainingPlanner;
	}

	public Long getVersionOfPlanner() {
		return versionOfPlanner;
	}

	public void setVersionOfPlanner(Long versionOfPlanner) {
		this.versionOfPlanner = versionOfPlanner;
	}

	public Long getVersionOfUserPlanner() {
		return versionOfUserPlanner;
	}

	public void setVersionOfUserPlanner(Long versionOfUserPlanner) {
		this.versionOfUserPlanner = versionOfUserPlanner;
	}

	public List<TrainingPlannerDocumentBranchQMSDepartment> getTrainingPlannerDocumentBranchQMSDepartments() {
		return trainingPlannerDocumentBranchQMSDepartments;
	}

	public void setTrainingPlannerDocumentBranchQMSDepartments(
			List<TrainingPlannerDocumentBranchQMSDepartment> trainingPlannerDocumentBranchQMSDepartments) {
		this.trainingPlannerDocumentBranchQMSDepartments = trainingPlannerDocumentBranchQMSDepartments;
	}

}
