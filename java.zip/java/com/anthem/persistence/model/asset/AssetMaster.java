package com.anthem.persistence.model.asset;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.calibrationpm.AssetType;

@Entity
public class AssetMaster extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3473649376963989926L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('EQUIPMENT', 'INSTRUMENT')")
	private AssetType assetType;
	
	@NotEmpty(message = "Asset Name is mandatory")
	private String name;
	
	@NotEmpty(message = "Asset Code is mandatory")
	private String code;
	
	public AssetMaster() {
		super();
	}

	public AssetMaster(AssetType assetType, String name, String code) {
		super();
		this.assetType = assetType;
		this.name = name;
		this.code = code;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public AssetType getAssetType() {
		return assetType;
	}

	public void setAssetType(AssetType assetType) {
		this.assetType = assetType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	
	
}
