package com.anthem.persistence.model.login;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.login.AccessType;

@Entity
public class LoginAndAccessItem extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5814962535073697391L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('LOGIN_ACCESS', 'BIONET_ACCESS', 'ACCESS_CARD')")
	private AccessType accessType;
	
	private String refrenceNo;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User generatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date generatedDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private LoginAndAccess loginAndAccess;

	public Long getId() {
		return id;
	}

	public AccessType getAccessType() {
		return accessType;
	}

	public String getRefrenceNo() {
		return refrenceNo;
	}

	public User getGeneratedBy() {
		return generatedBy;
	}

	public Date getGeneratedDate() {
		return generatedDate;
	}

	public LoginAndAccess getLoginAndAccess() {
		return loginAndAccess;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAccessType(AccessType accessType) {
		this.accessType = accessType;
	}

	public void setRefrenceNo(String refrenceNo) {
		this.refrenceNo = refrenceNo;
	}

	public void setGeneratedBy(User generatedBy) {
		this.generatedBy = generatedBy;
	}

	public void setGeneratedDate(Date generatedDate) {
		this.generatedDate = generatedDate;
	}

	public void setLoginAndAccess(LoginAndAccess loginAndAccess) {
		this.loginAndAccess = loginAndAccess;
	}	
	
}
