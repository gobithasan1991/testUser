package com.anthem.persistence.model.login;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.hr.BloodGroup;
import com.anthem.persistence.model.hr.OfferLetter;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.util.login.AccessStatus;

@Entity
public class LoginRequest extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8116699717265405265L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String firstName;

	private String lastName;
	
	private String employeeCode;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Department department;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date dob;
	
	private String designation;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date joinDate;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private BloodGroup bloodGroup;
	
	private String emergencyContactNo;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING'", insertable=false)
	private ApproveStatus approveStatus;	
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'CREATED') DEFAULT 'PENDING'", insertable=false)
	private AccessStatus accessStatus;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User approvedBy;
	
	private Date approvedDate;
	
	private String reason;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO')")
	private YesOrNoStatus emailIdRequired;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO')")
	private YesOrNoStatus intranetRequired;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO')")
	private YesOrNoStatus accessCardRequired;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Branch branch;
	
	@OneToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private OfferLetter offerLetter;
	
	public Long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public Department getDepartment() {
		return department;
	}

	public Date getDob() {
		return dob;
	}

	public String getDesignation() {
		return designation;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public BloodGroup getBloodGroup() {
		return bloodGroup;
	}

	public String getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public String getReason() {
		return reason;
	}

	public YesOrNoStatus getEmailIdRequired() {
		return emailIdRequired;
	}

	public YesOrNoStatus getIntranetRequired() {
		return intranetRequired;
	}

	public YesOrNoStatus getAccessCardRequired() {
		return accessCardRequired;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public void setBloodGroup(BloodGroup bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public void setEmergencyContactNo(String emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public void setEmailIdRequired(YesOrNoStatus emailIdRequired) {
		this.emailIdRequired = emailIdRequired;
	}

	public void setIntranetRequired(YesOrNoStatus intranetRequired) {
		this.intranetRequired = intranetRequired;
	}

	public void setAccessCardRequired(YesOrNoStatus accessCardRequired) {
		this.accessCardRequired = accessCardRequired;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public AccessStatus getAccessStatus() {
		return accessStatus;
	}

	public void setAccessStatus(AccessStatus accessStatus) {
		this.accessStatus = accessStatus;
	}

	public OfferLetter getOfferLetter() {
		return offerLetter;
	}

	public void setOfferLetter(OfferLetter offerLetter) {
		this.offerLetter = offerLetter;
	}

}
