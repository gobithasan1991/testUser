package com.anthem.persistence.model.login;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"loginRequest_id"}))
public class LoginAndAccess extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4568847139153526068L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private LoginRequest loginRequest;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ApproveStatus approveStatus;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User approvedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approvedDate;
	
	@Lob
	private String reason;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = LoginAndAccessItem.class)
	@JoinColumn(name = "loginAndAccess_id")
	private List<LoginAndAccessItem> loginAndAccessItems;

	public Long getId() {
		return id;
	}

	public LoginRequest getLoginRequest() {
		return loginRequest;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public List<LoginAndAccessItem> getLoginAndAccessItems() {
		return loginAndAccessItems;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLoginRequest(LoginRequest loginRequest) {
		this.loginRequest = loginRequest;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public void setLoginAndAccessItems(List<LoginAndAccessItem> loginAndAccessItems) {
		this.loginAndAccessItems = loginAndAccessItems;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
