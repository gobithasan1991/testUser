package com.anthem.persistence.model.document;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Entity
public class IndexOfSopReferenceDocument extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3055591843517256950L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;

	@ManyToOne(fetch = FetchType.LAZY)
	private Document document;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplateCategory templateCategory;

	private String documentVersionNo;

	private Long documentRevNo;

	@Temporal(TemporalType.DATE)
	private Date documentEffectiveDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public Date getDocumentEffectiveDate() {
		return documentEffectiveDate;
	}

	public void setDocumentEffectiveDate(Date documentEffectiveDate) {
		this.documentEffectiveDate = documentEffectiveDate;
	}

	public DocumentTemplateCategory getTemplateCategory() {
		return templateCategory;
	}

	public void setTemplateCategory(DocumentTemplateCategory templateCategory) {
		this.templateCategory = templateCategory;
	}

	public Long getDocumentRevNo() {
		return documentRevNo;
	}

	public void setDocumentRevNo(Long documentRevNo) {
		this.documentRevNo = documentRevNo;
	}

	@Override
	public String toString() {
		return "IndexOfSopReferenceDocument [id=" + id + ", branch=" + branch + ", document=" + document
				+ ", templateCategory=" + templateCategory + ", documentVersionNo=" + documentVersionNo
				+ ", documentRevNo=" + documentRevNo + ", documentEffectiveDate=" + documentEffectiveDate + "]";
	}
	
	

}
