/**
 * 
 */
package com.anthem.persistence.model.document;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.LastModifiedDate;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;

/**
 * @author kalaiselvan.a
 *
 */

@Entity 
public class DocumentTemplateReviewAndApproveMapping extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3967329338953444399L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message="Document templte should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	private DocumentTemplate documentTemplate;

	@NotNull(message="Department should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)
	private QMSDepartment qmsDepartment;
	
	@NotNull(message="User should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false) 
	private User user;

	@NotBlank(message="Review type should not be empty")
	private String reviewType;

	@NotBlank(message="Priority level should not be empty")
	private String prioritylevel;
	
	@NotNull(message="Mapping type should not be empty")
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('MAPPED', 'REMAPPED', 'REVIEWED', 'APPROVED', 'REJECTED','RECALLED') DEFAULT 'MAPPED'")
	private CustomStatus mappingStatus;
	
	@Column(columnDefinition = "boolean default false")
	private Boolean rejected;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	private User updatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updatedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private User reMappedBy;
	
	public DocumentTemplateReviewAndApproveMapping() {
		super(); 
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
 
	public DocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(DocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getPrioritylevel() {
		return prioritylevel;
	}

	public void setPrioritylevel(String prioritylevel) {
		this.prioritylevel = prioritylevel;
	}

	public CustomStatus getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(CustomStatus mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public Boolean getRejected() {
		return rejected;
	}

	public void setRejected(Boolean rejected) {
		this.rejected = rejected;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public User getReMappedBy() {
		return reMappedBy;
	}

	public void setReMappedBy(User reMappedBy) {
		this.reMappedBy = reMappedBy;
	}
	@PrePersist
	public void makeDefaultValues() {
		this.rejected = Boolean.FALSE;
		this.mappingStatus = CustomStatus.MAPPED;
	}
}
