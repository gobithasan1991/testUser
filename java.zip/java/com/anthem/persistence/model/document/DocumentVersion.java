/**
 * 
 */
package com.anthem.persistence.model.document;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;

/**
 * @author kalaiselvan.a
 *
 */

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "versionNo", "versionFileName" }))
public class DocumentVersion extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String versionNo;

	private String versionFileName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Document document;

	private String versionUUID;

	private String noOfPage;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getVersionFileName() {
		return versionFileName;
	}

	public void setVersionFileName(String versionFileName) {
		this.versionFileName = versionFileName;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getVersionUUID() {
		return versionUUID;
	}

	public void setVersionUUID(String versionUUID) {
		this.versionUUID = versionUUID;
	}

	public String getNoOfPage() {
		return noOfPage;
	}

	public void setNoOfPage(String noOfPage) {
		this.noOfPage = noOfPage;
	}

}
