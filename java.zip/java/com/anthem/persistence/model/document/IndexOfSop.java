package com.anthem.persistence.model.document;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class IndexOfSop extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7150025977803819851L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;

	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplateCategory templateCategory;

	@ManyToOne(fetch = FetchType.LAZY)
	private User approver;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approveDate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','APPROVED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ApproveStatus approveStatus;

	private String approveComments;

	@ManyToOne(fetch = FetchType.LAZY)
	private IndexOfSopReferenceDocument indexOfSopReferenceDocument;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "indexOfSop")
	private List<IndexOfSopDocument> indexOfSopDocuments;

	@Lob
	private String reasonForUpdate;

	@ManyToOne(fetch = FetchType.LAZY)
	private User preparedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date preparedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getApprover() {
		return approver;
	}

	public void setApprover(User approver) {
		this.approver = approver;
	}

	public List<IndexOfSopDocument> getIndexOfSopDocuments() {
		return indexOfSopDocuments;
	}

	public void setIndexOfSopDocuments(List<IndexOfSopDocument> indexOfSopDocuments) {
		this.indexOfSopDocuments = indexOfSopDocuments;
	}

	public Date getApproveDate() {
		return approveDate;
	}

	public void setApproveDate(Date approveDate) {
		this.approveDate = approveDate;
	}

	public String getApproveComments() {
		return approveComments;
	}

	public void setApproveComments(String approveComments) {
		this.approveComments = approveComments;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public IndexOfSopReferenceDocument getIndexOfSopReferenceDocument() {
		return indexOfSopReferenceDocument;
	}

	public void setIndexOfSopReferenceDocument(IndexOfSopReferenceDocument indexOfSopReferenceDocument) {
		this.indexOfSopReferenceDocument = indexOfSopReferenceDocument;
	}

	public String getReasonForUpdate() {
		return reasonForUpdate;
	}

	public void setReasonForUpdate(String reasonForUpdate) {
		this.reasonForUpdate = reasonForUpdate;
	}

	public User getPreparedBy() {
		return preparedBy;
	}

	public void setPreparedBy(User preparedBy) {
		this.preparedBy = preparedBy;
	}

	public Date getPreparedDate() {
		return preparedDate;
	}

	public void setPreparedDate(Date preparedDate) {
		this.preparedDate = preparedDate;
	}

	public DocumentTemplateCategory getTemplateCategory() {
		return templateCategory;
	}

	public void setTemplateCategory(DocumentTemplateCategory templateCategory) {
		this.templateCategory = templateCategory;
	}

}
