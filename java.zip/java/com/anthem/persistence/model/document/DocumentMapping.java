/**
 * 
 */
package com.anthem.persistence.model.document;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

/**
 * @author kalaiselvan.a
 *
 */

@Entity
@Audited(targetAuditMode=RelationTargetAuditMode.NOT_AUDITED)
public class DocumentMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3522343675838418106L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "Document should not empty")
	@OneToOne(fetch = FetchType.LAZY, optional = false)
	private Document document;

	private Long documentRevNo;

	@NotNull(message = "Department should not empty")
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	private QMSDepartment qmsDepartment;

	@NotNull(message = "Template category should not empty")
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	private DocumentTemplateCategory documentTemplateCategory;

	@NotNull(message = "Company option should not be blank")
	private Boolean companyOption;

	@NotNull(message = "Department option should not be blank")
	private Boolean departmentOption;

	@NotNull(message = "individual option should not be blank")
	private Boolean individualOption;

	private String trainingDuration;

	private String nextTraining;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL ,mappedBy = "documentMapping")
	@AuditJoinTable(name="documentcompanymapping_audit_log")
	private List<DocumentCompanyMapping> documentCompanyMappings;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL ,mappedBy = "documentMapping")
	@AuditJoinTable(name="documentdepartmentmapping_audit_log")
	private List<DocumentDepartmentMapping> documentDepartmentMappings;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL ,mappedBy = "documentMapping")
	@AuditJoinTable(name="documentindividualmapping_audit_log")
	private List<DocumentIndividualMapping> documentIndividualMappings;

	public DocumentMapping() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public DocumentTemplateCategory getDocumentTemplateCategory() {
		return documentTemplateCategory;
	}

	public void setDocumentTemplateCategory(DocumentTemplateCategory documentTemplateCategory) {
		this.documentTemplateCategory = documentTemplateCategory;
	}

	public Boolean getCompanyOption() {
		return companyOption;
	}

	public void setCompanyOption(Boolean companyOption) {
		this.companyOption = companyOption;
	}

	public Boolean getDepartmentOption() {
		return departmentOption;
	}

	public void setDepartmentOption(Boolean departmentOption) {
		this.departmentOption = departmentOption;
	}

	public Boolean getIndividualOption() {
		return individualOption;
	}

	public void setIndividualOption(Boolean individualOption) {
		this.individualOption = individualOption;
	}

	public String getTrainingDuration() {
		return trainingDuration;
	}

	public void setTrainingDuration(String trainingDuration) {
		this.trainingDuration = trainingDuration;
	}

	public String getNextTraining() {
		return nextTraining;
	}

	public void setNextTraining(String nextTraining) {
		this.nextTraining = nextTraining;
	}

	public List<DocumentCompanyMapping> getDocumentCompanyMappings() {
		return documentCompanyMappings;
	}

	public void setDocumentCompanyMappings(List<DocumentCompanyMapping> documentCompanyMappings) {
		this.documentCompanyMappings = documentCompanyMappings;
	}

	public List<DocumentDepartmentMapping> getDocumentDepartmentMappings() {
		return documentDepartmentMappings;
	}

	public void setDocumentDepartmentMappings(List<DocumentDepartmentMapping> documentDepartmentMappings) {
		this.documentDepartmentMappings = documentDepartmentMappings;
	}

	public List<DocumentIndividualMapping> getDocumentIndividualMappings() {
		return documentIndividualMappings;
	}

	public void setDocumentIndividualMappings(List<DocumentIndividualMapping> documentIndividualMappings) {
		this.documentIndividualMappings = documentIndividualMappings;
	}

	public Long getDocumentRevNo() {
		return documentRevNo;
	}

	public void setDocumentRevNo(Long documentRevNo) {
		this.documentRevNo = documentRevNo;
	}

}
