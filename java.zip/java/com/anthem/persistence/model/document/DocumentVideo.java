/**
 * 
 */
package com.anthem.persistence.model.document;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.status.CustomStatus;

/**
 * @author kalaiselvan.a
 *
 */

@Entity
public class DocumentVideo extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String videoName;

	@Temporal(TemporalType.DATE)
	private Date effectiveDate;

	@Temporal(TemporalType.DATE)
	private Date nextEffectiveDate;

	private String videoId;

	private String versionNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY)
	private Document document;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED', 'DELETED', 'MAPPED', 'REMAPPED',"
			+ " 'PARTIALLYMAPPED', 'REVIEWED', 'PARTIALLYREVIEWED','APPROVED', 'REJECTED', 'PARTIALLYAPPROVED','RECALLED') DEFAULT 'MAPPED'", insertable = false)
	private CustomStatus customStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getNextEffectiveDate() {
		return nextEffectiveDate;
	}

	public void setNextEffectiveDate(Date nextEffectiveDate) {
		this.nextEffectiveDate = nextEffectiveDate;
	}

	public String getVideoId() {
		return videoId;
	}

	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public CustomStatus getCustomStatus() {
		return customStatus;
	}

	public void setCustomStatus(CustomStatus customStatus) {
		this.customStatus = customStatus;
	}

}
