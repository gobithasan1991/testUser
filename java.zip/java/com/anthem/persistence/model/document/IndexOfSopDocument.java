package com.anthem.persistence.model.document;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class IndexOfSopDocument extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8207290877945317118L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Document document;

	private String documentVersionNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private IndexOfSop indexOfSop;

	@Temporal(TemporalType.DATE)
	private Date documentEffectiveDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getDocumentVersionNo() {
		return documentVersionNo;
	}

	public void setDocumentVersionNo(String documentVersionNo) {
		this.documentVersionNo = documentVersionNo;
	}

	public IndexOfSop getIndexOfSop() {
		return indexOfSop;
	}

	public void setIndexOfSop(IndexOfSop indexOfSop) {
		this.indexOfSop = indexOfSop;
	}

	public Date getDocumentEffectiveDate() {
		return documentEffectiveDate;
	}

	public void setDocumentEffectiveDate(Date documentEffectiveDate) {
		this.documentEffectiveDate = documentEffectiveDate;
	}

}
