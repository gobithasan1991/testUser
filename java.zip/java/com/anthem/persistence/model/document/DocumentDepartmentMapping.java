package com.anthem.persistence.model.document;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Entity
@Audited(targetAuditMode=RelationTargetAuditMode.NOT_AUDITED)
public class DocumentDepartmentMapping extends Default {


	/**
	 * 
	 */
	private static final long serialVersionUID = -7251232329271569334L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;
	
	@NotNull(message="Department should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false)  
	private QMSDepartment qmsDepartment;
	
	@NotNull(message="Mandatory option should not be blank")
	private Boolean mandatory;
	
	@NotNull(message="Training option should not be blank")
	private Boolean training;
	
	@NotNull(message="Evaluation option should not be blank")
	private Boolean evaluation;
	
	@NotNull(message="Document mapping should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional = false)
	private DocumentMapping documentMapping;

	public DocumentDepartmentMapping() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public Boolean getMandatory() {
		return mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public Boolean getTraining() {
		return training;
	}

	public void setTraining(Boolean training) {
		this.training = training;
	}

	public Boolean getEvaluation() {
		return evaluation;
	}

	public void setEvaluation(Boolean evaluation) {
		this.evaluation = evaluation;
	}

	public DocumentMapping getDocumentMapping() {
		return documentMapping;
	}

	public void setDocumentMapping(DocumentMapping documentMapping) {
		this.documentMapping = documentMapping;
	} 
	
}
