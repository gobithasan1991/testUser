package com.anthem.persistence.model.document;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.changecontrol.ChangeControlNumber;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.document.DocumentUpdateFrom;
import com.anthem.util.training.DocumentChangeControlStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Document extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Document Title Cant be Empty")
	@Size(min = 3, message = "Document Title is Required!.. Length should be more than 3 characters")
	private String documentTitle;

	@Column(unique = true)
	private String documentCode;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Set<Branch> branchs;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplateCategory templateCategory;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplate documentTemplate;

	@Temporal(TemporalType.DATE)
	private Date effectiveDate;

	@Column(nullable = true)
	@Temporal(TemporalType.DATE)
	private Date nextEffectiveDate;

	private String currentVersionNo;

	private String fileId;

	private String documentFileName;

	private String documentVersionFileName;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED', 'DELETED', 'MAPPED', 'REMAPPED',"
			+ " 'PARTIALLYMAPPED', 'REVIEWED', 'PARTIALLYREVIEWED','APPROVED', 'REJECTED', 'PARTIALLYAPPROVED','RECALLED') DEFAULT 'CREATED'")
	private CustomStatus customStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED','MODIFY','CHANGECONTROLMODIFY','DOCUMENTUPDATE','MAPPED','REVIEWED', 'APPROVED', 'REJECTED') DEFAULT 'CREATED'")
	private CustomStatus processIn;

	private String versionNo;

	@Column(nullable = true)
	private String versionDocumentnoOfPage;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED', 'MAPPED') DEFAULT 'CREATED'")
	private CustomStatus trainingMappedStatus;

	@OneToMany(cascade = { CascadeType.ALL }, targetEntity = DocumentOwner.class)
	@JoinColumn(name = "document_id")
	private List<DocumentOwner> documentOwners;

	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;

	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlNumber previousChangeControlNumber;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('NA', 'INITIATED','COMPLETED') DEFAULT 'NA'", insertable = false)
	private DocumentChangeControlStatus documentChangeControlStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('NA', 'INITIATED','COMPLETED') DEFAULT 'NA'", insertable = false)
	private DocumentChangeControlStatus documentUpdateStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'MODIFY','CHANGECONTROL','UPDATE') DEFAULT 'PENDING'", insertable = false)
	private DocumentUpdateFrom previousDocumentUpdateFrom;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'MODIFY','CHANGECONTROL','UPDATE') DEFAULT 'PENDING'", insertable = false)
	private DocumentUpdateFrom documentUpdateFrom;

	@ManyToOne(fetch = FetchType.LAZY)
	private DocumentUpdateTrack documentUpdateTrack;

	@ManyToOne(fetch = FetchType.LAZY)
	private DocumentUpdateTrack previousDocumentUpdateTrack;

	public Document() {
		super();
	}

	public Document(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public Set<Branch> getBranchs() {
		return branchs;
	}

	public void setBranchs(Set<Branch> branchs) {
		this.branchs = branchs;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public DocumentTemplateCategory getTemplateCategory() {
		return templateCategory;
	}

	public void setTemplateCategory(DocumentTemplateCategory templateCategory) {
		this.templateCategory = templateCategory;
	}

	public DocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(DocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getNextEffectiveDate() {
		return nextEffectiveDate;
	}

	public void setNextEffectiveDate(Date nextEffectiveDate) {
		this.nextEffectiveDate = nextEffectiveDate;
	}

	public String getCurrentVersionNo() {
		return currentVersionNo;
	}

	public void setCurrentVersionNo(String currentVersionNo) {
		this.currentVersionNo = currentVersionNo;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getDocumentFileName() {
		return documentFileName;
	}

	public void setDocumentFileName(String documentFileName) {
		this.documentFileName = documentFileName;
	}

	public String getDocumentVersionFileName() {
		return documentVersionFileName;
	}

	public void setDocumentVersionFileName(String documentVersionFileName) {
		this.documentVersionFileName = documentVersionFileName;
	}

	public CustomStatus getCustomStatus() {
		return customStatus;
	}

	public void setCustomStatus(CustomStatus customStatus) {
		this.customStatus = customStatus;
	}

	public CustomStatus getProcessIn() {
		return processIn;
	}

	public void setProcessIn(CustomStatus processIn) {
		this.processIn = processIn;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getVersionDocumentnoOfPage() {
		return versionDocumentnoOfPage;
	}

	public void setVersionDocumentnoOfPage(String versionDocumentnoOfPage) {
		this.versionDocumentnoOfPage = versionDocumentnoOfPage;
	}

	public CustomStatus getTrainingMappedStatus() {
		return trainingMappedStatus;
	}

	public void setTrainingMappedStatus(CustomStatus trainingMappedStatus) {
		this.trainingMappedStatus = trainingMappedStatus;
	}

	public List<DocumentOwner> getDocumentOwners() {
		return documentOwners;
	}

	public void setDocumentOwners(List<DocumentOwner> documentOwners) {
		this.documentOwners = documentOwners;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

	public DocumentChangeControlStatus getDocumentChangeControlStatus() {
		return documentChangeControlStatus;
	}

	public void setDocumentChangeControlStatus(DocumentChangeControlStatus documentChangeControlStatus) {
		this.documentChangeControlStatus = documentChangeControlStatus;
	}

	public ChangeControlNumber getPreviousChangeControlNumber() {
		return previousChangeControlNumber;
	}

	public void setPreviousChangeControlNumber(ChangeControlNumber previousChangeControlNumber) {
		this.previousChangeControlNumber = previousChangeControlNumber;
	}

	public DocumentUpdateTrack getDocumentUpdateTrack() {
		return documentUpdateTrack;
	}

	public void setDocumentUpdateTrack(DocumentUpdateTrack documentUpdateTrack) {
		this.documentUpdateTrack = documentUpdateTrack;
	}

	public DocumentUpdateTrack getPreviousDocumentUpdateTrack() {
		return previousDocumentUpdateTrack;
	}

	public void setPreviousDocumentUpdateTrack(DocumentUpdateTrack previousDocumentUpdateTrack) {
		this.previousDocumentUpdateTrack = previousDocumentUpdateTrack;
	}

	public DocumentChangeControlStatus getDocumentUpdateStatus() {
		return documentUpdateStatus;
	}

	public void setDocumentUpdateStatus(DocumentChangeControlStatus documentUpdateStatus) {
		this.documentUpdateStatus = documentUpdateStatus;
	}

	public DocumentUpdateFrom getDocumentUpdateFrom() {
		return documentUpdateFrom;
	}

	public void setDocumentUpdateFrom(DocumentUpdateFrom documentUpdateFrom) {
		this.documentUpdateFrom = documentUpdateFrom;
	}

	public DocumentUpdateFrom getPreviousDocumentUpdateFrom() {
		return previousDocumentUpdateFrom;
	}

	public void setPreviousDocumentUpdateFrom(DocumentUpdateFrom previousDocumentUpdateFrom) {
		this.previousDocumentUpdateFrom = previousDocumentUpdateFrom;
	}

}
