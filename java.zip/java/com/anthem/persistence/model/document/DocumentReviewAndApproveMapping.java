package com.anthem.persistence.model.document;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.changecontrol.ChangeControlNumber;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class DocumentReviewAndApproveMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private Document document;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.EAGER)
	private User user;

	private String reviewType;

	private String prioritylevels;

	private String fileid;

	@Enumerated(EnumType.STRING)
	@Column(name = "MappingStatus", columnDefinition = "ENUM('MAPPED', 'REMAPPED',"
			+ " 'REVIEWED', 'APPROVED', 'REJECTED','RECALLED') DEFAULT 'MAPPED'", insertable = false)
	private CustomStatus mappingStatus;

	@Column(columnDefinition = "boolean default false", insertable = false)
	private Boolean rejected;

	@ManyToOne(fetch = FetchType.LAZY)
	private User reMappedBy;

	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private DocumentUpdateTrack documentUpdateTrack;

	public DocumentReviewAndApproveMapping() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getPrioritylevels() {
		return prioritylevels;
	}

	public void setPrioritylevels(String prioritylevels) {
		this.prioritylevels = prioritylevels;
	}

	public String getFileid() {
		return fileid;
	}

	public void setFileid(String fileid) {
		this.fileid = fileid;
	}

	public CustomStatus getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(CustomStatus mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public Boolean getRejected() {
		return rejected;
	}

	public void setRejected(Boolean rejected) {
		this.rejected = rejected;
	}

	public User getReMappedBy() {
		return reMappedBy;
	}

	public void setReMappedBy(User reMappedBy) {
		this.reMappedBy = reMappedBy;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}
	
	
	

	public DocumentUpdateTrack getDocumentUpdateTrack() {
		return documentUpdateTrack;
	}

	public void setDocumentUpdateTrack(DocumentUpdateTrack documentUpdateTrack) {
		this.documentUpdateTrack = documentUpdateTrack;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentReviewAndApproveMapping other = (DocumentReviewAndApproveMapping) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DocumentReviewAndApproveMapping [" + (id != null ? "id=" + id + ", " : "")
				+ (document != null ? "document=" + document + ", " : "")
				+ (qmsDepartment != null ? "qmsDepartment=" + qmsDepartment + ", " : "")
				+ (user != null ? "user=" + user + ", " : "")
				+ (reviewType != null ? "reviewType=" + reviewType + ", " : "")
				+ (prioritylevels != null ? "prioritylevels=" + prioritylevels + ", " : "")
				+ (fileid != null ? "fileid=" + fileid + ", " : "")
				+ (mappingStatus != null ? "mappingStatus=" + mappingStatus + ", " : "")
				+ (rejected != null ? "rejected=" + rejected + ", " : "")
				+ (reMappedBy != null ? "reMappedBy=" + reMappedBy + ", " : "")
				+ (getId() != null ? "getId()=" + getId() + ", " : "")
				+ (getDocument() != null ? "getDocument()=" + getDocument() + ", " : "")
				+ (getQmsDepartment() != null ? "getQmsDepartment()=" + getQmsDepartment() + ", " : "")
				+ (getUser() != null ? "getUser()=" + getUser() + ", " : "")
				+ (getReviewType() != null ? "getReviewType()=" + getReviewType() + ", " : "")
				+ (getPrioritylevels() != null ? "getPrioritylevels()=" + getPrioritylevels() + ", " : "")
				+ (getFileid() != null ? "getFileid()=" + getFileid() + ", " : "")
				+ (getMappingStatus() != null ? "getMappingStatus()=" + getMappingStatus() + ", " : "")
				+ (getRejected() != null ? "getRejected()=" + getRejected() + ", " : "")
				+ (getReMappedBy() != null ? "getReMappedBy()=" + getReMappedBy() + ", " : "")
				+ (getCreatedBy() != null ? "getCreatedBy()=" + getCreatedBy() + ", " : "")
				+ (getSpecialNotes() != null ? "getSpecialNotes()=" + getSpecialNotes() + ", " : "")
				+ (getCreatedDate() != null ? "getCreatedDate()=" + getCreatedDate() + ", " : "") + "isEnabled()="
				+ isEnabled() + ", "
				+ (getEnabledStatus() != null ? "getEnabledStatus()=" + getEnabledStatus() + ", " : "")
				+ (getRecordStatus() != null ? "getRecordStatus()=" + getRecordStatus() + ", " : "")
				+ (getModifiedBy() != null ? "getModifiedBy()=" + getModifiedBy() + ", " : "")
				+ (getModifiedDate() != null ? "getModifiedDate()=" + getModifiedDate() + ", " : "")
				+ "getVersionNumber()=" + getVersionNumber() + ", "
				+ (getClass() != null ? "getClass()=" + getClass() + ", " : "") + "hashCode()=" + hashCode() + ", "
				+ (super.toString() != null ? "toString()=" + super.toString() : "") + "]";
	}

}
