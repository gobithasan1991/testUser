package com.anthem.persistence.model.document;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.status.CustomStatus;

@Entity 
public class DocumentTemplate extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8797853575643786415L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;

	@NotBlank(message="Template title should not be empty")
	@Size(min=3,max=255,message="Template title length should be 3 to 255 charactor")
	private String name;

	@NotNull(message="Branch shoult not be empty")
	@ManyToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY, targetEntity = Branch.class)
	private Set<Branch> branch;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE) 
	private QMSDepartment qmsDepartment;

	@NotNull(message="Document template category shoult not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional=false) 
	private DocumentTemplateCategory templateCategory;

	@Column(unique=true)
	private String fileId;
	
	@Column(unique=true)
	private String fileUUID;

	private String versionNo;

	private String currentVersion;

	private String currentVersiontemplate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED', 'DELETED', 'MAPPED', 'REMAPPED',"
			+ " 'PARTIALLYMAPPED', 'REVIEWED', 'PARTIALLYREVIEWED','APPROVED', 'REJECTED', 'PARTIALLYAPPROVED','RECALLED') DEFAULT 'CREATED'")
	private CustomStatus templateStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED','MODIFY', 'MAPPED', 'REVIEWED','APPROVED', 'REJECTED') DEFAULT 'CREATED'")
	private CustomStatus processIn;

	private Date effectiveDate;

	public DocumentTemplate() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Branch> getBranch() {
		return branch;
	}

	public void setBranch(Set<Branch> branch) {
		this.branch = branch;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public DocumentTemplateCategory getTemplateCategory() {
		return templateCategory;
	}

	public void setTemplateCategory(DocumentTemplateCategory templateCategory) {
		this.templateCategory = templateCategory;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileUUID() {
		return fileUUID;
	}

	public void setFileUUID(String fileUUID) {
		this.fileUUID = fileUUID;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getCurrentVersion() {
		return currentVersion;
	}

	public void setCurrentVersion(String currentVersion) {
		this.currentVersion = currentVersion;
	}

	public String getCurrentVersiontemplate() {
		return currentVersiontemplate;
	}

	public void setCurrentVersiontemplate(String currentVersiontemplate) {
		this.currentVersiontemplate = currentVersiontemplate;
	}

	public CustomStatus getTemplateStatus() {
		return templateStatus;
	}

	public void setTemplateStatus(CustomStatus templateStatus) {
		this.templateStatus = templateStatus;
	}

	public CustomStatus getProcessIn() {
		return processIn;
	}

	public void setProcessIn(CustomStatus processIn) {
		this.processIn = processIn;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

 
}
