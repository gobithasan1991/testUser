package com.anthem.persistence.model.document;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class DocumentVideoReviewAndApproveMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 86704071450087500L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private DocumentVideo documentVideo;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.EAGER)
	private User user;

	private String reviewType;

	private String prioritylevel;

	private String fileid;

	@Enumerated(EnumType.STRING)
	@Column(name = "MappingStatus", columnDefinition = "ENUM('MAPPED', 'REMAPPED',"
			+ " 'REVIEWED', 'APPROVED', 'REJECTED','RECALLED') DEFAULT 'MAPPED'", insertable = false)
	private CustomStatus mappingStatus;

	@Column(columnDefinition = "boolean default false", insertable = false)
	private Boolean rejected;

	@ManyToOne(fetch = FetchType.LAZY)
	private User reMappedBy;

	@Lob
	private String reason;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public DocumentVideo getDocumentVideo() {
		return documentVideo;
	}

	public void setDocumentVideo(DocumentVideo documentVideo) {
		this.documentVideo = documentVideo;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getPrioritylevel() {
		return prioritylevel;
	}

	public void setPrioritylevel(String prioritylevel) {
		this.prioritylevel = prioritylevel;
	}

	public String getFileid() {
		return fileid;
	}

	public void setFileid(String fileid) {
		this.fileid = fileid;
	}

	public CustomStatus getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(CustomStatus mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public Boolean getRejected() {
		return rejected;
	}

	public void setRejected(Boolean rejected) {
		this.rejected = rejected;
	}

	public User getReMappedBy() {
		return reMappedBy;
	}

	public void setReMappedBy(User reMappedBy) {
		this.reMappedBy = reMappedBy;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
