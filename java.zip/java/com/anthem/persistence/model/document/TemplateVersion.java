/**
 * 
 */
package com.anthem.persistence.model.document;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import com.anthem.persistence.model.user.User;
import com.anthem.web.view.View;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;

/**
 * @author kalaiselvan.a
 *
 */
@Entity
@Table(name="template_version")
public class TemplateVersion {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	@JsonView(View.BasicView.class)
	@JsonProperty
	private long id;

	@Column(name = "VersionNo")
	@JsonView(View.BasicView.class)
	@JsonProperty
	private String versionno;

	@Column(name = "VersionFileName")
	@JsonView(View.BasicView.class)
	@JsonProperty
	private String versionFileName;

	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn
	private DocumentTemplate documentTemplate;

	@Column(name = "VersionID")
	private String versionUUID;

	@ManyToOne(cascade = CascadeType.REMOVE)
	@JoinColumn(name = "CreatedBy")
	@JsonView(View.ExtendedView.class)
	@CreatedBy
	private User createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate")
	@JsonView(View.ExtendedView.class)
	@CreatedDate
	private Date createdDate;

	@Column(columnDefinition = "boolean default true", insertable = false)
	private boolean enabled;

	@Column(name = "SpecialNotes")
	@JsonProperty
	@JsonView(View.ExtendedView.class)
	private String specialNotes;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getVersionno() {
		return versionno;
	}

	public void setVersionno(String versionno) {
		this.versionno = versionno;
	}

	public String getVersionFileName() {
		return versionFileName;
	}

	public void setVersionFileName(String versionFileName) {
		this.versionFileName = versionFileName;
	}

	public DocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(DocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}

	public String getVersionUUID() {
		return versionUUID;
	}

	public void setVersionUUID(String versionUUID) {
		this.versionUUID = versionUUID;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}
	
	
}
