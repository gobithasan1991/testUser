package com.anthem.persistence.model.document;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class DocumentEditorMapping extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplateCategory templateCategory;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Document document;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Set<Branch> branchs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public DocumentTemplateCategory getTemplateCategory() {
		return templateCategory;
	}

	public void setTemplateCategory(DocumentTemplateCategory templateCategory) {
		this.templateCategory = templateCategory;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public Set<Branch> getBranchs() {
		return branchs;
	}

	public void setBranchs(Set<Branch> branchs) {
		this.branchs = branchs;
	}

	@Override
	public String toString() {
		return "DocumentEditorMapping [id=" + id + ", qmsDepartment=" + qmsDepartment + ", templateCategory="
				+ templateCategory + ", document=" + document + ", branchs=" + branchs + "]";
	}

}
