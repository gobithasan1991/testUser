/**
 * 
 */
package com.anthem.persistence.model.document;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;

import com.anthem.persistence.model.user.User;
import com.anthem.util.common.EnabledStatus;

/**
 * @author kalaiselvan.a
 *
 */
@Entity
public class DocumentTemplateVersion implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4570741041431687151L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String versionno;

	private String versionFileName;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplate documentTemplate;

	private String versionUUID;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	private Date createdDate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('OPEN', 'ONHOLD', 'CLOSED') DEFAULT 'OPEN'",insertable=false)
	private EnabledStatus enabledStatus;

	private String specialNotes;

	public DocumentTemplateVersion() {
		super();
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getVersionno() {
		return versionno;
	}

	public void setVersionno(String versionno) {
		this.versionno = versionno;
	}

	public String getVersionFileName() {
		return versionFileName;
	}

	public void setVersionFileName(String versionFileName) {
		this.versionFileName = versionFileName;
	}

	public DocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(DocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}

	public String getVersionUUID() {
		return versionUUID;
	}

	public void setVersionUUID(String versionUUID) {
		this.versionUUID = versionUUID;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public EnabledStatus getEnabledStatus() {
		return enabledStatus;
	}

	public void setEnabledStatus(EnabledStatus enabledStatus) {
		this.enabledStatus = enabledStatus;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}
 
 
}
