package com.anthem.persistence.model.calibrationpm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;

@Entity
public class CalibrationChecklistMasterInstData extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8717003564804346840L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String instName;
	
	private String stdBuffer;
	
	private String sno;
	
	private String certNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date dueDate;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private CalibrationChecklistFormData checklistFormData;

	public CalibrationChecklistMasterInstData() {
		super();
	}

	public CalibrationChecklistMasterInstData(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInstName() {
		return instName;
	}

	public void setInstName(String instName) {
		this.instName = instName;
	}

	public String getStdBuffer() {
		return stdBuffer;
	}

	public void setStdBuffer(String stdBuffer) {
		this.stdBuffer = stdBuffer;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public CalibrationChecklistFormData getChecklistFormData() {
		return checklistFormData;
	}

	public void setChecklistFormData(CalibrationChecklistFormData checklistFormData) {
		this.checklistFormData = checklistFormData;
	}
}
