package com.anthem.persistence.model.calibrationpm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;
import com.anthem.web.service.common.dto.IdCodeName;

@Entity
public class CalibrationChecklist extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3978907603132295427L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@NotEmpty(message = "Name is mandatory")
	private String name;
	
	@NotEmpty(message = "Code is mandatory")
	@Column(unique = true)
	private String code;
	
	@OneToOne(fetch = FetchType.LAZY)
	private CalibrationChecklistDocumentTemplate documentTemplate;
			
	public CalibrationChecklist() {
		super();
	}
	
	public CalibrationChecklist(Long id, String name, String code) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public CalibrationChecklistDocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(CalibrationChecklistDocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}

	public IdCodeName getIdCodeName() {
		return new IdCodeName(this.id, this.code, this.code);
	}
	
}
