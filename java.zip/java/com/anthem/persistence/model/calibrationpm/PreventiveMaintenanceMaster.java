package com.anthem.persistence.model.calibrationpm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;

@Entity
public class PreventiveMaintenanceMaster extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8650359374991965722L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastDate;
	
	private Integer freqMonth;
	
	private Integer freqDays;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date nextDate;
	
	private Double rangeFrom;
	
	private Double rangeTo;
	
	private String uom;		
		
	private Integer gracePeriod;
	
	private Double acceptCritFrom;
	
	private Double acceptCritTo;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.REMOVE)
	private PreventiveMaintenanceChecklist preventiveMaintenanceChecklist;
	
	@OneToOne(fetch=FetchType.LAZY, cascade=CascadeType.REMOVE)
	private EquipmentInstrumentMaster equipmentInstrumentMaster;
	
	public PreventiveMaintenanceMaster() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getLastDate() {
		return lastDate;
	}

	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}

	public Integer getFreqMonth() {
		return freqMonth;
	}

	public void setFreqMonth(Integer freqMonth) {
		this.freqMonth = freqMonth;
	}

	public Integer getFreqDays() {
		return freqDays;
	}

	public void setFreqDays(Integer freqDays) {
		this.freqDays = freqDays;
	}

	public Date getNextDate() {
		return nextDate;
	}

	public void setNextDate(Date nextDate) {
		this.nextDate = nextDate;
	}

	public Double getRangeFrom() {
		return rangeFrom;
	}

	public void setRangeFrom(Double rangeFrom) {
		this.rangeFrom = rangeFrom;
	}

	public Double getRangeTo() {
		return rangeTo;
	}

	public void setRangeTo(Double rangeTo) {
		this.rangeTo = rangeTo;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Integer getGracePeriod() {
		return gracePeriod;
	}

	public void setGracePeriod(Integer gracePeriod) {
		this.gracePeriod = gracePeriod;
	}

	public Double getAcceptCritFrom() {
		return acceptCritFrom;
	}

	public void setAcceptCritFrom(Double acceptCritFrom) {
		this.acceptCritFrom = acceptCritFrom;
	}

	public Double getAcceptCritTo() {
		return acceptCritTo;
	}

	public void setAcceptCritTo(Double acceptCritTo) {
		this.acceptCritTo = acceptCritTo;
	}

	public EquipmentInstrumentMaster getEquipmentInstrumentMaster() {
		return equipmentInstrumentMaster;
	}

	public void setEquipmentInstrumentMaster(EquipmentInstrumentMaster equipmentInstrumentMaster) {
		this.equipmentInstrumentMaster = equipmentInstrumentMaster;
	}

	public PreventiveMaintenanceChecklist getPreventiveMaintenanceChecklist() {
		return preventiveMaintenanceChecklist;
	}

	public void setPreventiveMaintenanceChecklist(PreventiveMaintenanceChecklist preventiveMaintenanceChecklist) {
		this.preventiveMaintenanceChecklist = preventiveMaintenanceChecklist;
	}
}
