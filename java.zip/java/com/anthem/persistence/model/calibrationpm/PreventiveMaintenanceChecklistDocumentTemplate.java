package com.anthem.persistence.model.calibrationpm;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.anthem.persistence.model.common.Default;

@Entity
public class PreventiveMaintenanceChecklistDocumentTemplate extends Default{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3084848739122089113L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String documentTemplateUrl;
	
	private String sopNo;
	
	private String version;
	
	public PreventiveMaintenanceChecklistDocumentTemplate() {
		super();
	}
	
	public PreventiveMaintenanceChecklistDocumentTemplate(Long id) {
		super();
		this.id = id;
	}
	
	public PreventiveMaintenanceChecklistDocumentTemplate(String documentTemplateUrl, String sopNo) {
		super();
		this.documentTemplateUrl = documentTemplateUrl;
		this.sopNo = sopNo;
	}

	
	public PreventiveMaintenanceChecklistDocumentTemplate(String documentTemplateUrl, String sopNo, String version) {
		super();
		this.documentTemplateUrl = documentTemplateUrl;
		this.sopNo = sopNo;
		this.version = version;
	}

	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getDocumentTemplateUrl() {
		return documentTemplateUrl;
	}
	
	public void setDocumentTemplateUrl(String documentTemplateUrl) {
		this.documentTemplateUrl = documentTemplateUrl;
	}

	public String getSopNo() {
		return sopNo;
	}

	public void setSopNo(String sopNo) {
		this.sopNo = sopNo;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	
	
}