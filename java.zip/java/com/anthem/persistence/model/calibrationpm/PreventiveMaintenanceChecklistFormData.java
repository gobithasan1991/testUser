package com.anthem.persistence.model.calibrationpm;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class PreventiveMaintenanceChecklistFormData extends Default{
	
	private static final long serialVersionUID = 2359369041584064807L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private PreventiveMaintenancePlanner preventiveMaintenancePlanner;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private PreventiveMaintenanceChecklist preventiveMaintenanceChecklist;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = PreventiveMaintenanceChecklistTopBottomData.class)
	@JoinColumn(name = "checklistFormData_id")
	private PreventiveMaintenanceChecklistTopBottomData topBottomData;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = PreventiveMaintenanceChecklistResultSummaryData.class)
	@JoinColumn(name = "checklistFormData_id")
	private List<PreventiveMaintenanceChecklistResultSummaryData> checklistResultSummaryData;

	public PreventiveMaintenanceChecklistFormData() {
		super();
	}

	public PreventiveMaintenanceChecklistFormData(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public PreventiveMaintenancePlanner getPreventiveMaintenancePlanner() {
		return preventiveMaintenancePlanner;
	}

	public void setPreventiveMaintenancePlanner(PreventiveMaintenancePlanner preventiveMaintenancePlanner) {
		this.preventiveMaintenancePlanner = preventiveMaintenancePlanner;
	}

	public PreventiveMaintenanceChecklist getPreventiveMaintenanceChecklist() {
		return preventiveMaintenanceChecklist;
	}

	public void setPreventiveMaintenanceChecklist(PreventiveMaintenanceChecklist preventiveMaintenanceChecklist) {
		this.preventiveMaintenanceChecklist = preventiveMaintenanceChecklist;
	}

	public PreventiveMaintenanceChecklistTopBottomData getTopBottomData() {
		return topBottomData;
	}

	public void setTopBottomData(PreventiveMaintenanceChecklistTopBottomData topBottomData) {
		this.topBottomData = topBottomData;
	}

	public List<PreventiveMaintenanceChecklistResultSummaryData> getChecklistResultSummaryData() {
		return checklistResultSummaryData;
	}

	public void setChecklistResultSummaryData(
			List<PreventiveMaintenanceChecklistResultSummaryData> checklistResultSummaryData) {
		this.checklistResultSummaryData = checklistResultSummaryData;
	}
	
}
