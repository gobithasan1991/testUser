package com.anthem.persistence.model.calibrationpm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.calibrationpm.CalibrationPMStatus;

@Entity
public class CalibrationPlanner extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6304023261423039176L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date nextDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date plannedDate;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'PLANNED', 'COMPLETED') DEFAULT 'PENDING'")
	private CalibrationPMStatus calibrationStatus;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private CalibrationMaster calibrationMaster;
		
	@ManyToOne(fetch = FetchType.LAZY)
	private CalibrationChecklistDocumentTemplate documentTemplate;

	public CalibrationPlanner() {
		super();
	}

	public CalibrationPlanner(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getLastDate() {
		return lastDate;
	}

	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}

	public Date getNextDate() {
		return nextDate;
	}

	public void setNextDate(Date nextDate) {
		this.nextDate = nextDate;
	}
	
	public Date getPlannedDate() {
		return plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	public CalibrationPMStatus getCalibrationStatus() {
		return calibrationStatus;
	}

	public void setCalibrationStatus(CalibrationPMStatus calibrationStatus) {
		this.calibrationStatus = calibrationStatus;
	}

	public CalibrationMaster getCalibrationMaster() {
		return calibrationMaster;
	}

	public void setCalibrationMaster(CalibrationMaster calibrationMaster) {
		this.calibrationMaster = calibrationMaster;
	}

	public CalibrationChecklistDocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(CalibrationChecklistDocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}
	
	
}
