package com.anthem.persistence.model.calibrationpm;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.anthem.persistence.model.user.User;
import com.anthem.util.common.YesOrNoStatus;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class CalibrationChecklistTopBottomData implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3936646575542643735L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String sno;
	
	private String model;
	
	private String instName;
	
	private String instCode;
	
	private Double rangeFrom;
	
	private Double rangeTo;
	
	private Double leastCount;
	
	private String make;
	
	private Double acceptCritFrom;
	
	private Double acceptCritTo;
	
	private String correctiveActionComments;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO')")
	private YesOrNoStatus calibrationResultComplies;
	
	private String remarks;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date previousCalibDate;
	
	@CreatedBy
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(updatable = false)
	private User doneBy;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(updatable = false)
	private User checkedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date nextCalibDate;
	
	@OneToOne
	private CalibrationChecklistFormData checklistFormData; 
	

	public CalibrationChecklistTopBottomData() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getInstName() {
		return instName;
	}

	public void setInstName(String instName) {
		this.instName = instName;
	}

	public String getInstCode() {
		return instCode;
	}

	public void setInstCode(String instCode) {
		this.instCode = instCode;
	}

	public Double getRangeFrom() {
		return rangeFrom;
	}

	public void setRangeFrom(Double rangeFrom) {
		this.rangeFrom = rangeFrom;
	}

	public Double getRangeTo() {
		return rangeTo;
	}

	public void setRangeTo(Double rangeTo) {
		this.rangeTo = rangeTo;
	}

	public Double getLeastCount() {
		return leastCount;
	}

	public void setLeastCount(Double leastCount) {
		this.leastCount = leastCount;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public Double getAcceptCritFrom() {
		return acceptCritFrom;
	}

	public void setAcceptCritFrom(Double acceptCritFrom) {
		this.acceptCritFrom = acceptCritFrom;
	}

	public Double getAcceptCritTo() {
		return acceptCritTo;
	}

	public void setAcceptCritTo(Double acceptCritTo) {
		this.acceptCritTo = acceptCritTo;
	}

	public String getCorrectiveActionComments() {
		return correctiveActionComments;
	}

	public void setCorrectiveActionComments(String correctiveActionComments) {
		this.correctiveActionComments = correctiveActionComments;
	}

	public YesOrNoStatus getCalibrationResultComplies() {
		return calibrationResultComplies;
	}

	public void setCalibrationResultComplies(YesOrNoStatus calibrationResultComplies) {
		this.calibrationResultComplies = calibrationResultComplies;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getPreviousCalibDate() {
		return previousCalibDate;
	}

	public void setPreviousCalibDate(Date previousCalibDate) {
		this.previousCalibDate = previousCalibDate;
	}

	public User getDoneBy() {
		return doneBy;
	}

	public void setDoneBy(User doneBy) {
		this.doneBy = doneBy;
	}

	public User getCheckedBy() {
		return checkedBy;
	}

	public void setCheckedBy(User checkedBy) {
		this.checkedBy = checkedBy;
	}

	public Date getNextCalibDate() {
		return nextCalibDate;
	}

	public void setNextCalibDate(Date nextCalibDate) {
		this.nextCalibDate = nextCalibDate;
	}

	public CalibrationChecklistFormData getChecklistFormData() {
		return checklistFormData;
	}

	public void setChecklistFormData(CalibrationChecklistFormData checklistFormData) {
		this.checklistFormData = checklistFormData;
	}
}
