package com.anthem.persistence.model.calibrationpm;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class PreventiveMaintenanceChecklistResultSummaryData extends Default{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7160259524781020437L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String taskToBePerformed;
	
	private String inspectedOkOrNot;
	
	private String action;
	
	private String observation;
	
	private String valveCode;
	
	private String checkForPhysicalDamage;
	
	private String checkForAnyAirLeakage;
	
	private String rollNewTeflonTapeInPUFitting;
	
	private String lubricateTheActuator;
	
	private String cleanAndCheckFeedbackSwitchCableTerminalTightness;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private PreventiveMaintenanceChecklistFormData checklistFormData;

	public PreventiveMaintenanceChecklistResultSummaryData(Long id) {
		super();
		this.id = id;
	}

	public PreventiveMaintenanceChecklistResultSummaryData() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTaskToBePerformed() {
		return taskToBePerformed;
	}

	public void setTaskToBePerformed(String taskToBePerformed) {
		this.taskToBePerformed = taskToBePerformed;
	}

	public String getInspectedOkOrNot() {
		return inspectedOkOrNot;
	}

	public void setInspectedOkOrNot(String inspectedOkOrNot) {
		this.inspectedOkOrNot = inspectedOkOrNot;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getObservation() {
		return observation;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	public String getValveCode() {
		return valveCode;
	}

	public void setValveCode(String valveCode) {
		this.valveCode = valveCode;
	}

	public String getCheckForPhysicalDamage() {
		return checkForPhysicalDamage;
	}

	public void setCheckForPhysicalDamage(String checkForPhysicalDamage) {
		this.checkForPhysicalDamage = checkForPhysicalDamage;
	}

	public String getCheckForAnyAirLeakage() {
		return checkForAnyAirLeakage;
	}

	public void setCheckForAnyAirLeakage(String checkForAnyAirLeakage) {
		this.checkForAnyAirLeakage = checkForAnyAirLeakage;
	}

	public String getRollNewTeflonTapeInPUFitting() {
		return rollNewTeflonTapeInPUFitting;
	}

	public void setRollNewTeflonTapeInPUFitting(String rollNewTeflonTapeInPUFitting) {
		this.rollNewTeflonTapeInPUFitting = rollNewTeflonTapeInPUFitting;
	}

	public String getLubricateTheActuator() {
		return lubricateTheActuator;
	}

	public void setLubricateTheActuator(String lubricateTheActuator) {
		this.lubricateTheActuator = lubricateTheActuator;
	}

	public String getCleanAndCheckFeedbackSwitchCableTerminalTightness() {
		return cleanAndCheckFeedbackSwitchCableTerminalTightness;
	}

	public void setCleanAndCheckFeedbackSwitchCableTerminalTightness(
			String cleanAndCheckFeedbackSwitchCableTerminalTightness) {
		this.cleanAndCheckFeedbackSwitchCableTerminalTightness = cleanAndCheckFeedbackSwitchCableTerminalTightness;
	}

	public PreventiveMaintenanceChecklistFormData getChecklistFormData() {
		return checklistFormData;
	}

	public void setChecklistFormData(PreventiveMaintenanceChecklistFormData checklistFormData) {
		this.checklistFormData = checklistFormData;
	}

	
}
