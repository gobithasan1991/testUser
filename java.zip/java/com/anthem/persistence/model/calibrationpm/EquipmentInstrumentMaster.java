package com.anthem.persistence.model.calibrationpm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.asset.AssetMaster;
import com.anthem.persistence.model.asset.LocationMaster;
import com.anthem.persistence.model.common.Default;
import com.anthem.util.calibrationpm.AssetType;
import com.anthem.util.common.YesOrNoStatus;

@Entity
public class EquipmentInstrumentMaster extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -247112539585967358L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@NotEmpty(message = "Name is mandatory")
	private String name;
	
	@NotEmpty(message = "Code is mandatory")
	private String code;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('EQUIPMENT', 'INSTRUMENT')")
	private AssetType assetType;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.REMOVE)
	private AssetMaster assetMaster;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.REMOVE)
	private Department department;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.REMOVE)
	private LocationMaster location;
	
	private String make;
	
	private String modelName;
		
	private String serialNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date mfgDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date installDate;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO')")
	private YesOrNoStatus calibrationStatus;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO')")
	private YesOrNoStatus pmStatus;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private EquipmentInstrumentMaster parent;
		
	@Lob
	private String specialNotes;

	public EquipmentInstrumentMaster() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public AssetMaster getAssetMaster() {
		return assetMaster;
	}

	public void setAssetMaster(AssetMaster assetMaster) {
		this.assetMaster = assetMaster;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public LocationMaster getLocation() {
		return location;
	}

	public void setLocation(LocationMaster location) {
		this.location = location;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public Date getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	public Date getInstallDate() {
		return installDate;
	}

	public void setInstallDate(Date installDate) {
		this.installDate = installDate;
	}

	public YesOrNoStatus getCalibrationStatus() {
		return calibrationStatus;
	}

	public void setCalibrationStatus(YesOrNoStatus calibrationStatus) {
		this.calibrationStatus = calibrationStatus;
	}

	public YesOrNoStatus getPmStatus() {
		return pmStatus;
	}

	public void setPmStatus(YesOrNoStatus pmStatus) {
		this.pmStatus = pmStatus;
	}

	public EquipmentInstrumentMaster getParent() {
		return parent;
	}

	public void setParent(EquipmentInstrumentMaster parent) {
		this.parent = parent;
	}

	public AssetType getAssetType() {
		return assetType;
	}

	public void setAssetType(AssetType assetType) {
		this.assetType = assetType;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}
}