package com.anthem.persistence.model.calibrationpm;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class CalibrationChecklistResultSummaryData extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9066015170469537449L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Integer slno;
	
	private Double feedValue;
	
	private Double stdBufferValue;
	
	private Double uucValue;
	
	private Double multiMeterReading;
	
	private Double controlValveStemPos;
	
	private Double mastInstReading;
	
	private Double mastInstReadingAsc;
	
	private Double mastInstReadingDesc;
	
	private Double currOutput;
	
	private Double errObserved;
	
	private Double errObservedAsc;
	
	private Double errObservedDesc;
	
	private String inputApplied;
	
	private String acceptanceCriteria;
	
	private String actualResult;
	
	private String remarks;
	
	private String taskToBePerformed;
	
	private String inspectedOkOrNot;
	
	private String action;
	
	private String observation;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private CalibrationChecklistFormData checklistFormData;

	public CalibrationChecklistResultSummaryData(Long id) {
		super();
		this.id = id;
	}

	public CalibrationChecklistResultSummaryData() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getSlno() {
		return slno;
	}

	public void setSlno(Integer slno) {
		this.slno = slno;
	}

	public Double getFeedValue() {
		return feedValue;
	}

	public void setFeedValue(Double feedValue) {
		this.feedValue = feedValue;
	}

	public Double getStdBufferValue() {
		return stdBufferValue;
	}

	public void setStdBufferValue(Double stdBufferValue) {
		this.stdBufferValue = stdBufferValue;
	}

	public Double getUucValue() {
		return uucValue;
	}

	public void setUucValue(Double uucValue) {
		this.uucValue = uucValue;
	}

	public Double getMultiMeterReading() {
		return multiMeterReading;
	}

	public void setMultiMeterReading(Double multiMeterReading) {
		this.multiMeterReading = multiMeterReading;
	}

	public Double getControlValveStemPos() {
		return controlValveStemPos;
	}

	public void setControlValveStemPos(Double controlValveStemPos) {
		this.controlValveStemPos = controlValveStemPos;
	}

	public Double getMastInstReading() {
		return mastInstReading;
	}

	public void setMastInstReading(Double mastInstReading) {
		this.mastInstReading = mastInstReading;
	}

	public Double getMastInstReadingAsc() {
		return mastInstReadingAsc;
	}

	public void setMastInstReadingAsc(Double mastInstReadingAsc) {
		this.mastInstReadingAsc = mastInstReadingAsc;
	}

	public Double getMastInstReadingDesc() {
		return mastInstReadingDesc;
	}

	public void setMastInstReadingDesc(Double mastInstReadingDesc) {
		this.mastInstReadingDesc = mastInstReadingDesc;
	}

	public Double getCurrOutput() {
		return currOutput;
	}

	public void setCurrOutput(Double currOutput) {
		this.currOutput = currOutput;
	}

	public Double getErrObserved() {
		return errObserved;
	}

	public void setErrObserved(Double errObserved) {
		this.errObserved = errObserved;
	}

	public Double getErrObservedAsc() {
		return errObservedAsc;
	}

	public void setErrObservedAsc(Double errObservedAsc) {
		this.errObservedAsc = errObservedAsc;
	}

	public Double getErrObservedDesc() {
		return errObservedDesc;
	}

	public void setErrObservedDesc(Double errObservedDesc) {
		this.errObservedDesc = errObservedDesc;
	}

	public String getInputApplied() {
		return inputApplied;
	}

	public void setInputApplied(String inputApplied) {
		this.inputApplied = inputApplied;
	}

	public String getAcceptanceCriteria() {
		return acceptanceCriteria;
	}

	public void setAcceptanceCriteria(String acceptanceCriteria) {
		this.acceptanceCriteria = acceptanceCriteria;
	}

	public String getActualResult() {
		return actualResult;
	}

	public void setActualResult(String actualResult) {
		this.actualResult = actualResult;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getTaskToBePerformed() {
		return taskToBePerformed;
	}

	public void setTaskToBePerformed(String taskToBePerformed) {
		this.taskToBePerformed = taskToBePerformed;
	}

	public String getInspectedOkOrNot() {
		return inspectedOkOrNot;
	}

	public void setInspectedOkOrNot(String inspectedOkOrNot) {
		this.inspectedOkOrNot = inspectedOkOrNot;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getObservation() {
		return observation;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	public CalibrationChecklistFormData getChecklistFormData() {
		return checklistFormData;
	}

	public void setChecklistFormData(CalibrationChecklistFormData checklistFormData) {
		this.checklistFormData = checklistFormData;
	}
	
	
}
