package com.anthem.persistence.model.calibrationpm;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class CalibrationChecklistFormData extends Default{
	
	private static final long serialVersionUID = 2359369041584064807L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private CalibrationPlanner calibrationPlanner;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private CalibrationChecklist calibrationChecklist;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = CalibrationChecklistTopBottomData.class)
	@JoinColumn(name = "checklistFormData_id")
	private CalibrationChecklistTopBottomData topBottomData;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = CalibrationChecklistMasterInstData.class)
	@JoinColumn(name = "checklistFormData_id")
	private List<CalibrationChecklistMasterInstData> checklistMasterInstData;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = CalibrationChecklistResultSummaryData.class)
	@JoinColumn(name = "checklistFormData_id")
	private List<CalibrationChecklistResultSummaryData> checklistResultSummaryData;

	public CalibrationChecklistFormData() {
		super();
	}

	public CalibrationChecklistFormData(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public CalibrationPlanner getCalibrationPlanner() {
		return calibrationPlanner;
	}

	public void setCalibrationPlanner(CalibrationPlanner calibrationPlanner) {
		this.calibrationPlanner = calibrationPlanner;
	}

	public CalibrationChecklist getCalibrationChecklist() {
		return calibrationChecklist;
	}

	public void setCalibrationChecklist(CalibrationChecklist calibrationChecklist) {
		this.calibrationChecklist = calibrationChecklist;
	}

	public CalibrationChecklistTopBottomData getTopBottomData() {
		return topBottomData;
	}

	public void setTopBottomData(CalibrationChecklistTopBottomData topBottomData) {
		this.topBottomData = topBottomData;
	}

	public List<CalibrationChecklistMasterInstData> getChecklistMasterInstData() {
		return checklistMasterInstData;
	}

	public void setChecklistMasterInstData(List<CalibrationChecklistMasterInstData> checklistMasterInstData) {
		this.checklistMasterInstData = checklistMasterInstData;
	}

	public List<CalibrationChecklistResultSummaryData> getChecklistResultSummaryData() {
		return checklistResultSummaryData;
	}

	public void setChecklistResultSummaryData(List<CalibrationChecklistResultSummaryData> checklistResultSummaryData) {
		this.checklistResultSummaryData = checklistResultSummaryData;
	}
	
	
	
}
