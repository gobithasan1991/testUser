package com.anthem.persistence.model.calibrationpm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.calibrationpm.CalibrationPMStatus;

@Entity
public class PreventiveMaintenancePlanner extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8225008787898729093L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastDate;
	
	@Temporal(TemporalType.TIMESTAMP)	
	private Date nextDate;
	
	@Temporal(TemporalType.TIMESTAMP)	
	private Date plannedDate;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'PLANNED', 'COMPLETED') DEFAULT 'PENDING'")
	private CalibrationPMStatus pmStatus;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private PreventiveMaintenanceMaster preventiveMaintenanceMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private PreventiveMaintenanceChecklistDocumentTemplate documentTemplate;

	public PreventiveMaintenancePlanner() {
		super();
	}

	public PreventiveMaintenancePlanner(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getLastDate() {
		return lastDate;
	}

	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}

	public Date getNextDate() {
		return nextDate;
	}

	public void setNextDate(Date nextDate) {
		this.nextDate = nextDate;
	}

	public CalibrationPMStatus getPmStatus() {
		return pmStatus;
	}

	public void setPmStatus(CalibrationPMStatus pmStatus) {
		this.pmStatus = pmStatus;
	}

	public PreventiveMaintenanceMaster getPreventiveMaintenanceMaster() {
		return preventiveMaintenanceMaster;
	}

	public void setPreventiveMaintenanceMaster(PreventiveMaintenanceMaster preventiveMaintenanceMaster) {
		this.preventiveMaintenanceMaster = preventiveMaintenanceMaster;
	}

	public Date getPlannedDate() {
		return plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	public PreventiveMaintenanceChecklistDocumentTemplate getDocumentTemplate() {
		return documentTemplate;
	}

	public void setDocumentTemplate(PreventiveMaintenanceChecklistDocumentTemplate documentTemplate) {
		this.documentTemplate = documentTemplate;
	}
	
	
}
