package com.anthem.persistence.model.qc.login;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.qc.login.LoginStatus;
import com.anthem.util.qc.login.Option;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "software_id", "qcUserGroup_id", "qcInstrument_id",
		"requestFor_id", "branch_id", "requestOption" }))
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class QCLoginRequestSoftware extends Default {

	private static final long serialVersionUID = 6112624519347089689L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	private User requestFor;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	private Branch branch;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@NotNull(message = "Software cannot be empty.")
	private Software software;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@NotNull(message = "User Group cannot be empty.")
	private QCUserGroup qcUserGroup;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@NotNull(message = "Instrument cannot be empty.")
	private QCInstrument qcInstrument;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('NEWUSER', 'ROLECHANGE', 'DISABLEUSER','OTHERS') DEFAULT 'NEWUSER'")
	@NotNull(message = "Option cannot be empty.")
	private Option requestOption;

	private String others;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private QCLoginRequest qcLoginRequest;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('REQUESTED', 'DEPTAPPROVE', 'QAAPPROVE', 'ITLOGINPROCESS', 'ITLOGINVERIFICATION', 'USERACKNOWLEDGED', 'REJECTED') DEFAULT 'REQUESTED'", insertable = false)
	private LoginStatus loginStatus;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User deptApprovedBy;

	private Date deptApprovedDate;

	private String deptApproveComment;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User qaApprovedBy;

	private Date qaApprovedDate;

	private String qaApprovedComment;

	private String userId;

	private String comment;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User loginCreatedBy;

	private Date loginCreatedDate;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User loginReviewedBy;

	private Date loginReviewedDate;

	private String loginReviewedComment;

	private Date userAcceptanceDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QCUserGroup getQcUserGroup() {
		return qcUserGroup;
	}

	public void setQcUserGroup(QCUserGroup qcUserGroup) {
		this.qcUserGroup = qcUserGroup;
	}

	public QCInstrument getQcInstrument() {
		return qcInstrument;
	}

	public void setQcInstrument(QCInstrument qcInstrument) {
		this.qcInstrument = qcInstrument;
	}

	public Option getRequestOption() {
		return requestOption;
	}

	public void setRequestOption(Option requestOption) {
		this.requestOption = requestOption;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public QCLoginRequest getQcLoginRequest() {
		return qcLoginRequest;
	}

	public void setQcLoginRequest(QCLoginRequest qcLoginRequest) {
		this.qcLoginRequest = qcLoginRequest;
	}

	public LoginStatus getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(LoginStatus loginStatus) {
		this.loginStatus = loginStatus;
	}

	public User getDeptApprovedBy() {
		return deptApprovedBy;
	}

	public void setDeptApprovedBy(User deptApprovedBy) {
		this.deptApprovedBy = deptApprovedBy;
	}

	public Date getDeptApprovedDate() {
		return deptApprovedDate;
	}

	public void setDeptApprovedDate(Date deptApprovedDate) {
		this.deptApprovedDate = deptApprovedDate;
	}

	public User getQaApprovedBy() {
		return qaApprovedBy;
	}

	public void setQaApprovedBy(User qaApprovedBy) {
		this.qaApprovedBy = qaApprovedBy;
	}

	public Date getQaApprovedDate() {
		return qaApprovedDate;
	}

	public void setQaApprovedDate(Date qaApprovedDate) {
		this.qaApprovedDate = qaApprovedDate;
	}

	public User getLoginCreatedBy() {
		return loginCreatedBy;
	}

	public void setLoginCreatedBy(User loginCreatedBy) {
		this.loginCreatedBy = loginCreatedBy;
	}

	public Date getLoginCreatedDate() {
		return loginCreatedDate;
	}

	public void setLoginCreatedDate(Date loginCreatedDate) {
		this.loginCreatedDate = loginCreatedDate;
	}

	public User getLoginReviewedBy() {
		return loginReviewedBy;
	}

	public void setLoginReviewedBy(User loginReviewedBy) {
		this.loginReviewedBy = loginReviewedBy;
	}

	public Date getLoginReviewedDate() {
		return loginReviewedDate;
	}

	public void setLoginReviewedDate(Date loginReviewedDate) {
		this.loginReviewedDate = loginReviewedDate;
	}

	public Software getSoftware() {
		return software;
	}

	public void setSoftware(Software software) {
		this.software = software;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDeptApproveComment() {
		return deptApproveComment;
	}

	public void setDeptApproveComment(String deptApproveComment) {
		this.deptApproveComment = deptApproveComment;
	}

	public String getQaApprovedComment() {
		return qaApprovedComment;
	}

	public void setQaApprovedComment(String qaApprovedComment) {
		this.qaApprovedComment = qaApprovedComment;
	}

	public String getLoginReviewedComment() {
		return loginReviewedComment;
	}

	public void setLoginReviewedComment(String loginReviewedComment) {
		this.loginReviewedComment = loginReviewedComment;
	}

	public Date getUserAcceptanceDate() {
		return userAcceptanceDate;
	}

	public void setUserAcceptanceDate(Date userAcceptanceDate) {
		this.userAcceptanceDate = userAcceptanceDate;
	}

	public User getRequestFor() {
		return requestFor;
	}

	public void setRequestFor(User requestFor) {
		this.requestFor = requestFor;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

}
