package com.anthem.persistence.model.qc.login;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class QCLoginRequest extends Default {

	private static final long serialVersionUID = 8463547518185801652L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@NotNull(message = "Branch cannot be null")
	private Branch branch;

	@Column(unique = true)
	private String requestNo;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User requestFor;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = QCLoginRequestSoftware.class)
	@JoinColumn(name = "qCLoginRequest_id")
	@NotAudited
	private List<QCLoginRequestSoftware> loginRequestSoftwares;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public User getRequestFor() {
		return requestFor;
	}

	public void setRequestFor(User requestFor) {
		this.requestFor = requestFor;
	}

	public List<QCLoginRequestSoftware> getLoginRequestSoftwares() {
		return loginRequestSoftwares;
	}

	public void setLoginRequestSoftwares(List<QCLoginRequestSoftware> loginRequestSoftwares) {
		this.loginRequestSoftwares = loginRequestSoftwares;
	}

}
