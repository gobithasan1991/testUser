package com.anthem.persistence.model.qc.login;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "software_id", "department_id" }))
public class SoftwareDepartmentMapping extends Default {

	private static final long serialVersionUID = -5595393522710721230L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Software software;
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Department department;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Software getSoftware() {
		return software;
	}

	public void setSoftware(Software software) {
		this.software = software;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

}
