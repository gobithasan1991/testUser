package com.anthem.persistence.model.admin;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "emailConfiguration_id", "user_id" }))
public class DefaultBCC extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2751084066888252842L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade=CascadeType.REMOVE)
	private User user;

	@ManyToOne(fetch = FetchType.LAZY, cascade=CascadeType.REMOVE)
	private EmailConfiguration emailConfiguration;

	public Long getId() {
		return id;
	}

	public User getUser() {
		return user;
	}

	public EmailConfiguration getEmailConfiguration() {
		return emailConfiguration;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setEmailConfiguration(EmailConfiguration emailConfiguration) {
		this.emailConfiguration = emailConfiguration;
	}

}
