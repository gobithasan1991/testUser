package com.anthem.persistence.model.admin;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.anthem.persistence.model.common.Default;

@Entity
public class EmailConfiguration extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3767473645655422859L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSCategory moduleName;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = DefaultCC.class, cascade = { CascadeType.PERSIST,
			CascadeType.REMOVE, CascadeType.MERGE })
	@JoinColumn(name = "emailConfiguration_id")
	private List<DefaultCC> defaultCCs;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = DefaultCCOther.class, cascade = { CascadeType.PERSIST,
			CascadeType.REMOVE, CascadeType.MERGE })
	@JoinColumn(name = "emailConfiguration_id")
	private List<DefaultCCOther> defaultCCOthers;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = DefaultBCC.class, cascade = { CascadeType.PERSIST,
			CascadeType.REMOVE, CascadeType.MERGE })
	@JoinColumn(name = "emailConfiguration_id")
	private List<DefaultBCC> defaultBCCs;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = DefaultBCCOther.class, cascade = { CascadeType.PERSIST,
			CascadeType.REMOVE, CascadeType.MERGE })
	@JoinColumn(name = "emailConfiguration_id")
	private List<DefaultBCCOther> defaultBCCOthers;

	public Long getId() {
		return id;
	}

	public QMSCategory getModuleName() {
		return moduleName;
	}

	public List<DefaultCC> getDefaultCCs() {
		return defaultCCs;
	}

	public List<DefaultCCOther> getDefaultCCOthers() {
		return defaultCCOthers;
	}

	public List<DefaultBCC> getDefaultBCCs() {
		return defaultBCCs;
	}

	public List<DefaultBCCOther> getDefaultBCCOthers() {
		return defaultBCCOthers;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setModuleName(QMSCategory moduleName) {
		this.moduleName = moduleName;
	}

	public void setDefaultCCs(List<DefaultCC> defaultCCs) {
		this.defaultCCs = defaultCCs;
	}

	public void setDefaultCCOthers(List<DefaultCCOther> defaultCCOthers) {
		this.defaultCCOthers = defaultCCOthers;
	}

	public void setDefaultBCCs(List<DefaultBCC> defaultBCCs) {
		this.defaultBCCs = defaultBCCs;
	}

	public void setDefaultBCCOthers(List<DefaultBCCOther> defaultBCCOthers) {
		this.defaultBCCOthers = defaultBCCOthers;
	}

}
