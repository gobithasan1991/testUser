package com.anthem.persistence.model.admin;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
@Entity
public class SchedulerConfigurationDuration extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5902635451802175727L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private SchedulerConfiguration schedulerConfiguration;
	
	@NotNull(message ="Duration should not empty")
	private Long duration;

	/**
	 * 
	 */
	public SchedulerConfigurationDuration() {
		super();
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the schedulerConfiguration
	 */
	public SchedulerConfiguration getSchedulerConfiguration() {
		return schedulerConfiguration;
	}

	/**
	 * @param schedulerConfiguration the schedulerConfiguration to set
	 */
	public void setSchedulerConfiguration(SchedulerConfiguration schedulerConfiguration) {
		this.schedulerConfiguration = schedulerConfiguration;
	}

	/**
	 * @return the duration
	 */
	public Long getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(Long duration) {
		this.duration = duration;
	}
	
	
}
