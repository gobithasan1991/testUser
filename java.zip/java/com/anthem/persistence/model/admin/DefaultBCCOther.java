package com.anthem.persistence.model.admin;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"emailConfiguration_id", "emailId"}))
public class DefaultBCCOther extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2189741580731969969L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String emailId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private EmailConfiguration emailConfiguration;

	public Long getId() {
		return id;
	}

	public String getEmailId() {
		return emailId;
	}

	public EmailConfiguration getEmailConfiguration() {
		return emailConfiguration;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setEmailConfiguration(EmailConfiguration emailConfiguration) {
		this.emailConfiguration = emailConfiguration;
	}

}
