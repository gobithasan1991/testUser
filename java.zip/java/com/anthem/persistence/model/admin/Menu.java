package com.anthem.persistence.model.admin;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.admin.MenuType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Menu extends Default {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	
	private String menuName;

	@Column(unique=true, nullable=false) 
	private String menuState;

	private String menuUrl;

	private String menuTemplateUrl;

	private String menuTitle;

	private String menuClassName;

	private Integer menuOrder;

	@ManyToOne
	@JoinColumn(name = "menuParent")
	@JsonBackReference("menu_parent")
	private Menu menuParent;

	@OneToMany(mappedBy = "menuParent", fetch = FetchType.LAZY)
	private List<Menu> menuChildrens;

	@OneToOne(cascade = { CascadeType.REMOVE, CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JsonManagedReference(value = "menu_privilege_mapping")
	private Privilege privilege;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('TAB','MENU','BOTH','OTHER') DEFAULT 'MENU'")
	private MenuType menuType;

	/**
	 * 
	 */
	public Menu() {
		super();
	}

	/**
	 * @param id
	 */
	public Menu(Long id) {
		super();
		this.id = id;
	}

	/**
	 * @param menuName
	 * @param menuUrl
	 * @param menuTemplateUrl
	 */
	public Menu(String menuName, String menuUrl, String menuTemplateUrl) {
		super();
		this.menuName = menuName;
		this.menuUrl = menuUrl;
		this.menuTemplateUrl = menuTemplateUrl;
	}

	public String getMenuClassName() {
		return menuClassName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMenuName() {
		return menuName;
	}

	public Menu getMenuParent() {
		return menuParent;
	}

	public String getMenuState() {
		return menuState;
	}

	public String getMenuTemplateUrl() {
		return menuTemplateUrl;
	}

	public String getMenuTitle() {
		return menuTitle;
	}

	public MenuType getMenuType() {
		return menuType;
	}

	public String getMenuUrl() {
		return menuUrl;
	}

	public Privilege getPrivilege() {
		return privilege;
	}

	public void setMenuClassName(String menuClassName) {
		this.menuClassName = menuClassName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public void setMenuParent(Menu menuParent) {
		this.menuParent = menuParent;
	}

	public void setMenuState(String menuState) {
		this.menuState = menuState;
	}

	public void setMenuTemplateUrl(String menuTemplateUrl) {
		this.menuTemplateUrl = menuTemplateUrl;
	}

	public void setMenuTitle(String menuTitle) {
		this.menuTitle = menuTitle;
	}

	public void setMenuType(MenuType menuType) {
		this.menuType = menuType;
	}

	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}

	public void setPrivilege(Privilege privilege) {
		this.privilege = privilege;
	}

	public List<Menu> getMenuChildrens() {
		return menuChildrens;
	}

	public void setMenuChildrens(List<Menu> menuChildrens) {
		this.menuChildrens = menuChildrens;
	}

	public Integer getMenuOrder() {
		return menuOrder;
	}

	public void setMenuOrder(Integer menuOrder) {
		this.menuOrder = menuOrder;
	}

}
