package com.anthem.persistence.model.admin;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.EnabledStatus;

@Entity
public class MailModule extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5668977127369496965L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String name;
	
	@Column(unique = true)
	private String code;
	
	@ManyToOne
	private MailModule mailModuleParent;
	
	@OneToMany(mappedBy = "mailModuleParent", fetch = FetchType.LAZY)
	private List<MailModule> mailModuleChildrens;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('OPEN', 'CLOSED') DEFAULT 'CLOSED'", insertable = false)
	private EnabledStatus mailStatus;

	public MailModule() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public MailModule getMailModuleParent() {
		return mailModuleParent;
	}

	public void setMailModuleParent(MailModule mailModuleParent) {
		this.mailModuleParent = mailModuleParent;
	}

	public List<MailModule> getMailModuleChildrens() {
		return mailModuleChildrens;
	}

	public void setMailModuleChildrens(List<MailModule> mailModuleChildrens) {
		this.mailModuleChildrens = mailModuleChildrens;
	}

	public EnabledStatus getMailStatus() {
		return mailStatus;
	}

	public void setMailStatus(EnabledStatus mailStatus) {
		this.mailStatus = mailStatus;
	}	
	
}
