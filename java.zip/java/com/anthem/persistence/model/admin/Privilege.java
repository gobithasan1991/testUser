package com.anthem.persistence.model.admin;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.springframework.security.core.GrantedAuthority;

import com.anthem.persistence.model.common.Default;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Privilege extends Default implements GrantedAuthority {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long privilegeId;

	@Column(unique = true)
	private String authority;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonBackReference(value = "menu_privilege_mapping")
	private Menu menu;

	/**
	 * 
	 */
	public Privilege() {
		super();
	}

	/**
	 * @param privilegeId
	 */
	public Privilege(Long privilegeId) {
		super();
		this.privilegeId = privilegeId;
	}

	public Long getPrivilegeId() {
		return privilegeId;
	}

	public void setPrivilegeId(Long privilegeId) {
		this.privilegeId = privilegeId;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	@Override
	public String getAuthority() {
		return authority;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

}
