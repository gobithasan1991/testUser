package com.anthem.persistence.model.admin;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
@Entity
public class LoginPromtTimeInterval extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -959814193353063608L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message ="Idle time should not empty")
	private Long idleTime;
	
	@NotNull(message ="Timeout should not empty")
	private Long timeOut;
	
	@NotNull(message ="Keep alive should not empty")
	private Long keepAlive;
	
	@NotNull(message ="maximum login attempt should not empty")
	private int maxLoginAttempt;
	
	@NotNull(message ="type should not empty")
	@Column(length=255,unique=true)
	private String type;
	
	public LoginPromtTimeInterval() {
		super();
	}
	
	public LoginPromtTimeInterval(Long idleTime, Long timeOut, Long keepAlive, String type,int maxLoginAttempt) {
		super();
		this.idleTime = idleTime;
		this.timeOut = timeOut;
		this.keepAlive = keepAlive;
		this.type = type;
		this.maxLoginAttempt = maxLoginAttempt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdleTime() {
		return idleTime;
	}

	public void setIdleTime(Long idleTime) {
		this.idleTime = idleTime;
	}

	public Long getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(Long timeOut) {
		this.timeOut = timeOut;
	}

	public Long getKeepAlive() {
		return keepAlive;
	}

	public void setKeepAlive(Long keepAlive) {
		this.keepAlive = keepAlive;
	}

	public int getMaxLoginAttempt() {
		return maxLoginAttempt;
	}

	public void setMaxLoginAttempt(int maxLoginAttempt) {
		this.maxLoginAttempt = maxLoginAttempt;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	} 
	
}
