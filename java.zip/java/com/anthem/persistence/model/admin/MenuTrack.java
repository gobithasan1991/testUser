/**
 * 
 */
package com.anthem.persistence.model.admin;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.anthem.persistence.model.common.Default;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author kalaiselvan.a
 *
 */

@Entity
@Table(name = "menu_track")
@SuppressWarnings("serial")
public class MenuTrack extends Default implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	@JsonProperty
	private long id;

	@Column(name = "SessionId")
	@JsonProperty
	private String sessionId;

	@Column(name = "SessionUser")
	@JsonProperty
	private String sessionUser;

	@Column(name = "Title")
	@JsonProperty
	private String title;

	@Column(name = "Link")
	@JsonProperty
	private String link;

	@Column(name = "Ip")
	@JsonProperty
	private String ip;

	@Column(name = "TemplateUrl")
	private String templateUrl;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getSessionUser() {
		return sessionUser;
	}

	public void setSessionUser(String sessionUser) {
		this.sessionUser = sessionUser;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getTemplateUrl() {
		return templateUrl;
	}

	public void setTemplateUrl(String templateUrl) {
		this.templateUrl = templateUrl;
	}

}
