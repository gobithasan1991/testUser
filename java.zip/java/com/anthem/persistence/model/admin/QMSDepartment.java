package com.anthem.persistence.model.admin;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
//@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "department_id", "code", "name" }),
//		@UniqueConstraint(columnNames = { "code" }), @UniqueConstraint(columnNames = { "name" }) })
public class QMSDepartment extends Default {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Department department;
	@Column(unique = true)
	private String code;
	@Column(unique = true)
	private String name;
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Company company;

	public QMSDepartment() {
		super();
	}

	public QMSDepartment(long id) {
		super();
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QMSDepartment other = (QMSDepartment) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
