package com.anthem.persistence.model.admin;

import java.util.Collection;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.springframework.security.core.GrantedAuthority;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler", "createdBy" }, allowSetters = true)
public class Role extends Default implements GrantedAuthority {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(unique = true)
	private String authority;

	@ManyToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@JsonBackReference(value = "role_menu_mapping")
	private Set<Menu> menus;

	@ManyToMany(mappedBy = "authorities", fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@JsonBackReference(value = "user_role_mapping")
	private Collection<User> users;

	public Role() {
		super();
	}

	/**
	 * @param id
	 */
	public Role(Long id) {
		super();
		this.id = id;
	}

	/**
	 * @param authority
	 */
	public Role(String authority) {
		super();
		this.authority = authority;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	public Set<Menu> getMenus() {
		return menus;
	}

	public void setMenus(Set<Menu> menus) {
		this.menus = menus;
	}

	public Collection<User> getUsers() {
		return users;
	}

	public void setUsers(Collection<User> users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "Role [roleId=" + id + ", authority=" + authority + "]";
	}

}
