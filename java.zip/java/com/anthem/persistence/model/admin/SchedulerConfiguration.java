package com.anthem.persistence.model.admin;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.anthem.persistence.model.common.Default;

@Entity
public class SchedulerConfiguration extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -703032131109132938L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message="Module Name should not be null")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSCategory module;

	@NotEmpty(message="Scheduler configuration duration should not be empty")
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL,mappedBy="schedulerConfiguration")
	private List<SchedulerConfigurationDuration> schedulerConfigurationDurations;

	/**
	 * 
	 */
	public SchedulerConfiguration() {
		super();
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	

	/**
	 * @return the module
	 */
	public QMSCategory getModule() {
		return module;
	}

	/**
	 * @param module the module to set
	 */
	public void setModule(QMSCategory module) {
		this.module = module;
	}

	/**
	 * @return the schedulerConfigurationDurations
	 */
	public List<SchedulerConfigurationDuration> getSchedulerConfigurationDurations() {
		return schedulerConfigurationDurations;
	}

	/**
	 * @param schedulerConfigurationDurations the schedulerConfigurationDurations to set
	 */
	public void setSchedulerConfigurationDurations(List<SchedulerConfigurationDuration> schedulerConfigurationDurations) {
		this.schedulerConfigurationDurations = schedulerConfigurationDurations;
	}
	
	
	
}
