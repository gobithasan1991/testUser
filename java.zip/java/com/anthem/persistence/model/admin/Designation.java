package com.anthem.persistence.model.admin;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.anthem.persistence.model.common.Default;

@Entity
public class Designation extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6617252907710171203L;
	/**
	 * 
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;	

	public Designation() {
		super();
	}
	
	public Designation(long id) {
		super();
		this.id = id;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
