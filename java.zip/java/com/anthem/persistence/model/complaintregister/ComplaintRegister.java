package com.anthem.persistence.model.complaintregister;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.util.complaintregister.ComplaintAssignTo;
import com.anthem.util.complaintregister.ComplaintRegisterStatus;

@Entity
public class ComplaintRegister extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	
	@Column(unique = true, nullable = false)
	private String complaintRegisterNo; 
	
	@NotNull(message = "Branch should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private Branch branch;
	
	@NotNull(message = "Department should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private Department department;
	
	@NotNull(message = "Location should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintLocation location;
	
	@NotNull(message = "Asset category should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintAssetCategory assetCategory;
	
	@NotNull(message = "Asset should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintAssetMaster assetMaster;	
	
	@Column(unique = true)
	@NotBlank(message = "complaint should not be empty")
	@Lob
	private String natureOfComplaint;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus maintenanceWork;
	
	@NotNull(message = "complaint Receiving Department should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private QMSDepartment complaintReceivingDepartment;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('SELF','OTHERS')DEFAULT 'SELF'")
	private ComplaintAssignTo complaintAssignTo;
	
	@ManyToOne(cascade = CascadeType.REMOVE)
	private User complaintAssignedUser;	
	
	@ManyToOne(cascade = CascadeType.REMOVE)
	private User assignedBy;	
	
	@Temporal(TemporalType.TIMESTAMP) 
	private Date assignedDate;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus handOverForUse;	
	
	@Lob
	private String actionTaken;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('ACCEPTED', 'APPROVED', 'ASSIGNED', 'COMPLETED', 'REGISTERED', 'REVIEWED', 'VERIFIED')DEFAULT 'REGISTERED'")
	private ComplaintRegisterStatus complaintRegisterStatus;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	private User reviewedBy;
	
	@Temporal(TemporalType.TIMESTAMP) 
	private Date reviewedDate;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	private User approvedBy;
	
	@Temporal(TemporalType.TIMESTAMP) 
	private Date approvedDate;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	private User verifiedBy;
	
	@Temporal(TemporalType.TIMESTAMP) 
	private Date verifiedDate;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	private User acceptedBy;
	
	@Temporal(TemporalType.TIMESTAMP) 
	private Date acceptedDate;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "complaintRegister_id")
	private List<ComplaintRegisterItem> complaintRegisterItems;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getComplaintRegisterNo() {
		return complaintRegisterNo;
	}

	public void setComplaintRegisterNo(String complaintRegisterNo) {
		this.complaintRegisterNo = complaintRegisterNo;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public ComplaintLocation getLocation() {
		return location;
	}

	public void setLocation(ComplaintLocation location) {
		this.location = location;
	}

	public ComplaintAssetCategory getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(ComplaintAssetCategory assetCategory) {
		this.assetCategory = assetCategory;
	}

	public ComplaintAssetMaster getAssetMaster() {
		return assetMaster;
	}

	public void setAssetMaster(ComplaintAssetMaster assetMaster) {
		this.assetMaster = assetMaster;
	}

	public String getNatureOfComplaint() {
		return natureOfComplaint;
	}

	public void setNatureOfComplaint(String natureOfComplaint) {
		this.natureOfComplaint = natureOfComplaint;
	}

	public YesOrNoStatus getMaintenanceWork() {
		return maintenanceWork;
	}

	public void setMaintenanceWork(YesOrNoStatus maintenanceWork) {
		this.maintenanceWork = maintenanceWork;
	}

	public QMSDepartment getComplaintReceivingDepartment() {
		return complaintReceivingDepartment;
	}

	public void setComplaintReceivingDepartment(QMSDepartment complaintReceivingDepartment) {
		this.complaintReceivingDepartment = complaintReceivingDepartment;
	}

	public ComplaintAssignTo getComplaintAssignTo() {
		return complaintAssignTo;
	}

	public void setComplaintAssignTo(ComplaintAssignTo complaintAssignTo) {
		this.complaintAssignTo = complaintAssignTo;
	}

	public User getComplaintAssignedUser() {
		return complaintAssignedUser;
	}

	public void setComplaintAssignedUser(User complaintAssignedUser) {
		this.complaintAssignedUser = complaintAssignedUser;
	}
	
	public User getAssignedBy() {
		return assignedBy;
	}

	public void setAssignedBy(User assignedBy) {
		this.assignedBy = assignedBy;
	}

	public Date getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(Date assignedDate) {
		this.assignedDate = assignedDate;
	}

	public YesOrNoStatus getHandOverForUse() {
		return handOverForUse;
	}

	public void setHandOverForUse(YesOrNoStatus handOverForUse) {
		this.handOverForUse = handOverForUse;
	}	

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public ComplaintRegisterStatus getComplaintRegisterStatus() {
		return complaintRegisterStatus;
	}

	public void setComplaintRegisterStatus(ComplaintRegisterStatus complaintRegisterStatus) {
		this.complaintRegisterStatus = complaintRegisterStatus;
	}

	public User getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(User reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public Date getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public User getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(User verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public Date getVerifiedDate() {
		return verifiedDate;
	}

	public void setVerifiedDate(Date verifiedDate) {
		this.verifiedDate = verifiedDate;
	}

	public User getAcceptedBy() {
		return acceptedBy;
	}

	public void setAcceptedBy(User acceptedBy) {
		this.acceptedBy = acceptedBy;
	}

	public Date getAcceptedDate() {
		return acceptedDate;
	}

	public void setAcceptedDate(Date acceptedDate) {
		this.acceptedDate = acceptedDate;
	}

	public List<ComplaintRegisterItem> getComplaintRegisterItems() {
		return complaintRegisterItems;
	}

	public void setComplaintRegisterItems(List<ComplaintRegisterItem> complaintRegisterItems) {
		this.complaintRegisterItems = complaintRegisterItems;
	}	
}
