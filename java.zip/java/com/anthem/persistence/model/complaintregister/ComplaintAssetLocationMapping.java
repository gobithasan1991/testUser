package com.anthem.persistence.model.complaintregister;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;

@Entity
@Table(name = "com_asset_location_mapping")
public class ComplaintAssetLocationMapping extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Branch should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private Branch branch;
	
	@NotNull(message = "Department should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private Department department;
	
	@NotNull(message = "Asset category should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintAssetCategory assetCategory;
	
	@NotNull(message = "Equipment/Instrument should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintAssetMaster assetMaster;	
	
	@NotNull(message = "Location should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintLocation location;	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public ComplaintAssetCategory getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(ComplaintAssetCategory assetCategory) {
		this.assetCategory = assetCategory;
	}

	public ComplaintAssetMaster getAssetMaster() {
		return assetMaster;
	}

	public void setAssetMaster(ComplaintAssetMaster assetMaster) {
		this.assetMaster = assetMaster;
	}

	public ComplaintLocation getLocation() {
		return location;
	}

	public void setLocation(ComplaintLocation location) {
		this.location = location;
	}	
}
