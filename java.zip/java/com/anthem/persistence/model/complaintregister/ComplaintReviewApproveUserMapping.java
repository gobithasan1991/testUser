package com.anthem.persistence.model.complaintregister;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity 
@Table(name = "com_review_approve_user_mapping", uniqueConstraints = { @UniqueConstraint(columnNames = { "branch_id", "qmsDepartment_id", "user_id" , "reviewType"})})
public class ComplaintReviewApproveUserMapping extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;

	@NotNull(message="Branch shoult not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Branch branch;

	@NotNull(message="Department should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional=false)
	private QMSDepartment qmsDepartment;
	
	@NotNull(message="User should not be empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional=false) 
	private User user;
	
	@NotBlank(message="Review type should not be empty")
	private String reviewType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

}
