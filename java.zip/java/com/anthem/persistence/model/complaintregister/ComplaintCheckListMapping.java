package com.anthem.persistence.model.complaintregister;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;

@Entity
@Table(name = "com_checklist_mapping")
public class ComplaintCheckListMapping extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Department should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private Department department;
	
	@NotNull(message = "Checklist should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintCheckList checkList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public ComplaintCheckList getCheckList() {
		return checkList;
	}

	public void setCheckList(ComplaintCheckList checkList) {
		this.checkList = checkList;
	}	
}
