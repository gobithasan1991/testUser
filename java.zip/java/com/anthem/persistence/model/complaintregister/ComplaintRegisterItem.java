package com.anthem.persistence.model.complaintregister;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.complaintregister.ComplaintAction;

@Entity
public class ComplaintRegisterItem extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ComplaintRegister complaintRegister;
	
	@NotNull(message = "Checklist should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintCheckList checkList;
	
	@Enumerated(EnumType.STRING)
	@NotNull(message = "CheckList Action is Required")
	@Column(columnDefinition = "ENUM('YES','NO','NA')DEFAULT 'NA'")
	private ComplaintAction complaintAction;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ComplaintRegister getComplaintRegister() {
		return complaintRegister;
	}

	public void setComplaintRegister(ComplaintRegister complaintRegister) {
		this.complaintRegister = complaintRegister;
	}

	public ComplaintCheckList getCheckList() {
		return checkList;
	}

	public void setCheckList(ComplaintCheckList checkList) {
		this.checkList = checkList;
	}

	public ComplaintAction getComplaintAction() {
		return complaintAction;
	}

	public void setComplaintAction(ComplaintAction complaintAction) {
		this.complaintAction = complaintAction;
	}
}
