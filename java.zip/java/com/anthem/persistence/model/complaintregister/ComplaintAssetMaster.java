package com.anthem.persistence.model.complaintregister;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;

@Entity
@Table(name = "com_asset_master")
public class ComplaintAssetMaster extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@NotNull(message = "Asset category should not be empty")
	@ManyToOne(cascade = CascadeType.REMOVE)
	private ComplaintAssetCategory assetCategory;
	
	@Column(unique = true)
	private String code;
	
	private String name;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public ComplaintAssetCategory getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(ComplaintAssetCategory assetCategory) {
		this.assetCategory = assetCategory;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
}
