package com.anthem.persistence.model.hr;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.util.training.TrainingDocumentStatus;

@Entity
public class Induction extends Default{

	/**
	 * @author gobithasan.s
	 */
	private static final long serialVersionUID = -4987548483891933330L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Branch is Should not Empty")
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Set<Branch> branches;
	
	@NotNull(message = "Induction month is Should not Empty")
	@Temporal(TemporalType.DATE)
	private Date dateOfJoinFrom;
	
	@NotNull(message = "Induction month is Should not Empty")
	@Temporal(TemporalType.DATE)
	private Date dateOfJoinTo;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','MAPPED','COMPLETED','PARTIALLYCOMPLETED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus inductionTrainingStatus;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy="induction")
	private List<InductionSession> inductionSessions;

	public Induction() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	} 
	
	public Set<Branch> getBranches() {
		return branches;
	}

	public void setBranches(Set<Branch> branches) {
		this.branches = branches;
	}

	public Date getDateOfJoinFrom() {
		return dateOfJoinFrom;
	}

	public void setDateOfJoinFrom(Date dateOfJoinFrom) {
		this.dateOfJoinFrom = dateOfJoinFrom;
	}

	public Date getDateOfJoinTo() {
		return dateOfJoinTo;
	}

	public void setDateOfJoinTo(Date dateOfJoinTo) {
		this.dateOfJoinTo = dateOfJoinTo;
	}

	public TrainingDocumentStatus getInductionTrainingStatus() {
		return inductionTrainingStatus;
	}

	public void setInductionTrainingStatus(TrainingDocumentStatus inductionTrainingStatus) {
		this.inductionTrainingStatus = inductionTrainingStatus;
	}

	public List<InductionSession> getInductionSessions() {
		return inductionSessions;
	}

	public void setInductionSessions(List<InductionSession> inductionSessions) {
		this.inductionSessions = inductionSessions;
	} 
	
}
