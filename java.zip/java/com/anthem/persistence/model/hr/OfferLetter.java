package com.anthem.persistence.model.hr;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Company;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.admin.Employee;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.hr.GenderList;
import com.anthem.util.login.LoginRequestStatus;

@Entity
public class OfferLetter extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1919562218339641459L;

	@Id
	private Long id;

	@Column(nullable = false)
	private String firstName;

	private String lastName;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('MALE', 'FEMALE')")
	private GenderList gender;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Company company;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Department department;

	private String reportUnit;

	@Lob
	private String address;

	private String designation;

	private Double ctc;

	@Temporal(TemporalType.TIMESTAMP)
	private Date offerDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date joinDate;

	private String contactNo;

	@Lob
	private String email;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Employee approvedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approvedDate;

	private String ltrref;

	@Lob
	private String preMedicalFile;

	@Lob
	private String offerLetterFile;

	private String mailStatus;

	@Column(unique = true, nullable = false)
	private String accessCode;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'REQUESTED') DEFAULT 'PENDING'", insertable=false)
	private LoginRequestStatus loginRequestStatus;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User declinedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date declinedDate;
	
	@Lob
	private String reason;

	public Long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Company getCompany() {
		return company;
	}

	public Department getDepartment() {
		return department;
	}

	public String getReportUnit() {
		return reportUnit;
	}

	public String getAddress() {
		return address;
	}

	public String getDesignation() {
		return designation;
	}

	public Double getCtc() {
		return ctc;
	}

	public Date getOfferDate() {
		return offerDate;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public String getContactNo() {
		return contactNo;
	}

	public String getEmail() {
		return email;
	}

	public Employee getApprovedBy() {
		return approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public String getLtrref() {
		return ltrref;
	}

	public String getPreMedicalFile() {
		return preMedicalFile;
	}

	public String getOfferLetterFile() {
		return offerLetterFile;
	}

	public String getMailStatus() {
		return mailStatus;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setReportUnit(String reportUnit) {
		this.reportUnit = reportUnit;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setCtc(Double ctc) {
		this.ctc = ctc;
	}

	public void setOfferDate(Date offerDate) {
		this.offerDate = offerDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setApprovedBy(Employee approvedBy) {
		this.approvedBy = approvedBy;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public void setLtrref(String ltrref) {
		this.ltrref = ltrref;
	}

	public void setPreMedicalFile(String preMedicalFile) {
		this.preMedicalFile = preMedicalFile;
	}

	public void setOfferLetterFile(String offerLetterFile) {
		this.offerLetterFile = offerLetterFile;
	}

	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}

	public String getAccessCode() {
		return accessCode;
	}

	public void setAccessCode(String accessCode) {
		this.accessCode = accessCode;
	}

	public LoginRequestStatus getLoginRequestStatus() {
		return loginRequestStatus;
	}

	public void setLoginRequestStatus(LoginRequestStatus loginRequestStatus) {
		this.loginRequestStatus = loginRequestStatus;
	}

	public GenderList getGender() {
		return gender;
	}

	public void setGender(GenderList gender) {
		this.gender = gender;
	}

	public User getDeclinedBy() {
		return declinedBy;
	}

	public Date getDeclinedDate() {
		return declinedDate;
	}

	public String getReason() {
		return reason;
	}

	public void setDeclinedBy(User declinedBy) {
		this.declinedBy = declinedBy;
	}

	public void setDeclinedDate(Date declinedDate) {
		this.declinedDate = declinedDate;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
