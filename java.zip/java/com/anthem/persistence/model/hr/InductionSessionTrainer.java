package com.anthem.persistence.model.hr;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingDocumentStatus;

@Entity
public class InductionSessionTrainer extends Default{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 980625267534502656L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Trainer department should not empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSDepartment trainerDepartment;
	
	@NotNull(message = "Trainer should not empty")
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User user;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','AVAILABLE','PARTIALLYCOMPLETED','COMPLETED','REJECTED') DEFAULT 'PENDING'",nullable = false , insertable = false)
	private TrainingDocumentStatus inductionTrainerStatus;
	
	@NotNull(message = "Induction Session should not empty")
	@ManyToOne(fetch = FetchType.LAZY, optional = false)  
	private InductionSession inductionSession;

	@NotNull(message = "Trainer type should not empty")
	@Column(columnDefinition = "boolean default true",nullable = false)
	private boolean primaryTrainer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QMSDepartment getTrainerDepartment() {
		return trainerDepartment;
	}

	public void setTrainerDepartment(QMSDepartment trainerDepartment) {
		this.trainerDepartment = trainerDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public TrainingDocumentStatus getInductionTrainerStatus() {
		return inductionTrainerStatus;
	}

	public void setInductionTrainerStatus(TrainingDocumentStatus inductionTrainerStatus) {
		this.inductionTrainerStatus = inductionTrainerStatus;
	}

	public InductionSession getInductionSession() {
		return inductionSession;
	}

	public void setInductionSession(InductionSession inductionSession) {
		this.inductionSession = inductionSession;
	}

	public boolean isPrimaryTrainer() {
		return primaryTrainer;
	}

	public void setPrimaryTrainer(boolean primaryTrainer) {
		this.primaryTrainer = primaryTrainer;
	}
	
}
