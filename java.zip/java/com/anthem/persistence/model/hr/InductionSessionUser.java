package com.anthem.persistence.model.hr;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.Employee;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.training.TrainingDocumentStatus;

@Entity
public class InductionSessionUser extends Default{

	/**
	 * @author gobithasan.s
	 */
	private static final long serialVersionUID = -7345348596018360882L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional = true)
	private User user;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE, optional = false)
	@NotNull(message = "Employee is Should not Null")
	private Employee employee;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','COMPLETED','PARTIALLYCOMPLETED','REJECTED','MISSED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus inductionTrainingStatus;
	
	@NotNull(message = "Induction Session should not empty")
	@ManyToOne(fetch = FetchType.LAZY, optional = false)  
	private InductionSession inductionSession;

	public InductionSessionUser() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public TrainingDocumentStatus getInductionTrainingStatus() {
		return inductionTrainingStatus;
	}

	public void setInductionTrainingStatus(TrainingDocumentStatus inductionTrainingStatus) {
		this.inductionTrainingStatus = inductionTrainingStatus;
	}

	public InductionSession getInductionSession() {
		return inductionSession;
	}

	public void setInductionSession(InductionSession inductionSession) {
		this.inductionSession = inductionSession;
	}
	
	
}
