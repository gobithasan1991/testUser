package com.anthem.persistence.model.hr;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.document.DocumentMapping;
import com.anthem.persistence.model.training.TrainingPlace;
import com.anthem.persistence.model.training.TrainingScheduler;
import com.anthem.util.training.TrainingDocumentStatus;

@Entity
public class InductionSession extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3784489093282805578L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Session title should not empty")
	private String sessionTitle;

	@NotNull(message = "Department Should not Null")
	@ManyToOne(fetch = FetchType.LAZY,optional=false)
	private QMSDepartment qmsDepartment;

	@NotNull(message = "Start Time Should not Null")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startTime;

	@NotNull(message = "End Time Should not Null")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endTime; 
	
	@NotNull(message = "Induction should not empty")
	@ManyToOne(fetch = FetchType.LAZY,optional=false)  
	private Induction induction;
	
	@ManyToOne(fetch = FetchType.LAZY,optional=true)  
	private Document document;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional = true) 
	private Branch trainingBranch;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE,optional = true) 
	private TrainingPlace trainingPlace;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private DocumentMapping documentMapping;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','MAPPED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus inductionTrainerStatus;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','MAPPED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus inductionUserStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','COMPLETED','PARTIALLYCOMPLETED') DEFAULT 'PENDING'", insertable = false)
	private TrainingDocumentStatus inductionTrainingStatus;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy="inductionSession")
	private List<InductionSessionUser> inductionSessionUsers;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy="inductionSession")
	private List<InductionSessionTrainer> inductionSessionTrainers; 
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private TrainingScheduler trainingScheduler;

	public InductionSession() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSessionTitle() {
		return sessionTitle;
	}

	public void setSessionTitle(String sessionTitle) {
		this.sessionTitle = sessionTitle;
	}

	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Induction getInduction() {
		return induction;
	}

	public void setInduction(Induction induction) {
		this.induction = induction;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public Branch getTrainingBranch() {
		return trainingBranch;
	}

	public void setTrainingBranch(Branch trainingBranch) {
		this.trainingBranch = trainingBranch;
	}

	public TrainingPlace getTrainingPlace() {
		return trainingPlace;
	}

	public void setTrainingPlace(TrainingPlace trainingPlace) {
		this.trainingPlace = trainingPlace;
	}

	public DocumentMapping getDocumentMapping() {
		return documentMapping;
	}

	public void setDocumentMapping(DocumentMapping documentMapping) {
		this.documentMapping = documentMapping;
	}

	public TrainingDocumentStatus getInductionTrainerStatus() {
		return inductionTrainerStatus;
	}

	public void setInductionTrainerStatus(TrainingDocumentStatus inductionTrainerStatus) {
		this.inductionTrainerStatus = inductionTrainerStatus;
	}

	public TrainingDocumentStatus getInductionUserStatus() {
		return inductionUserStatus;
	}

	public void setInductionUserStatus(TrainingDocumentStatus inductionUserStatus) {
		this.inductionUserStatus = inductionUserStatus;
	}

	public TrainingDocumentStatus getInductionTrainingStatus() {
		return inductionTrainingStatus;
	}

	public void setInductionTrainingStatus(TrainingDocumentStatus inductionTrainingStatus) {
		this.inductionTrainingStatus = inductionTrainingStatus;
	}

	public List<InductionSessionUser> getInductionSessionUsers() {
		return inductionSessionUsers;
	}

	public void setInductionSessionUsers(List<InductionSessionUser> inductionSessionUsers) {
		this.inductionSessionUsers = inductionSessionUsers;
	}

	public List<InductionSessionTrainer> getInductionSessionTrainers() {
		return inductionSessionTrainers;
	}

	public void setInductionSessionTrainers(List<InductionSessionTrainer> inductionSessionTrainers) {
		this.inductionSessionTrainers = inductionSessionTrainers;
	}

	public TrainingScheduler getTrainingScheduler() {
		return trainingScheduler;
	}

	public void setTrainingScheduler(TrainingScheduler trainingScheduler) {
		this.trainingScheduler = trainingScheduler;
	} 
	
}
