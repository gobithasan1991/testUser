package com.anthem.persistence.model.evaluation;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.document.DocumentTemplateCategory;
import com.anthem.util.evaluation.QuestionBankStatus;

@Entity
public class QuestionBank extends Default {

	/**
	 * @author prabhakaran.k
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QMSDepartment qmsDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DocumentTemplateCategory documentTemplateCategory;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Document document;

	@NotNull(message = "Please Enter Time Duration")
	private Integer timeDuration;

	@NotNull(message = "Please Enter no of Questins")
	private Integer noOfQuestions;

	@NotNull(message = "Plase Enter Total Marks")
	private double totalMarks;

	@NotNull(message = "Please Enter Pass Mark")
	private double passmarks;

	@Column(columnDefinition = "text")
	private String instructions;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = QuestionBankItem.class)
	@JoinColumn(name = "questionbank_id")
	private List<QuestionBankItem> questionBankItem;

	@Column(columnDefinition = "boolean default false", insertable = false)
	private boolean reviewApproveMapStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','REVIEWED','APPROVED','REJECTED') DEFAULT 'PENDING'", insertable = false)
	private QuestionBankStatus questionBankStatus;

	@Transient
	private String questionOption;

	public QuestionBank() {
		super();
	}

	

	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public QMSDepartment getQmsDepartment() {
		return qmsDepartment;
	}

	public void setQmsDepartment(QMSDepartment qmsDepartment) {
		this.qmsDepartment = qmsDepartment;
	}

	public DocumentTemplateCategory getDocumentTemplateCategory() {
		return documentTemplateCategory;
	}

	public void setDocumentTemplateCategory(DocumentTemplateCategory documentTemplateCategory) {
		this.documentTemplateCategory = documentTemplateCategory;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public Integer getTimeDuration() {
		return timeDuration;
	}

	public void setTimeDuration(Integer timeDuration) {
		this.timeDuration = timeDuration;
	}

	public Integer getNoOfQuestions() {
		return noOfQuestions;
	}

	public void setNoOfQuestions(Integer noOfQuestions) {
		this.noOfQuestions = noOfQuestions;
	}

	public double getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(double totalMarks) {
		this.totalMarks = totalMarks;
	}

	public double getPassmarks() {
		return passmarks;
	}

	public void setPassmarks(double passmarks) {
		this.passmarks = passmarks;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public List<QuestionBankItem> getQuestionBankItem() {
		return questionBankItem;
	}

	public void setQuestionBankItem(List<QuestionBankItem> questionBankItem) {
		this.questionBankItem = questionBankItem;
	}

	public boolean isReviewApproveMapStatus() {
		return reviewApproveMapStatus;
	}

	public void setReviewApproveMapStatus(boolean reviewApproveMapStatus) {
		this.reviewApproveMapStatus = reviewApproveMapStatus;
	}

	public QuestionBankStatus getQuestionBankStatus() {
		return questionBankStatus;
	}

	public void setQuestionBankStatus(QuestionBankStatus questionBankStatus) {
		this.questionBankStatus = questionBankStatus;
	}

	public String getQuestionOption() {
		return questionOption;
	}

	public void setQuestionOption(String questionOption) {
		this.questionOption = questionOption;
	}

}
