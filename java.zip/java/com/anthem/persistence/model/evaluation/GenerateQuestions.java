/**
 * 
 */
package com.anthem.persistence.model.evaluation;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;

/**
 * @author prabhakaran.k
 *
 */
@Entity
public class GenerateQuestions extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Document document;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QuestionBankItem questionBankItem;

	@Column(columnDefinition = "varchar(255) default 'Pending'", insertable = false)
	private String answeredStatus;

	@Column(columnDefinition = "boolean default false", insertable = false)
	private boolean mark;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private EvaluationAndEmployeeMapping evaluationAndEmployeeMapping;

	private String answeredByUser;

	public GenerateQuestions() {
		super();
	}

	
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public QuestionBankItem getQuestionBankItem() {
		return questionBankItem;
	}

	public void setQuestionBankItem(QuestionBankItem questionBankItem) {
		this.questionBankItem = questionBankItem;
	}

	public String getAnsweredStatus() {
		return answeredStatus;
	}

	public void setAnsweredStatus(String answeredStatus) {
		this.answeredStatus = answeredStatus;
	}

	public boolean isMark() {
		return mark;
	}

	public void setMark(boolean mark) {
		this.mark = mark;
	}

	public EvaluationAndEmployeeMapping getEvaluationAndEmployeeMapping() {
		return evaluationAndEmployeeMapping;
	}

	public void setEvaluationAndEmployeeMapping(EvaluationAndEmployeeMapping evaluationAndEmployeeMapping) {
		this.evaluationAndEmployeeMapping = evaluationAndEmployeeMapping;
	}

	public String getAnsweredByUser() {
		return answeredByUser;
	}

	public void setAnsweredByUser(String answeredByUser) {
		this.answeredByUser = answeredByUser;
	}

}
