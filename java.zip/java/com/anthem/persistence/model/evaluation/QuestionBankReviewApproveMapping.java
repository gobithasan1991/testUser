/**
 * 
 */
package com.anthem.persistence.model.evaluation;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.evaluation.QuestionBankStatus;

/**
 * @author prabhakaran.k
 *
 */
@Entity
public class QuestionBankReviewApproveMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private QuestionBank questionBank;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@NotNull(message = "User Should not Null")
	private User user;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('REVIEW','APPROVE') DEFAULT 'REVIEW'")
	private QuestionBankStatus reviewApproveType;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING','REVIEWED','APPROVED','REJECTED') DEFAULT 'PENDING'")
	private QuestionBankStatus reviewApproveStatus;

	private int prioritylevels;

	@Temporal(TemporalType.DATE)
	private Date reviewApproveDate;

	private String reviewApproveSpecialNotes;

	public QuestionBankReviewApproveMapping() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QuestionBank getQuestionBank() {
		return questionBank;
	}

	public void setQuestionBank(QuestionBank questionBank) {
		this.questionBank = questionBank;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public QuestionBankStatus getReviewApproveType() {
		return reviewApproveType;
	}

	public void setReviewApproveType(QuestionBankStatus reviewApproveType) {
		this.reviewApproveType = reviewApproveType;
	}

	public QuestionBankStatus getReviewApproveStatus() {
		return reviewApproveStatus;
	}

	public void setReviewApproveStatus(QuestionBankStatus reviewApproveStatus) {
		this.reviewApproveStatus = reviewApproveStatus;
	}

	public int getPrioritylevels() {
		return prioritylevels;
	}

	public void setPrioritylevels(int prioritylevels) {
		this.prioritylevels = prioritylevels;
	}

	public Date getReviewApproveDate() {
		return reviewApproveDate;
	}

	public void setReviewApproveDate(Date reviewApproveDate) {
		this.reviewApproveDate = reviewApproveDate;
	}

	public String getReviewApproveSpecialNotes() {
		return reviewApproveSpecialNotes;
	}

	public void setReviewApproveSpecialNotes(String reviewApproveSpecialNotes) {
		this.reviewApproveSpecialNotes = reviewApproveSpecialNotes;
	}
	
	

}
