/**
 * 
 */
package com.anthem.persistence.model.evaluation;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.training.TrainingPlannerDocument;
import com.anthem.persistence.model.user.User;
import com.anthem.util.evaluation.EvaluationStatus;

/**
 * @author prabhakaran.k
 *
 */
@Entity
public class EvaluationAndEmployeeMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Document document;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User user;

	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Temporal(TemporalType.DATE)
	private Date endDate;

	private Integer timeDuration;

	private Integer noOfQuestions;
	@Column(columnDefinition = "double default 0", insertable = false)
	private double totalMarks;
	@Column(columnDefinition = "double default 0", insertable = false)
	private double passmarks;

	private Integer scoredMark;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('UPCOMING' , 'COMPLETED', 'MISSED','CANCELLED') DEFAULT 'UPCOMING'")
	private EvaluationStatus evaluationStatus;

	@Column(columnDefinition = "boolean default false", insertable = false)
	private boolean result;

	@Temporal(TemporalType.TIMESTAMP)
	private Date evaluationStartDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date evaluationEndDate;

	private Long remainingTime;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private TrainingPlannerDocument trainingPlannerDocument;

	private String docCurrentVersionNo;

	public TrainingPlannerDocument getTrainingPlannerDocument() {
		return trainingPlannerDocument;
	}

	public void setTrainingPlannerDocument(TrainingPlannerDocument trainingPlannerDocument) {
		this.trainingPlannerDocument = trainingPlannerDocument;
	}

	public EvaluationAndEmployeeMapping() {
		super();

	}

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getTimeDuration() {
		return timeDuration;
	}

	public void setTimeDuration(Integer timeDuration) {
		this.timeDuration = timeDuration;
	}

	public Integer getNoOfQuestions() {
		return noOfQuestions;
	}

	public void setNoOfQuestions(Integer noOfQuestions) {
		this.noOfQuestions = noOfQuestions;
	}

	public double getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(double totalMarks) {
		this.totalMarks = totalMarks;
	}

	public double getPassmarks() {
		return passmarks;
	}

	public void setPassmarks(double passmarks) {
		this.passmarks = passmarks;
	}

	public Integer getScoredMark() {
		return scoredMark;
	}

	public void setScoredMark(Integer scoredMark) {
		this.scoredMark = scoredMark;
	}

	public EvaluationStatus getEvaluationStatus() {
		return evaluationStatus;
	}

	public void setEvaluationStatus(EvaluationStatus evaluationStatus) {
		this.evaluationStatus = evaluationStatus;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public Date getEvaluationStartDate() {
		return evaluationStartDate;
	}

	public void setEvaluationStartDate(Date evaluationStartDate) {
		this.evaluationStartDate = evaluationStartDate;
	}

	public Date getEvaluationEndDate() {
		return evaluationEndDate;
	}

	public void setEvaluationEndDate(Date evaluationEndDate) {
		this.evaluationEndDate = evaluationEndDate;
	}

	public Long getRemainingTime() {
		return remainingTime;
	}

	public void setRemainingTime(Long remainingTime) {
		this.remainingTime = remainingTime;
	}

	public String getDocCurrentVersionNo() {
		return docCurrentVersionNo;
	}

	public void setDocCurrentVersionNo(String docCurrentVersionNo) {
		this.docCurrentVersionNo = docCurrentVersionNo;
	}

}
