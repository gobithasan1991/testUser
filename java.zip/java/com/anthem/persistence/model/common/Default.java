package com.anthem.persistence.model.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.anthem.persistence.model.user.User;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.RecordStatus;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class Default implements Serializable {

	private static final long serialVersionUID = 1L;
	@CreatedBy
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(updatable = false)
	private User createdBy;

	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Column(updatable = false)
	private Date createdDate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('OPEN', 'ONHOLD', 'CLOSED') DEFAULT 'OPEN'")
	private EnabledStatus enabledStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('CREATED', 'MODIFIED', 'DELETED') DEFAULT 'CREATED'")
	private RecordStatus recordStatus;

	@LastModifiedBy
	@ManyToOne(fetch = FetchType.LAZY)
	private User modifiedBy;

	@LastModifiedDate
	@Temporal(TemporalType.TIMESTAMP)
	@ColumnDefault(value = "CURRENT_TIMESTAMP")
	private Date modifiedDate;

	@ColumnDefault(value = "1")
	@Column(columnDefinition = "Integer default '1'")
	private int versionNumber;

	@Column(columnDefinition = "boolean default true")
	private boolean enabled;

	private Long revNo;

	@Lob
	private String specialNotes;

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@PrePersist
	public void makeDefaultEnabledTrue() {
		this.enabled = true;
		this.enabledStatus = EnabledStatus.OPEN;
		this.recordStatus = RecordStatus.CREATED;
		if(this.versionNumber == 0)
			this.versionNumber = 1;
	}

	public EnabledStatus getEnabledStatus() {
		return enabledStatus;
	}

	public void setEnabledStatus(EnabledStatus enabledStatus) {
		this.enabledStatus = enabledStatus;
	}

	public RecordStatus getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(RecordStatus recordStatus) {
		this.recordStatus = recordStatus;
	}

	public User getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(User modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public Long getRevNo() {
		return revNo;
	}

	public void setRevNo(Long revNo) {
		this.revNo = revNo;
	}

}
