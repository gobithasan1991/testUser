package com.anthem.persistence.model.anthemerp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.common.Default;

@Entity
public class Product extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5908528600378826169L;

	@Id
	private Long id;
	
	@NotBlank(message = "name should not be empty")
	private String name;
	
	@Column(unique = true)
	@NotBlank(message = "code should not be empty")
	private String code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	
}
