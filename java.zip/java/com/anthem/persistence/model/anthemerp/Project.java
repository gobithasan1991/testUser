package com.anthem.persistence.model.anthemerp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


import com.anthem.persistence.model.common.Default;

@Entity
public class Project extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2601508102394136566L;

	@Id
	private Long id;	
	
	private String name;
	
	@Column(unique = true)	
	private String code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	
}
