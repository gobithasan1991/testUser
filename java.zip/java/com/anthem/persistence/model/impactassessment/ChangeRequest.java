package com.anthem.persistence.model.impactassessment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.util.impactassessment.ChangeRequestStatus;

@Entity
public class ChangeRequest extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2773392988675114058L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	private Module module;

	@ManyToOne
	private SubModule subModule;

	@Lob
	private String currentStatus;

	@Lob
	private String proposedChange;

	@Lob
	private String justification;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'REVIEWED', 'PARTIALLY_REVIEWED', 'APPROVED', 'PARTIALLY_APPROVED', 'REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ChangeRequestStatus changeRequestStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'", insertable = false)
	private YesOrNoStatus changeRequestITCreatedStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Module getModule() {
		return module;
	}

	public void setModule(Module module) {
		this.module = module;
	}

	public SubModule getSubModule() {
		return subModule;
	}

	public void setSubModule(SubModule subModule) {
		this.subModule = subModule;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getProposedChange() {
		return proposedChange;
	}

	public void setProposedChange(String proposedChange) {
		this.proposedChange = proposedChange;
	}

	public String getJustification() {
		return justification;
	}

	public void setJustification(String justification) {
		this.justification = justification;
	}

	public ChangeRequestStatus getChangeRequestStatus() {
		return changeRequestStatus;
	}

	public void setChangeRequestStatus(ChangeRequestStatus changeRequestStatus) {
		this.changeRequestStatus = changeRequestStatus;
	}

	public YesOrNoStatus getChangeRequestITCreatedStatus() {
		return changeRequestITCreatedStatus;
	}

	public void setChangeRequestITCreatedStatus(YesOrNoStatus changeRequestITCreatedStatus) {
		this.changeRequestITCreatedStatus = changeRequestITCreatedStatus;
	}

}
