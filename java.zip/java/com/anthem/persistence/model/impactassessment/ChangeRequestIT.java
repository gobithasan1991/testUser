package com.anthem.persistence.model.impactassessment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.impactassessment.ChangeRequestStatus;

@Entity
public class ChangeRequestIT extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3206801505753176429L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToOne
	private ChangeRequest changeRequest;

	@Lob
	private String impactAnalysis;
	@Lob
	private String modulesImpacted;
	@Lob
	private String specialNotes;

	private String developmentHours;

	private String testingHours;

	private String associatedEngineers;

	private String targetDate;

	private String completedDate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'REVIEWED', 'PARTIALLY_REVIEWED', 'APPROVED', 'PARTIALLY_APPROVED', 'REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ChangeRequestStatus changeRequestITStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ChangeRequest getChangeRequest() {
		return changeRequest;
	}

	public void setChangeRequest(ChangeRequest changeRequest) {
		this.changeRequest = changeRequest;
	}

	public String getImpactAnalysis() {
		return impactAnalysis;
	}

	public void setImpactAnalysis(String impactAnalysis) {
		this.impactAnalysis = impactAnalysis;
	}

	public String getModulesImpacted() {
		return modulesImpacted;
	}

	public void setModulesImpacted(String modulesImpacted) {
		this.modulesImpacted = modulesImpacted;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public String getDevelopmentHours() {
		return developmentHours;
	}

	public void setDevelopmentHours(String developmentHours) {
		this.developmentHours = developmentHours;
	}

	public String getTestingHours() {
		return testingHours;
	}

	public void setTestingHours(String testingHours) {
		this.testingHours = testingHours;
	}

	public String getAssociatedEngineers() {
		return associatedEngineers;
	}

	public void setAssociatedEngineers(String associatedEngineers) {
		this.associatedEngineers = associatedEngineers;
	}

	public String getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}

	public String getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(String completedDate) {
		this.completedDate = completedDate;
	}

	public ChangeRequestStatus getChangeRequestITStatus() {
		return changeRequestITStatus;
	}

	public void setChangeRequestITStatus(ChangeRequestStatus changeRequestITStatus) {
		this.changeRequestITStatus = changeRequestITStatus;
	}

}
