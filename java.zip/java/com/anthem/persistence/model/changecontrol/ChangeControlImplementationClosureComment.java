package com.anthem.persistence.model.changecontrol;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.YesOrNoStatus;

@Entity
public class ChangeControlImplementationClosureComment extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6488246907546324741L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlChangeImplementation changeControlChangeImplementation;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlClosureComment changeControlClosureComment;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus required;
	
	@Lob
	private String justification;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ChangeControlChangeImplementation getChangeControlChangeImplementation() {
		return changeControlChangeImplementation;
	}

	public void setChangeControlChangeImplementation(ChangeControlChangeImplementation changeControlChangeImplementation) {
		this.changeControlChangeImplementation = changeControlChangeImplementation;
	}

	public ChangeControlClosureComment getChangeControlClosureComment() {
		return changeControlClosureComment;
	}

	public void setChangeControlClosureComment(ChangeControlClosureComment changeControlClosureComment) {
		this.changeControlClosureComment = changeControlClosureComment;
	}


	public String getJustification() {
		return justification;
	}

	public void setJustification(String justification) {
		this.justification = justification;
	}

	public YesOrNoStatus getRequired() {
		return required;
	}

	public void setRequired(YesOrNoStatus required) {
		this.required = required;
	}
	
}
