package com.anthem.persistence.model.changecontrol;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.changecontrol.AssessmentStatus;
import com.anthem.util.common.YesOrNoStatus;


@Entity
public class ChangeControlAssessmentByDepartment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8468473490108028390L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Department department;
	
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'YES'",insertable=false)
	private YesOrNoStatus required;
	
	
	private String impactedDocument;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date targetDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User responsibility;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User assessedBy;
	
	private Date assessedDate;
	
	

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'ASSESSED') DEFAULT 'PENDING'",insertable=false)
	private AssessmentStatus assessmentStatus;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlRegulatoryImpactAssessment changeControllerRegulatoryImpactAssessment;
	
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getImpactedDocument() {
		return impactedDocument;
	}

	public void setImpactedDocument(String impactedDocument) {
		this.impactedDocument = impactedDocument;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public User getResponsibility() {
		return responsibility;
	}

	public void setResponsibility(User responsibility) {
		this.responsibility = responsibility;
	}

	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public YesOrNoStatus getRequired() {
		return required;
	}

	public void setRequired(YesOrNoStatus required) {
		this.required = required;
	}



	public ChangeControlRegulatoryImpactAssessment getChangeControllerRegulatoryImpactAssessment() {
		return changeControllerRegulatoryImpactAssessment;
	}

	public void setChangeControllerRegulatoryImpactAssessment(
			ChangeControlRegulatoryImpactAssessment changeControllerRegulatoryImpactAssessment) {
		this.changeControllerRegulatoryImpactAssessment = changeControllerRegulatoryImpactAssessment;
	}

	
	public AssessmentStatus getAssessmentStatus() {
		return assessmentStatus;
	}

	public void setAssessmentStatus(AssessmentStatus assessmentStatus) {
		this.assessmentStatus = assessmentStatus;
	}

	public User getAssessedBy() {
		return assessedBy;
	}

	public void setAssessedBy(User assessedBy) {
		this.assessedBy = assessedBy;
	}

	public Date getAssessedDate() {
		return assessedDate;
	}

	public void setAssessedDate(Date assessedDate) {
		this.assessedDate = assessedDate;
	}
 
	
}
