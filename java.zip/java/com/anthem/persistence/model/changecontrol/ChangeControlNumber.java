package com.anthem.persistence.model.changecontrol;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Entity
public class ChangeControlNumber extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4659245763734703057L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(unique = true, nullable = false)
	private String ccNumber;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlRequest changeControlRequest;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCcNumber() {
		return ccNumber;
	}

	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}

	public ChangeControlRequest getChangeControlRequest() {
		return changeControlRequest;
	}

	public void setChangeControlRequest(ChangeControlRequest changeControlRequest) {
		this.changeControlRequest = changeControlRequest;
	}
	
	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}
}
