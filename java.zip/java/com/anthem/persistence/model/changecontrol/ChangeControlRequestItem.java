package com.anthem.persistence.model.changecontrol;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.anthem.persistence.model.common.Default;

@Entity
public class ChangeControlRequestItem extends Default {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7853376927882275202L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlRequest changeControlRequest;
	
	@Lob
	private String currentStatus;
	
	@Lob
	private String proposedStatus;
	
	@Lob
	private String justification;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ChangeControlRequestItemDescription.class)
	@JoinColumn(name = "changeControlRequestItem_id")
	private List<ChangeControlRequestItemDescription> changeControlRequestItemDescriptions;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the changeControlRequest
	 */
	public ChangeControlRequest getChangeControlRequest() {
		return changeControlRequest;
	}

	/**
	 * @param changeControlRequest the changeControlRequest to set
	 */
	public void setChangeControlRequest(ChangeControlRequest changeControlRequest) {
		this.changeControlRequest = changeControlRequest;
	}

	/**
	 * @return the currentStatus
	 */
	public String getCurrentStatus() {
		return currentStatus;
	}

	/**
	 * @param currentStatus the currentStatus to set
	 */
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	/**
	 * @return the proposedStatus
	 */
	public String getProposedStatus() {
		return proposedStatus;
	}

	/**
	 * @param proposedStatus the proposedStatus to set
	 */
	public void setProposedStatus(String proposedStatus) {
		this.proposedStatus = proposedStatus;
	}

	/**
	 * @return the justification
	 */
	public String getJustification() {
		return justification;
	}

	/**
	 * @param justification the justification to set
	 */
	public void setJustification(String justification) {
		this.justification = justification;
	}

	/**
	 * @return the changeControlRequestItemDescriptions
	 */
	public List<ChangeControlRequestItemDescription> getChangeControlRequestItemDescriptions() {
		return changeControlRequestItemDescriptions;
	}

	/**
	 * @param changeControlRequestItemDescriptions the changeControlRequestItemDescriptions to set
	 */
	public void setChangeControlRequestItemDescriptions(
			List<ChangeControlRequestItemDescription> changeControlRequestItemDescriptions) {
		this.changeControlRequestItemDescriptions = changeControlRequestItemDescriptions;
	}
	
	
	
	
	
}
