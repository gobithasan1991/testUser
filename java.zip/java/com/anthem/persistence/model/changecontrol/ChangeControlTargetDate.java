package com.anthem.persistence.model.changecontrol;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="changeControlNumber_id"))
public class ChangeControlTargetDate extends Default{


	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1550785192301512607L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;	
	
	private Date targetDate;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

}
