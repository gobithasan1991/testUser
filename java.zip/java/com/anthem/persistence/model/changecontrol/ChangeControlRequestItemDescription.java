package com.anthem.persistence.model.changecontrol;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.auditmanagement.DocumentChange;
@Entity
public class ChangeControlRequestItemDescription extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8163897135734541589L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlRequestItem changeControlRequestItem;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeCategory changeCategory;
	
	
	private String changeDescription;

	private Long changeId;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'STARTED', 'COMPLETED') DEFAULT 'PENDING'")
	private DocumentChange documentChange;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the changeControlRequestItem
	 */
	public ChangeControlRequestItem getChangeControlRequestItem() {
		return changeControlRequestItem;
	}


	/**
	 * @param changeControlRequestItem the changeControlRequestItem to set
	 */
	public void setChangeControlRequestItem(ChangeControlRequestItem changeControlRequestItem) {
		this.changeControlRequestItem = changeControlRequestItem;
	}


	/**
	 * @return the changeCategory
	 */
	public ChangeCategory getChangeCategory() {
		return changeCategory;
	}


	/**
	 * @param changeCategory the changeCategory to set
	 */
	public void setChangeCategory(ChangeCategory changeCategory) {
		this.changeCategory = changeCategory;
	}


	/**
	 * @return the changeDescription
	 */
	public String getChangeDescription() {
		return changeDescription;
	}


	/**
	 * @param changeDescription the changeDescription to set
	 */
	public void setChangeDescription(String changeDescription) {
		this.changeDescription = changeDescription;
	}


	public Long getChangeId() {
		return changeId;
	}


	public void setChangeId(Long changeId) {
		this.changeId = changeId;
	}


	public DocumentChange getDocumentChange() {
		return documentChange;
	}


	public void setDocumentChange(DocumentChange documentChange) {
		this.documentChange = documentChange;
	}
	

}
