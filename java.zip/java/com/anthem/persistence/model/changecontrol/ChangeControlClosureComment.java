package com.anthem.persistence.model.changecontrol;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.common.Default;


@Entity
public class ChangeControlClosureComment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2197126712781204275L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "name should not be empty")
	private String name;
	
	@Column(unique = true)
	@NotBlank(message = "code should not be empty")
	private String code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
