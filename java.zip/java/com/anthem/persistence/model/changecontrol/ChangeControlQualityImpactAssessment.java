package com.anthem.persistence.model.changecontrol;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.YesOrNoStatus;


@Entity
public class ChangeControlQualityImpactAssessment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1672646159858908570L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private QualityImpactAssessment qualityImpactAssessment;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus required;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlImpactAssessment changeControlImpactAssessment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public YesOrNoStatus getRequired() {
		return required;
	}

	public void setRequired(YesOrNoStatus required) {
		this.required = required;
	}

	public ChangeControlImpactAssessment getChangeControlImpactAssessment() {
		return changeControlImpactAssessment;
	}

	public void setChangeControlImpactAssessment(ChangeControlImpactAssessment changeControlImpactAssessment) {
		this.changeControlImpactAssessment = changeControlImpactAssessment;
	}

	public QualityImpactAssessment getQualityImpactAssessment() {
		return qualityImpactAssessment;
	}

	public void setQualityImpactAssessment(QualityImpactAssessment qualityImpactAssessment) {
		this.qualityImpactAssessment = qualityImpactAssessment;
	}

	
	
	

}
