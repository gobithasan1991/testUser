package com.anthem.persistence.model.changecontrol;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"code","department_id"}))
public class QualityImpactAssessment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5358983423554587936L;	
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;		
	
	@ManyToOne(fetch = FetchType.LAZY)
	private Department department;
	
	@NotBlank(message = "name should not be empty")
	private String name;
	
	@NotBlank(message = "code should not be empty")
	private String code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}


}
