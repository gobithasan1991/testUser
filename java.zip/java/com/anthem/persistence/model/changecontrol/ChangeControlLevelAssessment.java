package com.anthem.persistence.model.changecontrol;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.changecontrol.ChangeLevel;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="changeControlNumber_id"))
public class ChangeControlLevelAssessment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4412315540131173385L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('LEVEL1', 'LEVEL2', 'LEVEL3')")
	private ChangeLevel changeLevel;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ChangeLevel getChangeLevel() {
		return changeLevel;
	}

	public void setChangeLevel(ChangeLevel changeLevel) {
		this.changeLevel = changeLevel;
	}
	
	
	
	

}
