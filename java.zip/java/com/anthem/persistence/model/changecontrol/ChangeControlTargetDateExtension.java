package com.anthem.persistence.model.changecontrol;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.YesOrNoStatus;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"changeControlNumber_id","enabledStatus"}))
public class ChangeControlTargetDateExtension extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8959371174920343439L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;	
	
	private Date targetDate;
	
	@Lob
	private String reasonForExtension;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User extensionReviewedBy;
	
	private Date extensionReviewedDate;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'",insertable=false)
	private YesOrNoStatus extensionApproved;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User extensionApprovedBy;
	
	private Date extensionApprovedDate;
	
	@Lob
	private String rejectReason;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public String getReasonForExtension() {
		return reasonForExtension;
	}

	public void setReasonForExtension(String reasonForExtension) {
		this.reasonForExtension = reasonForExtension;
	}

	public YesOrNoStatus getExtensionApproved() {
		return extensionApproved;
	}

	public void setExtensionApproved(YesOrNoStatus extensionApproved) {
		this.extensionApproved = extensionApproved;
	}

	public User getExtensionApprovedBy() {
		return extensionApprovedBy;
	}

	public void setExtensionApprovedBy(User extensionApprovedBy) {
		this.extensionApprovedBy = extensionApprovedBy;
	}

	public Date getExtensionApprovedDate() {
		return extensionApprovedDate;
	}

	public void setExtensionApprovedDate(Date extensionApprovedDate) {
		this.extensionApprovedDate = extensionApprovedDate;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

	public User getExtensionReviewedBy() {
		return extensionReviewedBy;
	}

	public void setExtensionReviewedBy(User extensionReviewedBy) {
		this.extensionReviewedBy = extensionReviewedBy;
	}

	public Date getExtensionReviewedDate() {
		return extensionReviewedDate;
	}

	public void setExtensionReviewedDate(Date extensionReviewedDate) {
		this.extensionReviewedDate = extensionReviewedDate;
	}
}
