package com.anthem.persistence.model.changecontrol;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
public class ChangeControlChangeImplementation extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7950099330458394354L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User reviewedBy;
	
	private Date reviewedDate;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ChangeControlChangeImplementationSummary.class)	
	@JoinColumn(name = "changeControlChangeImplementation_id")
	private List<ChangeControlChangeImplementationSummary> changeControlChangeImplementationSummaries;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ChangeControlImplementationClosureComment.class)	
	@JoinColumn(name = "changeControlChangeImplementation_id")
	private List<ChangeControlImplementationClosureComment> changeControlImplementationClosureComments;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

	public User getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(User reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	

	public List<ChangeControlChangeImplementationSummary> getChangeControlChangeImplementationSummaries() {
		return changeControlChangeImplementationSummaries;
	}

	public void setChangeControlChangeImplementationSummaries(
			List<ChangeControlChangeImplementationSummary> changeControlChangeImplementationSummaries) {
		this.changeControlChangeImplementationSummaries = changeControlChangeImplementationSummaries;
	}

	public List<ChangeControlImplementationClosureComment> getChangeControlImplementationClosureComments() {
		return changeControlImplementationClosureComments;
	}

	public void setChangeControlImplementationClosureComments(
			List<ChangeControlImplementationClosureComment> changeControlImplementationClosureComments) {
		this.changeControlImplementationClosureComments = changeControlImplementationClosureComments;
	}

	public Date getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

}
