package com.anthem.persistence.model.changecontrol;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.YesOrNoStatus;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"changeControlNumber_id","enabledStatus"}))
public class ChangeControlChangeAcceptance extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4969841156549499363L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus changeAcceptance;
	
	@Lob
	private String rejectReason;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public YesOrNoStatus getChangeAcceptance() {
		return changeAcceptance;
	}

	public void setChangeAcceptance(YesOrNoStatus changeAcceptance) {
		this.changeAcceptance = changeAcceptance;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}	

}
