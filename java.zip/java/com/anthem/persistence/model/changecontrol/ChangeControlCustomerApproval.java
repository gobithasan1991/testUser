package com.anthem.persistence.model.changecontrol;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;


@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="changeControlNumber_id"))
public class ChangeControlCustomerApproval extends Default {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -787218408242364969L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;
	
	@Lob
	private String fileName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	

	

}
