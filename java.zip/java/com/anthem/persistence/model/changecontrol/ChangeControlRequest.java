package com.anthem.persistence.model.changecontrol;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.YesOrNoStatus;

@Entity
public class ChangeControlRequest extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7285523269449946398L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true, nullable = false)
	private String requestNo;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private QMSDepartment department;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ReferenceType referenceType;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus referenceRequired;

	private String referenceNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private User reviewer;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ChangeControlRequestItem.class)
	@JoinColumn(name = "changeControlRequest_id")
	private List<ChangeControlRequestItem> changeControlRequestItems;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('INITIATED', 'REVIEWER_APPROVED', 'REVIEWER_REJECTED', 'QA_REVIEWER_APPROVED', 'QA_REVIEWER_REJECTED', 'NUMBER_GENERATED',"
			+ " 'IMPACT_ASSESSMENT', 'REGULATORY_IMPACT_ASSESSMENT', 'DEPARTMENTS_ASSESSED', "
			+ "'LEVEL_ASSESSED', 'CUSTOMER_APPROVED', 'TARGET_DATE_ENTERED', 'CHANGE_ACCEPTED', 'CHANGE_REJECTED', 'DOCUMENT_UPDATE_STARTED', 'DOCUMENT_UPDATE_COMPLETED',"
			+ " 'TARGET_DATE_EXTENDED', 'EXTENSION_REJECTED','EXTENSION_REVIEWED', 'EXTENSION_APPROVED', 'CHANGE_IMPLEMENTED', 'CHANGE_COMPLETED') DEFAULT 'INITIATED'")
	private ChangeControlStatus changeControlStatus;

	@Lob
	private String rejectReason;

	private Date reviewedDate;

	@Lob
	private String qaRejectReason;

	@ManyToOne(fetch = FetchType.LAZY)
	private User qaReviewer;

	private Date qaReviewedDate;

	private String versionNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the department
	 */
	public QMSDepartment getDepartment() {
		return department;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(QMSDepartment department) {
		this.department = department;
	}

	/**
	 * @return the reviewer
	 */
	public User getReviewer() {
		return reviewer;
	}

	/**
	 * @param reviewer the reviewer to set
	 */
	public void setReviewer(User reviewer) {
		this.reviewer = reviewer;
	}

	/**
	 * @return the changeControlRequestItems
	 */
	public List<ChangeControlRequestItem> getChangeControlRequestItems() {
		return changeControlRequestItems;
	}

	/**
	 * @param changeControlRequestItems the changeControlRequestItems to set
	 */
	public void setChangeControlRequestItems(List<ChangeControlRequestItem> changeControlRequestItems) {
		this.changeControlRequestItems = changeControlRequestItems;
	}

	/**
	 * @return the requestNo
	 */
	public String getRequestNo() {
		return requestNo;
	}

	/**
	 * @param requestNo the requestNo to set
	 */
	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	/**
	 * @return the changeControlStatus
	 */
	public ChangeControlStatus getChangeControlStatus() {
		return changeControlStatus;
	}

	/**
	 * @param changeControlStatus the changeControlStatus to set
	 */
	public void setChangeControlStatus(ChangeControlStatus changeControlStatus) {
		this.changeControlStatus = changeControlStatus;
	}

	/**
	 * @return the rejectReason
	 */
	public String getRejectReason() {
		return rejectReason;
	}

	/**
	 * @param rejectReason the rejectReason to set
	 */
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	/**
	 * @return the reviewedDate
	 */
	public Date getReviewedDate() {
		return reviewedDate;
	}

	/**
	 * @param reviewedDate the reviewedDate to set
	 */
	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public String getQaRejectReason() {
		return qaRejectReason;
	}

	public User getQaReviewer() {
		return qaReviewer;
	}

	public Date getQaReviewedDate() {
		return qaReviewedDate;
	}

	public void setQaRejectReason(String qaRejectReason) {
		this.qaRejectReason = qaRejectReason;
	}

	public void setQaReviewer(User qaReviewer) {
		this.qaReviewer = qaReviewer;
	}

	public void setQaReviewedDate(Date qaReviewedDate) {
		this.qaReviewedDate = qaReviewedDate;
	}

	public YesOrNoStatus getReferenceRequired() {
		return referenceRequired;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceRequired(YesOrNoStatus referenceRequired) {
		this.referenceRequired = referenceRequired;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public ReferenceType getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(ReferenceType referenceType) {
		this.referenceType = referenceType;
	}

}
