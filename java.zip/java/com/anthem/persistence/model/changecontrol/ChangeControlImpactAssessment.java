package com.anthem.persistence.model.changecontrol;

import java.util.List;

import javax.persistence.CascadeType;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;


@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="changeControlNumber_id"))
public class ChangeControlImpactAssessment extends Default {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5688341622457297515L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ChangeControlQualityImpactAssessment.class)
	@JoinColumn(name = "changeControlImpactAssessment_id")	
	private List<ChangeControlQualityImpactAssessment>  changeControlQualityImpactAssessments;	
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeControlNumber changeControlNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<ChangeControlQualityImpactAssessment> getChangeControlQualityImpactAssessments() {
		return changeControlQualityImpactAssessments;
	}

	public void setChangeControlQualityImpactAssessments(
			List<ChangeControlQualityImpactAssessment> changeControlQualityImpactAssessments) {
		this.changeControlQualityImpactAssessments = changeControlQualityImpactAssessments;
	}

	public ChangeControlNumber getChangeControlNumber() {
		return changeControlNumber;
	}

	public void setChangeControlNumber(ChangeControlNumber changeControlNumber) {
		this.changeControlNumber = changeControlNumber;
	}
	
	
}
