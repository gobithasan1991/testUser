package com.anthem.persistence.model.changecontrol;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class ChangeControlChangeImplementationSummary extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5246134884500827950L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ChangeControlChangeImplementation changeControlChangeImplementation;
	
	private String transaction;
	
	private Long documentId;
	
	private String documentName;
	
	private String documentReferenceNo;
	
	private String versionNo;
	
	
	private Date effectiveDate;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public ChangeControlChangeImplementation getChangeControlChangeImplementation() {
		return changeControlChangeImplementation;
	}


	public void setChangeControlChangeImplementation(ChangeControlChangeImplementation changeControlChangeImplementation) {
		this.changeControlChangeImplementation = changeControlChangeImplementation;
	}


	public String getTransaction() {
		return transaction;
	}


	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}


	public Long getDocumentId() {
		return documentId;
	}


	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}


	public String getDocumentName() {
		return documentName;
	}


	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}


	public String getDocumentReferenceNo() {
		return documentReferenceNo;
	}


	public void setDocumentReferenceNo(String documentReferenceNo) {
		this.documentReferenceNo = documentReferenceNo;
	}


	public String getVersionNo() {
		return versionNo;
	}


	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}


	public Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

}
