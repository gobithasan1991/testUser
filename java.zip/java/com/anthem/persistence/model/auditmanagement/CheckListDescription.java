package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.common.Default;

@Entity
public class CheckListDescription extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4984673103373218173L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private CheckListCategory chekListCategory;
	
	
	@Column(unique = true)
	@NotBlank(message = "description should not be empty")
	@Lob
	private String description;

	public Long getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CheckListCategory getChekListCategory() {
		return chekListCategory;
	}

	public void setChekListCategory(CheckListCategory chekListCategory) {
		this.chekListCategory = chekListCategory;
	}
	
	
	
}
