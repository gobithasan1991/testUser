package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Audited
@Entity
public class DepartmentGroupBranch extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5954220973093990781L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private DepartmentGroup departmentGroup;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Branch branch;

	public Long getId() {
		return id;
	}

	public DepartmentGroup getDepartmentGroup() {
		return departmentGroup;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartmentGroup(DepartmentGroup departmentGroup) {
		this.departmentGroup = departmentGroup;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

}
