package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Entity
public class CheckListMappingBranch extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3567949647440142275L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)	
	private Branch branch;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)	
	private CheckListMapping checkListMapping;

	public Long getId() {
		return id;
	}

	public Branch getBranch() {
		return branch;
	}

	public CheckListMapping getCheckListMapping() {
		return checkListMapping;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public void setCheckListMapping(CheckListMapping checkListMapping) {
		this.checkListMapping = checkListMapping;
	}

}
