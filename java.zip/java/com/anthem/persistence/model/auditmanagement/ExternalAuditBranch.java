package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Audited
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"externalAuditScheduler_id", "branch_id"}))
public class ExternalAuditBranch extends Default{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5250100552530905098L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditScheduler externalAuditScheduler;

	public Long getId() {
		return id;
	}

	public Branch getBranch() {
		return branch;
	}

	public ExternalAuditScheduler getExternalAuditScheduler() {
		return externalAuditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public void setExternalAuditScheduler(ExternalAuditScheduler externalAuditScheduler) {
		this.externalAuditScheduler = externalAuditScheduler;
	}
	
	
}
