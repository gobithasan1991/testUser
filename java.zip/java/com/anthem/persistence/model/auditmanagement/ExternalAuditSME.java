package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Audited
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"externalAuditScheduler_id", "sme_id", "department_id"}))
public class ExternalAuditSME extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6971470856191757073L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment department;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private User sme;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditScheduler externalAuditScheduler;

	public Long getId() {
		return id;
	}

	public User getSme() {
		return sme;
	}

	public ExternalAuditScheduler getExternalAuditScheduler() {
		return externalAuditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setSme(User sme) {
		this.sme = sme;
	}

	public void setExternalAuditScheduler(ExternalAuditScheduler externalAuditScheduler) {
		this.externalAuditScheduler = externalAuditScheduler;
	}

	public QMSDepartment getDepartment() {
		return department;
	}

	public void setDepartment(QMSDepartment department) {
		this.department = department;
	}
	
}
