package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class AdditionalObservation extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9016326633283786771L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Lob
	private String observation;
	
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditObservation auditObservation;


	public Long getId() {
		return id;
	}


	public String getObservation() {
		return observation;
	}


	public AuditObservation getAuditObservation() {
		return auditObservation;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public void setObservation(String observation) {
		this.observation = observation;
	}


	public void setAuditObservation(AuditObservation auditObservation) {
		this.auditObservation = auditObservation;
	}

}
