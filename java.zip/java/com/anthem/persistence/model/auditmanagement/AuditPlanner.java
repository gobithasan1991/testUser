package com.anthem.persistence.model.auditmanagement;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.auditmanagement.ApproveStatus;

@Audited
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "department_id", "date", "branch_id"}))
public class AuditPlanner extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 694738766546399039L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private QMSDepartment department;

	@Temporal(TemporalType.TIMESTAMP)
	private Date date;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditFrequencyMaster frequency;

	private Long frequency_revNo;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Branch branch;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'MR_APPROVED', 'QA_APPROVED', 'SCHEDULED') DEFAULT 'PENDING'")
	private ApproveStatus approveStatus;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User mrApprovedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date mrApprovedDate;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User qaApprovedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date qaApprovedDate;
	
	@Lob
	private String updateReason;

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	public Long getId() {
		return id;
	}

	public QMSDepartment getDepartment() {
		return department;
	}

	public Date getDate() {
		return date;
	}

	public AuditFrequencyMaster getFrequency() {
		return frequency;
	}

	public Branch getBranch() {
		return branch;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartment(QMSDepartment department) {
		this.department = department;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setFrequency(AuditFrequencyMaster frequency) {
		this.frequency = frequency;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public User getMrApprovedBy() {
		return mrApprovedBy;
	}

	public Date getMrApprovedDate() {
		return mrApprovedDate;
	}

	public User getQaApprovedBy() {
		return qaApprovedBy;
	}

	public Date getQaApprovedDate() {
		return qaApprovedDate;
	}

	public void setMrApprovedBy(User mrApprovedBy) {
		this.mrApprovedBy = mrApprovedBy;
	}

	public void setMrApprovedDate(Date mrApprovedDate) {
		this.mrApprovedDate = mrApprovedDate;
	}

	public void setQaApprovedBy(User qaApprovedBy) {
		this.qaApprovedBy = qaApprovedBy;
	}

	public void setQaApprovedDate(Date qaApprovedDate) {
		this.qaApprovedDate = qaApprovedDate;
	}

	public Long getFrequency_revNo() {
		return frequency_revNo;
	}

	public void setFrequency_revNo(Long frequency_revNo) {
		this.frequency_revNo = frequency_revNo;
	}
}
