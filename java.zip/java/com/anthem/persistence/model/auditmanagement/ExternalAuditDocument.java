package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;

@Audited
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"externalAuditScheduler_id", "documentId"}))
public class ExternalAuditDocument extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3964529531311945442L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	private Long documentId;
	
	@Lob
	private String fileName;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditScheduler externalAuditScheduler;

	public Long getId() {
		return id;
	}

	public Long getDocumentId() {
		return documentId;
	}

	public String getFileName() {
		return fileName;
	}

	public ExternalAuditScheduler getExternalAuditScheduler() {
		return externalAuditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setExternalAuditScheduler(ExternalAuditScheduler externalAuditScheduler) {
		this.externalAuditScheduler = externalAuditScheduler;
	}
	
}
