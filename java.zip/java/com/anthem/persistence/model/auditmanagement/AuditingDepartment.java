package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Audited
@Entity
public class AuditingDepartment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8378755484496589475L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;	

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private QMSDepartment auditingDepartment;
	
	@Audited(targetAuditMode=RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditTeamMaster auditTeamMaster;

	public Long getId() {
		return id;
	}

	public QMSDepartment getAuditingDepartment() {
		return auditingDepartment;
	}

	public AuditTeamMaster getAuditTeamMaster() {
		return auditTeamMaster;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAuditingDepartment(QMSDepartment auditingDepartment) {
		this.auditingDepartment = auditingDepartment;
	}

	public void setAuditTeamMaster(AuditTeamMaster auditTeamMaster) {
		this.auditTeamMaster = auditTeamMaster;
	}
		
	
}
