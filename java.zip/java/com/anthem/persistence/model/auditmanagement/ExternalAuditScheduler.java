package com.anthem.persistence.model.auditmanagement;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.anthemerp.Customer;
import com.anthem.persistence.model.anthemerp.Project;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.auditmanagement.AuditScheduleStatus;
import com.anthem.util.auditmanagement.ConfirmStatus;
import com.anthem.util.auditmanagement.ObservationStatus;
import com.anthem.util.common.YesOrNoStatus;

@Audited
@Entity
public class ExternalAuditScheduler extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7086248061763848435L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true)
	private String auditNumber;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private DepartmentGroup departmentGroup;

	private Long departmentGroup_revNo;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Customer customer;

	@Lob
	private String customerName;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus productSpecific;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Project project;

	@Lob
	private String projectName;

	@Lob
	private String productName;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditType auditType;

	@Temporal(TemporalType.TIMESTAMP)
	private Date startDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date endDate;

	@Lob
	private String auditAgenta;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditCategory auditCategory;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private User reviewedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date reviewedDate;

	private String reason;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private User confirmedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date confirmedDate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PROPOSED', 'CONFIRMED', 'CANCELLED')")
	private ConfirmStatus confirmStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('REQUESTED', 'APPROVED', 'REJECTED', 'CONFIRMED') DEFAULT 'REQUESTED'", insertable = false)
	private AuditScheduleStatus auditScheduleStatus;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'COMPLETED', 'APPROVED') DEFAULT 'PENDING'", insertable = false)
	private ObservationStatus observationStatus;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditBranch.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eabs_audit_log")
	private List<ExternalAuditBranch> externalAuditBranchs;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditProduct.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eap_audit_log")
	private List<ExternalAuditProduct> externalAuditProducts;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditDate.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eaad_audit_log")
	private List<ExternalAuditDate> externalAuditDates;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditAuditor.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eaat_audit_log")
	private List<ExternalAuditAuditor> externalAuditAuditors;

	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditSupportingDepartment.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_easd_audit_log")
	private List<ExternalAuditSupportingDepartment> externalAuditSupportingDepartments;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditDocument.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eaadoc_audit_log")
	private List<ExternalAuditDocument> externalAuditDocuments;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditSME.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eaasme_audit_log")
	private List<ExternalAuditSME> externalAuditSMEs;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditAuditee.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eaauditee_audit_log")
	private List<ExternalAuditAuditee> externalAuditAuditees;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditScriber.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_eascriber_audit_log")
	private List<ExternalAuditScriber> externalAuditScribers;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditRunner.class)
	@JoinColumn(name = "externalAuditScheduler_id")
	@AuditJoinTable(name="eas_earunners_audit_log")
	private List<ExternalAuditRunner> externalAuditRunners;

	@Lob
	private String updateReason;

	public Long getId() {
		return id;
	}

	public DepartmentGroup getDepartmentGroup() {
		return departmentGroup;
	}

	public Customer getCustomer() {
		return customer;
	}

	public YesOrNoStatus getProductSpecific() {
		return productSpecific;
	}

	public AuditType getAuditType() {
		return auditType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public String getAuditAgenta() {
		return auditAgenta;
	}

	public AuditCategory getAuditCategory() {
		return auditCategory;
	}

	public User getConfirmedBy() {
		return confirmedBy;
	}

	public Date getConfirmedDate() {
		return confirmedDate;
	}

	public List<ExternalAuditBranch> getExternalAuditBranchs() {
		return externalAuditBranchs;
	}

	public List<ExternalAuditProduct> getExternalAuditProducts() {
		return externalAuditProducts;
	}

	public List<ExternalAuditAuditor> getExternalAuditAuditors() {
		return externalAuditAuditors;
	}

	public List<ExternalAuditSupportingDepartment> getExternalAuditSupportingDepartments() {
		return externalAuditSupportingDepartments;
	}

	public List<ExternalAuditDocument> getExternalAuditDocuments() {
		return externalAuditDocuments;
	}

	public List<ExternalAuditSME> getExternalAuditSMEs() {
		return externalAuditSMEs;
	}

	public List<ExternalAuditAuditee> getExternalAuditAuditees() {
		return externalAuditAuditees;
	}

	public List<ExternalAuditScriber> getExternalAuditScribers() {
		return externalAuditScribers;
	}

	public List<ExternalAuditRunner> getExternalAuditRunners() {
		return externalAuditRunners;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartmentGroup(DepartmentGroup departmentGroup) {
		this.departmentGroup = departmentGroup;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public void setProductSpecific(YesOrNoStatus productSpecific) {
		this.productSpecific = productSpecific;
	}

	public void setAuditType(AuditType auditType) {
		this.auditType = auditType;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setAuditAgenta(String auditAgenta) {
		this.auditAgenta = auditAgenta;
	}

	public void setAuditCategory(AuditCategory auditCategory) {
		this.auditCategory = auditCategory;
	}

	public void setConfirmedBy(User confirmedBy) {
		this.confirmedBy = confirmedBy;
	}

	public void setConfirmedDate(Date confirmedDate) {
		this.confirmedDate = confirmedDate;
	}

	public void setExternalAuditBranchs(List<ExternalAuditBranch> externalAuditBranchs) {
		this.externalAuditBranchs = externalAuditBranchs;
	}

	public void setExternalAuditProducts(List<ExternalAuditProduct> externalAuditProducts) {
		this.externalAuditProducts = externalAuditProducts;
	}

	public void setExternalAuditAuditors(List<ExternalAuditAuditor> externalAuditAuditors) {
		this.externalAuditAuditors = externalAuditAuditors;
	}

	public void setExternalAuditSupportingDepartments(
			List<ExternalAuditSupportingDepartment> externalAuditSupportingDepartments) {
		this.externalAuditSupportingDepartments = externalAuditSupportingDepartments;
	}

	public void setExternalAuditDocuments(List<ExternalAuditDocument> externalAuditDocuments) {
		this.externalAuditDocuments = externalAuditDocuments;
	}

	public void setExternalAuditSMEs(List<ExternalAuditSME> externalAuditSMEs) {
		this.externalAuditSMEs = externalAuditSMEs;
	}

	public void setExternalAuditAuditees(List<ExternalAuditAuditee> externalAuditAuditees) {
		this.externalAuditAuditees = externalAuditAuditees;
	}

	public void setExternalAuditScribers(List<ExternalAuditScriber> externalAuditScribers) {
		this.externalAuditScribers = externalAuditScribers;
	}

	public void setExternalAuditRunners(List<ExternalAuditRunner> externalAuditRunners) {
		this.externalAuditRunners = externalAuditRunners;
	}

	public AuditScheduleStatus getAuditScheduleStatus() {
		return auditScheduleStatus;
	}

	public void setAuditScheduleStatus(AuditScheduleStatus auditScheduleStatus) {
		this.auditScheduleStatus = auditScheduleStatus;
	}

	public ObservationStatus getObservationStatus() {
		return observationStatus;
	}

	public void setObservationStatus(ObservationStatus observationStatus) {
		this.observationStatus = observationStatus;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Date getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedBy(User reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public User getReviewedBy() {
		return reviewedBy;
	}

	public String getAuditNumber() {
		return auditNumber;
	}

	public void setAuditNumber(String auditNumber) {
		this.auditNumber = auditNumber;
	}

	public List<ExternalAuditDate> getExternalAuditDates() {
		return externalAuditDates;
	}

	public void setExternalAuditDates(List<ExternalAuditDate> externalAuditDates) {
		this.externalAuditDates = externalAuditDates;
	}

	public ConfirmStatus getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(ConfirmStatus confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

	public String getCustomerName() {
		return customerName;
	}

	public Project getProject() {
		return project;
	}

	public String getProjectName() {
		return projectName;
	}

	public String getProductName() {
		return productName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	public Long getDepartmentGroup_revNo() {
		return departmentGroup_revNo;
	}

	public void setDepartmentGroup_revNo(Long departmentGroup_revNo) {
		this.departmentGroup_revNo = departmentGroup_revNo;
	}

}
