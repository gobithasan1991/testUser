package com.anthem.persistence.model.auditmanagement;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.util.auditmanagement.AuditUserGroupName;
@Audited
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "department_id", "groupName" }))
public class AuditUserGroup extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7296909415841872815L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment department;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('AUDITEE_GROUP', 'SME_GROUP', 'SCRIBE_GROUP', 'RUNNER_GROUP')")
	private AuditUserGroupName groupName;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AuditUserGroupBranch.class)
	@JoinColumn(name = "auditUserGroup_id")
	@AuditJoinTable(name="aug_branch_audit_log")
	private List<AuditUserGroupBranch> auditUserGroupBranch;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AuditUserGroupUser.class)
	@JoinColumn(name = "auditUserGroup_id")
	@AuditJoinTable(name="aug_user_audit_log")
	private List<AuditUserGroupUser> auditUserGroupUsers;

	
	private String updateReason;
	
	public Long getId() {
		return id;
	}

	public QMSDepartment getDepartment() {
		return department;
	}

	public AuditUserGroupName getGroupName() {
		return groupName;
	}

	public List<AuditUserGroupBranch> getAuditUserGroupBranch() {
		return auditUserGroupBranch;
	}

	public List<AuditUserGroupUser> getAuditUserGroupUsers() {
		return auditUserGroupUsers;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartment(QMSDepartment department) {
		this.department = department;
	}

	public void setGroupName(AuditUserGroupName groupName) {
		this.groupName = groupName;
	}

	public void setAuditUserGroupBranch(List<AuditUserGroupBranch> auditUserGroupBranch) {
		this.auditUserGroupBranch = auditUserGroupBranch;
	}

	public void setAuditUserGroupUsers(List<AuditUserGroupUser> auditUserGroupUsers) {
		this.auditUserGroupUsers = auditUserGroupUsers;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

}
