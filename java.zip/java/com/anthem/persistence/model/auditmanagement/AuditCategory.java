package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.common.Default;

@Entity
public class AuditCategory extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4026937814742316441L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "name should not be empty")
	private String name;

	@Column(unique = true)
	@NotBlank(message = "code should not be empty")
	private String code;

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
