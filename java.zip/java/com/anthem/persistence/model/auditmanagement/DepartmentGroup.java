package com.anthem.persistence.model.auditmanagement;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

import com.anthem.persistence.model.common.Default;
@Audited
@Entity
public class DepartmentGroup extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5702813336555268826L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;	
	
	@Column(unique=true)
	private String name;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = DepartmentGroupItem.class)
	@JoinColumn(name = "departmentGroup_id")
	@AuditJoinTable(name="dgroup_item_audit_log")
	private List<DepartmentGroupItem> departmentGroupItems;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = DepartmentGroupBranch.class)
	@JoinColumn(name = "departmentGroup_id")
	@AuditJoinTable(name="dgroup_branch_audit_log")
	private List<DepartmentGroupBranch> departmentGroupBranchs;
	
	@Lob
	private String updateReason;

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public List<DepartmentGroupItem> getDepartmentGroupItems() {
		return departmentGroupItems;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDepartmentGroupItems(List<DepartmentGroupItem> departmentGroupItems) {
		this.departmentGroupItems = departmentGroupItems;
	}

	public List<DepartmentGroupBranch> getDepartmentGroupBranchs() {
		return departmentGroupBranchs;
	}

	public void setDepartmentGroupBranchs(List<DepartmentGroupBranch> departmentGroupBranchs) {
		this.departmentGroupBranchs = departmentGroupBranchs;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	
	
}
