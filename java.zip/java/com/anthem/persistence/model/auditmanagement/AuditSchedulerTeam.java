package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;

@Audited
@Entity
public class AuditSchedulerTeam extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1624711603203063839L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditTeamMaster auditTeam;
	
	private Long auditTeam_revNo;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditorRoleMaster auditorRole;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditScheduler auditScheduler;

	public Long getId() {
		return id;
	}

	public AuditTeamMaster getAuditTeam() {
		return auditTeam;
	}

	public AuditorRoleMaster getAuditorRole() {
		return auditorRole;
	}

	public AuditScheduler getAuditScheduler() {
		return auditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAuditTeam(AuditTeamMaster auditTeam) {
		this.auditTeam = auditTeam;
	}

	public void setAuditorRole(AuditorRoleMaster auditorRole) {
		this.auditorRole = auditorRole;
	}

	public void setAuditScheduler(AuditScheduler auditScheduler) {
		this.auditScheduler = auditScheduler;
	}

	public Long getAuditTeam_revNo() {
		return auditTeam_revNo;
	}

	public void setAuditTeam_revNo(Long auditTeam_revNo) {
		this.auditTeam_revNo = auditTeam_revNo;
	}
	
	
}
