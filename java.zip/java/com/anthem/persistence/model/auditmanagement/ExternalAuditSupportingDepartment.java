package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;

@Audited
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"externalAuditScheduler_id", "department_id"}))
public class ExternalAuditSupportingDepartment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4450890667660841397L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private Department department;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditScheduler externalAuditScheduler;

	public Long getId() {
		return id;
	}

	public Department getDepartment() {
		return department;
	}

	public ExternalAuditScheduler getExternalAuditScheduler() {
		return externalAuditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setExternalAuditScheduler(ExternalAuditScheduler externalAuditScheduler) {
		this.externalAuditScheduler = externalAuditScheduler;
	}

}
