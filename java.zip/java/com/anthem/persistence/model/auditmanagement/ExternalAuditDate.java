package com.anthem.persistence.model.auditmanagement;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;

@Audited
@Entity
public class ExternalAuditDate extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5040959141941561661L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date endDate;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditScheduler externalAuditScheduler;

	public Long getId() {
		return id;
	}

	public Branch getBranch() {
		return branch;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public ExternalAuditScheduler getExternalAuditScheduler() {
		return externalAuditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setExternalAuditScheduler(ExternalAuditScheduler externalAuditScheduler) {
		this.externalAuditScheduler = externalAuditScheduler;
	}
	


}
