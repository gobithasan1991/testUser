package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class DepartmentPositive extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5786661592718885649L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Lob
	private String positiveNote;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditObservation auditObservation;

	public Long getId() {
		return id;
	}

	public String getPositiveNote() {
		return positiveNote;
	}

	public AuditObservation getAuditObservation() {
		return auditObservation;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setPositiveNote(String positiveNote) {
		this.positiveNote = positiveNote;
	}

	public void setAuditObservation(AuditObservation auditObservation) {
		this.auditObservation = auditObservation;
	}
	
	
}
