package com.anthem.persistence.model.auditmanagement;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.auditmanagement.ApproveStatus;
import com.anthem.util.auditmanagement.ObservationStatus;
@Audited
@Entity
public class AuditScheduler extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 450276466315298491L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(unique = true, nullable = false)
	private String auditNumber;
	
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditPlanner auditPlanner;

	private Long auditPlanner_revNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date auditDate;
	
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date startTime;
//	
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date endTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date endDate;
	
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity =InternalAuditDate.class)
	@JoinColumn(name = "auditScheduler_id")
	@AuditJoinTable(name="ias_iad_audit_log")
	private List<InternalAuditDate> internalAuditDates;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AuditSchedulerTeam.class)
	@JoinColumn(name = "auditScheduler_id")
	@AuditJoinTable(name="ias_ast_audit_log")
	private List<AuditSchedulerTeam> auditSchedulerTeams;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AuditSchedulerAuditee.class)
	@JoinColumn(name = "auditScheduler_id")
	@AuditJoinTable(name="ias_asauditee_audit_log")
	private List<AuditSchedulerAuditee> auditSchedulerAuditees;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Branch branch;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'MR_APPROVED', 'QA_APPROVED', 'SCHEDULED') DEFAULT 'PENDING'",insertable=false)
	private ApproveStatus approveStatus;	
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User mrApprovedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date mrApprovedDate;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User qaApprovedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date qaApprovedDate;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'COMPLETED', 'APPROVED') DEFAULT 'PENDING'",insertable=false)
	private ObservationStatus observationStatus;
	
	@Lob
	private String updateReason;
	
	
	public Long getId() {
		return id;
	}

	public AuditPlanner getAuditPlanner() {
		return auditPlanner;
	}

	public List<AuditSchedulerTeam> getAuditSchedulerTeams() {
		return auditSchedulerTeams;
	}

	public List<AuditSchedulerAuditee> getAuditSchedulerAuditees() {
		return auditSchedulerAuditees;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAuditPlanner(AuditPlanner auditPlanner) {
		this.auditPlanner = auditPlanner;
	}

	public void setAuditSchedulerTeams(List<AuditSchedulerTeam> auditSchedulerTeams) {
		this.auditSchedulerTeams = auditSchedulerTeams;
	}

	public void setAuditSchedulerAuditees(List<AuditSchedulerAuditee> auditSchedulerAuditees) {
		this.auditSchedulerAuditees = auditSchedulerAuditees;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Date getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public ObservationStatus getObservationStatus() {
		return observationStatus;
	}

	public void setObservationStatus(ObservationStatus observationStatus) {
		this.observationStatus = observationStatus;
	}

	public String getAuditNumber() {
		return auditNumber;
	}

	public void setAuditNumber(String auditNumber) {
		this.auditNumber = auditNumber;
	}

	public User getMrApprovedBy() {
		return mrApprovedBy;
	}

	public Date getMrApprovedDate() {
		return mrApprovedDate;
	}

	public User getQaApprovedBy() {
		return qaApprovedBy;
	}

	public Date getQaApprovedDate() {
		return qaApprovedDate;
	}

	public void setMrApprovedBy(User mrApprovedBy) {
		this.mrApprovedBy = mrApprovedBy;
	}

	public void setMrApprovedDate(Date mrApprovedDate) {
		this.mrApprovedDate = mrApprovedDate;
	}

	public void setQaApprovedBy(User qaApprovedBy) {
		this.qaApprovedBy = qaApprovedBy;
	}

	public void setQaApprovedDate(Date qaApprovedDate) {
		this.qaApprovedDate = qaApprovedDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public List<InternalAuditDate> getInternalAuditDates() {
		return internalAuditDates;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setInternalAuditDates(List<InternalAuditDate> internalAuditDates) {
		this.internalAuditDates = internalAuditDates;
	}

	public Long getAuditPlanner_revNo() {
		return auditPlanner_revNo;
	}

	public void setAuditPlanner_revNo(Long auditPlanner_revNo) {
		this.auditPlanner_revNo = auditPlanner_revNo;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	
}
