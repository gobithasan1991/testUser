package com.anthem.persistence.model.auditmanagement;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.YesOrNoStatus;

@Entity
public class ExternalAuditObseravtionDepartment extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2378125324394976553L;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment department;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditObservationItem externalAuditObservationItem;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'", insertable=false)
	private YesOrNoStatus observationApproved;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User acceptBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date acceptDate;

	public Long getId() {
		return id;
	}

	public QMSDepartment getDepartment() {
		return department;
	}

	public ExternalAuditObservationItem getExternalAuditObservationItem() {
		return externalAuditObservationItem;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartment(QMSDepartment department) {
		this.department = department;
	}

	public void setExternalAuditObservationItem(ExternalAuditObservationItem externalAuditObservationItem) {
		this.externalAuditObservationItem = externalAuditObservationItem;
	}

	public YesOrNoStatus getObservationApproved() {
		return observationApproved;
	}

	public void setObservationApproved(YesOrNoStatus observationApproved) {
		this.observationApproved = observationApproved;
	}

	public User getAcceptBy() {
		return acceptBy;
	}

	public Date getAcceptDate() {
		return acceptDate;
	}

	public void setAcceptBy(User acceptBy) {
		this.acceptBy = acceptBy;
	}

	public void setAcceptDate(Date acceptDate) {
		this.acceptDate = acceptDate;
	}

	
	
	
}
