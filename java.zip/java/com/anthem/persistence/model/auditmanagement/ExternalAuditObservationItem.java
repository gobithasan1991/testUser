package com.anthem.persistence.model.auditmanagement;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"externalAuditObservation_id", "documentReference"}))
public class ExternalAuditObservationItem extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7668895790672183923L;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;	
	
	private Long documentReference;
	
	@Lob
	private String observation;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ObservationCategory observationCategory;
	
	@Lob
	private String guidelinesReference; 
	
	

	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditObservation externalAuditObservation;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditObseravtionDepartment.class)
	@JoinColumn(name = "externalAuditObservationItem_id")
	private List<ExternalAuditObseravtionDepartment> auditObseravtionDepartments;

	public Long getId() {
		return id;
	}

	public Long getDocumentReference() {
		return documentReference;
	}

	public String getObservation() {
		return observation;
	}

	public ExternalAuditObservation getExternalAuditObservation() {
		return externalAuditObservation;
	}

	public List<ExternalAuditObseravtionDepartment> getAuditObseravtionDepartments() {
		return auditObseravtionDepartments;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDocumentReference(Long documentReference) {
		this.documentReference = documentReference;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	public void setExternalAuditObservation(ExternalAuditObservation externalAuditObservation) {
		this.externalAuditObservation = externalAuditObservation;
	}

	public void setAuditObseravtionDepartments(List<ExternalAuditObseravtionDepartment> auditObseravtionDepartments) {
		this.auditObseravtionDepartments = auditObseravtionDepartments;
	}	

	public ObservationCategory getObservationCategory() {
		return observationCategory;
	}

	public String getGuidelinesReference() {
		return guidelinesReference;
	}

	public void setObservationCategory(ObservationCategory observationCategory) {
		this.observationCategory = observationCategory;
	}

	public void setGuidelinesReference(String guidelinesReference) {
		this.guidelinesReference = guidelinesReference;
	}
}
