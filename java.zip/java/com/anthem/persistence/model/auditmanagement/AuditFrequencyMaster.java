package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.envers.Audited;
import org.hibernate.validator.constraints.NotBlank;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.auditmanagement.PeriodIn;

@Audited
@Entity
public class AuditFrequencyMaster extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7575917433651682494L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;	
	
	
	@NotBlank(message = "Code should not be empty")
	@Column(unique = true)
	private String code;
	
	private int period;
	
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('DAYS', 'WEEKS', 'MONTHS', 'YEARS') DEFAULT 'DAYS'")
	private PeriodIn periodIn;

	
	@Lob
	private String updateReason;

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public int getPeriod() {
		return period;
	}


	public void setPeriod(int period) {
		this.period = period;
	}


	public PeriodIn getPeriodIn() {
		return periodIn;
	}


	public void setPeriodIn(PeriodIn periodIn) {
		this.periodIn = periodIn;
	}


	public String getUpdateReason() {
		return updateReason;
	}


	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}
	 

}
