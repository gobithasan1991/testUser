package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.changecontrol.ChangeCategory;
import com.anthem.persistence.model.common.Default;
import com.anthem.util.auditmanagement.ObservationType;

@Entity
public class ObservationCheckList extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1315720903087210651L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private CheckListDescription checkListDescription;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('COMPLIANT', 'NON_COMPLIANT', 'NA') DEFAULT 'NA'")
	private ObservationType observationType;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private ChangeCategory observationWrt;
	
	private Long documentId;
	
	private String documentRef;
	
	@Lob
	private String observation;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditObservation auditObservation;

	public Long getId() {
		return id;
	}

	public CheckListDescription getCheckListDescription() {
		return checkListDescription;
	}

	public ObservationType getObservationType() {
		return observationType;
	}

	public ChangeCategory getObservationWrt() {
		return observationWrt;
	}

	public Long getDocumentId() {
		return documentId;
	}

	public String getDocumentRef() {
		return documentRef;
	}

	public String getObservation() {
		return observation;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCheckListDescription(CheckListDescription checkListDescription) {
		this.checkListDescription = checkListDescription;
	}

	public void setObservationType(ObservationType observationType) {
		this.observationType = observationType;
	}

	public void setObservationWrt(ChangeCategory observationWrt) {
		this.observationWrt = observationWrt;
	}

	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	public void setDocumentRef(String documentRef) {
		this.documentRef = documentRef;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	public AuditObservation getAuditObservation() {
		return auditObservation;
	}

	public void setAuditObservation(AuditObservation auditObservation) {
		this.auditObservation = auditObservation;
	}
	
}
