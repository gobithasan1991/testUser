package com.anthem.persistence.model.auditmanagement;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.auditmanagement.ApproveStatus;

@Audited
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "employee_id", "branch_id" }))
public class AuditTeamMaster extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 674611153177113814L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Department department;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User employee;

	@Lob
	private String jobDescription;

	@Lob
	private String fileName;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AuditTeamMasterRole.class)
	@JoinColumn(name = "auditTeamMaster_id")
	private List<AuditTeamMasterRole> auditTeamMasterRoles;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AuditingDepartment.class)
	@JoinColumn(name = "auditTeamMaster_id")
	private List<AuditingDepartment> auditingDepartments;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'MR_APPROVED', 'QA_APPROVED') DEFAULT 'PENDING'")
	private ApproveStatus approveStatus;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User mrApprovedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date mrApprovedDate;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User qaApprovedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date qaApprovedDate;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private Branch branch;

	@Lob
	private String updateReason;

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public Long getId() {
		return id;
	}

	public Department getDepartment() {
		return department;
	}

	public String getFileName() {
		return fileName;
	}

	public List<AuditingDepartment> getAuditingDepartments() {
		return auditingDepartments;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public User getEmployee() {
		return employee;
	}

	public void setEmployee(User employee) {
		this.employee = employee;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setAuditingDepartments(List<AuditingDepartment> auditingDepartments) {
		this.auditingDepartments = auditingDepartments;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public User getMrApprovedBy() {
		return mrApprovedBy;
	}

	public Date getMrApprovedDate() {
		return mrApprovedDate;
	}

	public void setMrApprovedBy(User mrApprovedBy) {
		this.mrApprovedBy = mrApprovedBy;
	}

	public void setMrApprovedDate(Date mrApprovedDate) {
		this.mrApprovedDate = mrApprovedDate;
	}

	public User getQaApprovedBy() {
		return qaApprovedBy;
	}

	public Date getQaApprovedDate() {
		return qaApprovedDate;
	}

	public void setQaApprovedBy(User qaApprovedBy) {
		this.qaApprovedBy = qaApprovedBy;
	}

	public void setQaApprovedDate(Date qaApprovedDate) {
		this.qaApprovedDate = qaApprovedDate;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	public List<AuditTeamMasterRole> getAuditTeamMasterRoles() {
		return auditTeamMasterRoles;
	}

	public void setAuditTeamMasterRoles(List<AuditTeamMasterRole> auditTeamMasterRoles) {
		this.auditTeamMasterRoles = auditTeamMasterRoles;
	}

}
