package com.anthem.persistence.model.auditmanagement;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.document.Document;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames= {"checkListDescription_id", "document_id"}))
public class CheckListMapping extends Default{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6599203601502547595L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)	
	private CheckListDescription checkListDescription;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)	
	private Document document;
	
	@Column(unique=true)
	private String documentRef;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = CheckListMappingBranch.class)
	@JoinColumn(name = "checkListMapping_id")
	private List<CheckListMappingBranch> checkListMappingBranchs;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = CheckListMappingDepartment.class)
	@JoinColumn(name = "checkListMapping_id")
	private List<CheckListMappingDepartment> checkListMappingDepartments;

	public Long getId() {
		return id;
	}

	public CheckListDescription getCheckListDescription() {
		return checkListDescription;
	}

	public Document getDocument() {
		return document;
	}

	public String getDocumentRef() {
		return documentRef;
	}

	public List<CheckListMappingBranch> getCheckListMappingBranchs() {
		return checkListMappingBranchs;
	}

	public List<CheckListMappingDepartment> getCheckListMappingDepartments() {
		return checkListMappingDepartments;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCheckListDescription(CheckListDescription checkListDescription) {
		this.checkListDescription = checkListDescription;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public void setDocumentRef(String documentRef) {
		this.documentRef = documentRef;
	}

	public void setCheckListMappingBranchs(List<CheckListMappingBranch> checkListMappingBranchs) {
		this.checkListMappingBranchs = checkListMappingBranchs;
	}

	public void setCheckListMappingDepartments(List<CheckListMappingDepartment> checkListMappingDepartments) {
		this.checkListMappingDepartments = checkListMappingDepartments;
	}


}
