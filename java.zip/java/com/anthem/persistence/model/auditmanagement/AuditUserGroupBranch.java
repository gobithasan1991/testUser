package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
@Audited
@Entity
public class AuditUserGroupBranch extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 106315727524277402L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
    private Branch branch;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private AuditUserGroup auditUserGroup;

	public Long getId() {
		return id;
	}

	public Branch getBranch() {
		return branch;
	}

	public AuditUserGroup getAuditUserGroup() {
		return auditUserGroup;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public void setAuditUserGroup(AuditUserGroup auditUserGroup) {
		this.auditUserGroup = auditUserGroup;
	}
	
	
	
	

}
