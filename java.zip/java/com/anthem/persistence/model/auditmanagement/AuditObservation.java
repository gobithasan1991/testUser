package com.anthem.persistence.model.auditmanagement;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.YesOrNoStatus;

@Entity
public class AuditObservation extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6486473188001237997L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private AuditScheduler auditScheduler;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	private QMSDepartment auditDepartment;	
	
	private String fileName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private Branch branch;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ObservationCategory observationCategory;	
	
	@Lob
	private String guidelinesReference;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private User acceptBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date acceptDate;

	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus checkListRequired;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ObservationCheckList.class)
	@JoinColumn(name ="auditObservation_id")
	private List<ObservationCheckList>  observationCheckLists;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus additionalObservationRequired;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = AdditionalObservation.class)
	@JoinColumn(name ="auditObservation_id")
	private List<AdditionalObservation> additionalObservations;
	
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('YES', 'NO') DEFAULT 'NO'")
	private YesOrNoStatus departmentPositivesRequired;
	
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = DepartmentPositive.class)
	@JoinColumn(name ="auditObservation_id")
	private List<DepartmentPositive> departmentPositives;
	
	
	
	
	public Long getId() {
		return id;
	}	

	public AuditScheduler getAuditScheduler() {
		return auditScheduler;
	}
	
	public QMSDepartment getAuditDepartment() {
		return auditDepartment;
	}


	public String getFileName() {
		return fileName;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

	public void setAuditScheduler(AuditScheduler auditScheduler) {
		this.auditScheduler = auditScheduler;
	}


	public void setAuditDepartment(QMSDepartment auditDepartment) {
		this.auditDepartment = auditDepartment;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public User getAcceptBy() {
		return acceptBy;
	}

	public Date getAcceptDate() {
		return acceptDate;
	}

	public void setAcceptBy(User acceptBy) {
		this.acceptBy = acceptBy;
	}

	public void setAcceptDate(Date acceptDate) {
		this.acceptDate = acceptDate;
	}

	public ObservationCategory getObservationCategory() {
		return observationCategory;
	}

	public String getGuidelinesReference() {
		return guidelinesReference;
	}

	public void setObservationCategory(ObservationCategory observationCategory) {
		this.observationCategory = observationCategory;
	}

	public void setGuidelinesReference(String guidelinesReference) {
		this.guidelinesReference = guidelinesReference;
	}

	public YesOrNoStatus getCheckListRequired() {
		return checkListRequired;
	}

	public List<ObservationCheckList> getObservationCheckLists() {
		return observationCheckLists;
	}

	public YesOrNoStatus getAdditionalObservationRequired() {
		return additionalObservationRequired;
	}

	public List<AdditionalObservation> getAdditionalObservations() {
		return additionalObservations;
	}

	public YesOrNoStatus getDepartmentPositivesRequired() {
		return departmentPositivesRequired;
	}

	public List<DepartmentPositive> getDepartmentPositives() {
		return departmentPositives;
	}

	public void setCheckListRequired(YesOrNoStatus checkListRequired) {
		this.checkListRequired = checkListRequired;
	}

	public void setObservationCheckLists(List<ObservationCheckList> observationCheckLists) {
		this.observationCheckLists = observationCheckLists;
	}

	public void setAdditionalObservationRequired(YesOrNoStatus additionalObservationRequired) {
		this.additionalObservationRequired = additionalObservationRequired;
	}

	public void setAdditionalObservations(List<AdditionalObservation> additionalObservations) {
		this.additionalObservations = additionalObservations;
	}

	public void setDepartmentPositivesRequired(YesOrNoStatus departmentPositivesRequired) {
		this.departmentPositivesRequired = departmentPositivesRequired;
	}

	public void setDepartmentPositives(List<DepartmentPositive> departmentPositives) {
		this.departmentPositives = departmentPositives;
	}
	
}
