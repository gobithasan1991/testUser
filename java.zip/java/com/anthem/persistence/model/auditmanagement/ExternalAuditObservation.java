package com.anthem.persistence.model.auditmanagement;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.anthem.persistence.model.common.Default;

@Entity
public class ExternalAuditObservation extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3421796958839905688L;
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ExternalAuditScheduler externalAuditScheduler;
	
	@Lob
	private String observation;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ExternalAuditObservationItem.class)
	@JoinColumn(name = "externalAuditObservation_id")
	private List<ExternalAuditObservationItem> externalAuditObservationItems;

	public Long getId() {
		return id;
	}

	public ExternalAuditScheduler getExternalAuditScheduler() {
		return externalAuditScheduler;
	}

	public String getObservation() {
		return observation;
	}

	public List<ExternalAuditObservationItem> getExternalAuditObservationItems() {
		return externalAuditObservationItems;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setExternalAuditScheduler(ExternalAuditScheduler externalAuditScheduler) {
		this.externalAuditScheduler = externalAuditScheduler;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	public void setExternalAuditObservationItems(List<ExternalAuditObservationItem> externalAuditObservationItems) {
		this.externalAuditObservationItems = externalAuditObservationItems;
	}
		

}
