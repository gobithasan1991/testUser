package com.anthem.persistence.model.auditmanagement;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
@Audited
@Entity
public class AuditUserGroupUser extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1361580249649228526L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private User user;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	private AuditUserGroup auditUserGroup;

	public Long getId() {
		return id;
	}

	public User getUser() {
		return user;
	}

	public AuditUserGroup getAuditUserGroup() {
		return auditUserGroup;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setAuditUserGroup(AuditUserGroup auditUserGroup) {
		this.auditUserGroup = auditUserGroup;
	}
	
	
	

}
