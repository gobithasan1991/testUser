package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.common.Default;

@Entity
public class CheckListMappingDepartment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3422798254605832988L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)	
	private QMSDepartment department;
	
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)	
	private CheckListMapping checkListMapping;

	public Long getId() {
		return id;
	}

	public QMSDepartment getDepartment() {
		return department;
	}

	public CheckListMapping getCheckListMapping() {
		return checkListMapping;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDepartment(QMSDepartment department) {
		this.department = department;
	}

	public void setCheckListMapping(CheckListMapping checkListMapping) {
		this.checkListMapping = checkListMapping;
	}

}
