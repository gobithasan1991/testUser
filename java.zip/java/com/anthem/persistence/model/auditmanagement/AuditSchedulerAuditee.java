package com.anthem.persistence.model.auditmanagement;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Audited
@Entity
public class AuditSchedulerAuditee extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 856172198667001809L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private User auditee;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private AuditScheduler auditScheduler;

	public Long getId() {
		return id;
	}

	public User getAuditee() {
		return auditee;
	}

	public AuditScheduler getAuditScheduler() {
		return auditScheduler;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAuditee(User auditee) {
		this.auditee = auditee;
	}

	public void setAuditScheduler(AuditScheduler auditScheduler) {
		this.auditScheduler = auditScheduler;
	}
	
}
