package com.anthem.persistence.repository.anthemerp;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.anthemerp.Product;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface ProductRepo extends JpaRepository<Product, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(p.id, p.code, p.name) FROM Product p "
			+ "WHERE p.enabledStatus IN(:enabledStatus) ORDER BY p.name")
	public List<IdCodeName> findAllByEnabledStatus(@Param("enabledStatus") EnabledStatus enabledStatus);

}
