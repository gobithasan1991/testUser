package com.anthem.persistence.repository.anthemerp;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.anthemerp.Customer;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(cus.id, cus.name, cus.name) FROM Customer cus "
			+ "WHERE cus.enabledStatus IN(:enabledStatus) ORDER BY cus.name")
	public List<IdCodeName> findAllByEnabledStatus(@Param("enabledStatus") EnabledStatus enabledStatus);

}
