package com.anthem.persistence.repository.admin;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.admin.DefaultPassword;

public interface DefaultPasswordRepo extends JpaRepository<DefaultPassword, Long> {
	public DefaultPassword findByEnabledTrue();
}
