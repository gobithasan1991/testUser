package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.admin.QMSCategory;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface QMSCategoryRepo extends JpaRepository<QMSCategory, Long> {

	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(QC.id, QC.code, QC.name) FROM QMSCategory QC WHERE QC.enabledStatus=:enabledStatus ORDER BY QC.name")	
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	public QMSCategory findByCode(String code);
 }
