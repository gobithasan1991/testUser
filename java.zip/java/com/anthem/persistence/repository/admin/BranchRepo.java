package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.anthem.persistence.model.admin.Branch;

public interface BranchRepo extends JpaRepository<Branch, Long> {
	@Query(value = "SELECT b FROM Branch b JOIN FETCH b.company WHERE b.enabled = ?1")
	List<Branch> findByEnabled(boolean enabled);

	@Query(value = "SELECT b FROM Branch b JOIN FETCH b.company c WHERE b.enabled = TRUE AND c.id=?1")
	List<Branch> findByCompany_Id(Long companyId);
}
