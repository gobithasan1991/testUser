package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.admin.State;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface StateRepo extends JpaRepository<State, Long> {

	@Query(value = "SELECT S FROM State S JOIN S.country C WHERE C.id =:countryId AND S.enabledStatus =:enabledStatus ORDER By S.name")
	public List<State> findAllByCountryAndEnabledStatus(@Param("countryId") Long countryId,
			@Param("enabledStatus") EnabledStatus enabledStatus);
}
