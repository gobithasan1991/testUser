package com.anthem.persistence.repository.admin;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.admin.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {

	public List<Employee> findByResignedFalse();

	public List<Employee> findByResignedTrue();

	@Query(value = "SELECT DISTINCT e FROM Employee e WHERE e.department.code = ?1 AND e.resigned IS FALSE")
	public List<Employee> listEmployeeByDepartmentCode(String department);

	@Query(value = "SELECT e FROM Employee e WHERE e.resigned IS FALSE AND e.user IS NULL")
	public List<Employee> findByResignedFalseAndUserIdIsNull();

	public Employee findByEmpId(String empId);

	public Employee findByUsername(String username);

	@Query(value = "SELECT e FROM Employee e WHERE (e.dateOfJoin BETWEEN :startDate AND :endDate) AND e.resigned IS FALSE")
	public List<Employee> findByDateOfJoinBetween(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

}
