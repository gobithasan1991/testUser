package com.anthem.persistence.repository.admin;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface QMSDepartmentRepo extends JpaRepository<QMSDepartment, Long> {

	@Query("select new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.code,q.name) from QMSDepartment q where q.enabledStatus=:enabledStatus ORDER BY q.name")
	List<IdNameCodeDTO> findAllQDeptIsEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	
	@Query("select new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.code,q.name) from QMSDepartment q ORDER BY q.name")
	List<IdNameCodeDTO> findAllQDeptForReport();

	@Transactional
	@Query("select qd from QMSDepartment qd where qd.enabled=?1 ")
	Page<QMSDepartment> getQMSDepartmentWithPageableData(Boolean true1, Pageable pageable);

	List<QMSDepartment> findByDepartment(Department department);

	QMSDepartment findByName(String deptName);

	@Query(value = "SELECT q.id FROM QMSDepartment q WHERE q.enabled=true")
	Set<Long> finAllQmsDepartmentId();

	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.name) FROM QMSDepartment q WHERE q.id IN(:qmsDepartmentIds) AND q.enabledStatus=:enabledStatus ORDER BY q.name")
	public Set<IdNameCodeDTO> findQmsDepartmentByIds(@Param("qmsDepartmentIds") Set<Long> qmsDepartmentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT q FROM QMSDepartment q WHERE q.id NOT IN(:qmsDepartmentIds) AND q.enabled=:enabledStatus ORDER BY q.name")
	public List<QMSDepartment> findQmsDepartmentByNotInIds(@Param("qmsDepartmentIds") List<Long> qmsDepartmentIds,
			@Param("enabledStatus") Boolean enabledStatus);

	@Query(value = "SELECT q.id FROM QMSDepartment q WHERE q.enabledStatus=:enabledStatus")
	public Set<Long> findAllQmsDepartmentIds(@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.name) FROM QMSDepartment q WHERE q.id NOT IN(:qmsDepartmentIds) AND q.enabledStatus=:enabledStatus ORDER BY q.name")
	public List<IdNameCodeDTO> findQmsDepartmentByQmsDepartmentNotIn(
			@Param("qmsDepartmentIds") List<Long> qmsDepartmentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM QMSDepartment q JOIN q.department d WHERE q.id=:qmsDepartmentId AND q.enabledStatus =:enabledStatus")
	public Long findDepartmentIdByQmsDepartmentId(@Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

}
