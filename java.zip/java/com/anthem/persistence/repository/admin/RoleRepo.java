package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.admin.Role;

public interface RoleRepo extends JpaRepository<Role, Long> {
	public List<Role> findByEnabledTrue();

	public Role findByAuthority(String roleName);
}
