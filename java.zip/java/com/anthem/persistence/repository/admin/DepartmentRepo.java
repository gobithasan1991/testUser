package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.admin.Department;

public interface DepartmentRepo extends JpaRepository<Department, Long> {

	List<Department> findByEnabledTrue();

	@Transactional
	Page<Department> findByEnabledTrue(Pageable pageable);

	Department findByCode(String deptCode);
}
