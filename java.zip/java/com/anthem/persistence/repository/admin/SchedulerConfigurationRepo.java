package com.anthem.persistence.repository.admin;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.admin.SchedulerConfiguration;
import com.anthem.util.common.EnabledStatus;

public interface SchedulerConfigurationRepo extends JpaRepository<SchedulerConfiguration, Long> {

	@Query(value="SELECT sc FROM SchedulerConfiguration sc WHERE sc.module.id=:moduleId")
	public SchedulerConfiguration findByModuleId(@Param("moduleId") Long moduleId);
	@Query(value="SELECT sc FROM SchedulerConfiguration sc JOIN FETCH sc.schedulerConfigurationDurations scd "
			+ "WHERE sc.module.code=:moduleCode AND sc.enabledStatus=:enabledStatus AND scd.enabledStatus=:enabledStatus")
	public SchedulerConfiguration findByModuleCodeAndEnabledStatus(@Param("moduleCode") String moduleCode,@Param("enabledStatus") EnabledStatus enabledStatus);
}
