package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.admin.MailModule;
import com.anthem.util.common.EnabledStatus;

public interface MailModuleRepo extends JpaRepository<MailModule, Long> {
	public MailModule findByCode(String mailModuleCode);
	
	@Query(value = "SELECT m FROM MailModule m WHERE m.mailModuleParent IS NULL AND m.enabledStatus=:enabledStatus")
	public List<MailModule> findMailModuleTree(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT m.mailStatus FROM MailModule m WHERE m.code=:code AND m.enabledStatus=:enabledStatus")
	public EnabledStatus findModuleByCode( @Param("code") String code , @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT m FROM MailModule m WHERE m.mailModuleParent.id=:mailModuleParentId AND m.enabledStatus=:enabledStatus")
	public List<MailModule> getMailModuleChild(@Param("mailModuleParentId") Long mailModuleParentId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT m FROM MailModule m WHERE m.mailStatus=:mailStatus AND m.enabledStatus=:enabledStatus")
	public List<MailModule> getMailModuleByMailStatus(@Param("mailStatus") EnabledStatus mailStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT m FROM MailModule m WHERE m.mailModuleParent.id=:mailModuleParentId AND m.mailStatus=:mailStatus AND m.enabledStatus=:enabledStatus")
	public List<MailModule> getMailModuleChildByMailStatus(@Param("mailModuleParentId") Long mailModuleParentId, @Param("enabledStatus") EnabledStatus enabledStatus, @Param("mailStatus") EnabledStatus mailStatus);
}
