package com.anthem.persistence.repository.admin;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.admin.HODMaster;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.util.common.EnabledStatus;

public interface HODMasterRepo extends JpaRepository<HODMaster, Long> {

	@Query("select h from HODMaster h where h.enabledStatus=?1 and h.hod.id=?2")
	List<HODMaster> findHeadOfDepartment(EnabledStatus enabledStatus, Long employeeId);

	@Query(value = "SELECT DISTINCT qd FROM HODMaster h JOIN QMSDepartment qd ON h.department.id = qd.department.id AND h.enabled = true AND h.hod.id=:hodId")
	Set<QMSDepartment> findQMSDepartmentByHOD(@Param("hodId") Long hodId);
	
	@Query(value ="SELECT h FROM HODMaster h WHERE h.branch.id=:branchId AND h.department.id=:departmentId AND h.endDate IS NULL AND h.enabledStatus=:enabledStatus")
	public HODMaster getHODByBranchIdAndDepartmentId(@Param("branchId") Long branchId, @Param("departmentId") Long departmentId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT h FROM HODMaster h WHERE h.branch.id=:branchId AND h.department.id=:deptId AND h.hod IS NOT NULL")
	public List<HODMaster> listAllHODDetailsByBranchIdAndDepartmentId(@Param("branchId") Long branchId, @Param("deptId") Long deptId);

}
