package com.anthem.persistence.repository.admin;

import java.util.Date;
import java.util.List;

import javax.persistence.TemporalType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Temporal;

import com.anthem.persistence.model.admin.QMSAuditTrail;
import com.anthem.persistence.model.user.User;

public interface QMSAuditTrailsRepo extends JpaRepository<QMSAuditTrail, Long> {

	@Query("select t from QMSAuditTrail t where  t.auditMapId=?1 and t.auditType like %?2% AND t.enabledStatus='OPEN'")
	List<QMSAuditTrail> findByAuditMapIdAndAuditType(Long id, String type);

	@Query("select t from QMSAuditTrail t where t.createdBy=?1 AND t.enabledStatus='OPEN'")
	List<QMSAuditTrail> findByCreatedBy(User User);

	@Query("select t from QMSAuditTrail t where t.user=?1 and t.createdBy not in ?1 AND t.enabledStatus='OPEN'")
	List<QMSAuditTrail> findByUser(User User);

	@Query("select t from QMSAuditTrail t where t.auditMapId=?1 and t.auditType like %?2% AND t.enabledStatus='OPEN'")
	List<QMSAuditTrail> findByAuditMapId(Long mapId, String category);

	@Query("select t from QMSAuditTrail t where Date(t.createdDate) between ?1 and ?2 AND t.enabledStatus='OPEN'")
	List<QMSAuditTrail> findByInterval(@Temporal(TemporalType.DATE) Date from, @Temporal(TemporalType.DATE) Date to);

	@Query("select t from QMSAuditTrail t where Date(t.createdDate) between ?1 and ?2 and t.auditType like %?3% AND t.enabledStatus='OPEN'")
	List<QMSAuditTrail> findByIntervalAndCategory(@Temporal(TemporalType.DATE) Date from,
			@Temporal(TemporalType.DATE) Date to, String category);
}
