package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.admin.Designation;

public interface DesignationRepo extends JpaRepository<Designation, Long>{
	List<Designation> findByEnabledTrue();

	@Transactional
	Page<Designation> findByEnabledTrue(Pageable pageable);

	Designation findByName(String designationName);
}
