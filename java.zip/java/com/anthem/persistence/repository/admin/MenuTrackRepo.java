/**
 * 
 */
package com.anthem.persistence.repository.admin;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.admin.MenuTrack;

/**
 * @author kalaiselvan.a
 *
 */
public interface MenuTrackRepo extends JpaRepository<MenuTrack, Long> {

}
