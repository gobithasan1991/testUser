package com.anthem.persistence.repository.admin;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.admin.DefaultBCC;
import com.anthem.persistence.model.admin.DefaultBCCOther;
import com.anthem.persistence.model.admin.DefaultCC;
import com.anthem.persistence.model.admin.DefaultCCOther;
import com.anthem.persistence.model.admin.EmailConfiguration;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface EmailConfigurationRepo extends JpaRepository<EmailConfiguration, Long> {

	@Query(value = "SELECT EC FROM EmailConfiguration EC JOIN EC.moduleName M WHERE M.id=:moduleId AND EC.enabledStatus=:enabledStatus")
	public EmailConfiguration findByModule(@Param("moduleId") Long moduleId,
			@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT EC FROM EmailConfiguration EC JOIN EC.moduleName M WHERE M.code=:moduleCode AND EC.enabledStatus=:enabledStatus")
	public EmailConfiguration findByModuleCode(@Param("moduleCode") String moduleCode, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Modifying
	@Query(value = "UPDATE FROM DefaultCC DCC  SET DCC.enabledStatus='CLOSED' WHERE DCC.emailConfiguration.id=:mailConfigId ")
	public void disableAllDefaultCC(@Param("mailConfigId") Long mailConfigId);

	@Modifying
	@Query(value = "UPDATE FROM DefaultBCC DBCC SET DBCC.enabledStatus='CLOSED' WHERE  DBCC.emailConfiguration.id=:mailConfigId ")
	public void disableAllDefaultBCC(@Param("mailConfigId") Long mailConfigId);

	@Modifying
	@Query(value = "UPDATE FROM DefaultCCOther DCCO SET DCCO.enabledStatus='CLOSED' WHERE DCCO.emailConfiguration.id=:mailConfigId ")
	public void disableAllDefaultCCOS(@Param("mailConfigId") Long mailConfigId);

	@Modifying
	@Query(value = "UPDATE FROM DefaultBCCOther DBCCO SET DBCCO.enabledStatus='CLOSED' WHERE DBCCO.emailConfiguration.id=:mailConfigId ")
	public void disableAllDefaultBCCOS(@Param("mailConfigId") Long mailConfigId);

	@Query(value = "SELECT dcc FROM DefaultCC dcc JOIN dcc.emailConfiguration ec JOIN dcc.user u WHERE ec.id=:mailConfigId AND u.id=:userId")
	DefaultCC findDefaultCCByEmailId(@Param("mailConfigId") Long mailConfigId, @Param("userId") Long userId);

	@Query(value = "SELECT dbcc FROM DefaultBCC dbcc JOIN dbcc.emailConfiguration ec JOIN dbcc.user u WHERE ec.id=:mailConfigId AND u.id=:userId")
	DefaultBCC findDefaultBCCByEmailId(@Param("mailConfigId") Long mailConfigId, @Param("userId") Long userId);

	@Query(value = "SELECT DCCO FROM DefaultCCOther DCCO JOIN DCCO.emailConfiguration EC WHERE EC.id=:mailConfigId AND DCCO.emailId=:emailId")
	public DefaultCCOther findDefaultCCOtherByEmailId(@Param("mailConfigId") Long mailConfigId,
			@Param("emailId") String emailId);

	@Query(value = "SELECT DBCCO FROM DefaultBCCOther DBCCO JOIN DBCCO.emailConfiguration EC WHERE EC.id=:mailConfigId AND DBCCO.emailId=:emailId")
	public DefaultBCCOther findDefaultBCCOtherByEmailId(@Param("mailConfigId") Long mailConfigId,
			@Param("emailId") String emailId);
}
