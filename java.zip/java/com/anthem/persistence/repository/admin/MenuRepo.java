package com.anthem.persistence.repository.admin;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.anthem.persistence.model.admin.Menu;
import com.anthem.util.admin.MenuType;

public interface MenuRepo extends JpaRepository<Menu, Long> {
	public List<Menu> findByEnabledTrueAndMenuTypeIn(List<MenuType> menuTypes);

	public List<Menu> findByMenuTypeAndPrivilege_AuthorityContainingAndEnabled(MenuType menuType, String privilage,
			Boolean enabled);

	public Set<Menu> findByMenuNameIn(List<String> menuNames);

	public Menu findByMenuName(String menuName);

	public Menu findByMenuState(String menuState);

	@Query(value = "SELECT DISTINCT m FROM Menu m WHERE m.menuParent IS NULL AND m.menuType IN ('MENU','BOTH') AND m.enabled=?1 ORDER By m.menuOrder ASC")
	public List<Menu> findByEnabledAndMenuParentIsNull(boolean enabled);

	@Query("SELECT DISTINCT m FROM Menu m WHERE  m.menuType IN ('MENU','BOTH') AND m.id IN (?1) AND m.enabled = TRUE ORDER BY m.id ASC")
	public Set<Menu> findByMenuIdIn(List<Long> menuIds);
}
