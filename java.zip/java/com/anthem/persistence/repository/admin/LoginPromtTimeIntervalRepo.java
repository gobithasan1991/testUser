package com.anthem.persistence.repository.admin;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.admin.LoginPromtTimeInterval;
import com.anthem.util.common.EnabledStatus;

public interface LoginPromtTimeIntervalRepo extends JpaRepository<LoginPromtTimeInterval, Long>{
	@Query("SELECT lpti FROM LoginPromtTimeInterval lpti WHERE lpti.type = :type AND lpti.enabledStatus=:enabledStatus")
	public LoginPromtTimeInterval findLoginPromtTimeIntervalByType(@Param("type") String type,@Param("enabledStatus") EnabledStatus enabledStatus);
	@Query("SELECT lpti FROM LoginPromtTimeInterval lpti WHERE lpti.type = :type")
	public LoginPromtTimeInterval findLoginPromtTimeIntervalByType(@Param("type") String type);
}
