package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.admin.Company;

public interface CompanyRepo extends JpaRepository<Company, Long> {

	List<Company> findByEnabledTrue();

}
