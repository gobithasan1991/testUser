/**
 * 
 */
package com.anthem.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.admin.Country;
import com.anthem.util.common.EnabledStatus;

/**
 * @author shivakumar.m
 *
 */
@Repository
public interface CountryRepo extends JpaRepository<Country, Long> {

	@Query(value = "SELECT c FROM Country c WHERE c.enabledStatus =:enabledStatus ORDER By c.name")
	public List<Country> findAllEnabledCountries(@Param("enabledStatus") EnabledStatus enabledStatus);
}
