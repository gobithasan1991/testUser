package com.anthem.persistence.repository.common;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.common.Reason;

public interface ReasonRepo extends JpaRepository<Reason, Long>{

}
