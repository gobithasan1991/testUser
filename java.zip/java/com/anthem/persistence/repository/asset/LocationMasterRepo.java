package com.anthem.persistence.repository.asset;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.asset.LocationMaster;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface LocationMasterRepo extends JpaRepository<LocationMaster, Long>{
	
	@Query(value = "select new com.anthem.web.service.common.dto.IdCodeName(lm.id,lm.code,lm.name) FROM LocationMaster lm WHERE lm.enabledStatus=:enabledStatus ORDER BY lm.name")
	public List<IdCodeName> listLocation(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT l FROM LocationMaster l WHERE l.branch.id=:branchId")
	public List<LocationMaster> listAllLocationMasterDetailsByBranchId(@Param("branchId") Long branchId);
	
	@Query(value ="SELECT new com.anthem.web.service.common.dto.IdCodeName(l.id, l.code, l.name) FROM LocationMaster l WHERE l.branch.id=:branchId AND l.enabledStatus = :enabledStatus ORDER BY l.name")
	public List<IdCodeName> getICNByBranchId(@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT new com.anthem.web.service.common.dto.IdCodeName(l.id, l.code, l.name) FROM LocationMaster l WHERE l.id NOT IN (:locationIdArr) AND l.enabledStatus = :enabledStatus ORDER BY l.name")
	public List<IdCodeName> getICNByBranchIdAndDeptIdAndAssetId(@Param("locationIdArr") List<Long> locationIdArr, @Param("enabledStatus") EnabledStatus enabledStatus);
	
}
