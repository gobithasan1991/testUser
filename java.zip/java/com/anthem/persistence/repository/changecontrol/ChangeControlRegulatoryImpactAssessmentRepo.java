package com.anthem.persistence.repository.changecontrol;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ChangeControlRegulatoryImpactAssessment;
import com.anthem.persistence.model.user.User;
import com.anthem.util.changecontrol.AssessmentStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlAssessmentByDepartmentDto;
import com.anthem.web.service.changecontrol.dto.ChangeControlRegulatoryImpactAssessmentDto;

@Repository
public interface ChangeControlRegulatoryImpactAssessmentRepo extends JpaRepository<ChangeControlRegulatoryImpactAssessment, Long> {

	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlRegulatoryImpactAssessmentDto(CCRIA) FROM ChangeControlRegulatoryImpactAssessment CCRIA JOIN CCRIA.changeControlNumber CCNO "
			+ "WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CCRIA.enabledStatus=:enabledStatus")
	public ChangeControlRegulatoryImpactAssessmentDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Modifying(clearAutomatically = true)
	@Query(value="UPDATE ChangeControlAssessmentByDepartment AD SET AD.required=:required, AD.impactedDocument=:impacteDoc, AD.targetDate=:targetDate, AD.responsibility=:responsibility, "
			+ "AD.assessmentStatus=:assessmentStatus, AD.specialNotes=:specialNotes, AD.assessedBy=:assessedBy, AD.assessedDate=:assessedDate WHERE AD.id=:id AND AD.enabledStatus=:enabledStatus")
	public void assessmentByDepartment(@Param("required") YesOrNoStatus required, @Param("impacteDoc") String impacteDoc,
			@Param("targetDate") Date targetDate, @Param("responsibility") User responsibility, @Param("assessmentStatus") AssessmentStatus assessmentStatus, 
			@Param("specialNotes") String specialNotes,	@Param("assessedBy") User assessedBy, @Param("assessedDate") Date assessedDate,
			@Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Modifying(clearAutomatically = true)
	@Query(value="UPDATE ChangeControlAssessmentByDepartment AD SET AD.assessmentStatus=:assessmentStatus, AD.assessedBy=:assessedBy, AD.assessedDate=:assessedDate WHERE AD.id=:id AND AD.enabledStatus=:enabledStatus")
	public void assessmentByDepartment(@Param("assessmentStatus") AssessmentStatus assessmentStatus, 
			@Param("assessedBy") User assessedBy, @Param("assessedDate") Date assessedDate,
			@Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlAssessmentByDepartmentDto(CCRD) FROM ChangeControlAssessmentByDepartment CCRD JOIN "
			+ "CCRD.changeControllerRegulatoryImpactAssessment CCRIA JOIN CCRD.department DEPT WHERE CCRIA.id=:ccRiaId AND DEPT.id=:departmentId AND CCRD.enabledStatus=:enabledStatus")
	public List<ChangeControlAssessmentByDepartmentDto> findAllByChangeControlANDDepartmentId(@Param("ccRiaId") Long ccRiaId, @Param("departmentId") Long departmentId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT count(CCRD) FROM ChangeControlAssessmentByDepartment CCRD JOIN "
			+ "CCRD.changeControllerRegulatoryImpactAssessment CCRIA WHERE CCRIA.id=:ccRiaId AND CCRD.assessmentStatus=:assessmentStatus AND CCRD.enabledStatus=:enabledStatus")
	public int remainingAssessments(@Param("ccRiaId") Long ccRiaId, @Param("assessmentStatus") AssessmentStatus assessmentStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
}
