package com.anthem.persistence.repository.changecontrol;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlTargetDate;
import com.anthem.util.common.EnabledStatus;

import com.anthem.web.service.changecontrol.dto.ChangeControlTargetDateDto;

public interface ChangeControlTargetDateRepo extends JpaRepository<ChangeControlTargetDate, Long>{
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlTargetDateDto(CTD) FROM ChangeControlTargetDate CTD "
			+ "JOIN CTD.changeControlNumber CCNO WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CTD.enabledStatus=:enabledStatus")
	public ChangeControlTargetDateDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
