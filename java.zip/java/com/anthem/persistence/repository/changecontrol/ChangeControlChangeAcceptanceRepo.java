package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlChangeAcceptance;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlChangeAcceptanceDto;

public interface ChangeControlChangeAcceptanceRepo extends JpaRepository<ChangeControlChangeAcceptance, Long> {

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE ChangeControlChangeAcceptance CA SET CA.enabledStatus=:enabledStatusN WHERE CA.changeControlNumber.id=:id AND CA.enabledStatus=:enabledStatus")
	public void deactiveAll(@Param("enabledStatusN") EnabledStatus enabledStatusN, @Param("id") Long id,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlChangeAcceptanceDto(CA) FROM ChangeControlChangeAcceptance CA "
			+ "JOIN CA.changeControlNumber CCNO WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CA.enabledStatus=:enabledStatus")
	public ChangeControlChangeAcceptanceDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlChangeAcceptanceDto(CA, CCNO) FROM ChangeControlChangeAcceptance CA "
			+ "JOIN CA.changeControlNumber CCNO JOIN CCNO.branch CCNOB JOIN CCNO.changeControlRequest CCR JOIN CCR.department QMSDEPT WHERE QMSDEPT.id IN (:userQmsDeptIds) AND CCR.changeControlStatus=:changeControlStatus AND"
			+ " CA.changeAcceptance=:changeAcceptance AND CCNOB.id=:branchId AND CCNO.enabledStatus=:enabledStatus AND CA.enabledStatus=:enabledStatus")
	public Page<ChangeControlChangeAcceptanceDto> findAllChangeAccepted(
			@Param("userQmsDeptIds") List<Long> userQmsDeptIds,
			@Param("changeControlStatus") ChangeControlStatus changeControlStatus,
			@Param("changeAcceptance") YesOrNoStatus changeAcceptance, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT DISTINCT CA FROM ChangeControlChangeAcceptance CA JOIN CA.changeControlNumber CCNO JOIN CCNO.branch CCNOB JOIN CCNO.changeControlRequest "
			+ "CCR WHERE CCR.changeControlStatus IN (:changeControlStatus) AND CCNOB.id=:branchId AND CCNO.enabledStatus=:enabledStatus AND CA.enabledStatus=:enabledStatus")
	public List<ChangeControlChangeAcceptance> findAllChangeAccepted(
			@Param("changeControlStatus") List<ChangeControlStatus> changeControlStatus,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
