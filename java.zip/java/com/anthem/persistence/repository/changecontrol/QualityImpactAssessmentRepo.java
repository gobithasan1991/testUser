package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.QualityImpactAssessment;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;
@Repository
public interface QualityImpactAssessmentRepo extends JpaRepository<QualityImpactAssessment, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(qia.id, qia.code, qia.name) FROM QualityImpactAssessment qia LEFT JOIN qia.department dept WHERE (dept.id=:departmentId OR department_id IS NULL) AND qia.enabledStatus=:enabledStatus ORDER BY qia.name")
	public List<IdCodeName> findAllByDepartmentANDEnabledStatus(@Param("departmentId") Long departmentId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value="SELECT DISTINCT(qia) FROM QualityImpactAssessment qia LEFT JOIN qia.department dept WHERE dept.id=:departmentId OR department_id IS NULL")
	public List<QualityImpactAssessment> findAllForUpdate(@Param("departmentId") Long departmentId);
	
	 
	QualityImpactAssessment findByCodeAndDepartmentIsNull(String code);
	
	
}
