package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ChangeControlClosureComment;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface ChangeControlClosureCommentRepo extends JpaRepository<ChangeControlClosureComment, Long> {

	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(CCMT.id, CCMT.code, CCMT.name) FROM ChangeControlClosureComment CCMT "
			+ "WHERE CCMT.enabledStatus=:enabledStatus ORDER BY CCMT.name")
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
}
