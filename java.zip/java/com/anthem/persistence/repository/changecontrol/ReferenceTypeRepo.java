package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ReferenceType;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface ReferenceTypeRepo extends JpaRepository<ReferenceType, Long> {
	@Query(value = "SELECT RT FROM ReferenceType RT WHERE RT.enabledStatus=:enabledStatus ORDER BY RT.name")
	public List<ReferenceType> findAllByEnabledStatus(@Param("enabledStatus") EnabledStatus enabledStatus);
}
