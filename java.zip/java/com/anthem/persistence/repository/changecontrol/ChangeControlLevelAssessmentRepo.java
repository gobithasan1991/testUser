package com.anthem.persistence.repository.changecontrol;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlLevelAssessment;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlLevelAssessmentDto;

public interface ChangeControlLevelAssessmentRepo extends JpaRepository<ChangeControlLevelAssessment, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlLevelAssessmentDto(CCL) FROM ChangeControlLevelAssessment CCL "
			+ "JOIN CCL.changeControlNumber CCNO WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CCL.enabledStatus=:enabledStatus")
	public ChangeControlLevelAssessmentDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);

}
