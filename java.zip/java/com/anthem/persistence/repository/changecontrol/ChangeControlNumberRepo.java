package com.anthem.persistence.repository.changecontrol;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlNumber;
import com.anthem.util.auditmanagement.DocumentChange;
import com.anthem.util.changecontrol.AssessmentStatus;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto;
import com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto;

public interface ChangeControlNumberRepo extends JpaRepository<ChangeControlNumber, Long> {	
	
	@Query(value = "SELECT COUNT(ccn) FROM ChangeControlNumber ccn WHERE ccn.ccNumber LIKE :prefixLike%")
	public int findAvailableSeriesCount(@Param("prefixLike") String prefixLike);
	
	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto(ccn) FROM "
			+ "ChangeControlNumber ccn JOIN ccn.branch ccnb JOIN ccn.changeControlRequest ccnr WHERE ccnr.changeControlStatus =:changeControlStatus AND ccnb.id=:branchId AND "
			+ "ccn.enabledStatus=:enabledStatus AND ccnr.enabledStatus=:enabledStatus")
	public Page<ChangeControlNumberDto> findCCNumbersByEnabledStatus(@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto(ccn) FROM "
			+ "ChangeControlNumber ccn JOIN ccn.changeControlRequest ccnr WHERE (ccnr.changeControlStatus =:changeControlStatus OR ccnr.changeControlStatus =:changeControlStatus1) AND "
			+ "ccn.enabledStatus=:enabledStatus AND ccnr.enabledStatus=:enabledStatus")
	public Page<ChangeControlNumberDto> findCCNumbersByEnabledStatus(@Param("changeControlStatus") ChangeControlStatus changeControlStatus,@Param("changeControlStatus1") ChangeControlStatus changeControlStatus1,@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	
	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto(ccn) FROM "
			+ "ChangeControlNumber ccn JOIN ccn.changeControlRequest ccnr WHERE ccn.id=:id AND ccn.enabledStatus=:enabledStatus AND ccnr.enabledStatus=:enabledStatus")
	public ChangeControlNumberDto findOneByIdANDEnabledStatus(@Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto(ccn) FROM ChangeControlRegulatoryImpactAssessment ccri JOIN ccri.changeControlNumber ccn JOIN ccn.branch ccnb JOIN ccn.changeControlRequest ccnr "
			+ "JOIN ccri.changeControlAssessmentByDepartments ccrids JOIN ccrids.department depts WHERE depts.id=:departmentId AND ccnb.id=:branchId AND ccnr.changeControlStatus=:changeControlStatus "
			+ "AND ccrids.assessmentStatus=:assessmentStatus AND ccnr.enabledStatus=:enabledStatus AND ccri.enabledStatus=:enabledStatus")
	public Page<ChangeControlNumberDto> findCCNumbersByDepatmentIdAndEnabledStatus(@Param("departmentId") Long departmentId, @Param("branchId") Long branchId,
			@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("assessmentStatus") AssessmentStatus assessmentStatus, 
			@Param("enabledStatus") EnabledStatus enabledStatus,Pageable pageable);
	
	@Query(value = "SELECT DISTINCT ccn FROM ChangeControlRegulatoryImpactAssessment ccri JOIN ccri.changeControlNumber ccn JOIN ccn.branch ccnb JOIN ccn.changeControlRequest ccnr "
			+ "LEFT JOIN ccri.changeControlAssessmentByDepartments ccrids  WHERE (ccnr.changeControlStatus=:changeControlStatus1 AND ccrids is NULL) OR (ccnr.changeControlStatus=:changeControlStatus) AND ccnb.id=:branchId AND ccnr.enabledStatus=:enabledStatus AND ccri.enabledStatus=:enabledStatus")
	public  Page<ChangeControlNumber> findCCNumbersforLevelAssessment(@Param("changeControlStatus") ChangeControlStatus changeControlStatus,@Param("changeControlStatus1") ChangeControlStatus changeControlStatus1, @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	
	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto(ccnr) FROM ChangeControlRequest ccnr JOIN ccnr.branch ccnrb "
			+ " JOIN ccnr.department qmsDept WHERE ccnr.changeControlStatus=:changeControlStatus AND "
			+ "(:deptId is  null OR qmsDept.id=:deptId) AND (:fromDate is null OR ccnr.createdDate BETWEEN :fromDate AND :toDate) AND ccnr.enabledStatus=:enabledStatus AND ccnrb.id=:branchId ORDER BY ccnr.requestNo")
	public Page<ChangeRequestCustomDto> findAllForCCRegisterCompleted(@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("deptId") Long deptId, 
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);
	
	
	@Query(value = "SELECT new com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto(ccnr) FROM ChangeControlRequest ccnr JOIN ccnr.branch ccnrb "
			+ " JOIN ccnr.department qmsDept WHERE ccnr.changeControlStatus!=:changeControlStatus AND "
			+ "(:deptId is  null OR qmsDept.id=:deptId) AND (:fromDate is null OR ccnr.createdDate BETWEEN :fromDate AND :toDate) AND ccnr.enabledStatus=:enabledStatus AND ccnrb.id=:branchId ORDER BY ccnr.requestNo")
	public Page<ChangeRequestCustomDto> findAllForCCRegisterPending(@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("deptId") Long deptId, 
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);
	
	
	@Query(value = "SELECT ccn FROM ChangeControlNumber ccn JOIN ccn.changeControlRequest ccnr WHERE "
			+ "ccnr.id=:id AND ccn.enabledStatus=:enabledStatus AND ccnr.enabledStatus=:enabledStatus")
	public ChangeControlNumber findOneByCCRId(@Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT ccn FROM ChangeControlNumber ccn JOIN ccn.changeControlRequest ccnr WHERE "
			+ "ccnr.id=:id")
	public ChangeControlNumber findOneByCCRId(@Param("id") Long id);
	
	@Modifying
	@Query(value="UPDATE ChangeControlRequestItemDescription CCRD SET CCRD.documentChange = :documentChange WHERE CCRD.changeId = :changeId AND CCRD.id = :ccrdId")
	public void updateChangeRequestDocumentStatus(@Param("documentChange") DocumentChange documentChange, @Param("changeId") Long changeId, @Param("ccrdId") Long ccrdId);
	
}
