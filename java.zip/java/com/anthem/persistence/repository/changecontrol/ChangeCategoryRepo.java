package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ChangeCategory;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface ChangeCategoryRepo extends JpaRepository<ChangeCategory, Long>  {
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(changeCat.id, changeCat.code, changeCat.name) FROM "
			+ "ChangeCategory changeCat WHERE changeCat.enabledStatus=:enabledStatus ORDER BY changeCat.name")
	public List<IdCodeName> findAllByRecordStatus(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	
	public ChangeCategory findBycode(String code);

}
