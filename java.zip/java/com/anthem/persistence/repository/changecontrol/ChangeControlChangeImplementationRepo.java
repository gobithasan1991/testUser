package com.anthem.persistence.repository.changecontrol;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ChangeControlChangeImplementation;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.AllImpactAssessmentCustomDto;
import com.anthem.web.service.changecontrol.dto.ChangeControlChangeImplementationDto;

@Repository
public interface ChangeControlChangeImplementationRepo extends JpaRepository<ChangeControlChangeImplementation, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.AllImpactAssessmentCustomDto(CIMPL, CA, CCNO) FROM ChangeControlChangeImplementation CIMPL,ChangeControlChangeAcceptance CA "
			+ "JOIN CIMPL.changeControlNumber CCNO JOIN CCNO.branch CCNOB JOIN CCNO.changeControlRequest CCR JOIN CA.changeControlNumber CACCNO WHERE CACCNO.id = CCNO.id AND CCR.changeControlStatus=:changeControlStatus "
			+ "AND CCNOB.id=:branchId AND CIMPL.enabledStatus=:enabledStatus AND CA.enabledStatus=:enabledStatus")
	public Page<AllImpactAssessmentCustomDto> findAllChangeImplmented(@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlChangeImplementationDto(CIMPL) FROM ChangeControlChangeImplementation CIMPL "
			+ "JOIN CIMPL.changeControlNumber CCNO WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CIMPL.enabledStatus=:enabledStatus")
	public ChangeControlChangeImplementationDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
