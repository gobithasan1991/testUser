package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlImpactAssessment;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.YesOrNoStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlImpactAssessmentDto;
import com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto;

public interface ChangeControlImpactAssessmentRepo extends JpaRepository<ChangeControlImpactAssessment, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlImpactAssessmentDto(CCIA) FROM ChangeControlImpactAssessment CCIA JOIN CCIA.changeControlNumber CCNO "
			+ "WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CCIA.enabledStatus=:enabledStatus")
	public ChangeControlImpactAssessmentDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto(CCNO) FROM ChangeControlImpactAssessment CCIA JOIN CCIA.changeControlNumber CCNO JOIN CCNO.branch CCNB "
			+ "JOIN CCNO.changeControlRequest CCR JOIN CCIA.changeControlQualityImpactAssessments CCQIA JOIN CCQIA.qualityImpactAssessment QIA WHERE "
			+ "CCR.changeControlStatus=:changeControlStatus AND QIA.code IN ('CR') AND CCQIA.required=:required AND CCNB.id=:branchId AND CCR.enabledStatus=:enabledStatus AND CCQIA.enabledStatus=:enabledStatus AND CCNO.enabledStatus=:enabledStatus "
			+ "AND CCIA.enabledStatus=:enabledStatus")
	public Page<ChangeControlNumberDto> findAllByCCStatusANDCustomerApprovalRequired(@Param("changeControlStatus") ChangeControlStatus changeControlStatus,@Param("required") YesOrNoStatus required, @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlNumberDto(CCNO) FROM ChangeControlImpactAssessment CCIA JOIN CCIA.changeControlNumber CCNO JOIN CCNO.branch CCNOB "
			+ "JOIN CCNO.changeControlRequest CCR JOIN CCR.department QMSDEPT JOIN CCIA.changeControlQualityImpactAssessments CCQIA JOIN CCQIA.qualityImpactAssessment QIA WHERE "
			+ "((CCR.changeControlStatus='CUSTOMER_APPROVED' AND QIA.code IN ('CR') AND CCQIA.required='YES') OR "
			+ "(CCR.changeControlStatus='LEVEL_ASSESSED' AND QIA.code IN ('CR') AND CCQIA.required='NO')) AND QMSDEPT.id IN (:userQmsDeptIds) AND CCNOB.id=:branchId AND "
			+ "CCR.enabledStatus=:enabledStatus AND CCQIA.enabledStatus=:enabledStatus AND CCNO.enabledStatus=:enabledStatus AND CCIA.enabledStatus=:enabledStatus")
	public Page<ChangeControlNumberDto> findAllTargetDateRequired(@Param("userQmsDeptIds") List<Long> userQmsDeptIds, @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
}
