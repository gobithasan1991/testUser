package com.anthem.persistence.repository.changecontrol;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ChangeControlRequest;
import com.anthem.persistence.model.changecontrol.ChangeControlRequestItemDescription;
import com.anthem.util.auditmanagement.DocumentChange;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlRequestDto;
import com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto;

@Repository
public interface ChangeControlRequestRepo extends JpaRepository<ChangeControlRequest, Long> {
	
	
	@Query(value = "SELECT COUNT(ccr) FROM ChangeControlRequest ccr WHERE ccr.requestNo LIKE :prefixLike%")
	public int findAvailableSeriesCount(@Param("prefixLike") String prefixLike);
	
	@Query(value= "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlRequestDto(ccr) FROM ChangeControlRequest ccr JOIN ccr.branch ccrb LEFT JOIN ccr.reviewer ccrreviewer WHERE  "
			+ "ccrreviewer.id=:reviewerId AND ccrb.id=:branchId AND ccr.changeControlStatus IN (:changeControlStatus) AND ccr.enabledStatus=:enabledStatus ORDER BY ccr.requestNo")
	public Page<ChangeControlRequestDto> findAllByReviewer(@Param("reviewerId") Long reviewerId, @Param("branchId") Long branchId, @Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("enabledStatus") EnabledStatus enabledStatus,Pageable pageable);
	
	@Query(value= "SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlRequestDto(ccr) FROM ChangeControlRequest ccr JOIN ccr.branch ccrb LEFT JOIN ccr.reviewer ccrreviewer WHERE  "
			+ "ccr.changeControlStatus IN (:changeControlStatus) AND ccrb.id=:branchId AND ccr.enabledStatus=:enabledStatus ORDER BY ccr.requestNo")
	public Page<ChangeControlRequestDto> findAllByChangeStatus(@Param("changeControlStatus") ChangeControlStatus changeControlStatus,  @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus,Pageable pageable);
	
	@Modifying(clearAutomatically = true)
	@Query(value="UPDATE ChangeControlRequest CCR SET CCR.changeControlStatus=:changeControlStatus WHERE CCR.id=:ccRId")
	public void updateCCStatus(@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("ccRId") Long ccRId);
	

	@Query(value="SELECT COUNT(CR) FROM ChangeControlRequest CR JOIN CR.branch CRB WHERE CR.changeControlStatus IN (:changeControlStatus) AND CRB.id=:branchId")
	public int getAllByChangeControlStatus(@Param("changeControlStatus") List<ChangeControlStatus> changeControlStatus, @Param("branchId") Long branchId);
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto(CR) FROM ChangeControlRequest CR JOIN CR.branch CRB WHERE "
			+ "CR.changeControlStatus IN (:changeControlStatus) AND CRB.id=:branchId")
	public Page<ChangeRequestCustomDto> findAllByCCStatus(@Param("changeControlStatus") List<ChangeControlStatus> changeControlStatus, @Param("branchId") Long branchId, Pageable pageable);
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto(CR) FROM ChangeControlRequest CR JOIN CR.branch CRB WHERE "
			+ "CR.changeControlStatus NOT IN (:changeControlStatus) AND CRB.id=:branchId")
	public Page<ChangeRequestCustomDto> findAllByCCStatusNOTIN(@Param("changeControlStatus") List<ChangeControlStatus> changeControlStatus, @Param("branchId") Long branchId, Pageable pageable);
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeRequestCustomDto(CR) FROM ChangeControlRequest CR")
	public Page<ChangeRequestCustomDto> findAllCCDetails(Pageable pageable);
	
	@Query(value = "SELECT COUNT(ccr) FROM ChangeControlRequest ccr JOIN ccr.branch ccrb WHERE ccrb.id=:branchId")
	public int findTotalCC(@Param("branchId") Long branchId);
	
	
	@Query(value="SELECT DISTINCT CCRD FROM ChangeControlRequest CCR, DocumentOwner DO JOIN CCR.changeControlRequestItems CCRI JOIN CCRI.changeControlRequestItemDescriptions CCRD "
			+ "JOIN CCRD.changeCategory CCAT JOIN DO.document DOC JOIN DO.user DOWNER WHERE DOC.id = CCRD.changeId AND CCAT.id=:changeCatId AND DOWNER.id=:ownerId AND CCRD.documentChange <> :documentChange "
			+ "AND CCR.changeControlStatus=:changeControlStatus AND CCR.enabledStatus=:enabledStatus ")
	public List<ChangeControlRequestItemDescription> findByRequestAndDocumentOwner(@Param("changeCatId") Long changeCatId ,
			@Param("ownerId") Long ownerId, @Param("documentChange") DocumentChange documentChange,
			@Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT COUNT(CCRD) FROM ChangeControlRequest CCR JOIN CCR.changeControlRequestItems CCRI JOIN CCRI.changeControlRequestItemDescriptions CCRD WHERE "
			+ " CCRD.documentChange IN ('COMPLETED') AND CCR.id=:ccrId AND CCR.enabledStatus=:enabledStatus ")
	public int findDocumentChangeCompleted(@Param("ccrId") Long ccrId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
