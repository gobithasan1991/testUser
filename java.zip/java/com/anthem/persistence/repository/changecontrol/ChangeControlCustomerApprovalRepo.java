package com.anthem.persistence.repository.changecontrol;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.changecontrol.ChangeControlCustomerApproval;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlCustomerApprovalDto;

@Repository
public interface ChangeControlCustomerApprovalRepo extends JpaRepository<ChangeControlCustomerApproval, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlCustomerApprovalDto(CA) FROM ChangeControlCustomerApproval CA JOIN CA.changeControlNumber CCNO "
			+ "WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CA.enabledStatus=:enabledStatus")
	public ChangeControlCustomerApprovalDto findByCCNOIdANDEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
