package com.anthem.persistence.repository.changecontrol;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlImpactAssessmentByEhs;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlImpactAssessmentByEhsDto;

public interface ChangeControlImpactAssessmentByEhsRepo extends JpaRepository<ChangeControlImpactAssessmentByEhs, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlImpactAssessmentByEhsDto(IAEHS) FROM ChangeControlImpactAssessmentByEhs IAEHS "
			+ "JOIN IAEHS.changeControlNumber CCNO WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND IAEHS.enabledStatus=:enabledStatus")
	public ChangeControlImpactAssessmentByEhsDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);

}
