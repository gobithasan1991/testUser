package com.anthem.persistence.repository.changecontrol;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.changecontrol.ChangeControlTargetDateExtension;
import com.anthem.util.changecontrol.ChangeControlStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.changecontrol.dto.ChangeControlTargetDateExtensionDto;

public interface ChangeControlTargetDateExtensionRepo extends JpaRepository<ChangeControlTargetDateExtension, Long> {

	
	@Modifying(clearAutomatically = true)
	@Query(value="UPDATE ChangeControlTargetDateExtension CTE SET CTE.enabledStatus=:enabledStatusN WHERE CTE.changeControlNumber.id=:id AND CTE.enabledStatus=:enabledStatus")
	public void deactiveAll( @Param("enabledStatusN") EnabledStatus enabledStatusN, @Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlTargetDateExtensionDto(CTE) FROM ChangeControlTargetDateExtension CTE "
			+ "JOIN CTE.changeControlNumber CCNO WHERE CCNO.id=:ccNoId AND CCNO.enabledStatus=:enabledStatus AND CTE.enabledStatus=:enabledStatus")
	public ChangeControlTargetDateExtensionDto findOneByCCNoIdAndEnabledStatus(@Param("ccNoId") Long ccNoId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlTargetDateExtensionDto(TE, CCNO) FROM ChangeControlTargetDateExtension TE " + 
			"JOIN TE.changeControlNumber CCNO JOIN CCNO.branch CCNOB JOIN CCNO.changeControlRequest CCR JOIN CCR.department QMSDEPT WHERE QMSDEPT.id IN (:userQmsDeptIds) AND CCNOB.id=:branchId AND "
			+ "CCR.changeControlStatus=:changeControlStatus AND CCNO.enabledStatus=:enabledStatus AND TE.enabledStatus=:enabledStatus")
	public Page<ChangeControlTargetDateExtensionDto> findAllTargetDateExtension(@Param("userQmsDeptIds") List<Long> userQmsDeptIds, @Param("branchId") Long branchId, @Param("changeControlStatus") ChangeControlStatus changeControlStatus, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	@Query(value="SELECT new com.anthem.web.service.changecontrol.dto.ChangeControlTargetDateExtensionDto(TE, CCNO) FROM ChangeControlTargetDateExtension TE " + 
			"JOIN TE.changeControlNumber CCNO JOIN CCNO.branch CCNOB JOIN CCNO.changeControlRequest CCR WHERE CCR.changeControlStatus=:changeControlStatus AND CCNOB.id=:branchId AND "
			+ "CCNO.enabledStatus=:enabledStatus AND TE.enabledStatus=:enabledStatus")
	public Page<ChangeControlTargetDateExtensionDto> findAllTargetDateExtension(@Param("changeControlStatus") ChangeControlStatus changeControlStatus,  @Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
}
