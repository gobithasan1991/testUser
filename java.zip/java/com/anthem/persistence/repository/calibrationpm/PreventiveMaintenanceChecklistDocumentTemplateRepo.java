package com.anthem.persistence.repository.calibrationpm;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.PreventiveMaintenanceChecklistDocumentTemplate;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface PreventiveMaintenanceChecklistDocumentTemplateRepo extends JpaRepository<PreventiveMaintenanceChecklistDocumentTemplate, Long>{
	
	@Query("SELECT t FROM PreventiveMaintenanceChecklistDocumentTemplate t WHERE t.enabledStatus=:enabledStatus")
	public List<PreventiveMaintenanceChecklistDocumentTemplate> listPreventiveMaintenanceChecklistDocumentTemplate(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	public PreventiveMaintenanceChecklistDocumentTemplate findById(Long id);

}