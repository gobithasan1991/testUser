package com.anthem.persistence.repository.calibrationpm;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationChecklistFormData;
import com.anthem.persistence.model.calibrationpm.CalibrationChecklistMasterInstData;

@Repository
public interface CalibrationChecklistMasterInstDataRepo extends JpaRepository<CalibrationChecklistMasterInstData, Long>{
	
	public List<CalibrationChecklistMasterInstData> findByChecklistFormData(CalibrationChecklistFormData calibrationChecklistFormData);

}
