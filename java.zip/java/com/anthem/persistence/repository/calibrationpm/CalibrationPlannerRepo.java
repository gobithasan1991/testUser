package com.anthem.persistence.repository.calibrationpm;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationPlanner;
import com.anthem.util.calibrationpm.CalibrationPMStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.calibrationpm.dto.CalibrationPMPlannerCalendarDto;
import com.anthem.web.service.calibrationpm.dto.CalibrationPlannerDto;

@Repository
public interface CalibrationPlannerRepo extends JpaRepository<CalibrationPlanner, Long>{
	
	@Query(value = "SELECT new com.anthem.web.service.calibrationpm.dto.CalibrationPlannerDto(cp) FROM CalibrationPlanner cp WHERE cp.calibrationStatus=:calibrationStatus and cp.enabledStatus=:enabledStatus")
	public List<CalibrationPlannerDto> listCalibrationPlanner(@Param("calibrationStatus") CalibrationPMStatus calibrationStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT new com.anthem.web.service.calibrationpm.dto.CalibrationPMPlannerCalendarDto(cp) FROM CalibrationPlanner cp WHERE ( cp.plannedDate BETWEEN :startDate AND :endDate) AND cp.calibrationStatus=:calibrationStatus and cp.enabledStatus=:enabledStatus")
	public List<CalibrationPMPlannerCalendarDto> listCalendarPlanner(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("calibrationStatus") CalibrationPMStatus calibrationStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	public CalibrationPlanner findById(Long id);
}