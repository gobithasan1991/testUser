package com.anthem.persistence.repository.calibrationpm;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationChecklistFormData;
import com.anthem.persistence.model.calibrationpm.CalibrationPlanner;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.calibrationpm.dto.CalibrationChecklistFormDataDto;

@Repository
public interface CalibrationChecklistFormDataRepo extends JpaRepository<CalibrationChecklistFormData, Long>{
	
	public CalibrationChecklistFormData findByCalibrationPlanner(CalibrationPlanner calibrationPlanner);
	
	@Query("SELECT new com.anthem.web.service.calibrationpm.dto.CalibrationChecklistFormDataDto(d) FROM CalibrationChecklistFormData d JOIN d.calibrationPlanner p WHERE p.id=:plannerId")
	public CalibrationChecklistFormDataDto findByCalibrationPlannerId(@Param("plannerId") Long id);
	
	
	@Query("SELECT COUNT(d) FROM CalibrationChecklistFormData d JOIN d.calibrationPlanner p WHERE p.id=:plannerId")
	public Long checkEntry(@Param("plannerId") Long plannerId);
		
	@Query("SELECT new com.anthem.web.service.calibrationpm.dto.CalibrationChecklistFormDataDto(d) FROM CalibrationChecklistFormData d JOIN d.calibrationPlanner p JOIN p.calibrationMaster cm "
			+ "WHERE cm.id=:calibrationMasterId AND d.enabledStatus=:enabledStatus ORDER BY p.plannedDate DESC")
	public Page<CalibrationChecklistFormDataDto> getListFormDataForNCalibration(@Param("calibrationMasterId") Long calibrationMasterId,@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
}