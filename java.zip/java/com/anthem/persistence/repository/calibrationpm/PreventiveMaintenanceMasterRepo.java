package com.anthem.persistence.repository.calibrationpm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.PreventiveMaintenanceMaster;
import com.anthem.persistence.model.calibrationpm.EquipmentInstrumentMaster;


@Repository
public interface PreventiveMaintenanceMasterRepo extends JpaRepository<PreventiveMaintenanceMaster, Long>{
	
	public PreventiveMaintenanceMaster findById(Long id);
	
	public PreventiveMaintenanceMaster findByEquipmentInstrumentMaster(EquipmentInstrumentMaster equipmentInstrumentMaster);
	
}
