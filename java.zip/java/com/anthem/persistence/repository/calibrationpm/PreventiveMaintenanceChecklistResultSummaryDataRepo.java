package com.anthem.persistence.repository.calibrationpm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.PreventiveMaintenanceChecklistResultSummaryData;

@Repository
public interface PreventiveMaintenanceChecklistResultSummaryDataRepo extends JpaRepository<PreventiveMaintenanceChecklistResultSummaryData, Long>{

}
