package com.anthem.persistence.repository.calibrationpm;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationChecklist;
import com.anthem.web.service.calibrationpm.dto.CalibrationChecklistDto;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface CalibrationChecklistRepo extends JpaRepository<CalibrationChecklist, Long>{	
	public CalibrationChecklist findByCode(String code);
	
	@Query("SELECT new com.anthem.web.service.common.dto.IdCodeName(c.id, c.code, c.name) FROM CalibrationChecklist c WHERE c.enabledStatus = 'OPEN'")
	public List<IdCodeName> getICN();
	
	@Query("SELECT new com.anthem.web.service.calibrationpm.dto.CalibrationChecklistDto(c) FROM CalibrationChecklist c WHERE c.id=:id")
	public CalibrationChecklistDto getCalibrationCheckListDto(@Param("id") Long id);
	
	public CalibrationChecklist findById(Long id);
}
