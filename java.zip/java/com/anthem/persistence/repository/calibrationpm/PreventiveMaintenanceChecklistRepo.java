package com.anthem.persistence.repository.calibrationpm;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.PreventiveMaintenanceChecklist;
import com.anthem.web.service.calibrationpm.dto.PreventiveMaintenanceChecklistDto;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface PreventiveMaintenanceChecklistRepo extends JpaRepository<PreventiveMaintenanceChecklist, Long>{
	
	public PreventiveMaintenanceChecklist findByCode(String code);
	
	@Query("SELECT new com.anthem.web.service.common.dto.IdCodeName(c.id, c.code, c.name) FROM PreventiveMaintenanceChecklist c WHERE c.enabledStatus = 'OPEN'")
	public List<IdCodeName> getICN();
	
	@Query("SELECT new com.anthem.web.service.calibrationpm.dto.PreventiveMaintenanceChecklistDto(c) FROM PreventiveMaintenanceChecklist c WHERE c.id=:id")
	public PreventiveMaintenanceChecklistDto getPreventiveMaintenanceChecklistDto(@Param("id") Long id);
	
	public PreventiveMaintenanceChecklist findById(Long id);
	
}