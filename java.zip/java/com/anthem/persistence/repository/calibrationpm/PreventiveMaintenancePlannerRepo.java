package com.anthem.persistence.repository.calibrationpm;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.calibrationpm.PreventiveMaintenancePlanner;
import com.anthem.util.calibrationpm.CalibrationPMStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.calibrationpm.dto.CalibrationPMPlannerCalendarDto;
import com.anthem.web.service.calibrationpm.dto.PreventiveMaintenancePlannerDto;

public interface PreventiveMaintenancePlannerRepo extends JpaRepository<PreventiveMaintenancePlanner, Long>{
	
	@Query(value = "SELECT new com.anthem.web.service.calibrationpm.dto.PreventiveMaintenancePlannerDto(pm) FROM PreventiveMaintenancePlanner pm WHERE pm.pmStatus=:pmStatus and pm.enabledStatus=:enabledStatus")
	public List<PreventiveMaintenancePlannerDto> listCalibrationPlanner(@Param("pmStatus") CalibrationPMStatus pmStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT new com.anthem.web.service.calibrationpm.dto.CalibrationPMPlannerCalendarDto(pm) FROM PreventiveMaintenancePlanner pm WHERE (pm.plannedDate BETWEEN :startDate AND :endDate) AND pm.pmStatus=:pmStatus and pm.enabledStatus=:enabledStatus")
	public List<CalibrationPMPlannerCalendarDto> listCalendarPlanner(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("pmStatus") CalibrationPMStatus pmStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	public PreventiveMaintenancePlanner findById(Long id);	
}