package com.anthem.persistence.repository.calibrationpm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationChecklistTopBottomData;

@Repository
public interface CalibrationChecklistTopBottomDataRepo extends JpaRepository<CalibrationChecklistTopBottomData, Long>{

}
