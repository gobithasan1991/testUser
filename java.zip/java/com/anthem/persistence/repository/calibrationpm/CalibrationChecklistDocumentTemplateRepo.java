package com.anthem.persistence.repository.calibrationpm;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationChecklistDocumentTemplate;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface CalibrationChecklistDocumentTemplateRepo extends JpaRepository<CalibrationChecklistDocumentTemplate, Long>{
	
	@Query("SELECT t FROM CalibrationChecklistDocumentTemplate t WHERE t.enabledStatus=:enabledStatus")
	public List<CalibrationChecklistDocumentTemplate> listCalibrationChecklistDocumentTemplate(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	public CalibrationChecklistDocumentTemplate findById(Long id);

}