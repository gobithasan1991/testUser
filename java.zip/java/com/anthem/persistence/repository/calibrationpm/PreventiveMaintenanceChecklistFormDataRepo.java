package com.anthem.persistence.repository.calibrationpm;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.PreventiveMaintenanceChecklistFormData;
import com.anthem.persistence.model.calibrationpm.PreventiveMaintenancePlanner;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.calibrationpm.dto.PreventiveMaintenanceChecklistFormDataDto;

@Repository
public interface PreventiveMaintenanceChecklistFormDataRepo extends JpaRepository<PreventiveMaintenanceChecklistFormData, Long>{

	public PreventiveMaintenanceChecklistFormData findByPreventiveMaintenancePlanner(PreventiveMaintenancePlanner preventiveMaintenancePlanner);
	
	@Query("SELECT new com.anthem.web.service.calibrationpm.dto.PreventiveMaintenanceChecklistFormDataDto(d) FROM PreventiveMaintenanceChecklistFormData d JOIN d.preventiveMaintenancePlanner p WHERE p.id=:plannerId")
	public PreventiveMaintenanceChecklistFormDataDto findByPreventiveMaintenancePlannerId(@Param("plannerId") Long id);
	
	
	@Query("SELECT COUNT(d) FROM PreventiveMaintenanceChecklistFormData d JOIN d.preventiveMaintenancePlanner p WHERE p.id=:plannerId")
	public Long checkEntry(@Param("plannerId") Long plannerId);
		
	@Query("SELECT new com.anthem.web.service.calibrationpm.dto.PreventiveMaintenanceChecklistFormDataDto(d) FROM PreventiveMaintenanceChecklistFormData d JOIN d.preventiveMaintenancePlanner p JOIN p.preventiveMaintenanceMaster cm "
			+ "WHERE cm.id=:preventiveMaintenanceMasterId AND d.enabledStatus=:enabledStatus ORDER BY p.plannedDate DESC")
	public Page<PreventiveMaintenanceChecklistFormDataDto> getListFormDataForNPreventiveMaintenance(@Param("preventiveMaintenanceMasterId") Long preventiveMaintenanceMasterId,@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
}
