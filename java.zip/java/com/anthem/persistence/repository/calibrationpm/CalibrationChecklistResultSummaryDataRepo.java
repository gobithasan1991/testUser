package com.anthem.persistence.repository.calibrationpm;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationChecklistFormData;
import com.anthem.persistence.model.calibrationpm.CalibrationChecklistMasterInstData;
import com.anthem.persistence.model.calibrationpm.CalibrationChecklistResultSummaryData;

@Repository
public interface CalibrationChecklistResultSummaryDataRepo extends JpaRepository<CalibrationChecklistMasterInstData, Long>{
	public List<CalibrationChecklistResultSummaryData> findByChecklistFormData(CalibrationChecklistFormData calibrationChecklistFormData);
}
