package com.anthem.persistence.repository.calibrationpm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.calibrationpm.CalibrationMaster;
import com.anthem.persistence.model.calibrationpm.EquipmentInstrumentMaster;

@Repository
public interface CalibrationMasterRepo extends JpaRepository<CalibrationMaster, Long>{
	
	public CalibrationMaster findById(Long id);
	
	public CalibrationMaster findByEquipmentInstrumentMaster(EquipmentInstrumentMaster master);
	
}