package com.anthem.persistence.repository.auditmanagement;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.auditmanagement.AuditObservation;

public interface AuditObservationRepo extends JpaRepository<AuditObservation, Long> {

	@Query(value="SELECT AO FROM AuditObservation AO JOIN AO.auditScheduler AOS WHERE AOS.id=:schedulerId AND AO.enabledStatus='OPEN'")
	public AuditObservation findOneBySchedulerId(@Param("schedulerId") Long schedulerId);
}
