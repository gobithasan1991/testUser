package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.DepartmentGroup;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface DepartmentGroupRepo extends JpaRepository<DepartmentGroup, Long> {	
	@Query(value="SELECT DISTINCT DG FROM DepartmentGroup DG JOIN DG.departmentGroupBranchs DGBS JOIN DGBS.branch DGB WHERE DGB.id IN (:branchIds) AND "
			+ "DG.enabledStatus=:enabledStatus AND DGBS.enabledStatus=:enabledStatus ORDER BY DG.name")
	public List<DepartmentGroup> findAllByBranchAndEnabledStatus(@Param("branchIds") List<Long> branchIds, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	
	@Query(value="SELECT DISTINCT DG FROM DepartmentGroup DG JOIN DG.departmentGroupBranchs DGBS WHERE SIZE(DGBS)=:branchSize AND "
			+ "DG.enabledStatus=:enabledStatus AND DGBS.enabledStatus=:enabledStatus ORDER BY DG.name")
	public List<DepartmentGroup> findAllByBranchSizeAndEnabledStatus(@Param("branchSize") int branchSize, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value = "SELECT DISTINCT DG FROM DepartmentGroup DG JOIN DG.departmentGroupBranchs DGBS JOIN DGBS.branch DGB WHERE DGB.id=:branchId ORDER BY DG.name")
	public Page<DepartmentGroup> findAllDepartmentGroup(@Param("branchId") Long branchId, Pageable pageable);
}
