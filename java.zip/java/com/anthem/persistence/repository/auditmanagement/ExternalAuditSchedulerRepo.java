package com.anthem.persistence.repository.auditmanagement;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.ExternalAuditScheduler;
import com.anthem.util.auditmanagement.AuditScheduleStatus;
import com.anthem.util.auditmanagement.ConfirmStatus;
import com.anthem.util.auditmanagement.ObservationStatus;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface ExternalAuditSchedulerRepo extends JpaRepository<ExternalAuditScheduler, Long> {

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE EAS.startDate >= :cDate AND EAS.confirmStatus=:confirmStatus AND EAS.auditScheduleStatus=:auditScheduleStatus AND EAS.observationStatus=:observationStatus AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllEnabledByScheduleStatus(@Param("cDate") Date cDate,
			@Param("confirmStatus") ConfirmStatus confirmStatus,
			@Param("auditScheduleStatus") AuditScheduleStatus auditScheduleStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler "
			+ "EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch EXBSB WHERE EAS.confirmStatus=:confirmStatus AND EAS.auditScheduleStatus=:auditScheduleStatus "
			+ "AND EAS.observationStatus=:observationStatus AND EAS.endDate <= :fdate AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllObservationRequireds(@Param("confirmStatus") ConfirmStatus confirmStatus,
			@Param("auditScheduleStatus") AuditScheduleStatus auditScheduleStatus,
			@Param("observationStatus") ObservationStatus observationStatus, @Param("fdate") Date fdate,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE EAS.confirmStatus=:confirmStatus AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.startDate")
	public Page<ExternalAuditScheduler> findAuditSchedulerRegister(@Param("confirmStatus") ConfirmStatus confirmStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND EAS.confirmStatus=:confirmStatus AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.startDate")
	public Page<ExternalAuditScheduler> findAuditSchedulerRegisterByAuditDate(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("confirmStatus") ConfirmStatus confirmStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT COUNT(eas) FROM ExternalAuditScheduler eas WHERE eas.auditNumber LIKE :prefixLike%")
	public int findAvailableSeriesCount(@Param("prefixLike") String prefixLike);

	@Query(value = "SELECT COUNT(EAS) FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch EXBSB "
			+ "WHERE EAS.confirmStatus IN ('CONFIRMED') AND EXBSB.id=:branchId")
	public int findCountByBranchId(@Param("branchId") Long branchId);
//
//	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto(EAS) FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
//			+ "EXBS.branch EXBSB WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId")
//	public List<ExternalAuditObservationSelectDto> findAllEnabledForCalender(@Param("fromDate") Date fromDate,
//			@Param("toDate") Date toDate, @Param("enabledStatus") EnabledStatus enabledStatus,
//			@Param("branchId") Long branchId);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE EAS.confirmStatus = :confirmStatus AND EXBSB.id=:branchId AND EAS.enabledStatus=:enabledStatus")
	public Page<ExternalAuditScheduler> findAllSchedulersByConfirmStatus(
			@Param("confirmStatus") ConfirmStatus confirmStatus, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	// for calendar
	@Query(value = "SELECT DISTINCT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND EAS.confirmStatus IN ('CONFIRMED') AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.startDate")
	public List<ExternalAuditScheduler> findAllByAuditDate(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND EAS.observationStatus <> :observationStatus AND EAS.auditScheduleStatus=:auditScheduleStatus AND EAS.confirmStatus IN ('CONFIRMED') AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.startDate")
	public List<ExternalAuditScheduler> findAllByAuditDateANDAuditScheduleStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("auditScheduleStatus") AuditScheduleStatus auditScheduleStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND EAS.auditScheduleStatus <> :auditScheduleStatus AND EAS.confirmStatus IN ('CONFIRMED') AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.startDate")
	public List<ExternalAuditScheduler> findAllByAuditDateANDNOTINAuditScheduleStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("auditScheduleStatus") AuditScheduleStatus auditScheduleStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN "
			+ "EXBS.branch EXBSB WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND EAS.observationStatus=:observationStatus AND EAS.confirmStatus IN ('CONFIRMED') AND EAS.enabledStatus=:enabledStatus AND EXBSB.id=:branchId ORDER BY EAS.startDate")
	public List<ExternalAuditScheduler> findAllByAuditDateANDObservationStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT EAS FROM ExternalAuditScheduler EAS WHERE (EAS.startDate BETWEEN :fromDate AND :toDate) AND "
			+ "EAS.auditScheduleStatus=:auditScheduleStatus AND EAS.observationStatus=:observationStatus AND EAS.confirmStatus=:confirmStatus AND "
			+ "EAS.enabledStatus=:enabledStatus")
	public List<ExternalAuditScheduler> findAllByAuditDate(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("auditScheduleStatus") AuditScheduleStatus auditScheduleStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("confirmStatus") ConfirmStatus confirmStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch B WHERE EAS.confirmStatus IN (:confirmStatus) AND EAS.observationStatus=:observationStatus AND EAS.enabledStatus=:enabledStatus AND B.id=:branchId")
	public Page<ExternalAuditScheduler> findAllByConfirmStatusAndObservationStatus(
			@Param("confirmStatus") ConfirmStatus confirmStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch B WHERE EAS.customerName LIKE %:customerName% AND EAS.enabledStatus=:enabledStatus AND B.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllByCustomerName(@Param("customerName") String customerName,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch B WHERE EAS.projectName LIKE %:projectName% AND EAS.enabledStatus=:enabledStatus AND B.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllByProjectName(@Param("projectName") String projectName,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch B WHERE EAS.productName LIKE %:productName% AND EAS.enabledStatus=:enabledStatus AND B.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllByProductName(@Param("productName") String productName,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch B JOIN EAS.auditCategory ACAT WHERE ACAT.id=:auditCategoryId AND EAS.enabledStatus=:enabledStatus AND B.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllByAuditCategory(@Param("auditCategoryId") Long auditCategoryId,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAS FROM ExternalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch B JOIN EAS.auditType EAT  WHERE EAT.id=:auditTypeId AND EAS.enabledStatus=:enabledStatus AND B.id=:branchId ORDER BY EAS.auditNumber")
	public Page<ExternalAuditScheduler> findAllByAuditType(@Param("auditTypeId") Long auditTypeId,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

}
