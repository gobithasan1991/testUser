package com.anthem.persistence.repository.auditmanagement;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.ExternalAuditObseravtionDepartment;

@Repository
public interface ExternalAuditObseravtionDepartmentRepo extends JpaRepository<ExternalAuditObseravtionDepartment, Long> {

}
