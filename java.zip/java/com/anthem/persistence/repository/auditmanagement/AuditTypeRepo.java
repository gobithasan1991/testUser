package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditType;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface AuditTypeRepo extends JpaRepository<AuditType, Long> {

	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(AT.id, AT.code, AT.name) FROM AuditType AT WHERE AT.enabledStatus=:enabledStatus ORDER BY AT.name")
	public List<IdCodeName> findAllByEnabledStatus(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	public AuditType findByCode(String code);
}
