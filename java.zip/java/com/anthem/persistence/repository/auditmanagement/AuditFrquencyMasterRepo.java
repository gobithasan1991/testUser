package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditFrequencyMaster;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface AuditFrquencyMasterRepo extends JpaRepository<AuditFrequencyMaster, Long> {
	
	
	@Query(value="SELECT AFM FROM AuditFrequencyMaster AFM WHERE AFM.enabledStatus=:enabledStatus ORDER BY AFM.code")
	public List<AuditFrequencyMaster> findAllByEnabledStatus(@Param("enabledStatus") EnabledStatus enabledStatus);
	

	@Query(value="SELECT AFM FROM AuditFrequencyMaster AFM  ORDER BY AFM.code")
	public Page<AuditFrequencyMaster> findAllAFM(Pageable pageable);
	
	public String findCodeById(Long id);
	
	public int findPeriodById(Long id);
	
	public String findPeriodInById(Long id);
	

 
}
