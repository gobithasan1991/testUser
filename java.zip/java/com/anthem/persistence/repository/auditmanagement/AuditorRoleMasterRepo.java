package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditorRoleMaster;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface AuditorRoleMasterRepo extends JpaRepository<AuditorRoleMaster, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(ARM.id,ARM.name,ARM.name) FROM AuditorRoleMaster ARM WHERE ARM.enabledStatus=:enabledStatus ORDER BY ARM.name")
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
}
