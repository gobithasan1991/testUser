package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.ObservationCategory;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface ObservationCategoryRepo extends JpaRepository<ObservationCategory, Long>{

	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(OC.id, OC.code, OC.name) FROM ObservationCategory OC WHERE OC.enabledStatus IN ('OPEN')")
	public List<IdCodeName> findAllEnabled();
}
