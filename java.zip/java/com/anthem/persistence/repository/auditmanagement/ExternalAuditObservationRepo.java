package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.ExternalAuditObservation;
import com.anthem.persistence.model.auditmanagement.ExternalAuditScheduler;
import com.anthem.util.auditmanagement.ObservationStatus;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface ExternalAuditObservationRepo extends JpaRepository<ExternalAuditObservation, Long> {
	@Query(value = "SELECT EAS FROM ExternalAuditObservation EAO JOIN EAO.externalAuditScheduler EAS JOIN EAS.externalAuditBranchs EXBS JOIN EXBS.branch EXBSB JOIN "
			+ " EAO.externalAuditObservationItems EAOI JOIN EAOI.auditObseravtionDepartments EAODS JOIN EAODS.department EOD WHERE EAS.observationStatus=:observationStatus AND "
			+ "EAODS.observationApproved='NO' AND EAS.enabledStatus=:enabledStatus AND EOD.id IN (:departmentIds) AND EXBSB.id=:branchId")
	public Page<ExternalAuditScheduler> findAllEnabledByObservationCompleted(
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("departmentIds") List<Long> departmentIds,
			@Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT EAO FROM ExternalAuditObservation EAO JOIN EAO.externalAuditScheduler EAOE WHERE EAOE.id=:schedulerId AND EAO.enabledStatus='OPEN'")
	public ExternalAuditObservation findOneBySchedulerId(@Param("schedulerId") Long schedulerId);

	@Query(value = "SELECT COUNT(EAODS) FROM ExternalAuditObservation EAO JOIN EAO.externalAuditScheduler EAOE JOIN  EAO.externalAuditObservationItems EAOI JOIN EAOI.auditObseravtionDepartments EAODS"
			+ " WHERE EAOE.id=:schedulerId AND EAO.enabledStatus='OPEN'")
	public int findAllObservationEntered(@Param("schedulerId") Long schedulerId);

	@Query(value = "SELECT COUNT(EAODS) FROM ExternalAuditObservation EAO JOIN EAO.externalAuditScheduler EAOE JOIN  EAO.externalAuditObservationItems EAOI JOIN EAOI.auditObseravtionDepartments EAODS"
			+ " WHERE EAODS.observationApproved='YES' AND EAOE.id=:schedulerId AND EAO.enabledStatus='OPEN'")
	public int findAllObservationaccepted(@Param("schedulerId") Long schedulerId);

}
