package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.CheckListMapping;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface CheckListMappingRepo extends JpaRepository<CheckListMapping, Long> {
	
	@Query(value="SELECT DISTINCT CLM FROM CheckListMapping CLM JOIN CLM.checkListDescription DESCN JOIN CLM.checkListMappingBranchs BS JOIN BS.branch B JOIN CLM.checkListMappingDepartments DS "
			+ "JOIN DS.department D WHERE B.id = :branchId AND D.id = :deptId AND DESCN.id=:clDescId AND CLM.enabledStatus=:enabledStatus")
	public List<CheckListMapping> findAllByBranchAndDepartmentAndDescId(@Param("branchId") Long branchId, @Param("deptId") Long deptId, @Param("clDescId") Long clDescId, @Param("enabledStatus") EnabledStatus enabledStatus);

}
