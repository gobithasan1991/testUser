package com.anthem.persistence.repository.auditmanagement;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditPlanner;
import com.anthem.util.auditmanagement.ApproveStatus;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface AuditPlannerRepo extends JpaRepository<AuditPlanner, Long> {

	@Query(value = "SELECT AP FROM AuditPlanner AP JOIN AP.branch APB WHERE "
			+ "AP.approveStatus=:approveStatus AND APB.id=:branchId AND AP.enabledStatus=:enabledStatus ORDER BY AP.createdDate")
	public Page<AuditPlanner> findAllEnabledByApproveStatus(@Param("approveStatus") ApproveStatus approveStatus,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT AP FROM AuditPlanner AP JOIN AP.branch APB JOIN AP.department APD WHERE "
			+ "APD.id=:deptId AND APB.id=:branchId AND AP.approveStatus='QA_APPROVED' AND AP.enabledStatus=:enabledStatus AND MONTH(AP.date) >= MONTH(CURRENT_DATE) AND YEAR(AP.date) >= YEAR(CURRENT_DATE) ORDER BY AP.date")
	public Page<AuditPlanner> findAllUpComming(@Param("deptId") Long deptId, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT AP FROM AuditPlanner AP WHERE AP.id=:plannerId AND AP.enabledStatus=:enabledStatus")
	public AuditPlanner findPlannerDtoById(@Param("plannerId") Long plannerId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT AP FROM AuditPlanner AP JOIN AP.branch APB WHERE AP.approveStatus IN (:approveStatus) "
			+ "AND (AP.date BETWEEN :fromDate AND :toDate) AND APB.id=:branchId AND AP.enabledStatus=:enabledStatus")
	public Page<AuditPlanner> findAllForRegister(@Param("approveStatus") List<ApproveStatus> approveStatus,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT DISTINCT AP FROM AuditPlanner AP WHERE AP.date=:date AND AP.approveStatus=:approveStatus AND AP.enabledStatus=:enabledStatus")
	public List<AuditPlanner> findAllByDate(@Param("date") Date date,
			@Param("approveStatus") ApproveStatus approveStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT AP FROM AuditPlanner AP JOIN AP.branch B WHERE AP.approveStatus<>:approveStatus AND (AP.date BETWEEN :fromDate AND :toDate) AND B.id=:branchId ORDER BY AP.date")
	public Page<AuditPlanner> findAllByAuditDateAndApproveStatusNotIN(
			@Param("approveStatus") ApproveStatus approveStatus, @Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT AP FROM AuditPlanner AP JOIN AP.branch B JOIN AP.department D WHERE AP.approveStatus<>:approveStatus AND D.id=:deptId AND B.id=:branchId ORDER BY AP.date")
	public Page<AuditPlanner> findAllByDepartmentAndApproveStatusNotIN(
			@Param("approveStatus") ApproveStatus approveStatus, @Param("deptId") Long deptId,
			@Param("branchId") Long branchId, Pageable pageable);

}
