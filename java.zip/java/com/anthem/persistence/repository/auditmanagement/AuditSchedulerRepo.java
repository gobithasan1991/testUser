package com.anthem.persistence.repository.auditmanagement;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditScheduler;
import com.anthem.util.auditmanagement.ApproveStatus;
import com.anthem.util.auditmanagement.ObservationStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto;
import com.anthem.web.service.auditmanagement.dto.AuditSchedulerInternalDto;

@Repository
public interface AuditSchedulerRepo extends JpaRepository<AuditScheduler, Long> {

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto(ASR) FROM AuditScheduler "
			+ "ASR JOIN ASR.branch ASRB WHERE ASR.approveStatus=:approveStatus AND ASR.observationStatus=:observationStatus "
			+ "AND ASR.enabledStatus=:enabledStatus AND ASRB.id=:branchId")
	public Page<AuditObservationSelectDto> findAllEnabledByApproveStatus(
			@Param("approveStatus") ApproveStatus approveStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto(ASR) FROM AuditScheduler ASR "
			+ "JOIN ASR.branch ASRB WHERE ASR.approveStatus=:approveStatus AND ASR.observationStatus=:observationStatus "
			+ "AND ASR.enabledStatus=:enabledStatus AND ASRB.id=:branchId AND ASR.endDate <= :fdate ORDER BY ASR.endDate")
	public Page<AuditObservationSelectDto> findAllObservationRequireds(
			@Param("approveStatus") ApproveStatus approveStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId,
			@Param("fdate") Date fdate, Pageable pageable);

	@Query(value = "SELECT ASR FROM AuditScheduler ASR JOIN ASR.branch ASB WHERE ASR.id=:id AND ASR.enabledStatus=:enabledStatus")
	public AuditScheduler findAllEnabledByIdAndBranchId(@Param("id") Long id,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditSchedulerInternalDto(ASR) FROM AuditScheduler ASR JOIN ASR.branch ASRB WHERE ASR.auditDate >= :cDate  AND ASR.approveStatus=:approveStatus AND ASRB.id=:branchId AND "
			+ "ASR.enabledStatus=:enabledStatus")
	public Page<AuditSchedulerInternalDto> findAllByEnabledAndApproveStatus(@Param("cDate") Date cDate,
			@Param("approveStatus") ApproveStatus approveStatus, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto(ASR)"
			+ " FROM AuditScheduler ASR JOIN ASR.branch ASRB JOIN ASR.auditPlanner ASRP JOIN ASRP.department ASDEPT"
			+ " WHERE ASR.observationStatus=:observationStatus AND ASR.enabledStatus=:enabledStatus AND ASRB.id=:branchId AND ASDEPT.id IN (:departmentIds)")
	public Page<AuditObservationSelectDto> findAllEnabledByObservationCompleted(
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId,
			@Param("departmentIds") List<Long> departmentIds, Pageable pageable);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto(ASO) FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE "
			+ "(ASO.auditDate BETWEEN :fromDate AND :toDate) AND ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public Page<AuditObservationSelectDto> findAuditSchedulerRegisterByAuditDate(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditObservationSelectDto(ASO) FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE "
			+ "ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public Page<AuditObservationSelectDto> findAuditSchedulerRegister(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT COUNT(eas) FROM AuditScheduler eas WHERE eas.auditNumber LIKE :prefixLike%")
	public int findAvailableSeriesCount(@Param("prefixLike") String prefixLike);

	@Query(value = "SELECT COUNT(ASR) FROM AuditScheduler ASR JOIN ASR.branch ASRB WHERE ASRB.id=:branchId")
	public int findCountByBranchId(@Param("branchId") Long branchId);

	// for calendar

	@Query(value = "SELECT DISTINCT ASO FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE (ASO.auditDate BETWEEN :fromDate AND :toDate) AND "
			+ "ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public List<AuditScheduler> findAllByAuditDate(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT ASO FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE (ASO.auditDate BETWEEN :fromDate AND :toDate) AND "
			+ "ASO.approveStatus = :approveStatus AND ASO.observationStatus <> :observationStatus AND ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public List<AuditScheduler> findAllByAuditDateANDApproveStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("approveStatus") ApproveStatus approveStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT ASO FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE (ASO.auditDate BETWEEN :fromDate AND :toDate) AND "
			+ "ASO.approveStatus <> :approveStatus AND ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public List<AuditScheduler> findAllByAuditDateANDNotINApproveStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("approveStatus") ApproveStatus approveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT ASO FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE (ASO.auditDate BETWEEN :fromDate AND :toDate) AND "
			+ "ASO.observationStatus = :observationStatus AND ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public List<AuditScheduler> findAllByAuditDateANDObservationStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId);

	@Query(value = "SELECT DISTINCT ASO FROM AuditScheduler ASO WHERE (ASO.auditDate BETWEEN :fromDate AND :toDate) AND ASO.approveStatus=:approveStatus AND "
			+ "ASO.observationStatus=:observationStatus AND ASO.enabledStatus=:enabledStatus")
	public List<AuditScheduler> findAllByAuditDate(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("approveStatus") ApproveStatus approveStatus,
			@Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT ASO FROM AuditScheduler ASO JOIN ASO.branch ASOB WHERE (ASO.auditDate BETWEEN :fromDate AND :toDate) AND "
			+ "ASO.observationStatus=:observationStatus AND ASO.enabledStatus=:enabledStatus AND ASOB.id=:branchId ORDER BY ASO.auditDate")
	public Page<AuditScheduler> findAllByAuditDateAndObservationStatus(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("observationStatus") ObservationStatus observationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT ASO FROM AuditScheduler ASO JOIN ASO.branch B WHERE ASO.observationStatus=:observationStatus AND B.id=:branchId ORDER BY ASO.auditDate")
	public Page<AuditScheduler> findAllByObservationStatus(
			@Param("observationStatus") ObservationStatus observationStatus, @Param("branchId") Long branchId,
			Pageable pageable);

	@Query(value = "SELECT ASO FROM AuditScheduler ASO JOIN ASO.auditPlanner AP JOIN AP.department D JOIN ASO.branch B WHERE ASO.observationStatus=:observationStatus AND "
			+ "D.id=:deptId AND B.id=:branchId ORDER BY ASO.auditDate")
	public Page<AuditScheduler> findAllByObservationStatusANDDepartment(
			@Param("observationStatus") ObservationStatus observationStatus, @Param("deptId") Long deptId,
			@Param("branchId") Long branchId, Pageable pageable);
}
