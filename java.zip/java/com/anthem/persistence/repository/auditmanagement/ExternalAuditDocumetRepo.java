package com.anthem.persistence.repository.auditmanagement;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.auditmanagement.ExternalAuditDocument;

public interface ExternalAuditDocumetRepo extends JpaRepository<ExternalAuditDocument, Long> {

}
