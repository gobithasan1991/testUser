package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditUserGroup;
import com.anthem.persistence.model.user.User;
import com.anthem.util.auditmanagement.AuditUserGroupName;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface AuditUserGroupRepo extends JpaRepository<AuditUserGroup, Long> {

	public List<AuditUserGroup> findAll();

	@Query(value = "SELECT DISTINCT U FROM AuditUserGroup AUG JOIN AUG.department D JOIN AUG.auditUserGroupBranch AUGB JOIN AUGB.branch B "
			+ "JOIN AUG.auditUserGroupUsers AUGU JOIN AUGU.user U WHERE D.id = :deptId AND B.id IN (:branchIds) AND AUG.groupName = :groupName AND AUGU.enabledStatus='OPEN' AND U.enabledStatus='OPEN'")
	public List<User> findAuditGroupUsersByDepartmentANDBranchANDGroupName(@Param("deptId") Long deptId,
			@Param("branchIds") List<Long> branchIds, @Param("groupName") AuditUserGroupName groupName);

	@Query(value = "SELECT DISTINCT U FROM AuditUserGroup AUG JOIN AUG.department D JOIN AUG.auditUserGroupBranch AUGB "
			+ "JOIN AUG.auditUserGroupUsers AUGU JOIN AUGU.user U WHERE D.id = :deptId AND SIZE(AUGB)=:branchSize AND AUG.groupName = :groupName AND AUGU.enabledStatus='OPEN' AND U.enabledStatus='OPEN'")
	public List<User> findAuditGroupUsersByDepartmentANDBranchSizeANDGroupName(@Param("deptId") Long deptId,
			@Param("branchSize") int branchSize, @Param("groupName") AuditUserGroupName groupName);

	@Query(value = "SELECT AUG FROM AuditUserGroup AUG JOIN AUG.department D JOIN AUG.auditUserGroupBranch AUGB JOIN AUGB.branch B WHERE D.id=:departmentId AND B.id=:branchId AND AUG.enabledStatus=:enabledStatus ORDER BY AUG.groupName")
	public Page<AuditUserGroup> findAllByDepartment(@Param("departmentId") Long departmentId,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	@Query(value = "SELECT AUG FROM AuditUserGroup AUG JOIN AUG.auditUserGroupBranch AUGB JOIN AUGB.branch B WHERE B.id=:branchId AND AUG.enabledStatus=:enabledStatus ORDER BY AUG.groupName")
	public Page<AuditUserGroup> findAll(@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	public List<AuditUserGroup> findAllByDepartmentId(Long DepartmentId);
}
