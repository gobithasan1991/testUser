package com.anthem.persistence.repository.auditmanagement;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.CheckListDescription;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

@Repository
public interface CheckListDescriptionRepo extends JpaRepository<CheckListDescription, Long> {
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(CLD.id, CLD.description, CLD.description) FROM CheckListDescription CLD WHERE CLD.enabledStatus = :enabledStatus ORDER BY CLD.description")
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(CLD.id, CLD.description, CLD.description) FROM CheckListDescription CLD JOIN CLD.chekListCategory CLDC "
			+ "WHERE CLDC.id=:clCatId AND CLD.enabledStatus = :enabledStatus  ORDER BY CLD.description")
	public List<IdCodeName> findAllEnabledByCatId(@Param("clCatId") Long clCatId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT DISTINCT CLD FROM CheckListDescription CLD WHERE CLD.enabledStatus = :enabledStatus ORDER BY CLD.description")
	public List<CheckListDescription> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	@Query(value="SELECT COUNT(CLD) FROM CheckListDescription CLD WHERE CLD.enabledStatus = :enabledStatus ORDER BY CLD.description")
	public int allEnabledCount(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT DISTINCT CLD  FROM CheckListDescription CLD JOIN CLD.chekListCategory CLDC "
			+ "WHERE CLDC.id=:clCatId AND CLD.enabledStatus = :enabledStatus  ORDER BY CLD.description")
	public List<CheckListDescription> findAllEnabledByCatId(@Param("clCatId") Long clCatId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	@Query(value="SELECT  COUNT(CLD) FROM CheckListDescription CLD JOIN CLD.chekListCategory CLDC "
			+ "WHERE CLDC.id=:clCatId AND CLD.enabledStatus = :enabledStatus  ORDER BY CLD.description")
	public int  allEnabledByCatIdCount(@Param("clCatId") Long clCatId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
