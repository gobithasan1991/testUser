package com.anthem.persistence.repository.auditmanagement;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.persistence.model.auditmanagement.AuditTeamMaster;
import com.anthem.util.auditmanagement.ApproveStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.auditmanagement.dto.AuditTeamMasterDto;

@Repository
public interface AuditTeamRepo extends JpaRepository<AuditTeamMaster, Long> {

	@Query(value = "SELECT ATM FROM AuditTeamMaster ATM JOIN ATM.auditingDepartments AD JOIN AD.auditingDepartment ADD "
			+ " JOIN ATM.branch ATMB WHERE ATM.approveStatus=:approveStatus AND ATMB.id=:branchId AND ATM.enabledStatus=:enabledStatus AND AD.enabledStatus=:enabledStatus GROUP BY ATM.id ORDER BY ATM.createdDate DESC")
	public Page<AuditTeamMaster> findAllEnabledByApproveStatus(@Param("approveStatus") ApproveStatus approveStatus,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditTeamMasterDto(ATM) FROM AuditTeamMaster ATM JOIN ATM.branch ATMB WHERE ATM.approveStatus IN (:approveStatus) "
			+ "AND (ATM.createdDate BETWEEN :fromDate AND :toDate) AND ATMB.id=:branchId AND ATM.enabledStatus=:enabledStatus")
	public Page<AuditTeamMasterDto> findAllForRegister(@Param("approveStatus") List<ApproveStatus> approveStatus,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchId") Long branchId, Pageable pageable);

	@Query(value = "SELECT DISTINCT(AT) FROM AuditTeamMaster AT JOIN AT.employee ATE JOIN AT.auditingDepartments ATDS JOIN ATDS.auditingDepartment ATD JOIN AT.branch ATMB WHERE "
			+ " ATD.id=:deptId AND ATMB.id=:branchId AND AT.approveStatus='QA_APPROVED' AND ATDS.enabledStatus=:enabledStatus AND AT.enabledStatus=:enabledStatus ORDER BY ATE.fullName ")
	public List<AuditTeamMaster> findAuditorsByDepartmentId(@Param("deptId") Long deptId,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditTeamMasterDto(AT) FROM AuditTeamMaster AT JOIN AT.auditTeamMasterRoles ATA JOIN AT.employee ATE JOIN AT.department ATD JOIN AT.branch ATMB WHERE "
			+ " ATD.id=:deptId AND ATMB.id=:branchId AND AT.approveStatus IN (:approveStatus) AND  AT.enabledStatus=:enabledStatus ORDER BY ATE.fullName ")
	public Page<AuditTeamMasterDto> findAuditorsByDepartmentId(@Param("deptId") Long deptId,
			@Param("branchId") Long branchId, @Param("approveStatus") List<ApproveStatus> approveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT new com.anthem.web.service.auditmanagement.dto.AuditTeamMasterDto(AT) FROM AuditTeamMaster AT JOIN AT.auditTeamMasterRoles ATA JOIN AT.employee ATE JOIN AT.branch ATMB WHERE "
			+ " ATMB.id=:branchId AND AT.approveStatus IN (:approveStatus) AND  AT.enabledStatus=:enabledStatus ORDER BY ATE.fullName ")
	public Page<AuditTeamMasterDto> findAuditors(@Param("branchId") Long branchId,
			@Param("approveStatus") List<ApproveStatus> approveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT DISTINCT(AT) FROM AuditTeamMaster AT JOIN AT.employee ATE JOIN AT.auditingDepartments ATDS JOIN ATDS.auditingDepartment ATD JOIN AT.branch ATMB WHERE ATE.id=:userId AND ATD.id=:deptId  AND ATMB.id=:branchId AND  AT.enabledStatus=:enabledStatus")
	public AuditTeamMaster findRoleByAuditUserAndDept(@Param("userId") Long userId, @Param("deptId") Long deptId,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT AT FROM AuditTeamMaster AT JOIN AT.employee E JOIN AT.department D JOIN AT.branch B WHERE D.id =:departmentId AND B.id=:branchId ORDER BY E.fullName")
	public Page<AuditTeamMaster> findAllByDepartmentId(@Param("departmentId") Long departmentId,
			@Param("branchId") Long branchId, Pageable pageable);
}
