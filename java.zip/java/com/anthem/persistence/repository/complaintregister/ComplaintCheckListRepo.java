package com.anthem.persistence.repository.complaintregister;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintCheckList;
import com.anthem.util.common.EnabledStatus;

public interface ComplaintCheckListRepo extends JpaRepository<ComplaintCheckList, Long>{
	@Query(value="SELECT cl FROM ComplaintCheckList cl WHERE cl.enabledStatus = :enabledStatus")
	public List<ComplaintCheckList> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
}
