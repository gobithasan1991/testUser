package com.anthem.persistence.repository.complaintregister;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintRegisterItem;

public interface ComplaintRegisterItemRepo extends JpaRepository<ComplaintRegisterItem, Long>{
	@Query(value = "SELECT cri FROM ComplaintRegisterItem cri WHERE cri.id =:complaintRegisterItemId")
	public ComplaintRegisterItem findOne(@Param("complaintRegisterItemId") Long complaintRegisterItemId);
}
