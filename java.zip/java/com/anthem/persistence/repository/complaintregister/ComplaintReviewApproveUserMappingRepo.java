package com.anthem.persistence.repository.complaintregister;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintReviewApproveUserMapping;
import com.anthem.util.common.EnabledStatus;

public interface ComplaintReviewApproveUserMappingRepo extends JpaRepository<ComplaintReviewApproveUserMapping, Long>{
	@Query(value="SELECT crraum FROM ComplaintReviewApproveUserMapping crraum JOIN crraum.user u WHERE crraum.enabledStatus = :enabledStatus AND u.id =:userId AND crraum.reviewType =:reviewType")
	public ComplaintReviewApproveUserMapping getPermissionByLoginUser(@Param("userId") Long userId, @Param("enabledStatus") EnabledStatus enabledStatus, @Param("reviewType") String reviewType);
	
	@Query(value="SELECT crraum FROM ComplaintReviewApproveUserMapping crraum JOIN crraum.qmsDepartment d WHERE crraum.enabledStatus = :enabledStatus AND d.id =:deptId AND crraum.reviewType =:reviewType")
	public List<ComplaintReviewApproveUserMapping> getAuthorisedReviewApproveUsersByQMSDeptId(@Param("deptId") Long deptId, @Param("enabledStatus") EnabledStatus enabledStatus, @Param("reviewType") String reviewType);
}
