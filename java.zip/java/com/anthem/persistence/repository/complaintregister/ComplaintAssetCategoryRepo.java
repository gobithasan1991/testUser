package com.anthem.persistence.repository.complaintregister;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintAssetCategory;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

public interface ComplaintAssetCategoryRepo extends JpaRepository<ComplaintAssetCategory, Long>{	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(c.id, c.code, c.name) FROM ComplaintAssetCategory c WHERE c.enabledStatus = :enabledStatus ORDER BY c.name")
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
}
