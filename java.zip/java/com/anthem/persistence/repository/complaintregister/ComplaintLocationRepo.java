package com.anthem.persistence.repository.complaintregister;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintLocation;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

public interface ComplaintLocationRepo extends JpaRepository<ComplaintLocation, Long>{
	@Query(value ="SELECT l FROM ComplaintLocation l WHERE l.branch.id=:branchId")
	public List<ComplaintLocation> listAllComplaintLocationDetailsByBranchId(@Param("branchId") Long branchId);
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(l.id, l.code, l.name) FROM ComplaintLocation l WHERE l.enabledStatus = :enabledStatus ORDER BY l.name")
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT new com.anthem.web.service.common.dto.IdCodeName(l.id, l.code, l.name) FROM ComplaintLocation l WHERE l.branch.id=:branchId AND l.enabledStatus = :enabledStatus ORDER BY l.name")
	public List<IdCodeName> getICNByBranchId(@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT new com.anthem.web.service.common.dto.IdCodeName(l.id, l.code, l.name) FROM ComplaintLocation l WHERE l.id NOT IN (:locationIdArr) AND l.enabledStatus = :enabledStatus ORDER BY l.name")
	public List<IdCodeName> getICNByBranchIdAndDeptIdAndAssetId(@Param("locationIdArr") List<Long> locationIdArr, @Param("enabledStatus") EnabledStatus enabledStatus);
	
}
