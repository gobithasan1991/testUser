package com.anthem.persistence.repository.complaintregister;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintAssetLocationMapping;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

public interface ComplaintAssetLocationMappingRepo extends JpaRepository<ComplaintAssetLocationMapping, Long>{
	@Query(value ="SELECT alm FROM ComplaintAssetLocationMapping alm WHERE alm.branch.id=:branchId AND alm.department.id=:deptId AND alm.assetMaster.id=:assetMasterId AND alm.location.id=:locationId AND alm.enabledStatus = :enabledStatus")
	public ComplaintAssetLocationMapping checkDuplicate(@Param("branchId") Long branchId, @Param("deptId") Long deptId, @Param("assetMasterId") Long assetMasterId, @Param("locationId") Long locationId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT alm.location.id FROM ComplaintAssetLocationMapping alm WHERE alm.branch.id=:branchId AND alm.department.id=:deptId AND alm.assetMaster.id=:assetMasterId AND alm.enabledStatus = :enabledStatus")
	public List<Long> getLocation(@Param("branchId") Long branchId, @Param("deptId") Long deptId, @Param("assetMasterId") Long assetMasterId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT new com.anthem.web.service.common.dto.IdCodeName(l.id, l.code, l.name) FROM ComplaintAssetLocationMapping alm JOIN alm.location l JOIN alm.branch b JOIN alm.department d WHERE b.id=:branchId AND d.id=:deptId AND alm.enabledStatus = :enabledStatus ORDER BY l.name")
	public Set<IdCodeName> getLocationByLoginBranchIdAndDeptId(@Param("branchId") Long branchId, @Param("deptId") Long deptId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value ="SELECT new com.anthem.web.service.common.dto.IdCodeName(am.id, am.code, am.name) FROM ComplaintAssetLocationMapping alm JOIN alm.assetMaster am JOIN alm.location l JOIN alm.assetCategory ac JOIN alm.branch b JOIN alm.department d WHERE b.id=:branchId AND d.id=:deptId AND l.id=:locationId AND ac.id=:assetCategoryId AND alm.enabledStatus = :enabledStatus ORDER BY am.name")
	public Set<IdCodeName> getAssetByLocationIdAssetCategoryIdLoginBranchIdAndDeptId(@Param("branchId") Long branchId, @Param("deptId") Long deptId, @Param("locationId") Long locationId, @Param("assetCategoryId") Long assetCategoryId, @Param("enabledStatus") EnabledStatus enabledStatus);
}
