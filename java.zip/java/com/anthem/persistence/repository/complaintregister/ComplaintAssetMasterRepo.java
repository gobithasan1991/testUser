package com.anthem.persistence.repository.complaintregister;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintAssetMaster;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;

public interface ComplaintAssetMasterRepo extends JpaRepository<ComplaintAssetMaster, Long>{
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(am.id, am.code, am.name) FROM ComplaintAssetMaster am WHERE am.enabledStatus = :enabledStatus ORDER BY am.name")
	public List<IdCodeName> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT new com.anthem.web.service.common.dto.IdCodeName(am.id, am.code, am.name) FROM ComplaintAssetMaster am WHERE am.enabledStatus = :enabledStatus AND am.assetCategory.id =:assetCategoryId ORDER BY am.name")
	public List<IdCodeName> findAllEnabledByAssetCategoryId(@Param("assetCategoryId") Long assetCategoryId, @Param("enabledStatus") EnabledStatus enabledStatus);
	
	@Query(value="SELECT am FROM ComplaintAssetMaster am WHERE am.assetCategory.id =:assetCategoryId")
	public List<ComplaintAssetMaster> listAllComplaintAssetDetailsByAssetCategoryId(@Param("assetCategoryId") Long assetCategoryId);
}
