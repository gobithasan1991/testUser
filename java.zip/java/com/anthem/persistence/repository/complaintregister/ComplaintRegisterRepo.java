package com.anthem.persistence.repository.complaintregister;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintRegister;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.complaintregister.ComplaintRegisterStatus;

public interface ComplaintRegisterRepo extends JpaRepository<ComplaintRegister, Long>{	
	@Query(value="SELECT cr FROM ComplaintRegister cr JOIN cr.branch b JOIN cr.complaintReceivingDepartment d WHERE cr.complaintRegisterStatus =:complaintRegisterStatus AND b.id =:branchId AND d.id IN (:qmsDepartmentIdArr)")
	public List<ComplaintRegister> listAllcomplaintRegistersByLoginBranchAndDepartment(@Param("branchId") Long branchId, @Param("qmsDepartmentIdArr") List<Long> qmsDepartmentIdArr, @Param("complaintRegisterStatus") ComplaintRegisterStatus complaintRegisterStatus);
	
	@Query(value="SELECT cr FROM ComplaintRegister cr JOIN cr.branch b JOIN cr.complaintReceivingDepartment d WHERE b.id =:branchId AND d.id IN (:qmsDepartmentIdArr)")
	public List<ComplaintRegister> listAllcomplaintRegistersByLoginBranchAndDepartmentStatus(@Param("branchId") Long branchId, @Param("qmsDepartmentIdArr") List<Long> qmsDepartmentIdArr);
	
	@Query(value="SELECT cr FROM ComplaintRegister cr JOIN cr.complaintAssignedUser u WHERE cr.complaintRegisterStatus =:complaintRegisterStatus AND u.id =:userId")
	public List<ComplaintRegister> listAllcomplaintRegistersByLoginUser(@Param("userId") Long userId, @Param("complaintRegisterStatus") ComplaintRegisterStatus complaintRegisterStatus);
	
	@Query(value = "SELECT COUNT(cr) FROM ComplaintRegister cr WHERE cr.complaintRegisterNo LIKE :prefixLike%")
	public int findAvailableSeriesCount(@Param("prefixLike") String prefixLike);
	
	@Query(value = "SELECT cr FROM ComplaintRegister cr WHERE cr.id =:complaintRegisterId")
	public ComplaintRegister findComplaintRegisterById(@Param("complaintRegisterId") Long complaintRegisterId);
	
	@Query(value="SELECT cr FROM ComplaintRegister cr JOIN cr.createdBy cb WHERE cr.complaintRegisterStatus =:complaintRegisterStatus AND cb.id =:userId")
	public List<ComplaintRegister> listAllcomplaintRegistersByCreatedUserId(@Param("userId") Long userId, @Param("complaintRegisterStatus") ComplaintRegisterStatus complaintRegisterStatus);
	
	@Query(value="SELECT cr FROM ComplaintRegister cr JOIN cr.branch b JOIN cr.complaintReceivingDepartment d WHERE cr.complaintRegisterStatus =:complaintRegisterStatus AND cr.createdDate >=:fromDate AND cr.createdDate <= :toDate AND b.id =:branchId AND d.id IN (:qmsDepartmentIdArr) AND cr.enabledStatus=:enabledStatus")
	public List<ComplaintRegister> listAllcomplaintRegistersByLoginBranchAndDepartmentAndDate(@Param("branchId") Long branchId, @Param("qmsDepartmentIdArr") List<Long> qmsDepartmentIdArr, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("complaintRegisterStatus") ComplaintRegisterStatus complaintRegisterStatus, @Param("enabledStatus") EnabledStatus enabledStatus);
}
