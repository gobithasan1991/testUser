package com.anthem.persistence.repository.complaintregister;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.complaintregister.ComplaintCheckListMapping;

public interface ComplaintCheckListMappingRepo extends JpaRepository<ComplaintCheckListMapping, Long>{
	@Query(value ="SELECT clm FROM ComplaintCheckListMapping clm WHERE clm.department.id=:deptId")
	public List<ComplaintCheckListMapping> listComplaintCheckListMappingByDepartmentId(@Param("deptId") Long deptId);
	
	@Query(value ="SELECT clm FROM ComplaintCheckListMapping clm WHERE clm.department.id=:departmentId AND clm.checkList.id=:checkListId")
	public ComplaintCheckListMapping getComplaintCheckListMappingByDepartmentIdChecklistId(@Param("departmentId") Long departmentId, @Param("checkListId") Long checkListId);
}
