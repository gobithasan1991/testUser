package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.document.DocumentTemplate;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;

public interface DocumentTemplateRepo extends JpaRepository<DocumentTemplate, Long> {
	/**
	 * file document template by its fileId
	 * 
	 * @param fileUUID
	 * @return
	 */
	public DocumentTemplate findByFileUUIDAndEnabledStatusIn(String fileUUID,EnabledStatus enabledStatus);
	
	
	@Query("SELECT DISTINCT(dt) from DocumentTemplate dt LEFT JOIN dt.branch b JOIN dt.templateCategory tc "
			+ "WHERE tc.id=:templateCategoryId AND dt.enabledStatus=:enabledStatus AND dt.templateStatus=:templateStatus AND b.id in :branchIds")
	public List<DocumentTemplate> findApprovedDocumentTemplatesByTemplateCategoryAndBranchIds(@Param("templateCategoryId")Long templateCategoryId,@Param("enabledStatus")EnabledStatus enabledStatus,@Param("templateStatus")CustomStatus approved,@Param("branchIds")List<Long> branchIds);
	
	/**
	 * for document template modify page data
	 * @param true1
	 * @param userid 
	 * @param approved 
	 * @return
	 */
	@Query("SELECT DISTINCT dt from DocumentTemplate dt LEFT JOIN dt.branch b WHERE dt.enabledStatus=:enabledStatus AND dt.createdBy.id=:userId AND b.id IN :branchIds AND dt.templateStatus NOT in :templateStatus")
	public List<DocumentTemplate> getDocumentTemplatesforModifyByEnabledStatusAndCreatedByAndBranchIdAndTamplateStatus(@Param("enabledStatus")EnabledStatus enabledStatus,@Param("userId") Long userId,@Param("branchIds") List<Long> branchIds,@Param("templateStatus") CustomStatus templateStatus);
	
	
	public DocumentTemplate findOneById(Long documentTemplateId);
	
	/**
	 * for getting document Template by fileId not in user view
	 * @param docCaption
	 * @return
	 */
	public DocumentTemplate findByFileId(String fileId);
	
	public DocumentTemplate findByIdAndEnabledStatusIn(Long documentTemplateId,EnabledStatus enabledStatus);
	
	/**
	 * for document template modify page data
	 * @param true1
	 * @param userid 
	 * @param approved 
	 * @return
	 */
	@Query("SELECT DISTINCT dt from DocumentTemplate dt LEFT JOIN dt.branch b JOIN dt.qmsDepartment qmsd WHERE dt.enabledStatus=:enabledStatus AND b.id IN (:branchIds) AND dt.templateStatus NOT in (:templateStatus) AND (dt.createdBy.id=:userId OR qmsd.id IN (:qmsDepartmentIds))")
	public List<DocumentTemplate> getDocumentTemplatesforModifyByEnabledStatusAndCreatedByAndBranchIdAndTamplateStatusAndQMSDepartmentIds(@Param("enabledStatus")EnabledStatus enabledStatus,@Param("userId") Long userId,@Param("branchIds") List<Long> branchIds,@Param("templateStatus") CustomStatus templateStatus,@Param("qmsDepartmentIds") List<Long> qmsDepartmentIds);
	
	@Query("SELECT DISTINCT dt FROM DocumentTemplate dt JOIN dt.branch b WHERE dt.qmsDepartment IS NOT NULL AND b.id IN :branchIds AND dt.enabledStatus=:enabledStatus")
	public List<DocumentTemplate> getDocumentTemplateByBranchIdsAndEnabledStatus(@Param("branchIds")List<Long> branchIds,@Param("enabledStatus")EnabledStatus enabledStatus);
	

	@Transactional
	@Modifying
	@Query("update DocumentTemplate dt set dt.currentVersiontemplate=?1,dt.currentVersion=?2 where dt.id = ?3")	
	void updateDocumentTemplateVersionNoAndfileName(String currentVersiontemplate, String versionNo, long id);

	

	

	

}
