package com.anthem.persistence.repository.document;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.document.DocumentMapping;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public interface DocumentMappingRepo extends JpaRepository<DocumentMapping, Long> {

	@Query("SELECT DISTINCT dm FROM DocumentMapping dm " + "JOIN  dm.documentCompanyMappings dmdc JOIN dmdc.company c "
			+ "WHERE c.id=:companyId AND dm.enabledStatus=:enabledStatus "
			+ "AND dm.companyOption=true AND dmdc.enabledStatus=:enabledStatus")
	public List<DocumentMapping> getDocumentMappingListByEnabledStatusAndCompanyId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("companyId") Long companyId);

	@Query("SELECT DISTINCT dm FROM DocumentMapping dm " + "LEFT JOIN  dm.documentCompanyMappings dmdc "
			+ "LEFT JOIN  dm.documentDepartmentMappings dmdd " + "LEFT JOIN dmdd.qmsDepartment q "
			+ "WHERE dm.enabledStatus=:enabledStatus "
			+ "AND ((dm.companyOption=true AND dmdc.enabledStatus=:enabledStatus) "
			+ "OR (q.id=:qmsDepartmentId AND dm.departmentOption=true AND dmdd.enabledStatus=:enabledStatus))")
	public List<DocumentMapping> getDocumentMappingListByEnabledStatusAndQMSDepartmentId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("qmsDepartmentId") Long qmsDepartmentId);

	@Query("SELECT DISTINCT dm FROM DocumentMapping dm " + "LEFT JOIN  dm.documentCompanyMappings dmdc "
			+ "LEFT JOIN  dm.documentDepartmentMappings dmdd LEFT JOIN dmdd.qmsDepartment qmsd "
			+ "LEFT JOIN dm.documentIndividualMappings dmdi LEFT JOIN dmdi.user u "
			+ "WHERE dm.enabledStatus=:enabledStatus "
			+ "AND ((dm.companyOption=true AND dmdc.enabledStatus=:enabledStatus) "
			+ "OR (dm.departmentOption=true AND qmsd.id=:qmsDepartmentId AND dmdd.enabledStatus=:enabledStatus) "
			+ "OR (dm.individualOption=true AND u.id IN :userId AND dmdi.enabledStatus=:enabledStatus))")
	public List<DocumentMapping> getDocumentMappingListByEnabledStatusAndQMSDepartmentIdOrUserId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("userId") Long userId);

	@Query("SELECT DISTINCT dm FROM DocumentMapping dm JOIN dm.document doc "
			+ "LEFT JOIN  dm.documentCompanyMappings dmdc "
			+ "LEFT JOIN  dm.documentDepartmentMappings dmdd LEFT JOIN dmdd.qmsDepartment qmsd "
			+ "LEFT JOIN dm.documentIndividualMappings dmdi LEFT JOIN dmdi.user u "
			+ "WHERE dm.enabledStatus=:enabledStatus AND doc.id IN (:documentId) "
			+ "AND ((dm.companyOption=true AND dmdc.enabledStatus=:enabledStatus) "
			+ "OR (dm.departmentOption=true AND dmdd.enabledStatus=:enabledStatus) "
			+ "OR (dm.individualOption=true AND dmdi.enabledStatus=:enabledStatus))")
	public List<DocumentMapping> getDocumentMappingListByEnabledStatusAndDocumentId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId);

	/**
	 * @author gobithasan.s
	 * @param enabled,approvedStatus,qmsDepartment,branchId Get Company Mapped
	 *        DocumentMapping
	 * @return List<DocumentMapping>
	 */
	@Query("SELECT DISTINCT dm FROM DocumentMapping dm JOIN dm.document doc JOIN doc.branchs bran "
			+ "LEFT JOIN  dm.documentCompanyMappings dmdc "
			+ "LEFT JOIN  dm.documentDepartmentMappings dmdd LEFT JOIN dmdd.qmsDepartment qmsd "
			+ "LEFT JOIN dm.documentIndividualMappings dmdi LEFT JOIN dmdi.user u "
			+ "WHERE dm.enabledStatus=:enabledStatus AND doc.customStatus=:approvedStatus AND doc.documentUpdateStatus IN('NA','COMPLETED') "
			+ "AND doc.documentChangeControlStatus IN('NA','COMPLETED') AND bran.id = :branchId "
			+ "AND ((dm.companyOption=true AND dmdc.enabledStatus=:enabledStatus) "
			+ "OR (dm.departmentOption=true AND qmsd.id=:qmsDepartmentId AND dmdd.enabledStatus=:enabledStatus) "
			+ "OR (dm.individualOption=true AND u.id IN (:userIds) AND dmdi.enabledStatus=:enabledStatus))")
	public List<DocumentMapping> getDocumentMappingListByEnabledStatusAndDocumentApprovedStatusAndQMSDepartmentIdOrUserIdsOrBranchId(
			@Param("approvedStatus") CustomStatus approvedStatus, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("userIds") List<Long> userIds, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT DISTINCT doc FROM DocumentMapping dm JOIN dm.document doc JOIN doc.templateCategory dtc JOIN doc.qmsDepartment q WHERE dtc.id =:documentTemplateCategoryId AND q.id=:qmsDepartmentId AND dm.enabledStatus=:enabledStatus AND dm.enabledStatus=:enabledStatus AND doc.enabledStatus=:enabledStatus")
	public List<Document> getDocumentsByTemplateCategoryIdAndQMSDepartmentId(
			@Param("documentTemplateCategoryId") Long documentTemplateCategoryId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DocumentMapping dm JOIN dm.document doc "
			+ "LEFT JOIN dm.documentCompanyMappings dmdc "
			+ "LEFT JOIN dm.documentDepartmentMappings dmdd LEFT JOIN dmdd.qmsDepartment qms "
			+ "LEFT JOIN dm.documentIndividualMappings dmdi LEFT JOIN dmdi.user dmu "
			+ " WHERE ((dm.companyOption=true AND dmdc.enabledStatus=:enabledStatus AND dmdc.evaluation=true) "
			+ "OR (dm.departmentOption=true AND qms.id=:qmsDepartmentId AND dmdd.enabledStatus=:enabledStatus AND dmdd.evaluation=true) "
			+ "OR (dm.individualOption=true AND dmu.id =:userId AND dmdi.enabledStatus=:enabledStatus AND dmdi.evaluation=true))"
			+ " AND doc.id=:documentId AND dm.enabledStatus=:enabledStatus")
	public DocumentMapping checkEvolutionRequiredByDocumentIdAndUserIdOrQMSDepartmentIdAndEnabledStatus(
			@Param("documentId") Long documentId, @Param("userId") Long userId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("enabledStatus") EnabledStatus enabledStatus);
	// @Query("SELECT DISTINCT dm FROM DocumentMapping dm JOIN dm.document doc JOIN
	// doc.branchs b JOIN doc.templateCategory dtc JOIN doc.qmsDepartment q "
	// + "WHERE dtc.id =:documentTemplateCategoryId AND q.id=:qmsDepartmentId AND
	// b.id=:branchId "
	// + "AND dm.enabledStatus=:enabledStatus AND dm.enabledStatus=:enabledStatus
	// AND doc.enabledStatus=:enabledStatus")
	// public List<DocumentMapping>
	// getDocumentMappingsByTemplateCategoryIdAndDocumentQMSDepartmentIdAndDocumentBranchIdAndEnabledStatus(
	// @Param("documentTemplateCategoryId") Long documentTemplateCategoryId,
	// @Param("qmsDepartmentId") Long qmsDepartmentId, @Param("branchId") Long
	// branchId,
	// @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DocumentMapping dm join fetch dm.document d join d.branchs b JOIN dm.documentCompanyMappings dmdc "
			+ "WHERE b.id=:branchId AND d.qmsDepartment.id =:qmsDepartmentId AND d.templateCategory.id =:categoryId AND d.customStatus =:customStatus "
			+ "AND dm.companyOption = true AND dm.enabledStatus=:enabledStatus AND d.enabledStatus=:enabledStatus AND dmdc.enabledStatus=:enabledStatus")
	public Set<DocumentMapping> findDocumentMappingForCompany(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("categoryId") Long categoryId,
			@Param("customStatus") CustomStatus customStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DocumentMapping dm join dm.document d join dm.documentDepartmentMappings dd join d.branchs b "
			+ "WHERE dd.qmsDepartment.id IN (:qmsDepartmentIds) AND b.id=:branchId AND d.qmsDepartment.id =:qmsDepartmentId AND d.templateCategory.id =:categoryId "
			+ " AND d.customStatus =:customStatus AND dm.departmentOption = true AND dm.enabledStatus=:enabledStatus AND d.enabledStatus=:enabledStatus AND dd.enabledStatus=:enabledStatus")
	public Set<DocumentMapping> findDocumentMappingForDepartment(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("categoryId") Long categoryId,
			@Param("customStatus") CustomStatus customStatus, @Param("qmsDepartmentIds") Set<Long> qmsDepartmentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DocumentMapping dm join dm.document d join dm.documentIndividualMappings di join d.branchs b JOIN di.user u JOIN u.qmsDepartments qms "
			+ "WHERE  b.id=:branchId AND d.qmsDepartment.id =:qmsDepartmentId AND d.templateCategory.id =:categoryId AND d.customStatus =:customStatus "
			+ " AND qms.id IN(:qmsDepartmentIds) AND dm.individualOption = true AND dm.enabledStatus=:enabledStatus AND d.enabledStatus=:enabledStatus AND di.enabledStatus=:enabledStatus")
	public Set<DocumentMapping> findDocumentMappingForIndividual(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("categoryId") Long categoryId,
			@Param("customStatus") CustomStatus customStatus, @Param("qmsDepartmentIds") Set<Long> qmsDepartmentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT count(dm) FROM DocumentMapping dm JOIN dm.documentCompanyMappings dc WHERE "
			+ "dm.id=:documentMappingId AND dc.mandatory=:mandatory AND dm.enabledStatus=:enabledStatus AND dm.companyOption = true")
	public int checkDocumentMappingCompany(@Param("documentMappingId") Long documentMappingId,
			@Param("mandatory") Boolean mandatory, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT count(dm) FROM DocumentMapping dm WHERE "
			+ "dm in (SELECT ddm.documentMapping FROM DocumentDepartmentMapping ddm WHERE ddm.documentMapping = dm AND ddm.mandatory=:mandatory AND ddm.enabledStatus=:enabledStatus) "
			+ "OR dm in(SELECT dim.documentMapping FROM DocumentIndividualMapping dim WHERE dim.documentMapping = dm AND dim.mandatory=:mandatory AND dim.enabledStatus=:enabledStatus) AND "
			+ "dm.id=:documentMappingId AND dm.enabledStatus=:enabledStatus AND dm.departmentOption = true AND dm.individualOption=true")
	public int checkDocumentMappingDepartmentAndIndividual(@Param("documentMappingId") Long documentMappingId,
			@Param("mandatory") Boolean mandatory, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(qms.id,qms.name) FROM DocumentMapping dm  JOIN  dm.documentIndividualMappings di JOIN di.user u JOIN u.qmsDepartments qms "
			+ "WHERE dm.id=:documentMappingId AND di.mandatory =:mandatory AND qms.id IN(:qmsDepartmentIds) AND dm.individualOption=true "
			+ "AND dm.enabledStatus =:enabledStatus AND di.enabledStatus =:enabledStatus")
	public Set<IdNameCodeDTO> findQmsDepartmentForIndividualDocumentMapping(
			@Param("documentMappingId") Long documentMappingId, @Param("mandatory") Boolean mandatory,
			@Param("qmsDepartmentIds") Set<Long> qmsDepartmentIds, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(qms.id,qms.name) FROM DocumentMapping dm JOIN  "
			+ "dm.documentDepartmentMappings dd JOIN  dd.qmsDepartment qms "
			+ "WHERE dm.id=:documentMappingId AND dd.mandatory=:mandatory AND qms.id IN (:qmsDepartmentIds) "
			+ "AND dm.departmentOption=true AND dm.enabledStatus=:enabledStatus AND dd.enabledStatus =:enabledStatus ")
	public Set<IdNameCodeDTO> findQmsDepartmentForDepartmentDocumentMapping(
			@Param("documentMappingId") Long documentMappingId, @Param("mandatory") Boolean mandatory,
			@Param("qmsDepartmentIds") Set<Long> qmsDepartmentIds, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT count(dm) FROM DocumentMapping dm JOIN dm.documentDepartmentMappings dd "
			+ "WHERE dm.id=:documentMappingId AND dd.mandatory=:mandatory AND dm.enabledStatus=:enabledStatus AND dm.departmentOption = true")
	public int checkDocumentMappingDepartment(@Param("documentMappingId") Long documentMappingId,
			@Param("mandatory") Boolean mandatory, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT count(dim) FROM DocumentIndividualMapping dim join dim.user u JOIN u.qmsDepartments qms	"
			+ "WHERE dim.documentMapping.id=:documentMappingId	AND qms.id=:qmsDepartmentId AND dim.enabledStatus=:enabledStatus")
	public int checkIndividualDocumentMapping(@Param("documentMappingId") Long documentMappingId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.user.dto.UserBasicDetailsDTO(u) FROM DocumentIndividualMapping dim JOIN dim.user u JOIN u.qmsDepartments qms JOIN  u.branches ub "
			+ "WHERE dim.documentMapping.id=:documentMappingId AND ub.id=:branchId AND qms.id=:qmsDepartment  AND "
			+ "u.id NOT IN(:usersInDocument) AND dim.enabledStatus=:enabledStatus AND u.employee IS NOT NULL ORDER BY u.fullName")
	public Set<UserBasicDetailsDTO> getUserInIndividualDocumentMappingTriningSchedulerEmployeeMapping(
			@Param("qmsDepartment") Long qmsDepartment, @Param("branchId") Long branchId,
			@Param("usersInDocument") Set<Long> usersInDocument, @Param("documentMappingId") Long documentMappingId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT count(dim) FROM DocumentIndividualMapping dim WHERE  dim.documentMapping.id=:documentMappingId AND dim.user.id=:userId AND dim.enabledStatus=:enabledStatus")
	public int checkDocumentIndividualHavingUser(@Param("documentMappingId") Long documentMappingId,
			@Param("userId") Long userId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DocumentMapping dm WHERE dm.id=:documentMappingId AND dm.enabledStatus=:enabledStatus")
	public DocumentMapping findDocumentMappingByIdAndEnabledStatus(@Param("documentMappingId") Long documentMappingId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT u FROM DocumentIndividualMapping dim JOIN dim.documentMapping dm JOIN dim.user u JOIN u.qmsDepartments q "
			+ "WHERE  dm.id=:documentMappingId AND q.id IN(:qmsDepartmentId) AND dim.enabledStatus=:enabledStatus")
	public List<User> findIndividualMappingUsersByDocumentMappingIdAndQmsDepartmentId(
			@Param("documentMappingId") Long documentMappingId, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT count(ddm) FROM DocumentDepartmentMapping ddm JOIN ddm.documentMapping dm  JOIN ddm.qmsDepartment q "
			+ "WHERE dm.id=:documentMappingId AND q.id=:qmsDepartmentId AND ddm.enabledStatus=:enabledStatus ")
	public int checkDepartemntInDocumentHavingDepartment(@Param("documentMappingId") Long documentMappingId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT DISTINCT dm FROM DocumentMapping dm JOIN dm.document doc "
			+ "WHERE dm.enabledStatus=:enabledStatus AND doc.id IN (:documentId) ")
	public DocumentMapping getDocumentMappingByEnabledStatusAndDocumentId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId);

	// List<DocumentMapping> findByDocumentsAndUser(Document document, User
	// user);
	//
	// List<DocumentMapping> findByDocumentsAndQmsDepartment(Document document,
	// QMSDepartment qmsDepartment);

	// @Query("select dm from DocumentMapping dm join dm.user u left join fetch
	// dm.document d where dm.enabled=?1 and dm.document.customStatus=?2 and u
	// in ?3 ")
	// List<DocumentMapping> documentmappinglist(Boolean enabled, CustomStatus
	// approved, List<User> user);

	// List<DocumentMapping>
	// findByEnabledTrueAndDocumentsAndQmsDepartment(Document document,
	// QMSDepartment qmsDepartment);
	//
	// List<DocumentMapping> findByEnabledTrueAndDocumentsAndUser(Document
	// document, User user);
	//
	// List<DocumentMapping> findByEnabledTrueAndDocumentsAndCompany(Document
	// document, Company company);

	// @Query("select distinct dm from DocumentMapping dm join dm.user u where
	// dm.document.id=?1 and u.id=?2 and dm.enabled=?3")
	// DocumentMapping findDocumentTrainingDurationbyDocumentIdandUserid(long
	// id, long userid, Boolean enabled);

	// @Query(value = "select distinct dm from DocumentMapping dm left join
	// fetch dm.document d join d.branch b join d.templateCategory tc join
	// dm.qmsDepartment dmdept left join fetch dm.user left join fetch
	// dm.company left join fetch dm.qmsDepartment where tc.id=?1 and
	// dmdept.id=?2 and b.id=?3 and dm.enabled=true and d.customStatus=?4")
	// List<DocumentMapping>
	// findApprovedDocumentByCategoryDepartmentAndBranch(long categoryId, long
	// departmentId,
	// long branchId, CustomStatus status);

	/*
	 * For training session employee mapping entry page
	 */

	// @Query(value = "SELECT u FROM DocumentMapping dm join dm.user u JOIN
	// u.qmsDepartment qmsd where u.qmsDepartment.id=?2 AND dm.document.id=?1
	// AND "
	// + "u NOT IN(SELECT dram.user from DocumentReviewAndApproveMapping dram
	// WHERE dram.document.id =?1 AND dram.enabled=true) AND "
	// + "u NOT IN(SELECT d.createdBy FROM Document d where d.id=?1 AND
	// d.enabled=true) AND "
	// + "u NOT IN(SELECT ts.trainer FROM TrainingSession ts WHERE
	// ts.trainingScheduler.id =?3 and ts.enabled=true) ")
	// Set<User> findDocumentMappingUserForIndividual(long documentId, long
	// qmsDepartments, long trainingSchedulerId);
	//
	// /*
	// * For training session employee mapping update page
	// */
	//
	// @Query(value = "SELECT u FROM DocumentMapping dm join dm.user u JOIN
	// u.qmsDepartment qmsd where dm.document.id =?1 AND qmsd IN (?3) AND "
	// + "u NOT IN(SELECT dram.user from DocumentReviewAndApproveMapping dram
	// WHERE dram.document.id =?1 AND dram.enabled=true) AND "
	// + "u NOT IN(SELECT d.createdBy FROM Document d where d.id=?1 AND
	// d.enabled=true) AND "
	// + "u NOT IN(SELECT ts.trainer FROM TrainingSession ts WHERE
	// ts.trainingScheduler.id =?4 and ts.enabled=true) AND "
	// + "u NOT IN(SELECT tsem.user FROM TrainingSessionEmployeeMapping tsem
	// WHERE tsem.trainingSession.id=?5 AND tsem.enabled=true)")
	// Set<User>
	// findDocumentMappingUserByDepartmentForSessionEmployeeUpdate(long
	// documentId,
	// QMSDepartment qmsDepartments, long trainingSchedulerId, long
	// trainingSessionId);
	//
	// /*
	// * For Training Planner Creation
	// */
	// @Query("select DISTINCT dm from DocumentMapping dm left join dm.user u
	// left join fetch dm.document d JOIN dm.qmsDepartment dmqmsd where
	// dm.enabled=?1 and dm.document.customStatus=?2 and (dm.options='Company'
	// OR (dm.options='Department' AND dmqmsd.id=?3) OR (dm.options='Individual'
	// and u in ?4))")
	// List<DocumentMapping> documentmappinglistByUser(Boolean enabled,
	// CustomStatus approved, Long qmsDepartment,
	// List<User> user);
	//
	// @Query(value = "SELECT DISTINCT dm.qmsDepartment FROM DocumentMapping dm
	// WHERE dm.document.id=?1 AND dm.mandatory = ?2 AND
	// dm.options='Department' AND dm.enabled = true")
	// public Set<QMSDepartment> getDepartmentsForDocument(long documentId,
	// boolean mandatory);
	//
	// @Query(value = "SELECT count(dm) FROM DocumentMapping dm WHERE
	// dm.document.id=?1 AND dm.mandatory = ?2 AND dm.options='Company' AND
	// dm.enabled = true")
	// public int checkIfCompanyOrNot(long documentId, boolean mandatory);
	//
	// @Query(value = "SELECT DISTINCT qms FROM DocumentMapping dm JOIN dm.user
	// u JOIN u.qmsDepartment qms WHERE dm.document.id=?1 AND dm.mandatory = ?2
	// AND dm.options='Individual' AND dm.enabled = true")
	// public Set<QMSDepartment> getDepartmentsForIndividualByDocument(long
	// documentId, boolean mandatory);
	//
	//// @Query(value = "SELECT count(qms) FROM DocumentMapping dm JOIN
	// dm.qmsDepartment qms "
	//// + "WHERE dm.document.id=?1 AND qms.id = ?2 AND dm.options='Department'
	// AND dm.enabled = true")
	//// public int CheckIndividualOrDepartment(long documentId, long
	// qmsDepartmentId);
	//
	// @Query(value = "SELECT dm FROM DocumentMapping dm WHERE
	// dm.document.id=?1 AND dm.options='Company' AND dm.enabled= true")
	// public DocumentMapping getDocumentMappingForCompany(long documentId);
	//
	// @Query(value = "SELECT dm FROM DocumentMapping dm JOIN dm.qmsDepartment
	// qms WHERE dm.document.id=?1 AND qms.id=?2 AND dm.options='Department'
	// AND dm.enabled= true")
	// public DocumentMapping getDocumentMappingForDepartment(long documentId,
	// long qmsDepartment);
	//
	// @Query(value = "SELECT dm FROM DocumentMapping dm JOIN dm.user u WHERE
	// dm.document.id=?1 AND u.id=?2 AND dm.options='Individual' AND
	// dm.enabled= true")
	// public DocumentMapping getDocumentMappingForIndividual(long documentId,
	// long userId);

	/**
	 * @author ganeshamurthi.r Written for training Scheduler module
	 */

	/**
	 * start
	 */
	// @Query("SELECT dm FROM DocumentMapping dm WHERE dm.document.id=?1 AND
	// dm.enabled=true")
	// public DocumentMapping findDocumentMappingByDocumentId(long documentId);

	// @Query(value = "SELECT DISTINCT u FROM DocumentIndividualMapping dim join
	// dim.user u JOIN FETCH u.branches ub JOIN u.qmsDepartments qms "
	// + "WHERE dim.documentMapping.id=?4 AND ub.id=?2 AND qms.id=?1 AND
	// dim.enabled=true AND "
	// + "u NOT IN(?3) AND u.employee IS NOT NULL ORDER BY u.fullName")
	// public Set<User>
	// getUserInIndividualDocumentMappingTriningSchedulerEmployeeMappingUpdate(Long
	// qmsDepartment,
	// long branchId, Set<User> usersInDocument, long documentMappingId);
	//

	//
	// @Query(value = "SELECT dm FROM DocumentMapping dm join fetch dm.document d
	// join d.branchs b "
	// + "WHERE b.id=?1 AND d.qmsDepartment.id = ?2 AND d.templateCategory.id = ?3
	// AND d.customStatus = ?4 "
	// + "AND dm.enabled=true AND d.enabled=true")
	// public Set<DocumentMapping> findDocumentMappingForUserDepartment(long
	// branchId, long qmsDepartmentId,
	// long categoryId, CustomStatus customStatus);

	/**
	 * end
	 */
}
