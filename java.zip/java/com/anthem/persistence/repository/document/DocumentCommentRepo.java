/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentComment;
import com.anthem.util.common.EnabledStatus;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentCommentRepo extends JpaRepository<DocumentComment, Long> {
	/**
	 * get document comments based on documentid
	 * 
	 * @param id
	 * @param true1
	 * @return
	 */
	@Query(value = "select dc from DocumentComment dc JOIN dc.document d where d.id=:documentId and dc.enabledStatus=:enabledStatus")
	public List<DocumentComment> findByDocumentId(@Param("documentId") Long id,
			@Param("enabledStatus") EnabledStatus enabledStatus);

}
