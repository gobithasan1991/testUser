package com.anthem.persistence.repository.document;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentEditorMapping;
import com.anthem.util.common.EnabledStatus;

public interface DocumentEditorMappingRepo extends JpaRepository<DocumentEditorMapping, Long> {

	@Query("SELECT DISTINCT dem FROM DocumentEditorMapping dem LEFT JOIN dem.qmsDepartment qd LEFT JOIN dem.templateCategory tc LEFT JOIN dem.document d "
			+ "JOIN FETCH dem.branchs")
	public List<DocumentEditorMapping> getDocumentEditorMappingData();

	@Query("SELECT d.id FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd JOIN dem.templateCategory tc JOIN dem.document d JOIN d.branchs b"
			+ " WHERE b.id IN (:branchIds) AND tc.id=:docCategoryId AND qd.id=:qmsDepartmentId")
	public List<Long> getDocumentIdByQMSDepartmentIdAndDocCategoryIdAndBranchIds(
			@Param("docCategoryId") Long docCategoryId, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("branchIds") List<Long> branchIds);

	@Query("SELECT dem FROM DocumentEditorMapping dem LEFT JOIN dem.qmsDepartment qd LEFT JOIN dem.templateCategory tc LEFT JOIN dem.document d "
			+ "WHERE dem.id=:documentEditorMappingId")
	public DocumentEditorMapping getById(@Param("documentEditorMappingId") Long documentEditorMappingId);

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem LEFT JOIN dem.qmsDepartment qd JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE tc.id=:docCategoryId AND d IS NULL AND qd IS NULL")
	public Boolean checkDataAvalibleOrNotByTemplateCategoryId(@Param("docCategoryId") Long docCategoryId);

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd LEFT JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE qd.id=:qmsDepartmentId AND d IS NULL AND tc IS NULL")
	public Boolean checkDataAvalibleOrNotByQmsDepartmentId(@Param("qmsDepartmentId") Long qmsDepartmentId);

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd LEFT JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE qd.id=:qmsDepartmentId AND tc.id=:docCategoryId AND d IS NULL")
	public Boolean checkDataAvalibleOrNotByQmsDepartmentIdAndTemplateCategoryId(
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("docCategoryId") Long docCategoryId);

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE qd.id=:qmsDepartmentId AND tc.id=:docCategoryId AND d.id=:documentId")
	public boolean checkDataAvalibleOrNotByQmsDepartmentIdAndTemplateCategoryIdAndDocumentId(
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("docCategoryId") Long docCategoryId,
			@Param("documentId") Long documentId);

	@Query(value = "SELECT dem FROM DocumentEditorMapping dem JOIN dem.branchs b WHERE  b.id IN(:branchId) AND dem.document IS NULL "
			+ "AND dem.templateCategory IS NOT NULL AND dem.qmsDepartment IS NULL AND dem.enabledStatus=:enabledStatus")
	public List<DocumentEditorMapping> findDocumentEditorMappingByBranchAndDocumentIsNullAndCategoryNotNull(
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dem FROM DocumentEditorMapping dem JOIN dem.branchs b WHERE  b.id IN(:branchId) AND dem.document IS NULL "
			+ "AND dem.templateCategory IS NULL AND dem.qmsDepartment IS NOT NULL AND dem.enabledStatus=:enabledStatus")
	public List<DocumentEditorMapping> findDocumentEditorMappingByBranchAndCategoryIsNullAndDocumemntIsNull(
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dem FROM DocumentEditorMapping dem JOIN dem.branchs b WHERE  b.id IN(:branchId) AND dem.document IS NULL "
			+ "AND dem.templateCategory IS NOT NULL AND dem.qmsDepartment IS NOT NULL AND dem.enabledStatus=:enabledStatus")
	public List<DocumentEditorMapping> findDocumentEditorMappingByBranchAndCategoryAndDepartmentAndDocumemntIsNull(
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

//	@Query(value = "SELECT dem FROM DocumentEditorMapping dem JOIN dem.branchs b WHERE  b.id IN(:branchId) AND dem.document IS NULL "
//			+ "AND dem.templateCategory IS NULL AND dem.qmsDepartment IS NULL AND dem.enabledStatus=:enabledStatus")
//	public List<DocumentEditorMapping> findDocumentEditorMappingByBranchAndQmsDepartmentIsNullAndCategoryIsNullAndDocumemntIsNull(
//			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM DocumentEditorMapping dem JOIN dem.branchs b JOIN dem.document d JOIn d.documentOwners dos JOIN dos.user u WHERE b.id IN(:branchId) "
			+ "AND u.id IN(:userId) AND dem.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByUser(@Param("branchId") Long branchId, @Param("userId") Long userId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM DocumentEditorMapping dem JOIN dem.branchs b JOIN dem.document d JOIn d.documentOwners dos JOIN dos.user u WHERE b.id IN(:branchId) "
			+ " AND dem.enabledStatus=:enabledStatus")
	public Set<Long> findAllDocumentId(@Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem LEFT JOIN dem.qmsDepartment qd JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE tc.id=:docCategoryId AND d IS NULL AND qd IS NULL AND dem.id NOT IN (:Id)")
	public Boolean checkDataAvalibleOrNotByTemplateCategoryIdAndNotINId(@Param("docCategoryId") Long docCategoryId,
			@Param("Id") Long Id);

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd LEFT JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE qd.id=:qmsDepartmentId AND d IS NULL AND tc IS NULL AND dem.id NOT IN (:Id)")
	public Boolean checkDataAvalibleOrNotByQmsDepartmentIdAndNotINId(@Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("Id") Long Id);

	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd LEFT JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE qd.id=:qmsDepartmentId AND tc.id=:docCategoryId AND d IS NULL AND dem.id NOT IN (:Id)")
	public Boolean checkDataAvalibleOrNotByQmsDepartmentIdAndTemplateCategoryIdAndNotINId(
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("docCategoryId") Long docCategoryId,
			@Param("Id") Long Id);
	
	@Query("SELECT CASE WHEN COUNT(dem.id) > 0 THEN true ELSE false END FROM DocumentEditorMapping dem JOIN dem.qmsDepartment qd JOIN dem.templateCategory tc "
			+ "  LEFT JOIN dem.document d WHERE qd.id=:qmsDepartmentId AND tc.id=:docCategoryId AND d.id=:documentId AND dem.id NOT IN (:Id)")
	public boolean checkDataAvalibleOrNotByTemplateCategoryIdAndQmsDepartmentIdAndDocumentANDNotINId(
			@Param("docCategoryId") Long docCategoryId, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("documentId") Long documentId, @Param("Id") Long Id);
}
