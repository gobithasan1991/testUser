/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.document.DocumentReviewAndApproveMapping;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentReviewApproveMappingRepo extends JpaRepository<DocumentReviewAndApproveMapping, Long> {

	@Query("select distinct m from DocumentReviewAndApproveMapping m join fetch m.document d join d.branchs b left join fetch d.documentTemplate t "
			+ "JOIN  d.changeControlNumber dcc  JOIN m.changeControlNumber mcc "
			+ "left join fetch d.templateCategory tc left join fetch d.qmsDepartment qd "
			+ "where dcc.id=mcc.id AND m.enabledStatus=:enabledStatus and m.mappingStatus IN (:mappingStatus) "
			+ "and m.user.id=:userId and m.reviewType=:reviewType and b in (:branchs) and d.processIn in (:customStatus)")
	public List<DocumentReviewAndApproveMapping> getDocumentsMappingDetailsByChangeControlForReviewAndApproveWithoutPagination(
			@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("mappingStatus") List<CustomStatus> mappingStatus, @Param("userId") Long userId,
			@Param("reviewType") String reviewType, @Param("branchs") List<Branch> branchs,
			@Param("customStatus") CustomStatus customStatus);

	@Query("select distinct m from DocumentReviewAndApproveMapping m join fetch m.document d join d.branchs b left join fetch d.documentTemplate t "
			+ "left join fetch d.templateCategory tc left join fetch d.qmsDepartment qd "
			+ "where  m.enabledStatus=:enabledStatus and m.mappingStatus IN (:mappingStatus) "
			+ "and m.user.id=:userId and m.reviewType=:reviewType and b in (:branchs) and d.processIn in (:customStatus) AND d.changeControlNumber IS NULL AND m.changeControlNumber IS NULL")
	public List<DocumentReviewAndApproveMapping> getDocumentsMappingDetailsByChangeControlIsNullForReviewAndApproveWithoutPagination(
			@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("mappingStatus") List<CustomStatus> mappingStatus, @Param("userId") Long userId,
			@Param("reviewType") String reviewType, @Param("branchs") List<Branch> branchs,
			@Param("customStatus") CustomStatus customStatus);

	// @Query("select distinct m from DocumentReviewAndApproveMapping m join fetch
	// m.document d join d.branchs b left join fetch d.documentTemplate t join fetch
	// d.templateCategory tc "
	// + "left join fetch d.qmsDepartment qd where m.enabledStatus=:enabledStatus
	// and m.mappingStatus IN (:mappingStatus) and m.user.id=:userId"
	// + " and m.reviewType=:reviewType and b in (:branchs) and d.processIn in
	// (:processStatus)")
	// public List<DocumentReviewAndApproveMapping>
	// getDocumentsMappingDetailsForRevieworApproveWithoutPagination(
	// @Param("mappingStatus") List<CustomStatus> mappingStatus, @Param("userId")
	// Long userid,
	// @Param("reviewType") String reviewType, @Param("branchs") List<Branch>
	// branchs,
	// @Param("processStatus") CustomStatus processStatus, @Param("enabledStatus")
	// EnabledStatus enabledStatus);

	@Query(value = "select m from DocumentReviewAndApproveMapping m JOIN m.document d WHERE d.id=:documentId AND m.enabledStatus=:enabledStatus")
	public List<DocumentReviewAndApproveMapping> findByEnabledTrueAndDocument(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	/**
	 * @author gobithasan.s
	 * @param documentId Get Document Reviewer And Approver
	 * @return User
	 */
	@Query("SELECT DISTINCT u.id FROM  DocumentReviewAndApproveMapping dram JOIN dram.user u JOIN dram.document d "
			+ "WHERE d.id=:documentId AND dram.mappingStatus IN ('REVIEWED','APPROVED') and dram.enabledStatus=:enabledStatus AND dram.rejected!=TRUE")
	public Set<Long> getDocumentReviewerIdAndApproverIdListByDocumentId(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT DISTINCT u FROM  DocumentReviewAndApproveMapping dram JOIN dram.user u JOIN dram.document d "
			+ "WHERE d.id=:documentId AND dram.mappingStatus IN ('REVIEWED','APPROVED') and dram.enabledStatus=:enabledStatus AND dram.rejected!=TRUE")
	public Set<User> getDocumentReviewerAndApproverListByDocumentId(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m where  m.mappingStatus=:mappingStatus and m.document.id=:documentId AND m.enabledStatus=:enabledStatus")
	int findByDocumentsAndEnabledTrue(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("mappingStatus") CustomStatus mappingStatus, @Param("documentId") Long documentId);

	@Query("select count(distinct m) from  DocumentReviewAndApproveMapping m left join m.document d JOIN d.branchs b "
			+ "where m.user.id=:userId and m.reviewType=:reviewType and m.mappingStatus in(:mappingStatus) AND b IN(:branchs) and d.processIn=:processIn AND m.enabledStatus=:enabledStatus")
	int getDashboardCount(@Param("userId") Long userId, @Param("reviewType") String reviewType,
			@Param("mappingStatus") List<CustomStatus> mappingStatus, @Param("processIn") CustomStatus processIn,
			@Param("branchs") List<Branch> branchs, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select m from DocumentReviewAndApproveMapping m JOIN m.changeControlNumber cc where m.enabledStatus=:enabledStatus and m.document.id=:documentId and m.user.id=:userId "
			+ " AND cc.id=:changeControlId and m.reviewType=:reviewType and m.rejected !=:rejectedStatus")
	DocumentReviewAndApproveMapping findEnableAndReviewApproveMappingAndChangeControlId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId,
			@Param("changeControlId") Long changeControlId, @Param("userId") Long userId,
			@Param("reviewType") String reviewType, @Param("rejectedStatus") Boolean rejectedStatus);

	@Query("select m from DocumentReviewAndApproveMapping m JOIN m.documentUpdateTrack cc where m.enabledStatus=:enabledStatus and m.document.id=:documentId and m.user.id=:userId "
			+ " AND cc.id=:documentUpdateTrackId and m.reviewType=:reviewType and m.rejected !=:rejectedStatus")
	DocumentReviewAndApproveMapping findEnableAndReviewApproveMappingAndDocumentUpdateTrackId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId,
			@Param("documentUpdateTrackId") Long documentUpdateTrackId, @Param("userId") Long userId,
			@Param("reviewType") String reviewType, @Param("rejectedStatus") Boolean rejectedStatus);

	@Query("select m from DocumentReviewAndApproveMapping m  where m.enabledStatus=:enabledStatus and m.document.id=:documentId and m.user.id=:userId "
			+ "  and m.reviewType=:reviewType and m.rejected !=:rejectedStatus AND m.changeControlNumber IS NULL")
	DocumentReviewAndApproveMapping findEnableAndReviewApproveMappingAndChangeControlIsNull(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId,
			@Param("userId") Long userId, @Param("reviewType") String reviewType,
			@Param("rejectedStatus") Boolean rejectedStatus);

	@Query("select m from DocumentReviewAndApproveMapping m JOIN m.changeControlNumber cc where m.enabledStatus=:enabledStatus and m.document.id=:documentId "
			+ "and m.prioritylevels=:priority AND cc.id=:changeControlId and m.reviewType=:reviewType and m.rejected !=:rejectedStatus")
	DocumentReviewAndApproveMapping findEnableAndReviewApproveMappingAndPriorityAndChangeControlId(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId,
			@Param("changeControlId") Long changeControlId, @Param("priority") String priority,
			@Param("reviewType") String reviewType, @Param("rejectedStatus") Boolean rejectedStatus);

	@Query("select m from DocumentReviewAndApproveMapping m JOIN m.documentUpdateTrack cc where m.enabledStatus=:enabledStatus and m.document.id=:documentId "
			+ "and m.prioritylevels=:priority AND cc.id=:documentUpdateTrackId and m.reviewType=:reviewType and m.rejected !=:rejectedStatus")
	DocumentReviewAndApproveMapping findEnableAndReviewApproveMappingAndPriorityAndDocumentUpdateTrack(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId,
			@Param("documentUpdateTrackId") Long documentUpdateTrackId, @Param("priority") String priority,
			@Param("reviewType") String reviewType, @Param("rejectedStatus") Boolean rejectedStatus);

	@Query("select m from DocumentReviewAndApproveMapping m  where m.enabledStatus=:enabledStatus and m.document.id=:documentId and m.prioritylevels=:priority "
			+ "  and m.reviewType=:reviewType and m.rejected !=:rejectedStatus AND m.changeControlNumber IS NULL AND m.documentUpdateTrack IS NULL")
	DocumentReviewAndApproveMapping findEnableAndReviewApproveMappingAndPriorityAndChangeControlIsNullAndDocumentUpdateTrackIsNull(
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("documentId") Long documentId,
			@Param("priority") String priority, @Param("reviewType") String reviewType,
			@Param("rejectedStatus") Boolean rejectedStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d where d.id=:documemtId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus AND m.enabledStatus=:enabledStatus "
			+ "AND m.changeControlNumber IS NULL AND m.documentUpdateTrack IS NULL")
	int getMappingCountByDocumentIdAndRejectStatusAndTypeAndChangeControlIsNullAndDocumentUpdateTrackIsNull(
			@Param("documemtId") Long documemtId, @Param("rejectStatus") Boolean rejectStatus,
			@Param("reviewApproveType") String reviewApproveType, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d JOIN m.changeControlNumber cc where d.id=:documemtId AND cc.id =:changeControlId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus AND m.enabledStatus=:enabledStatus")
	int getMappingCountByDocumentIdAndRejectStatusAndTypeAndChangeControl(@Param("documemtId") Long documemtId,
			@Param("changeControlId") Long changeControlId, @Param("rejectStatus") Boolean rejectStatus,
			@Param("reviewApproveType") String reviewApproveType, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d JOIN m.documentUpdateTrack cc where d.id=:documemtId AND cc.id =:documentUpdateTrackId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus AND m.enabledStatus=:enabledStatus")
	int getMappingCountByDocumentIdAndRejectStatusAndTypeAndDocumentUpdateTrack(@Param("documemtId") Long documemtId,
			@Param("documentUpdateTrackId") Long documentUpdateTrackId, @Param("rejectStatus") Boolean rejectStatus,
			@Param("reviewApproveType") String reviewApproveType, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d where d.id=:documemtId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus AND m.enabledStatus=:enabledStatus AND m.mappingStatus IN(:mappingStatus) "
			+ "AND m.changeControlNumber IS NULL AND m.documentUpdateTrack IS NULL")
	int getMappingCountByDocumentIdAndRejectStatusAndTypeAndMappingStatusAndChangeControlIsNullAndDocumentUpdateTrackIsNull(
			@Param("documemtId") Long documemtId, @Param("mappingStatus") CustomStatus mappingStatus,
			@Param("rejectStatus") Boolean rejectStatus, @Param("reviewApproveType") String reviewApproveType,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d JOIN m.changeControlNumber cc where d.id=:documemtId AND cc.id =:changeControlId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus AND m.mappingStatus IN(:mappingStatus) AND m.enabledStatus=:enabledStatus")
	int getMappingCountByDocumentIdAndRejectStatusAndTypeAndMappingStatusAndChangeControl(
			@Param("documemtId") Long documemtId, @Param("changeControlId") Long changeControlId,
			@Param("mappingStatus") CustomStatus mappingStatus, @Param("rejectStatus") Boolean rejectStatus,
			@Param("reviewApproveType") String reviewApproveType, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d JOIN m.documentUpdateTrack cc where d.id=:documemtId AND cc.id =:documentUpdateTrackId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus AND m.mappingStatus IN(:mappingStatus) AND m.enabledStatus=:enabledStatus")
	int getMappingCountByDocumentIdAndRejectStatusAndTypeAndMappingStatusAndDocumentUpdateTrack(
			@Param("documemtId") Long documemtId, @Param("documentUpdateTrackId") Long documentUpdateTrackId,
			@Param("mappingStatus") CustomStatus mappingStatus, @Param("rejectStatus") Boolean rejectStatus,
			@Param("reviewApproveType") String reviewApproveType, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d  where d.id=:documentId  "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus  AND m.enabledStatus=:enabledStatus")
	int findCountByStatusMappedAndReviewApproveType(@Param("documentId") Long documentId,
			@Param("reviewApproveType") String reviewApproveType, @Param("rejectStatus") Boolean rejectStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d JOIN m.changeControlNumber cc where d.id=:documentId  AND cc.id=:changeControlId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus  AND m.enabledStatus=:enabledStatus")
	int findCountByStatusMappedAndReviewApproveTypeAndChangeControl(@Param("documentId") Long documentId,
			@Param("changeControlId") Long changeControlId, @Param("reviewApproveType") String reviewApproveType,
			@Param("rejectStatus") Boolean rejectStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(m) from DocumentReviewAndApproveMapping m JOIN m.document d JOIN m.documentUpdateTrack cc where d.id=:documentId  AND cc.id=:documentUpdateTrackId "
			+ "and m.reviewType=:reviewApproveType and m.rejected=:rejectStatus  AND m.enabledStatus=:enabledStatus")
	int findCountByStatusMappedAndReviewApproveTypeAndUpdateTrack(@Param("documentId") Long documentId,
			@Param("documentUpdateTrackId") Long documentUpdateTrackId,
			@Param("reviewApproveType") String reviewApproveType, @Param("rejectStatus") Boolean rejectStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	/**
	 * get Approved count
	 * 
	 * @param id
	 * @param enabled
	 * @param string
	 * @param approved
	 * @return
	 */
//	@Query("select  count(m) from DocumentReviewAndApproveMapping m where m.document.id=?1 and m.enabledStatus=?2 and m.reviewType=?3 and m.mappingStatus=?4 and m.rejected!=?5")
//	int getCompletedMappingCount(long id, EnabledStatus enabledStatus, String string, CustomStatus status,
//			Boolean rejected);

	/**
	 * need to change method
	 */

	/**
	 * get Mapping details for Review based user session userid
	 */
	@Query("select m from DocumentReviewAndApproveMapping m where m.enabled=?1 and m.mappingStatus IN ?2 and m.user.id=?3 and m.reviewType=?4")
	Page<DocumentReviewAndApproveMapping> getDocumentsMappingDetailsForReview(Boolean enabled,
			List<CustomStatus> customstatuslist, long userid, String string, Pageable pageable);

	/**
	 * get Mapping details for Review/Approve based user on session user *
	 */
	@Query("select m from DocumentReviewAndApproveMapping m where m.enabled=?1 and m.mappingStatus IN ?2 and m.user.id=?3 and m.reviewType=?4")
	Page<DocumentReviewAndApproveMapping> getDocumentsMappingDetailsForRevieworApprove(Boolean enabled,
			List<CustomStatus> customstatuslist, long userid, String string, Pageable pageable);

	/**
	 * get Approve Mapping Count
	 * 
	 * @param id
	 * @param enabled
	 * @param string
	 * @return
	 */
//	@Query("select count(m) from DocumentReviewAndApproveMapping m  where m.document.id=?1 and m.enabled=?2 and m.reviewType=?3 and m.rejected!=?4")
//	int getMappingCount(long id, Boolean enabled, String string, Boolean rejected);

	/**
	 * 
	 * @param id
	 * @param type
	 * @param enabled
	 * @return
	 */
	@Query("select m from  DocumentReviewAndApproveMapping m where m.document.id=?1 and m.reviewType=?2 and m.enabled=?3")
	List<DocumentReviewAndApproveMapping> findReviewDetails(long id, String type, Boolean enabled);

	@Query("select m from DocumentReviewAndApproveMapping m join fetch m.document where m.id=?1")
	DocumentReviewAndApproveMapping findOneById(long id);

	@Query("select m from DocumentReviewAndApproveMapping m join fetch m.document where m.id=?1 and m.enabled=?2")
	DocumentReviewAndApproveMapping findOneByID(long id, Boolean enabled);

	// @Query("select count(distinct m) from DocumentReviewAndApproveMapping m left
	// join m.documents d left join d.branch b where m.user.id=?1 and b in ?2 and
	// m.enabled=?3 and m.reviewType=?4 and m.mappingStatus in ?5")

	@Query("select distinct m from DocumentReviewAndApproveMapping m where m.document.id=?1 and m.enabled=?2 and m.mappingStatus not in?3")
	List<DocumentReviewAndApproveMapping> findDocumentMappingDetailsForUpdate(long documentId, Boolean enabled,
			List<CustomStatus> customStatus);

	@Query("select distinct m from  DocumentReviewAndApproveMapping m where m.document.id=?1 and m.enabled=?2")
	List<DocumentReviewAndApproveMapping> findDocumentDetailsForRecall(long id, Boolean enabled);

	// @Query(value = "select distinct m from DocumentReviewAndApproveMapping m left
	// join m.document d where d.id=?1 and m.enabled=?2 and m.mappingStatus not in
	// ?3 and m.rejected not in ?4")
	// List<DocumentReviewAndApproveMapping> findDocumentBasedMappedList(long id,
	// Boolean enabled,
	// List<CustomStatus> mappingStatuslist, Boolean rejectedStatus);

	/**
	 * @author gobithasan.s
	 * @param documentId,userId Get Reviewed / Approved date By Document Reviewer
	 *        And Approver
	 * @return Date
	 */
	@Query("SELECT MAX(dram.modifiedDate) FROM  DocumentReviewAndApproveMapping dram "
			+ "WHERE dram.document.id=?1 AND dram.user.id=?2 AND dram.mappingStatus IN ('REVIEWED','APPROVED') "
			+ "and dram.enabled=true AND dram.rejected!=TRUE ORDER By id DESC")
	public Date getDocumentReviewedAndApprovedDateByDocumentIdAndUser(long documentId, long userid);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u   WHERE d.id=:documentId "
			+ "  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus ")
	public List<DocumentReviewAndApproveMapping> getAllDocumentReviewApproverByDocumentIdAndEnabledStatus(
			@Param("documentId") Long documentId, @Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u JOIN dram.changeControlNumber cc  WHERE d.id=:documentId AND "
			+ " cc.id =:changeControlId  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndChangeControl(
			@Param("documentId") Long documentId, @Param("changeControlId") Long changeControlId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u JOIN dram.documentUpdateTrack cc  WHERE d.id=:documentId AND "
			+ " cc.id =:documentUpdateTrackId  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndDocumentUpdateTrack(
			@Param("documentId") Long documentId, @Param("documentUpdateTrackId") Long documentUpdateTrackId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u   WHERE d.id=:documentId "
			+ "  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus "
			+ "AND dram.changeControlNumber IS NULL AND dram.documentUpdateTrack IS NULL")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndChangeControlIsNullAndDocumentUpdateTrackIsNull(
			@Param("documentId") Long documentId, @Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u   WHERE d.id=:documentId "
			+ "  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus "
			+ "AND dram.changeControlNumber IS NULL AND dram.documentUpdateTrack IS NULL AND  dram.rejected in(:rejected)")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndRejectStatusAndChangeControlIsNullAndDocumentUpdateTrackIsNull(
			@Param("documentId") Long documentId, @Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u JOIN dram.changeControlNumber cc  WHERE d.id=:documentId AND "
			+ " cc.id =:changeControlId  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus AND  dram.rejected in(:rejected)")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndRejectStatusAndChangeControl(
			@Param("documentId") Long documentId, @Param("changeControlId") Long changeControlId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u JOIN dram.documentUpdateTrack dt  WHERE d.id=:documentId AND "
			+ " dt.id =:documentTrackId  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus AND  dram.rejected in(:rejected)")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndRejectStatusAndDocumentUpdateTrack(
			@Param("documentId") Long documentId, @Param("documentTrackId") Long documentTrackId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u   WHERE d.id=:documentId "
			+ "  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus AND dram.documentUpdateTrack IS NULL AND  dram.rejected in(:rejected)")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndRejectStatusAndDocuemntUpdateTrackIsNull(
			@Param("documentId") Long documentId, @Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u   WHERE d.id=:documentId "
			+ "  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus "
			+ "AND dram.documentUpdateTrack IS NULL AND dram.changeControlNumber IS NULL AND  dram.rejected in(:rejected)")
	public List<DocumentReviewAndApproveMapping> findAllDocumentReviewApproverByDocumentIdAndEnabledStatusAndRejectStatusAndDocuemntUpdateTrackIsNullAndChangeControlIsNull(
			@Param("documentId") Long documentId, @Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT distinct u.emailId FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u JOIN dram.changeControlNumber cc  WHERE d.id=:documentId AND "
			+ " cc.id =:changeControlId  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus AND  dram.rejected in(:rejected)")
	public String[] findAllDocumentReviewApproverEmailIdsByDocumentIdAndEnabledStatusAndRejectStatusAndChangeControl(
			@Param("documentId") Long documentId, @Param("changeControlId") Long changeControlId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT distinct u.emailId FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u JOIN dram.documentUpdateTrack cc  WHERE d.id=:documentId AND "
			+ " cc.id =:documentUpdateTrackId  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus AND  dram.rejected in(:rejected)")
	public String[] findAllDocumentReviewApproverEmailIdsByDocumentIdAndEnabledStatusAndRejectStatusAndDocumentUpdateTrack(
			@Param("documentId") Long documentId, @Param("documentUpdateTrackId") Long documentUpdateTrackId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT distinct u.emailId FROM DocumentReviewAndApproveMapping dram JOIN dram.document d JOIN dram.user u   WHERE d.id=:documentId "
			+ "  AND dram.mappingStatus IN (:reviewApproveStatus)  AND dram.enabledStatus=:enabledStatus AND u.enabledStatus=:enabledStatus "
			+ "AND dram.changeControlNumber IS NULL AND dram.documentUpdateTrack IS NULL AND  dram.rejected in(:rejected)")
	public String[] findAllDocumentReviewApproverEamilIdsByDocumentIdAndEnabledStatusAndRejectStatusAndChangeControlIsNullAndDocumentUpdateTrackIsNull(
			@Param("documentId") Long documentId, @Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT dram FROM DocumentReviewAndApproveMapping dram JOIN dram.document d WHERE d.id=:documentId ")
	public List<DocumentReviewAndApproveMapping> finalAllReviewApproveMappingByDocumentId(
			@Param("documentId") Long documentId);

}
