package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentTemplateCategory;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface DocumentsTemplateCategoryRepo extends JpaRepository<DocumentTemplateCategory, Long> {

	// @Query("select dtc from DocumentTemplateCategory dtc order by
	// dtc.createdDate")
	// Page<DocumentTemplateCategory>
	// findAllDocumentTemplateCategorysOrderByCreatedDate(Pageable pageable);
	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(dtc.id,dtc.name) FROM DocumentTemplateCategory dtc WHERE dtc.enabledStatus =:enabledStatus ORDER BY dtc.name")
	public List<IdNameCodeDTO> findDocumentTemplateCategoryByEnabledStatus(
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select dtc from DocumentTemplateCategory dtc where dtc.enabledStatus=:enabledStatus ORDER BY dtc.name")
	List<DocumentTemplateCategory> findAllDocumentTemplateCategory(@Param("enabledStatus") EnabledStatus enabledStatus);

	/**
	 * need to change methods
	 */

	@Query("select dtc from DocumentTemplateCategory dtc where dtc.enabled=?1")
	Page<List<DocumentTemplateCategory>> getDocumentTemplateCategorysWithPageableData(Boolean enabled,
			Pageable pageable);

	@Query("select dtc from DocumentTemplateCategory dtc where dtc.enabled=?1 order by dtc.name")
	List<DocumentTemplateCategory> findAllByStatus(Boolean enabled);

	@Query("select  dtc from DocumentTemplateCategory dtc")
	Page<List<DocumentTemplateCategory>> findAllData(Pageable pageable);

	@Query("select dtc from DocumentTemplateCategory dtc where  LOWER(dtc.name)=LOWER(?1)")
	DocumentTemplateCategory findByTemplateCategory(String category);

	@Query(value = "select distinct dtc from DocumentTemplateCategory dtc left join dtc.createdBy where dtc.enabled=?1")
	List<DocumentTemplateCategory> findDocumentTemplateCategoryforUpdate(Boolean enabled);

}
