package com.anthem.persistence.repository.document;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.TemporalType;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Temporal;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.QMSDepartment;
import com.anthem.persistence.model.document.Document;
import com.anthem.persistence.model.document.DocumentTemplateCategory;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.training.DocumentChangeControlStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;
import com.anthem.web.service.document.dto.DocumentDTO;

public interface DocumentRepo extends JpaRepository<Document, Long> {

	@Query(value = "select d from Document d  left join fetch d.documentTemplate t join fetch  d.templateCategory tc left join fetch d.qmsDepartment qd "
			+ "where d.enabledStatus=:enabledStatus")
	public List<Document> findDocumetsforRecallData(@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select d from Document d where d.enabledStatus='OPEN' and d.id=:documentId")
	Document findById(@Param("documentId") Long id);

	@Query("select distinct d from Document d left join fetch d.documentTemplate t join fetch  d.templateCategory tc left join fetch"
			+ " d.qmsDepartment qd inner join d.branchs b  where  d.qmsDepartment.id=:qmsDepartmentId and d.enabledStatus=:enabledStatus "
			+ "and b in (:branchs) order by d.documentTitle")
	public List<Document> getDocumentsforDisplayByQMSDepartment(@Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("branchs") List<Branch> branchs);

	@Query(value = "SELECT d FROM Document d JOIN d.templateCategory tc JOIN d.qmsDepartment qd JOIN  d.branchs b WHERE  qd.id=:qmsDepartmentId "
			+ "AND b.id in (:branchIds) AND tc.id=:categoryId AND d.enabledStatus=:enabledStatus order by d.documentTitle")
	public List<Document> findDocumentByBrnachAndQmsDepartmentAndCategory(@Param("branchIds") List<Long> branchIds,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("categoryId") Long categoryId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	/**
	 * get document by user id for Modify
	 * 
	 * @param true1
	 * @param userid
	 * @return
	 */
	@Query("select distinct d from Document d left join fetch d.templateCategory tc left join d.documentTemplate t  join  d.branchs b  "
			+ "join d.qmsDepartment JOIN d.documentOwners do where do.user.id IN(:userId) and d.customStatus not in (:approved) and  b in (:branchs) "
			+ "AND d.documentChangeControlStatus IN('NA') AND d.documentUpdateStatus IN('NA') AND d.enabledStatus=:enabledStatus")
	public List<Document> findDocumentsforModifyByUserId(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("approved") CustomStatus approved, @Param("userId") Long userId,
			@Param("branchs") List<Branch> branchs);

	@Query("select d from Document d JOIN d.qmsDepartment qms where qms.id=:qmsDepartmentId and d.enabledStatus=:enabledStatus order by d.documentTitle")
	public List<Document> getQMSDepartmentBasedDocumentsforBasicView(@Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select d from Document d left join fetch d.templateCategory tc left join fetch d.documentTemplate t left join fetch d.branchs b "
			+ "where d.id=:documentId and  d.enabledStatus=:enabledStatus")
	public Document findDocumentByIdforDisplay(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select d from Document d left join fetch d.templateCategory tc left join fetch d.documentTemplate t left join fetch d.branchs b "
			+ "where d.id=:documentId and  d.enabledStatus=:enabledStatus")
	public Document findDocumentforRecallStore(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select d from Document d where d.customStatus=:approvedStatus and d.trainingMappedStatus=:mappedStatus and d.templateCategory.id=:templateCategoryId"
			+ " and d.qmsDepartment.id=:qmsDepartmentId AND d.enabledStatus=:enabledStatus order by d.documentTitle")
	public List<Document> getApprovedNonMappedDocument(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("approvedStatus") CustomStatus approvedStatus, @Param("mappedStatus") CustomStatus mappedStatus,
			@Param("templateCategoryId") Long templateCategoryId, @Param("qmsDepartmentId") Long qmsDepartmentId);

	/**
	 * @author gobithasan.s
	 * @param documentId Get Document Owner
	 * @return User
	 */
	@Query("SELECT u.id FROM  Document d JOIN d.createdBy u WHERE d.id=:documentId and d.enabledStatus=:enabledStatus")
	public Long getDocumentCreatedUserId(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT u FROM  Document d JOIN d.createdBy u WHERE d.id=:documentId and d.enabledStatus=:enabledStatus")
	public User getDocumentCreatedUser(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	/**
	 * for getting document User not mapped with qms department
	 * 
	 * @param true1
	 * @param approved
	 * @param loginId
	 * @return
	 */
	@Query("select d from Document d  join fetch d.qmsDepartment qd JOIN  d.documentOwners do "
			+ "where d.enabledStatus=:enabledStatus and d.customStatus  in (:customStatus) and d.processIn not IN(:processIn) and  do.user.id IN(:createdBy)")
	List<Document> findDocumentforReviewMappingwithoutPagination(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("customStatus") List<CustomStatus> customStatus, @Param("createdBy") Long createdBy,
			@Param("processIn") List<CustomStatus> processIn);

	@Query(value = "SELECT new com.anthem.web.service.document.dto.DocumentDTO(d.id,d.documentTitle,d.documentCode,d.currentVersionNo) FROM Document d JOIN d.branchs b "
			+ " JOIN d.templateCategory tc WHERE b.id=:branchId  AND"
			+ " tc.name =:documentCategoryName AND d.effectiveDate<=:effectiveDate AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public List<DocumentDTO> findApprovedDocumentByDepartmentAndBranchAndEffectiveDateAndDocumentCategoryName(
			@Param("branchId") long branchId, @Param("documentCategoryName") String documentCategoryName,
			@Param("effectiveDate") Date effectiveDate, @Param("customStatus") CustomStatus customStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE b.id IN (:branchId) "
			+ "AND dep.id=:qmsDepartmentId AND tc.id=:templateCategoryId AND d.customStatus='APPROVED'")
	public List<Document> findDepartmentApprovedDocumentByQmsDepartmentIdAndbranchIdAndDocumentCategoryID(
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("branchId") Long branchId,
			@Param("templateCategoryId") Long templateCategoryId);

	@Query("SELECT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE d.id NOT IN(:documentIds) AND b.id IN (:branchId) "
			+ "AND dep.id=:qmsDepartmentId AND tc.id=:templateCategoryId AND d.customStatus='APPROVED'")
	public List<Document> findDepartmentApprovedDocumentByQmsDepartmentIdAndbranchIdAndDocumentCategoryIDAndNotInDocument(
			@Param("documentIds") List<Long> documentIds, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("branchId") Long branchId, @Param("templateCategoryId") Long templateCategoryId);

	@Query("SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.name) FROM Document d JOIN d.branchs b JOIN d.qmsDepartment q  "
			+ "WHERE b.id IN (:branchId) AND d.customStatus='APPROVED' AND d.effectiveDate <=:effectiveDate ANd d.enabledStatus=:enabledStatus")
	public Set<IdNameCodeDTO> getApprovedDocumentQMSDepartments(@Param("branchId") Long branchId,
			@Param("effectiveDate") Date effectiveDate, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select d from Document d left join fetch d.documentTemplate t join fetch  d.templateCategory tc left join fetch d.branchs b left join fetch d.qmsDepartment qd "
			+ "left join fetch d.createdBy where d.fileId=:fileId and d.enabledStatus=:enabledStatus")
	public Document findDocumentByFileId(@Param("fileId") String fileId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select DISTINCT d from Document d join fetch d.qmsDepartment qd JOIN d.documentOwners do"
			+ " where d.enabledStatus=:enabledStatus and d.customStatus in (:customStatus) and d.processIn NOT IN(:processIn) "
			+ "and (d.qmsDepartment.id IN(:qmsDepartmentIds) or do.user.id IN(:createdBy))")
	List<Document> findDocumentforReviewMappingwithoutPagination(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("customStatus") List<CustomStatus> customStatus,
			@Param("qmsDepartmentIds") List<Long> qmsDepartmentIds, @Param("createdBy") Long createdBy,
			@Param("processIn") List<CustomStatus> processIn);

	@Query(value = "SELECT new  com.anthem.web.service.document.dto.DocumentDTO(d.id,d.documentTitle,d.documentCode,d.currentVersionNo) FROM Document d "
			+ "JOIN d.branchs b WHERE b.id=:branchId AND d.qmsDepartment.id =:qmsDepartmentId AND "
			+ "d.customStatus =:approved AND d.enabledStatus=:enabledStatus AND d IN (SELECT dsub FROM DocumentMapping dm JOIN dm.document dsub WHERE dsub = d AND  dm.enabled = true )")
	List<DocumentDTO> findApprovedDocumentByDepartmentAndBranch(@Param("branchId") long branchId,
			@Param("qmsDepartmentId") long qmsDepartmentId, @Param("approved") CustomStatus approved,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select d from Document d where d.enabledStatus=:enabledStatus and d.customStatus=:approved order by d.documentTitle")
	List<Document> getApprovedDocumentsForBasicView(@Param("approved") CustomStatus approved,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select new  com.anthem.web.service.document.dto.DocumentDTO(d.id,d.documentTitle,d.documentCode,d.currentVersionNo) from Document d JOIN d.templateCategory tc where d.id NOT IN(:documentIds) AND d.customStatus=:customStatus and tc.id=:templateCategoryId "
			+ "and d.qmsDepartment.id=:qmsDepartmentId AND d.enabledStatus=:enabledStatus order by d.documentTitle")
	List<DocumentDTO> getDepartmentCategoryCustomStatusBasedDocumentsAndDocumentIdNotIn(
			@Param("customStatus") CustomStatus customStatus, @Param("templateCategoryId") long templateCategoryId,
			@Param("qmsDepartmentId") long qmsDepartmentId, @Param("documentIds") List<Long> documentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select new  com.anthem.web.service.document.dto.DocumentDTO(d.id,d.documentTitle,d.documentCode,d.currentVersionNo) from Document d JOIN d.templateCategory tc where  d.customStatus=:customStatus and tc.id=:templateCategoryId "
			+ "and d.qmsDepartment.id=:qmsDepartmentId AND d.enabledStatus=:enabledStatus order by d.documentTitle")
	List<DocumentDTO> getDepartmentCategoryCustomStatusBasedDocuments(@Param("customStatus") CustomStatus customStatus,
			@Param("templateCategoryId") long templateCategoryId, @Param("qmsDepartmentId") long qmsDepartmentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE b.id IN (:branchId) "
			+ "AND dep.id=:qmsDepartmentId AND tc.id=:templateCategoryId AND d.enabledStatus=:enabledStatus")
	public List<Document> findDocumentByQmsDepartmentIdAndbranchIdAndDocumentCategoryId(
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("branchId") Long branchId,
			@Param("templateCategoryId") Long templateCategoryId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE b.id IN (:branchId) AND "
			+ "tc.id=:categoryId AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public List<Document> findDocumentByBrnachIdAndCategoryId(@Param("branchId") Long branchId,
			@Param("categoryId") Long categoryId, @Param("customStatus") CustomStatus customStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE b.id IN (:branchIds) AND "
			+ "tc.id=:categoryId AND dep.id=:qmsDepartmentId AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public List<Document> findApprovedDocumentByBranchsAndCategoryAndQmsDepartment(
			@Param("branchIds") List<Long> branchIds, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("categoryId") Long categoryId, @Param("customStatus") CustomStatus customStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE d.id NOT IN(:documentIds) AND b.id IN (:branchIds) AND "
			+ "tc.id=:categoryId AND dep.id=:qmsDepartmentId AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public List<Document> findApprovedDocumentByBranchsAndCategoryAndQmsDepartmentAndDocumentIdsNotIn(
			@Param("branchIds") List<Long> branchIds, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("categoryId") Long categoryId, @Param("customStatus") CustomStatus customStatus,
			@Param("documentIds") List<Long> documentIds, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT d FROM Document d JOIN d.branchs b  JOIN d.templateCategory tc WHERE b.id IN (:branchIds) AND "
			+ "tc.id=:categoryId AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public List<Document> findApprovedDocumentByBranchsAndCategory(@Param("branchIds") List<Long> branchIds,
			@Param("categoryId") Long categoryId, @Param("customStatus") CustomStatus customStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select distinct d from Document d join  d.templateCategory tc left join  d.documentTemplate t  left join  d.branchs b  join  d.qmsDepartment "
			+ "where d.id = :documentId AND d.enabledStatus=:enabledStatus )")
	public Document findDocumentforUpdateByDocumentId(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT d FROM Document d JOIN d.documentOwners dos JOIN dos.user u WHERE d.id IN(:documentIds) AND u.id IN(:userId) "
			+ "AND  d.customStatus=:customStatus AND d.processIn IN(:processIn) AND d.enabledStatus=:enabledStatus")
	public Set<Document> findApprovedDocumentsForDocumentUpdate(@Param("customStatus") CustomStatus customStatus,
			@Param("processIn") CustomStatus processIn, @Param("documentIds") Set<Long> documentIds,
			@Param("userId") Long userId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT d FROM Document d JOIN d.documentOwners dos JOIN dos.user u WHERE d.id IN(:documentIds) AND d.processIn NOT IN(:processIn) "
			+ "AND u.id IN(:userId) AND d.documentUpdateStatus=:documentUpdateStatus AND d.enabledStatus=:enabledStatus")
	public Set<Document> findDocumentUpdateInitialtedForDocumentUpdate(@Param("processIn") List<CustomStatus> processIn,
			@Param("documentUpdateStatus") DocumentChangeControlStatus documentUpdateStatus,
			@Param("documentIds") Set<Long> documentIds, @Param("userId") Long userId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d JOIN d.templateCategory tc JOIN d.qmsDepartment qd JOIN  d.branchs b JOIN d.documentOwners do JOIN do.user u WHERE  qd.id=:qmsDepartmentId "
			+ "AND b.id in (:branchId) AND u.id IN(:userId)  AND tc.id=:categoryId AND d.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByBranchAndQmsDepartmentAndCategoryAndOwner(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("categoryId") Long categoryId,
			@Param("userId") Long userId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d JOIN  d.branchs b JOIN d.documentOwners do JOIN do.user u WHERE b.id in (:branchId) AND u.id IN(:userId) "
			+ "AND d.enabledStatus=:enabledStatus ")
	public Set<Long> findDocumentIdByBranch(@Param("branchId") Long branchId, @Param("userId") Long userId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d  JOIN d.qmsDepartment qd JOIN  d.branchs b JOIN d.documentOwners do JOIN do.user u WHERE  qd.id=:qmsDepartmentId "
			+ "AND b.id in (:branchId) AND u.id IN(:userId)  AND d.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByBranchAndQmsDepartmentAndOwner(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("userId") Long userId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d JOIN d.templateCategory tc JOIN d.qmsDepartment qd JOIN  d.branchs b JOIN d.documentOwners do JOIN do.user u WHERE "
			+ " b.id in (:branchId) AND u.id IN(:userId)  AND tc.id=:categoryId AND d.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByBranchAndCategoryAndOwner(@Param("branchId") Long branchId,
			@Param("categoryId") Long categoryId, @Param("userId") Long userId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE  b.id IN (:branchId) AND "
			+ "tc.id=:categoryId AND dep.id=:qmsDepartmentId AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public Set<Document> findDocumentByBrnachIdAndCategoryIdForChangeControl(@Param("branchId") Long branchId,
			@Param("categoryId") Long categoryId, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("customStatus") CustomStatus customStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d FROM Document d JOIN d.branchs b JOIN d.qmsDepartment dep JOIN d.templateCategory tc WHERE d.id NOT IN(:documentIds) AND b.id IN (:branchId) AND "
			+ "tc.id=:categoryId AND dep.id=:qmsDepartmentId AND d.customStatus=:customStatus AND d.enabledStatus=:enabledStatus")
	public Set<Document> findDocumentByBrnachIdAndCategoryIdAndDocumentIdNotInForChangeControl(
			@Param("branchId") Long branchId, @Param("categoryId") Long categoryId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("documentIds") Set<Long> documentIds,
			@Param("customStatus") CustomStatus customStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d  JOIN d.qmsDepartment qd JOIN  d.branchs b   WHERE  qd.id=:qmsDepartmentId "
			+ "AND b.id in (:branchId)   AND d.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByBranchAndQmsDepartment(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d JOIN d.templateCategory tc JOIN d.qmsDepartment qd JOIN  d.branchs b  WHERE  qd.id=:qmsDepartmentId "
			+ "AND b.id in (:branchId)   AND tc.id=:categoryId AND d.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByBranchAndQmsDepartmentAndCategory(@Param("branchId") Long branchId,
			@Param("qmsDepartmentId") Long qmsDepartmentId, @Param("categoryId") Long categoryId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM Document d JOIN d.templateCategory tc JOIN d.qmsDepartment qd JOIN  d.branchs b  WHERE "
			+ " b.id in (:branchId)  AND tc.id=:categoryId AND d.enabledStatus=:enabledStatus")
	public Set<Long> findDocumentIdByBranchAndCategory(@Param("branchId") Long branchId,
			@Param("categoryId") Long categoryId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT d FROM Document d JOIN d.templateCategory tc JOIN d.qmsDepartment qd JOIN  d.branchs b JOIN d.documentOwners do JOIN do.user u WHERE  qd.id=:qmsDepartmentId "
			+ "AND b.id in (:branchId) AND u.id IN(:userId) AND d.customStatus=:customStatus  AND tc.id=:categoryId AND d.enabledStatus=:enabledStatus")
	public List<Document> findApprovedDocumentByBranchAndQmsDepartmentAndCategoryAndOwner(
			@Param("branchId") Long branchId, @Param("qmsDepartmentId") Long qmsDepartmentId,
			@Param("categoryId") Long categoryId, @Param("userId") Long userId,
			@Param("customStatus") CustomStatus customStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT COUNT(d) FROM Document d where d.documentCode=:documentCode AND d.id!=:documentId AND d.enabledStatus=:enabledStatus")
	public int checkDocumentCodeDuplicateByDocumentCodeAndNotInDocumentId(@Param("documentCode") String documentCode,
			@Param("documentId") Long documentId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT COUNT(d) FROM Document d where d.documentCode=:documentCode AND d.enabledStatus=:enabledStatus")
	public int checkDocumentCodeDuplicateByDocumentCode(@Param("documentCode") String documentCode,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	/**
	 * need to change methods
	 */

	@Transactional
	@Modifying
	@Query("update Document d set d.documentVersionFileName=?1,d.currentVersionNo=?2,d.versionDocumentnoOfPage=?3 where d.id = ?4")
	void updateDocumentVersionNoAndfileName(String documentVersionFileName, String currentVersionNo, String noOfPages,
			long id);

	/**
	 * 
	 * @param pageRequest
	 * @return
	 */
	// @Query("select d from Document d where d.nextEffectiveDate <
	// CURRENT_TIMESTAMP")
	@Query(value = "select d from Document d join fetch d.documentTemplate t join fetch  d.templateCategory tc ", countQuery = "select count(d) from Document d")
	Page<Document> findDocumetsforRecall(Pageable pageable);

	// @Query(value = "select d from Document d left join fetch d.templates t join
	// fetch d.templateCategory tc left join fetch d.qmsDepartment qd where
	// d.customStatus=?1 and d.enabled=?2")
	// List<Document> findDocumetsforRecallData(CustomStatus status, Boolean
	// enabled);

	@Query("select d from Document d where d.enabled=?1")
	Page<Document> getDocumentsList(Boolean true1, Pageable pageable);

	/**
	 * get Documents for basic view id and document title
	 * 
	 * @param true1
	 * @return
	 */
	@Query("select d from Document d where d.enabled=?1 order by d.documentTitle")
	List<Document> getDocumentsForBasicView(Boolean true1);

	/**
	 * get documents for display by its qmsdepartments
	 * 
	 * @param id
	 * @param true1
	 * @param pageable
	 * @return
	 */
	@Query("select d from Document d where d.qmsDepartment.id=?1 and d.enabled=?2 order by d.documentTitle")
	Page<Document> getDocumentsforDisplayByQMSDepartment(long id, Boolean true1, Pageable pageable);

	/**
	 * get Documents for basic view id and document title (Approved Documents Only)
	 * 
	 * @param true1
	 * @param approved
	 */

	public Document findByDocumentFileName(String documentFileName);

	/**
	 * for getting documents user mapped with qms department
	 * 
	 * @param enabled
	 * @param approved
	 * @param branchlist
	 * @param id
	 * @param deptcode
	 * @return
	 */

	@Query("select d from Document d where d.enabled=?1 and d.templateCategory.id=?2 and d.qmsDepartment.id=?3 order by d.documentTitle")
	List<Document> getDeptCatBasedDocuments(Boolean status, long category, long department);

	@Query("select d from Document d join fetch d.templateCategory tc left join fetch d.documentTemplate t where d.enabled=true and d.id in ?1")
	List<Document> findDocumentsByList(List<Long> documentlist);

	@Query("select d from Document d  left join fetch d.templateCategory tc left join fetch d.documentTemplate t left join fetch d.qmsDepartment qd where d.templateCategory.id=?1 and d.enabled=?2 and d.customStatus in ?3")
	List<Document> findDocumentByCategoryforTrainingScheduler(long docCategoryId, Boolean enabled,
			CustomStatus documentstatus);

	@Query(value = "select d from Document d  left join fetch d.templateCategory tc left join fetch d.documentTemplate t left join fetch d.qmsDepartment qd join d.createdBy c where (Date(d.nextEffectiveDate)=?1 or Date(d.nextEffectiveDate)=Date(?2) or Date(d.nextEffectiveDate)=Date(?3) or Date(d.nextEffectiveDate)=Date(?4)) and d.enabled=?5 and c.id=?6 ")
	List<Document> findDocumentforsendAlertforNextEffectiveDate(@Temporal(TemporalType.DATE) Date date,
			@Temporal(TemporalType.DATE) Date sevendays, @Temporal(TemporalType.DATE) Date fiftendays,
			@Temporal(TemporalType.DATE) Date thirtydays, Boolean status, long userid);

	@Query(value = "select d.createdBy from Document d where Date(d.nextEffectiveDate)=?1 or Date(d.nextEffectiveDate)=Date(?2) or Date(d.nextEffectiveDate)=Date(?3) or Date(d.nextEffectiveDate)=Date(?4) and d.enabled=?5 group by d.createdBy")
	List<User> findDocumentforsendAlertforNextEffectiveDateGroupByUsers(Date date, Date time, Date time2, Date time3,
			Boolean status);

	@Query("select d from Document d where  d.enabled=?1 and d.documentTitle=?2")
	Document findDuplicateDocument(Boolean enabled, String documentTitle);

	@Query(value = "SELECT DISTINCT qms FROM Document d JOIN d.qmsDepartment qms JOIN d.branchs b WHERE b.id = ?1 AND d.customStatus = ?2 AND d.enabled=true AND "
			+ "d IN (SELECT dm.document FROM DocumentMapping dm WHERE dm.enabled = true )")
	public List<QMSDepartment> findDocDepartmentByBranch(long branch, CustomStatus customStatus);

	@Query(value = "SELECT DISTINCT tc FROM Document d join  d.templateCategory tc JOIN d.branchs b WHERE b.id=?1 AND d.qmsDepartment.id = ?2 AND "
			+ "d.customStatus = ?3 AND d.enabled=true AND d IN (SELECT dsub FROM DocumentMapping dm JOIN dm.document dsub WHERE dsub = d AND dm.enabled = true ) ")
	public List<DocumentTemplateCategory> findDocTemplateCategoryByDeprtmentIdANDBranch(long branch,
			long qmsDepartemntId, CustomStatus customStatus);

	@Query(value = "SELECT  d FROM Document d JOIN d.branchs b WHERE b.id=?1 AND d.qmsDepartment.id = ?2 AND d.templateCategory.id = ?3 AND "
			+ "d.customStatus = ?4 AND d.enabled=true AND d IN (SELECT dsub FROM DocumentMapping dm JOIN dm.document dsub WHERE dsub = d AND  dm.enabled = true )")
	public List<Document> findApprovedDocumentByDepartmentBranchAndCategory(long branchId, long qmsDepartmentId,
			long categoryId, CustomStatus status);

	/**
	 * @author gobithasan.s
	 * @param documentId Get Document ById
	 * @return Document
	 */
	@Query("SELECT d FROM  Document d JOIN FETCH d.branchs WHERE d.id=?1 and d.enabled=true")
	public Document getDocumentById(long documentId);

	@Query("select d from Document d where d.enabled=?1 and d.customStatus=?2 and d.trainingMappedStatus=?3 and d.templateCategory.id=?4 and d.qmsDepartment.id=?5 order by d.documentTitle")
	List<Document> getApprovedTrainingMappedDocument(Boolean true1, CustomStatus approved, CustomStatus mapped,
			long categoryId, long departmentId);

}
