/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.anthem.persistence.model.document.DocumentTemplateVersionTrack;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentTemplateVersionTrackRepo extends JpaRepository<DocumentTemplateVersionTrack, Long> {

	@Query("select count(dtvt) from DocumentTemplateVersionTrack dtvt where dtvt.documentTemplate.id=?1 and dtvt.enabled=?2")
	long findLastVersion(long id, Boolean enabled);
	
	@Query(value="select tv from DocumentTemplateVersionTrack tv  left join fetch tv.createdBy  where tv.enabled=true and tv.documentTemplate.id=?1 order by tv.createdDate ASC")
	List<DocumentTemplateVersionTrack> findVersionListByDocumentTemplateId(long id);

}
