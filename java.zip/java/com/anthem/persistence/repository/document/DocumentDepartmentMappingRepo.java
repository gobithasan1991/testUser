package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentDepartmentMapping;
import com.anthem.util.common.EnabledStatus;

public interface DocumentDepartmentMappingRepo extends JpaRepository<DocumentDepartmentMapping, Long> {

	@Query(value = "SELECT q.id FROM DocumentDepartmentMapping ddm JOIN ddm.qmsDepartment q JOIN ddm.documentMapping dm  "
			+ "WHERE q.id IN(:qmsDepartmentIds) AND dm.id =:documentMappingId AND ddm.enabledStatus=:enabledStatus")
	public List<Long> findQmsdepartmentinDocumentMappingByQmsDepartmentAndDocument(
			@Param("qmsDepartmentIds") List<Long> qmsDepartmentIds, @Param("documentMappingId") Long documentMappingId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

}
