package com.anthem.persistence.repository.document;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.persistence.model.document.DocumentCompanyMapping;

public interface DocumentCompanyMappingRepo extends JpaRepository<DocumentCompanyMapping, Long> {

}
