/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentTemplate;
import com.anthem.persistence.model.document.DocumentTemplateReviewAndApproveMapping;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentTemplateReviewAndApproveMappingRepo
		extends JpaRepository<DocumentTemplateReviewAndApproveMapping, Long> {
	@Query(value = "SELECT ra FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt WHERE dt.id=:documentTemplateId AND ra.enabledStatus=:enabledStatus")
	public List<DocumentTemplateReviewAndApproveMapping> findAllMappingByDocumentTemplateIdANDEnabledStatus(
			@Param("documentTemplateId") Long documentTemplateId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT DISTINCT ra FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt JOIN ra.user u LEFT JOIN dt.branch b "
			+ "WHERE ra.user.id=:userId AND ra.enabledStatus=:enabledStatus AND b.id IN (:branchIds) AND ra.mappingStatus IN (:mappingStatus) AND dt.processIn IN (:processIn)")
	public List<DocumentTemplateReviewAndApproveMapping> getDocumentTemplateReviewAndApproveMappingByUserIdAndEnabledStatusAndBranchIdINAndMappingStatus(
			@Param("userId") Long userId, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("branchIds") List<Long> branchIds, @Param("mappingStatus") List<CustomStatus> mappingStatus,
			@Param("processIn") List<CustomStatus> processIn);

	@Query(value = "SELECT DISTINCT  ra FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt WHERE dt.id=:documentTemplateId AND ra.enabledStatus=:enabledStatus AND ra.mappingStatus NOT IN :mappingStatus AND ra.rejected NOT IN :rejectedStatus")
	public List<DocumentTemplateReviewAndApproveMapping> findDocumentTemplateReviewAndApproveMappingByDocumentTemplateIdAndEnabledStatusAndMappingStatusAndRejectedStatus(
			@Param("documentTemplateId") Long documentTemplateId, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("mappingStatus") List<CustomStatus> mappingStatus, @Param("rejectedStatus") Boolean rejectedStatus);

	@Query("SELECT COUNT(ra) FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt WHERE dt.id=:documentTemplateId AND ra.enabledStatus=:enabledStatus AND dt.enabledStatus=:enabledStatus AND ra.reviewType=:reviewType AND ra.rejected!=:rejected")
	public int getDocumentTemplateReviewAndApproveMappingCountByDocumentTemplateIdAndEnabledStatusAndReviewTypeAndRejectedStatus(
			@Param("documentTemplateId") Long documentTemplateId, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("reviewType") String reviewType, @Param("rejected") Boolean rejected);

	@Query("SELECT COUNT(ra) FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt WHERE dt.id=:documentTemplateId AND ra.enabledStatus=:enabledStatus AND dt.enabledStatus=:enabledStatus AND ra.reviewType=:reviewType AND ra.rejected!=:rejected AND ra.mappingStatus=:mappingStatus")
	public int getDocumentTemplateReviewAndApproveMappingCountByDocumentTemplateIdAndEnabledStatusAndReviewTypeAndMappingStatusAndRejectedStatus(
			@Param("documentTemplateId") Long documentTemplateId, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("reviewType") String string, @Param("mappingStatus") CustomStatus mappingStatus,
			@Param("rejected") Boolean rejected);

	@Query(value = "SELECT DISTINCT ra FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt  JOIN dt.branch b WHERE dt.id=:documentTemplateId AND ra.enabledStatus=:enabledStatus AND b.id in :branchIds AND ra.mappingStatus NOT IN :mappingStatus")
	public List<DocumentTemplateReviewAndApproveMapping> getDocumentTemplatesReviewOrApproveDataforUpdateByDocumentTemplateIdAndEnabledStatusAndBranchIdsAndMappingStatus(
			@Param("documentTemplateId") Long documentTemplateId, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("branchIds") List<Long> branchIds, @Param("mappingStatus") List<CustomStatus> mappingStatus);

	@Query(value = "SELECT DISTINCT ra FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt WHERE dt.id=:documentTemplateId AND ra.mappingStatus NOT IN (:mappingStatus) AND ra.rejected NOT IN :rejectedStatus AND ra.enabledStatus=:enabledStatus")
	public List<DocumentTemplateReviewAndApproveMapping> findDocumentTemplateByDocumentTemplateIdAndMappingStatusAndRejectedStatusAndEnabledStatus(
			@Param("documentTemplateId") Long documentTemplateId,
			@Param("mappingStatus") List<CustomStatus> mappingStatus, @Param("rejectedStatus") Boolean rejectedStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT DISTINCT m FROM DocumentTemplateReviewAndApproveMapping m JOIN m.documentTemplate dt WHERE dt.id=:documentTemplateId AND m.mappingStatus=:mappingStatus AND m.enabledStatus=:enabledStatus")
	public List<DocumentTemplateReviewAndApproveMapping> findDocumentTemplateReviewAndApproveMappingsByDocumentTemplateIdAndMappingStatusAndEnabledStatus(
			@Param("documentTemplateId") Long documentTemplateId, @Param("mappingStatus") CustomStatus mappingStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT ra FROM DocumentTemplateReviewAndApproveMapping ra JOIN ra.documentTemplate dt WHERE ra.id=:id AND ra.enabledStatus=:enabledStatus")
	public DocumentTemplateReviewAndApproveMapping findDocumentTemplateReviewAndApproveMappingByIDANDEnabledStatus(
			@Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);

	DocumentTemplateReviewAndApproveMapping findByEnabledTrueAndDocumentTemplateAndUserAndReviewTypeAndRejected(
			DocumentTemplate documentTemplate, User user, String reviewType, Boolean rejectedStatus);

	@Query("SELECT dram FROM DocumentTemplateReviewAndApproveMapping dram JOIN dram.documentTemplate d JOIN dram.user u  "
			+ " WHERE d.id=:documentTemplateId AND dram.mappingStatus IN (:reviewApproveStatus) AND dram.enabledStatus=:enabledStatus "
			+ "AND u.enabledStatus=:enabledStatus AND  dram.rejected in(:rejected)")
	public List<DocumentTemplateReviewAndApproveMapping> findDocumentTemplateReviewAndApproverByIdAndReviewApproveStatusAndRejectStatus(
			@Param("documentTemplateId") Long documentTemplateId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

	@Query("SELECT DISTINCT u.emailId FROM DocumentTemplateReviewAndApproveMapping dram JOIN dram.documentTemplate d JOIN dram.user u  "
			+ " WHERE d.id=:documentTemplateId AND dram.mappingStatus IN (:reviewApproveStatus) AND dram.enabledStatus=:enabledStatus "
			+ "AND u.enabledStatus=:enabledStatus AND  dram.rejected in(:rejected)")
	public String[] findDocumentTemplateReviewAndApproverEmailIdsByIdAndReviewApproveStatusAndRejectStatus(
			@Param("documentTemplateId") Long documentTemplateId,
			@Param("reviewApproveStatus") List<CustomStatus> reviewApproveStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("rejected") Boolean rejected);

}
