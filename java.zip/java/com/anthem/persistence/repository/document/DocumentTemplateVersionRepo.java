/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.List;


import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentTemplateVersion;
import com.anthem.util.common.EnabledStatus;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentTemplateVersionRepo extends JpaRepository<DocumentTemplateVersion, Long> {

	@Query(value="SELECT dtv FROM DocumentTemplateVersion dtv JOIn dtv.documentTemplate dt WHERE dt.id=:documentTemplateId AND dtv.enabledStatus=:enabledStatus")
	public List<DocumentTemplateVersion> findDocumentTemplateVersionsbyDocumentTemplateIdAndEnabledStatus(@Param("documentTemplateId") Long documentTemplateId,@Param("enabledStatus") EnabledStatus enabledStatus);
	
	
	
	
	@Query(value = "select tv from DocumentTemplateVersion tv where tv.documentTemplate.id=?1 and tv.enabledStatus=?2 order by tv.createdDate DESC")
	List<DocumentTemplateVersion> findLastVersionofDocumentTemplate(long id, EnabledStatus enabledStatus, Pageable pageable);

	@Query(value="select tv from DocumentTemplateVersion tv  left join fetch tv.createdBy  where tv.enabledStatus='OPEN' and tv.documentTemplate.id=?1 order by tv.createdDate ASC")
	List<DocumentTemplateVersion> findVersionListByDocumentTemplateId(long id);


	@Query(value="select tv from DocumentTemplateVersion tv left join fetch tv.documentTemplate left join fetch tv.createdBy c where tv.versionUUID=?1")
	public DocumentTemplateVersion findDocumentTemplateVersionByVersionUUID(String versionUUID);

}
