package com.anthem.persistence.repository.document;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentIndividualMapping;
import com.anthem.util.common.EnabledStatus;

public interface DocumentIndividualMappingRepo extends JpaRepository<DocumentIndividualMapping, Long> {
	/**
	 * @author gobithasan.s
	 * @param enabled,DocumentMappingId Get DocumentIndividualMapping For That
	 *        Document Mapping
	 * @return List<DocumentIndividualMapping>
	 */
	@Query("SELECT DISTINCT dim FROM DocumentIndividualMapping dim JOIN dim.documentMapping dm JOIN dim.user usr WHERE dm.id=:documentMappingId AND usr.id IN (:userIds) AND dim.enabledStatus=:enabledStatus")
	public List<DocumentIndividualMapping> documentIndividualMappingsByDocumentMappingIdAndUserIdsAndEnabledStatus(
			@Param("documentMappingId") Long documentMappingId, @Param("userIds") List<Long> userIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT q.id FROM DocumentIndividualMapping ddm JOIN ddm.user u JOIN  u.qmsDepartments q JOIN u.branches b  JOIN ddm.documentMapping dm  "
			+ "WHERE q.id IN(:qmsDepartmentIds) AND dm.id =:documentMappingId ANd b.id IN(:branchIds) AND ddm.enabledStatus=:enabledStatus")
	public Set<String> findUserEmailIdInDocumentMappingByQmsDepartmentAndDocument(
			@Param("qmsDepartmentIds") List<Long> qmsDepartmentIds, @Param("branchIds") List<Long> branchIds,
			@Param("documentMappingId") Long documentMappingId, @Param("enabledStatus") EnabledStatus enabledStatus);

}
