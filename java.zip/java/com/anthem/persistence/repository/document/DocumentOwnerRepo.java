package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentOwner;
import com.anthem.util.common.EnabledStatus;

public interface DocumentOwnerRepo extends JpaRepository<DocumentOwner, Long> {

	@Query(value = "SELECT u.emailId FROM DocumentOwner do JOIN do.user u JOIN do.document d WHERE d.id=:documentId "
			+ "AND d.enabledStatus =:enabledStatus AND u.enabledStatus =:enabledStatus AND u.emailId IS NOT NULL")
	public String[] findDocumentOwnerMailIdsByDocumentId(@Param("documentId") Long documentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT CASE WHEN COUNT(do.id) > 0 THEN true ELSE false END FROM DocumentOwner do JOIN do.document d JOIN do.user u "
			+ " WHERE d.id=:documentId AND u.id=:usedId")
	public Boolean checkDuplicateUserByUserIdAndDocumentId(@Param("documentId") Long documentId,
			@Param("usedId") Long usedId);

	@Query("SELECT do FROM DocumentOwner do JOIN do.document d JOIN do.user u ORDER BY d.documentTitle,u.fullName")
	public List<DocumentOwner> getAllDocumentOwnerMappingData();

	@Query("SELECT do FROM DocumentOwner do JOIN do.document d JOIN do.user u WHERE d.id=:documentId ORDER BY d.documentTitle,u.fullName")
	public List<DocumentOwner> getDocumentOwnerMappingData(@Param("documentId") Long documentId);

	@Query("SELECT do FROM DocumentOwner do JOIN do.document d JOIN do.user u WHERE do.id=:documentOwnerId")
	public DocumentOwner getDocumentOwnerById(@Param("documentOwnerId") Long documentOwnerId);
}
