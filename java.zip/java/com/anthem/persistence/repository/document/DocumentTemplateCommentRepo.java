/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.persistence.model.document.DocumentTemplateComment;
import com.anthem.util.common.EnabledStatus;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentTemplateCommentRepo extends JpaRepository<DocumentTemplateComment, Long> {

	@Query(value="SELECT tc FROM DocumentTemplateComment tc JOIN tc.documentTemplate dt WHERE dt.id=:documentTemplateId AND tc.enabledStatus=:enabledStatus")
	public List<DocumentTemplateComment> findAllCommentsByDocumentTemplateIdAndEnabledStatus(@Param("documentTemplateId") Long id,@Param("enabledStatus") EnabledStatus enabledStatus);

}
