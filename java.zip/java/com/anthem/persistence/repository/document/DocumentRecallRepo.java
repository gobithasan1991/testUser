/**
 * 
 */
package com.anthem.persistence.repository.document;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.anthem.persistence.model.document.DocumentRecall;
import com.anthem.persistence.status.CustomStatus;

/**
 * @author kalaiselvan.a
 *
 */
public interface DocumentRecallRepo extends JpaRepository<DocumentRecall, Long> {

	@Query("select distinct dr from DocumentRecall dr left join fetch dr.document d left join fetch d.branchs b left join fetch d.templateCategory tc left join fetch d.documentTemplate t where dr.enabled=?1  and dr.document.customStatus=?2")
	List<DocumentRecall> findDocumentsAfterRecall(Boolean enabled, CustomStatus status);

}
