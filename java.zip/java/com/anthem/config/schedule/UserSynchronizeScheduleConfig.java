package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.user.UserSyncJob;
import com.anthem.web.service.admin.DepartmentService;
import com.anthem.web.service.hr.employee.EmployeeService;
import com.anthem.web.service.user.UserService;

@Configuration
@PropertySource("classpath:schedule/user-sync-config.properties")
public class UserSynchronizeScheduleConfig {
	@Resource
	private Environment env;

	private EmployeeService employeeService;
	private UserService userService;
	private DepartmentService departmentService;

	@Autowired
	public UserSynchronizeScheduleConfig(EmployeeService employeeService, UserService userService,
			DepartmentService departmentService) {
		super();
		this.employeeService = employeeService;
		this.userService = userService;
		this.departmentService = departmentService;
	}

	@Bean
	@Qualifier(value = "UserSyncJobDetailFactoryBean")
	public JobDetailFactoryBean userSyncJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(UserSyncJob.class);
		Map<String, Object> map = new HashMap<>();
		map.put("departmentService", departmentService);
		map.put("employeeService", employeeService);
		map.put("userService", userService);
		factory.setJobDataAsMap(map);
		return factory;
	}

	@Bean
	@Qualifier(value = "UserSyncBean")
	public CronTriggerFactoryBean UserSyncBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(userSyncJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("use.sync.timer"));
		return stFactory;
	}

}
