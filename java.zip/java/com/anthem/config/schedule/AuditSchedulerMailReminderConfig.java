package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.auditmanagement.AuditMailReminderJob;
import com.anthem.web.service.auditmanagement.AuditSchedulerService;

@Configuration
@PropertySource("classpath:schedule/audit-management.properties")
public class AuditSchedulerMailReminderConfig {

	@Resource
	private Environment env;
	private AuditSchedulerService auditSchedulerService;

	@Autowired
	public AuditSchedulerMailReminderConfig(AuditSchedulerService auditSchedulerService) {
		this.auditSchedulerService = auditSchedulerService;
	}

	@Bean
	@Qualifier(value = "AuditEmailReminderJobDetailFactoryBean")
	public JobDetailFactoryBean auditEmailReminderJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(AuditMailReminderJob.class);
		Map<String, Object> map = new HashMap<>();
		map.put("auditSchedulerService", auditSchedulerService);
		factory.setJobDataAsMap(map);
		return factory;
	}

	@Bean
	@Qualifier(value = "AuditEmailReminderTriggerFactoryBean")
	public CronTriggerFactoryBean auditEmailReminderTriggerFactoryBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(auditEmailReminderJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("schedule.timer"));
		return stFactory;
	}

}
