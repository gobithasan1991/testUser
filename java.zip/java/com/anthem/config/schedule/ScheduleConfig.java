package com.anthem.config.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

@Configuration
@EnableScheduling
public class ScheduleConfig {
	@Autowired
	@Qualifier("AuditEmailReminderTriggerFactoryBean")
	private CronTriggerFactoryBean auditEmailReminderTriggerFactoryBean;
	@Autowired
	@Qualifier("AuditPlannerEmailReminderTriggerFactoryBean")
	private CronTriggerFactoryBean auditPlannerEmailReminderTriggerFactoryBean;
	@Autowired
	@Qualifier("AuditPlannerEmailReminderTriggerFactoryBean1")
	private CronTriggerFactoryBean auditPlannerEmailReminderTriggerFactoryBean1;
	@Autowired
	@Qualifier("TrainingPlannerDocumentDueDateManagementBean")
	private CronTriggerFactoryBean trainingPlannerDocumentDueDateManagementBean;
	@Autowired
	@Qualifier("EvaluationAndEmployeeMappingMissedManagementBean")
	private CronTriggerFactoryBean evaluationAndEmployeeMappingMissedManagementBean;
	@Autowired
	@Qualifier("CommonScheduleConfigReminderBean")
	private CronTriggerFactoryBean commonScheduleConfigReminderBean;
	@Autowired
	@Qualifier("InductionReminderMailManagementBean")
	private CronTriggerFactoryBean inductionReminderMailManagementBean;

	@Autowired
	@Qualifier("UserSyncBean")
	private CronTriggerFactoryBean userSyncBean;

	public ScheduleConfig() {
		super();
	}

	@Bean
	public SchedulerFactoryBean schedulerFactoryBean() {
		SchedulerFactoryBean scheduler = new SchedulerFactoryBean();
		scheduler.setTriggers(auditPlannerEmailReminderTriggerFactoryBean1.getObject(),
				auditPlannerEmailReminderTriggerFactoryBean.getObject(),
				auditEmailReminderTriggerFactoryBean.getObject(),
				trainingPlannerDocumentDueDateManagementBean.getObject(),
				evaluationAndEmployeeMappingMissedManagementBean.getObject(),
				commonScheduleConfigReminderBean.getObject(), 
				userSyncBean.getObject(),
				inductionReminderMailManagementBean.getObject());
		return scheduler;
	}
}
