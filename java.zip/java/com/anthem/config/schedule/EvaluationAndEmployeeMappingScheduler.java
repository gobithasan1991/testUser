package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.evaluation.MissedEvaluationAndEmployeeMappingManagement;
import com.anthem.web.service.evaluation.EvaluationAndEmployeeMappingService;

@Configuration
@PropertySource("classpath:schedule/common-time-management.properties")
public class EvaluationAndEmployeeMappingScheduler {
	@Resource
	private Environment env;
	private EvaluationAndEmployeeMappingService evaluationAndEmployeeMappingService;
	
	/**
	 * @param evaluationAndEmployeeMappingService
	 */
	@Autowired
	public EvaluationAndEmployeeMappingScheduler(
			EvaluationAndEmployeeMappingService evaluationAndEmployeeMappingService) {
		super();
		this.evaluationAndEmployeeMappingService = evaluationAndEmployeeMappingService;
	}

	@Bean
	@Qualifier(value = "EvaluationAndEmployeeMappingMissedJobDetailFactoryBean")
	public JobDetailFactoryBean evaluationAndEmployeeMappingMissedJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(MissedEvaluationAndEmployeeMappingManagement.class);
		Map<String, Object> map = new HashMap<>();
		map.put("evaluationAndEmployeeMappingService", evaluationAndEmployeeMappingService);
		factory.setJobDataAsMap(map);
		return factory;
	}
	
	@Bean
	@Qualifier(value = "EvaluationAndEmployeeMappingMissedManagementBean")
	public CronTriggerFactoryBean evaluationAndEmployeeMappingMissedManagementBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(evaluationAndEmployeeMappingMissedJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("daily.timer"));
		return stFactory;
	}
}
