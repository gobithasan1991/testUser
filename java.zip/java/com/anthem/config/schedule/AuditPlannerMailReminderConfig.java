package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.auditmanagement.AuditPlannerMailReminderJob;
import com.anthem.web.service.auditmanagement.AuditPlannerService;

@Configuration
@PropertySource("classpath:schedule/audit-management.properties")
public class AuditPlannerMailReminderConfig {

	@Resource
	private Environment env;
	private AuditPlannerService auditPlannerService;

	@Autowired
	public AuditPlannerMailReminderConfig(AuditPlannerService auditPlannerService) {
		this.auditPlannerService = auditPlannerService;
	}

	@Bean
	@Qualifier(value = "AuditPlannerEmailReminderJobDetailFactoryBean")
	public JobDetailFactoryBean auditPlannerEmailReminderJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(AuditPlannerMailReminderJob.class);
		Map<String, Object> map = new HashMap<>();
		map.put("auditPlannerService", auditPlannerService);
		factory.setJobDataAsMap(map);
		return factory;
	}

	@Bean
	@Qualifier(value = "AuditPlannerEmailReminderTriggerFactoryBean")
	public CronTriggerFactoryBean auditPlannerEmailReminderTriggerFactoryBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(auditPlannerEmailReminderJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("scheule.timer.centerofmonth"));
		return stFactory;
	}

	@Bean
	@Qualifier(value = "AuditPlannerEmailReminderTriggerFactoryBean1")
	public CronTriggerFactoryBean auditPlannerEmailReminderTriggerFactoryBean1() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(auditPlannerEmailReminderJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("schedule.timer.lastdayofmonth"));
		return stFactory;
	}

}
