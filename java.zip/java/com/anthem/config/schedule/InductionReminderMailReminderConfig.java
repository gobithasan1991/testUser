package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.hr.InductionReminderMailManagement;
import com.anthem.web.service.admin.SchedulerConfigurationService;
import com.anthem.web.service.hr.InductionService;

@Configuration
@PropertySource("classpath:schedule/common-time-management.properties")
public class InductionReminderMailReminderConfig {
	@Resource
	private Environment env;
	private InductionService inductionService;
	private SchedulerConfigurationService schedulerConfigurationService;	
	@Autowired
	public InductionReminderMailReminderConfig(InductionService inductionService,
			SchedulerConfigurationService schedulerConfigurationService) {
		super();
		this.inductionService = inductionService;
		this.schedulerConfigurationService = schedulerConfigurationService;
	}

	@Bean
	@Qualifier(value = "InductionReminderMailJobDetailFactoryBean")
	public JobDetailFactoryBean inductionReminderMailJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(InductionReminderMailManagement.class);
		Map<String, Object> map = new HashMap<>();
		map.put("inductionService", inductionService);
		map.put("schedulerConfigurationService", schedulerConfigurationService);
		factory.setJobDataAsMap(map);
		return factory;
	}
	
	@Bean
	@Qualifier(value = "InductionReminderMailManagementBean")
	public CronTriggerFactoryBean inductionReminderMailManagementBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(inductionReminderMailJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("daily.timer"));
		return stFactory;
	}
}
