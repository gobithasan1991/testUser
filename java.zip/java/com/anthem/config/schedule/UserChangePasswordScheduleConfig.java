package com.anthem.config.schedule;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.anthem.web.service.user.UserService;

@Configuration
public class UserChangePasswordScheduleConfig {

	private UserService userService;

	@Autowired
	public UserChangePasswordScheduleConfig(UserService userService) {
		super();
		this.userService = userService;
	}

	@Scheduled(fixedRate = 120000)
	public void changePasswordSceduler() {
		InetAddress inet = null;
		String ip = "";
		try {
			inet = InetAddress.getLocalHost();
			// System.out.println("Your current IP address : " + inet.getHostAddress());
			ip = inet.getHostAddress();
			if (ip.equals("192.168.9.239")) {
				userService.scheduledPasswordUpdate();
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

}
