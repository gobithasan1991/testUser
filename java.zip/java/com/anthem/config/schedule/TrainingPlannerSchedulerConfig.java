package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.training.TrainingPlannerDocumentDueDateManagement;
import com.anthem.web.service.training.TrainingPlannerDocumentService;

@Configuration
@PropertySource("classpath:schedule/common-time-management.properties")
public class TrainingPlannerSchedulerConfig {
	@Resource
	private Environment env;
	private TrainingPlannerDocumentService trainingPlannerDocumentService;
	@Autowired
	public TrainingPlannerSchedulerConfig(TrainingPlannerDocumentService trainingPlannerDocumentService) {
		super(); 
		this.trainingPlannerDocumentService = trainingPlannerDocumentService;
	}
	 
	@Bean
	@Qualifier(value = "TrainingPlannerDocumentDueDateManagementJobDetailFactoryBean")
	public JobDetailFactoryBean trainingPlannerDocumentDueDateManagementJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(TrainingPlannerDocumentDueDateManagement.class);
		Map<String, Object> map = new HashMap<>();
		map.put("trainingPlannerDocumentService", trainingPlannerDocumentService);
		factory.setJobDataAsMap(map);
		return factory;
	}
	
	@Bean
	@Qualifier(value = "TrainingPlannerDocumentDueDateManagementBean")
	public CronTriggerFactoryBean trainingPlannerDocumentDueDateManagementBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(trainingPlannerDocumentDueDateManagementJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("daily.timer"));
		return stFactory;
	}
}
