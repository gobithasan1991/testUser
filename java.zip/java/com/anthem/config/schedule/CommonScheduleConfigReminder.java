package com.anthem.config.schedule;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.anthem.web.jobclass.admin.SchedulerConfigurationRemainderManagement;
import com.anthem.web.service.admin.SchedulerConfigurationService;
import com.anthem.web.service.evaluation.EvaluationAndEmployeeMappingService;
import com.anthem.web.service.training.TrainingPlannerService;
import com.anthem.web.service.training.TrainingSchedulerService;

@Configuration
@PropertySource("classpath:schedule/common-time-management.properties")
public class CommonScheduleConfigReminder {
	@Resource
	private Environment env;
	private TrainingPlannerService trainingPlannerService;
	private SchedulerConfigurationService schedulerConfigurationService;
	private TrainingSchedulerService trainingSchedulerService;
	private EvaluationAndEmployeeMappingService evaluationAndEmployeeMappingService;
	/**
	 * @param trainingPlannerService
	 * @param schedulerConfigurationService
	 */
	@Autowired
	public CommonScheduleConfigReminder(TrainingPlannerService trainingPlannerService,
			SchedulerConfigurationService schedulerConfigurationService,
			TrainingSchedulerService trainingSchedulerService,
			EvaluationAndEmployeeMappingService evaluationAndEmployeeMappingService) {
		super();
		this.trainingPlannerService = trainingPlannerService;
		this.schedulerConfigurationService = schedulerConfigurationService;
		this.trainingSchedulerService = trainingSchedulerService;
		this.evaluationAndEmployeeMappingService = evaluationAndEmployeeMappingService;
	}

	@Bean
	@Qualifier(value = "CommonScheduleConfigReminderJobDetailFactoryBean")
	public JobDetailFactoryBean commonScheduleConfigReminderJobDetailFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(SchedulerConfigurationRemainderManagement.class);
		Map<String, Object> map = new HashMap<>();
		map.put("trainingPlannerService", trainingPlannerService);
		map.put("trainingSchedulerService", trainingSchedulerService);
		map.put("schedulerConfigurationService", schedulerConfigurationService);
		map.put("evaluationAndEmployeeMappingService", evaluationAndEmployeeMappingService);
		factory.setJobDataAsMap(map);
		return factory;
	}
	
	@Bean
	@Qualifier(value = "CommonScheduleConfigReminderBean")
	public CronTriggerFactoryBean commonScheduleConfigReminderBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(commonScheduleConfigReminderJobDetailFactoryBean().getObject());
		stFactory.setStartDelay(3000);
		stFactory.setCronExpression(env.getProperty("hourly.timer"));
		return stFactory;
	}
}
