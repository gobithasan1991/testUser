package com.anthem.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.anthem.persistence.auditor.UsernameAuditorAware;

@Configuration
@EnableJpaRepositories(basePackages = {"com.anthem.persistence.repository", "com.anthem.glp.persistence.repository"})
@EnableJpaAuditing
@EnableTransactionManagement
@PropertySource(value = { "classpath:config/db.properties" })
@EnableSpringDataWebSupport
@Profile(value = "dev")
public class JPAConfig {

	// JDBC Constants
	private static final String PROPERTY_DB_DRIVER = "db.driver";
	private static final String PROPERTY_DB_URL = "db.url";
	private static final String PROPERTY_DB_USERNAME = "db.username";
	private static final String PROPERTY_DB_PASSWORD = "db.password";

	// Hibernate Constants
	private static final String PROPERTY_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	private static final String PROPERTY_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
	private static final String PROPERTY_HIBERNATE_GENERATEDDL = "hibernate.generateddl";
	private static final String PROPERTY_HIBERNATE_DIALECT = "hibernate.dialect";

	// Hibernate Envers
	private static final String PROPERTY_HIBERNATE_AUDIT = "org.hibernate.envers.audit_table_suffix";

	// JPA Constants
	private static final String PROPERTY_PACKAGE_TO_SCAN = "entitymanager.packages.to.scan";

	@Autowired
	private Environment env;

	@Primary
	@Bean
	@Qualifier(value = "transactionManager")
	public PlatformTransactionManager transactionManager() {
		EntityManagerFactory entityManagerFactory = entityManagerFactory().getObject();
		return new JpaTransactionManager(entityManagerFactory);
	}

	@Primary
	@Bean
	@Qualifier(value = "entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
		localContainerEntityManagerFactoryBean.setDataSource(dataSource());
		localContainerEntityManagerFactoryBean.setJpaVendorAdapter(hibernateJpaVendorAdapter());
		localContainerEntityManagerFactoryBean.setPackagesToScan(env.getProperty(PROPERTY_PACKAGE_TO_SCAN).split(","));
		localContainerEntityManagerFactoryBean.setJpaProperties(properties());
		localContainerEntityManagerFactoryBean.afterPropertiesSet();
		localContainerEntityManagerFactoryBean.setLoadTimeWeaver(new InstrumentationLoadTimeWeaver());
		return localContainerEntityManagerFactoryBean;
	}

	@Bean
	@Qualifier(value = "dataSource")
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty(PROPERTY_DB_DRIVER));
		dataSource.setUrl(env.getProperty(PROPERTY_DB_URL));
		dataSource.setUsername(env.getProperty(PROPERTY_DB_USERNAME));
		dataSource.setPassword(env.getProperty(PROPERTY_DB_PASSWORD));

		return dataSource;
	}

	@Bean
	public HibernateExceptionTranslator hibernateExceptionTranslator() {
		return new HibernateExceptionTranslator();
	}

	@Bean
	public HibernateJpaVendorAdapter hibernateJpaVendorAdapter() {
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setGenerateDdl(Boolean.parseBoolean(env.getProperty(PROPERTY_HIBERNATE_GENERATEDDL)));
		hibernateJpaVendorAdapter.setShowSql(Boolean.parseBoolean(env.getProperty(PROPERTY_HIBERNATE_SHOW_SQL)));
		hibernateJpaVendorAdapter.setDatabasePlatform(env.getProperty(PROPERTY_HIBERNATE_DIALECT));
		return hibernateJpaVendorAdapter;
	}

	public Properties properties() {
		Properties properties = new Properties();
		properties.setProperty(PROPERTY_HIBERNATE_HBM2DDL_AUTO, env.getProperty(PROPERTY_HIBERNATE_HBM2DDL_AUTO));
		properties.setProperty("hibernate.jdbc.batch_size", "100");
		properties.put("hibernate.order_inserts", "true");
		properties.put("hibernate.order_updates", "true");

		// Below Code will help to audit the table
		properties.setProperty(PROPERTY_HIBERNATE_AUDIT, env.getProperty(PROPERTY_HIBERNATE_AUDIT));
		return properties;
	}

	@Bean
	public UsernameAuditorAware usernameAuditorAware() {
		return new UsernameAuditorAware();
	}

}
