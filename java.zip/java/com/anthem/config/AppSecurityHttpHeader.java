/**
 * 
 */
package com.anthem.config;

import java.util.Arrays;
import java.util.Base64;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

/**
 * @author shivakumar.m
 *
 */
@Component
@PropertySource(value = { "classpath:config/RESTConfig.properties" })
public class AppSecurityHttpHeader {

	private Environment environment;

	/**
	 * 
	 */
	@Autowired
	public AppSecurityHttpHeader(Environment environment) {
		this.environment = environment;
	}

	@Bean
	public HttpHeaders getHeaders() {
		String userName = environment.getProperty("anthemerp.login.username");
		String password = environment.getProperty("anthemerp.login.password");
		String plainCredentials = userName+":"+password;
		String base64Credentials = new String(Base64.getEncoder().encode(plainCredentials.getBytes()));
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Credentials);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}
}
