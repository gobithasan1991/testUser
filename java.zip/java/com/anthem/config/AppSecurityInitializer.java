/**
 * 
 */
package com.anthem.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author vigneshwaran.b
 *
 */
public class AppSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

	@Override
	protected boolean enableHttpSessionEventPublisher() {
		return true;
	}

}
