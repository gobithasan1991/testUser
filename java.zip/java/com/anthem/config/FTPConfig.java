package com.anthem.config;

import java.io.InputStream;

import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.ftp.filters.FtpPersistentAcceptOnceFileListFilter;
import org.springframework.integration.ftp.inbound.FtpStreamingMessageSource;
import org.springframework.integration.ftp.session.DefaultFtpSessionFactory;
import org.springframework.integration.ftp.session.FtpRemoteFileTemplate;
import org.springframework.integration.metadata.SimpleMetadataStore;
import org.springframework.integration.transformer.StreamTransformer;

//@Configuration
@EnableIntegration
public class FTPConfig {

	@Bean
	public DefaultFtpSessionFactory ftpSessionFactory() {
		System.out.println("-------------------------------------------------------");
		System.out.println("ftp session factory");
		System.out.println("-------------------------------------------------------");
		DefaultFtpSessionFactory sessionFactory = new DefaultFtpSessionFactory();
		sessionFactory.setHost("abcom286");
		sessionFactory.setPort(21);
		sessionFactory.setUsername("kalaiselvan.a");
		sessionFactory.setPassword("Abcom@3");
		return sessionFactory;
	}

	// @Bean
	// public FtpInboundFileSynchronizer ftpInboundFileSynchronizer() {
	// FtpInboundFileSynchronizer ftpchannel = new
	// FtpInboundFileSynchronizer(ftpSessionFactory());
	// ftpchannel.setDeleteRemoteFiles(false);
	// ftpchannel.setRemoteDirectory("/dts");
	// return ftpchannel;
	// }

	@Bean
	@InboundChannelAdapter(channel = "stream")
	public MessageSource<InputStream> ftpMessageSource() {
		FtpStreamingMessageSource messageSource = new FtpStreamingMessageSource(template());
		messageSource.setRemoteDirectory("dts/");
		messageSource.setFilter(new FtpPersistentAcceptOnceFileListFilter(new SimpleMetadataStore(), "streaming"));
		return messageSource;
	}

	@Bean
	@Transformer(inputChannel = "stream", outputChannel = "data")
	public org.springframework.integration.transformer.Transformer transformer() {
		return new StreamTransformer();
	}

	@Bean
	public FtpRemoteFileTemplate template() {
		return new FtpRemoteFileTemplate(ftpSessionFactory());
	}
}
