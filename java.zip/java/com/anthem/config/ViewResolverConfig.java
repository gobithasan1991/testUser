/**
 * 
 */
package com.anthem.config;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.anthem.web.view.JsonViewResolver;
import com.anthem.web.view.PdfViewResolver;

/**
 * @author kalaiselvan.a
 *
 */
public class ViewResolverConfig extends UrlBasedViewResolver {

	public final static Logger log = LoggerFactory.getLogger(ViewResolverConfig.class);

	/**
	 * Set view Class
	 */
	public ViewResolverConfig() {
		setViewClass(InternalResourceView.class);
	}

	/**
	 * @param manager
	 * @return
	 */
	@Bean
	public ViewResolver contentNegotiatingViewResolver(ContentNegotiationManager manager) {
		ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
		resolver.setContentNegotiationManager(manager);
		List<ViewResolver> resolvers = new ArrayList<>();
		resolvers.add(viewresolver());
		resolvers.add(jsonViewResolver());		
		// resolvers.add(pdfViewResolver());
		resolver.setViewResolvers(resolvers);

		return resolver;
	}

	@Bean
	public CommonsMultipartResolver multipartResolver() {
		CommonsMultipartResolver resolver = new CommonsMultipartResolver();
		resolver.setDefaultEncoding("utf-8");
		return resolver;
	}

	/**
	 * @return
	 */
	@Bean
	public ViewResolver jsonViewResolver() {
		return new JsonViewResolver();
	}

	@Bean
	public ViewResolver pdfViewResolver() {
		return new PdfViewResolver();
	}

	/**
	 * @return
	 */
	@Bean
	public ViewResolver viewresolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setViewClass(JstlView.class);
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}
}
