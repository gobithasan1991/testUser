package com.anthem.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.switchuser.SwitchUserFilter;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.anthem.web.service.user.UserService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(1)
public class AppSecurityConfig extends WebSecurityConfigurerAdapter {

//	@Autowired
//	private LimitLoginAuthenticationProvider limitLoginAuthenticationProvider;

	private static String REALM = "ANTHEM_REST_REALM";
	@Autowired
	private UserService userService;

	@Autowired
	protected void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userService).passwordEncoder(passwordEncoder());
		super.configure(auth);
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/js/**", "/plugins/**", "/styles/**", "/fonts/**", "/img/**", "/vendors/**",
				"resources/**", "css/**", "/DocumentVersionList/**", "/CreateDocumentVersion/**",
				"/AddDocumentComments/**", "/AddTemplateComments/**", "/GetVersions/**", "/DocumentRecallApprover/**",
				"/IndexServlet/**", "/dts/**", "/login-request/request/**", "/assets/loginrequest/**", "/assets/hr/**",
				"/assets/common/**","/offer-letter/get-by-access-code/**","/blood-group/get-all-enabled/**");
		super.configure(web);
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().anyRequest().authenticated().and().formLogin().loginPage("/login")
				.defaultSuccessUrl("/").failureUrl("/login?error").permitAll().and().logout()
				.logoutSuccessUrl("/login?logout").invalidateHttpSession(true).clearAuthentication(true).permitAll()
				.and().httpBasic().realmName(REALM).authenticationEntryPoint(getBasicAuthEntryPoint()).and()
				.exceptionHandling().accessDeniedPage("/errors/AccessDeniedPage").and().sessionManagement()
				.sessionFixation().newSession().and().sessionManagement().maximumSessions(1)
				.maxSessionsPreventsLogin(false).sessionRegistry(sessionRegistry()).expiredUrl("/login?expired");

		http.headers().disable();
		http.csrf().disable();
		http.rememberMe().disable();
		http.addFilter(switchUserProcessingFilter());
	}

	@Bean
	public AppBasicAuthenticationEntryPoint getBasicAuthEntryPoint() {
		return new AppBasicAuthenticationEntryPoint();
	}

	@Bean
	public SwitchUserFilter switchUserProcessingFilter() {
		SwitchUserFilter switchUserFilter = new SwitchUserFilter();
		switchUserFilter.setUserDetailsService(userService);
		switchUserFilter.setSwitchUserUrl("/login/switch");
		switchUserFilter.setExitUserUrl("/logout/switch");
		switchUserFilter.setUsernameParameter("username");
		switchUserFilter.setTargetUrl("/");
		switchUserFilter.setSwitchFailureUrl("/switchFailUser");
		return switchUserFilter;
	}

	@Bean
	public SessionRegistry sessionRegistry() {
		return new SessionRegistryImpl();
	}

	@Bean
	public HttpSessionEventPublisher eventPublisher() {
		return new HttpSessionEventPublisher();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(4);
	}
}
