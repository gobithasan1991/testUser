package com.anthem.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.CacheControl;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.WebContentInterceptor;
import org.springframework.web.util.UrlPathHelper;

import com.anthem.rest.SwaggerConfig;
import com.anthem.security.listener.LoginUserListener;
import com.anthem.web.util.revisions.AuditService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate5.Hibernate5Module;

@Configuration
@EnableWebMvc
@EnableAsync
@EnableScheduling
@ComponentScan(basePackages = { "com.anthem", "com.aberp" })
@Import({ SwaggerConfig.class, ViewResolverConfig.class, AppSecurityConfig.class, CacheConfig.class,
		MailConfiguration.class })

@PropertySource(value = { "classpath:settings.properties" })
public class AppConfig extends WebMvcConfigurerAdapter {

	@Autowired
	private Environment env;

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/WEB-INF/resources/");
		registry.addResourceHandler("/vendors/**").addResourceLocations("/WEB-INF/resource/vendors/");
		registry.addResourceHandler("/js/**").addResourceLocations("/WEB-INF/resource/js/");
		registry.addResourceHandler("/plugins/**").addResourceLocations("/WEB-INF/resource/plugins/");
		registry.addResourceHandler("/styles/**").addResourceLocations("/WEB-INF/resource/styles/");
		registry.addResourceHandler("/fonts/**").addResourceLocations("/WEB-INF/resource/fonts/");
		registry.addResourceHandler("/img/**").addResourceLocations("/WEB-INF/resource/img/");
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
		registry.addResourceHandler("/dts/**").addResourceLocations("/dts/");
		registry.addResourceHandler("/assets/**").addResourceLocations("/WEB-INF/views/");
		super.addResourceHandlers(registry);
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		// for only office cross origin please don't change this
		registry.addMapping("/IndexServlet").allowedOrigins(env.getProperty("onlyoffice.origin"))
				.allowedHeaders("Access-Control-Allow-Origin", "*")
				.allowedHeaders("Access-Control-Allow-Headers", "Content-Type,x-requested-with").maxAge(864000)
				.allowCredentials(false).allowedMethods("POST");

		registry.addMapping("/dts/**").allowedOrigins(env.getProperty("onlyoffice.origin"))
				.allowedHeaders("Access-Control-Allow-Origin", "*")
				.allowedHeaders("Access-Control-Allow-Headers", "Content-Type,x-requested-with").maxAge(864000)
				.allowCredentials(false).allowedMethods("POST", "DELETE", "GET");

		super.addCorsMappings(registry);

	}

	@Bean
	@Qualifier(value = "objectMapper")
	@Description("getting ObjectMapper bean")
	public ObjectMapper getObjectMapperBean() {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.registerModule(new Hibernate5Module());
		return objectMapper;
	}

	@Bean(name = "multipartResolver")
	public CommonsMultipartResolver multipartResolver() {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		multipartResolver.setMaxUploadSize(100000);
		return new CommonsMultipartResolver();
	}

	@Bean
	public LoginUserListener loginUserListener() {
		return new LoginUserListener();
	}

	@Override
	public void configurePathMatch(PathMatchConfigurer configurer) {
		UrlPathHelper urlPathHelper = new UrlPathHelper();
		urlPathHelper.setRemoveSemicolonContent(false);
		configurer.setUrlPathHelper(urlPathHelper);
	}

	// @Bean
	// public ClientHttpRequestFactory clientHttpRequestFactory() {
	// HttpComponentsClientHttpRequestFactory factory = new
	// HttpComponentsClientHttpRequestFactory();
	// factory.setReadTimeout(20000);
	// factory.setConnectTimeout(20000);
	// return factory;
	// }

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean
	public AuditService auditService() {
		return new AuditService();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(contentInterceptor());
		super.addInterceptors(registry);
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		converters.add(jackson2HttpMessageConverter());
		super.configureMessageConverters(converters);
	}

	@Bean
	MappingJackson2HttpMessageConverter jackson2HttpMessageConverter() {
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new Hibernate5Module());
		converter.setObjectMapper(mapper);
		return converter;
	}

	@Bean
	WebContentInterceptor contentInterceptor() {
		WebContentInterceptor contentInterceptor = new WebContentInterceptor();
		contentInterceptor.setCacheSeconds(0);
		contentInterceptor.addCacheMapping(CacheControl.noCache(), "/*");
		contentInterceptor.addCacheMapping(CacheControl.noStore(), "/*");
		return contentInterceptor;
	}
	
	
	@Bean("threadPoolTaskExecutor")
    public TaskExecutor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(20);
        executor.setMaxPoolSize(1000);
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setThreadNamePrefix("Async-");
        return executor;
    }
}
