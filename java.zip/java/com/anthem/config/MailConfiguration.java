/**
 * 
 */
package com.anthem.config;

import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

/**
 * @author kalaiselvan.a
 *
 */
@Profile(value = "dev")
@PropertySource({ "classpath:config/mail.properties" })
@SuppressWarnings("unused")
public class MailConfiguration {

	private static final Logger log = LoggerFactory.getLogger(MailConfiguration.class);

	private static final String MAIL_HOST = "mail.HName";
	private static final String MAIL_HADDRESS = "mail.HAddress";
	private static final String MAIL_PNAME = "mail.pName";
	private static final String MAIL_PORT = "mail.pNo";
	private static final String MAIL_USERNAME = "mail.username";
	private static final String MAIL_PASSWORD = "mail.password";

	@Resource
	private Environment env;

	/**
	 * @return
	 */
	@Bean(name = "JavaMailSenderImpl")
	@Scope("prototype")
	public JavaMailSenderImpl JavaMailSenderImpl() {
		JavaMailSenderImpl javamail = new JavaMailSenderImpl();
		javamail.setHost(env.getRequiredProperty(MAIL_HADDRESS));
		javamail.setJavaMailProperties(mailproperties());
		return javamail;
	}

	/**
	 * @return
	 */
	private Properties mailproperties() {
		Properties properties = new Properties();
		properties.setProperty("mail.debug", "false");
//		properties.setProperty("mail.smtp.auth", "false");
//		properties.setProperty("mail.smtp.starttls.enable", "true");
		properties.setProperty("mail.mime.charset", "UTF-8");
		properties.setProperty("mail.transport.protocol", "smtp");
		return properties;
	}

//	@Bean(name = "VelocityEngine")
//	public VelocityEngine getVelocityEngine() {
//		VelocityEngine velocityEngine = new VelocityEngine();
//		velocityEngine.setProperty("resource.loader", "class");
//		velocityEngine.setProperty("class.resource.loader.class",
//				"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
//		velocityEngine.init();
//		return velocityEngine;
//	}

	@Bean
	public FreeMarkerConfigurationFactoryBean getFreeMarkerConfiguration() {
		FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
		bean.setTemplateLoaderPath("classpath:MailTemplates/");
		return bean;
	}

}
