/**
 * 
 */
package com.anthem.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;

/**
 * @author kalaiselvan.a
 *
 */
@EnableCaching
public class CacheConfig {

	@Bean
	public CacheManager getCacheManager() {
		List<Cache> cache = new ArrayList<>();
		cache.add(new ConcurrentMapCache("qmsdepartments"));
		SimpleCacheManager simpleCache = new SimpleCacheManager();
		simpleCache.setCaches(cache);
		simpleCache.afterPropertiesSet();
		return simpleCache;
	}
}
