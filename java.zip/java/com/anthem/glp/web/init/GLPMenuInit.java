package com.anthem.glp.web.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.admin.Menu;
import com.anthem.persistence.model.admin.Privilege;
import com.anthem.util.admin.MenuType;
import com.anthem.web.service.admin.MenuService;

@Service
public class GLPMenuInit {

	private MenuService menuService;

	@Autowired
	public GLPMenuInit(MenuService menuService) {
		super();
		this.menuService = menuService;

	}

	@Transactional
	public void init() {
		Menu menu = null;
		Privilege privilege = null;

		if (menuService.findByMenuState("glpadmin") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("Admin");
			menu.setMenuState("glpadmin");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("Admin");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("app.GLP"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.sponsor") == null) {
			menu = new Menu();
			menu.setMenuName("Sponsor");
			menu.setMenuState("glpadmin.sponsor");
			menu.setMenuUrl("/sponsor/create");
			menu.setMenuTemplateUrl("sponsor/create");
			menu.setMenuTitle("Sponsor");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(5);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.nominee") == null) {
			menu = new Menu();
			menu.setMenuName("Nominee");
			menu.setMenuState("glpadmin.nominee");
			menu.setMenuUrl("/nominee/create");
			menu.setMenuTemplateUrl("nominee/create");
			menu.setMenuTitle("Nominee");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(6);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.physicalprop") == null) {
			menu = new Menu();
			menu.setMenuName("Physical Property");
			menu.setMenuState("glpadmin.physicalprop");
			menu.setMenuUrl("/physical-property/create");
			menu.setMenuTemplateUrl("physical-property/create");
			menu.setMenuTitle("Physical Property");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(7);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.packageType") == null) {
			menu = new Menu();
			menu.setMenuName("Package Type");
			menu.setMenuState("glpadmin.packageType");
			menu.setMenuUrl("/package-type/create");
			menu.setMenuTemplateUrl("package-type/create");
			menu.setMenuTitle("Package Type");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(8);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.storageondition") == null) {
			menu = new Menu();
			menu.setMenuName("Storage Condition");
			menu.setMenuState("glpadmin.storageondition");
			menu.setMenuUrl("/storage-condition/create");
			menu.setMenuTemplateUrl("storage-condition/create");
			menu.setMenuTitle("Storage Condition");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(9);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.glpDocumentTemplate") == null) {
			menu = new Menu();
			menu.setMenuName("GLP Document Template");
			menu.setMenuState("glpadmin.glpDocumentTemplate");
			menu.setMenuUrl("/glp-document-template/create");
			menu.setMenuTemplateUrl("glp-document-template/create");
			menu.setMenuTitle("GLP Document Template");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(12);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.studydirectorcreation") == null) {
			menu = new Menu();
			menu.setMenuName("Study Director");
			menu.setMenuState("glpadmin.studydirectorcreation");
			menu.setMenuUrl("/study-director-master/create");
			menu.setMenuTemplateUrl("study-director-master/create");
			menu.setMenuTitle("Study Director Creation");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(11);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.glpdepartment") == null) {
			menu = new Menu();
			menu.setMenuName("Department");
			menu.setMenuState("glpadmin.glpdepartment");
			menu.setMenuUrl("/glp-department/glpdepartment");
			menu.setMenuTemplateUrl("glp-department/glpdepartment");
			menu.setMenuTitle("Department");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(1);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.glpusermapping") == null) {
			menu = new Menu();
			menu.setMenuName("User Mapping");
			menu.setMenuState("glpadmin.glpusermapping");
			menu.setMenuUrl("/glp-user-mapping/creation");
			menu.setMenuTemplateUrl("glp-user-mapping/creation");
			menu.setMenuTitle("User Mapping");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(2);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.glpDesignationMaster") == null) {
			menu = new Menu();
			menu.setMenuName("Designation Master");
			menu.setMenuState("glpadmin.glpDesignationMaster");
			menu.setMenuUrl("/glp-designation/master");
			menu.setMenuTemplateUrl("glp-designation/master");
			menu.setMenuTitle("Designation Master");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(3);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.glpEmpDesignationMap") == null) {
			menu = new Menu();
			menu.setMenuName("Employee Designation Mapping");
			menu.setMenuState("glpadmin.glpEmpDesignationMap");
			menu.setMenuUrl("/glp-designation-employee/mapping");
			menu.setMenuTemplateUrl("glp-designation-employee/mapping");
			menu.setMenuTitle("Employee Designation Mapping");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(4);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.transportation") == null) {
			menu = new Menu();
			menu.setMenuName("Transportation Master");
			menu.setMenuState("glpadmin.transportation");
			menu.setMenuUrl("/transportation-master/create");
			menu.setMenuTemplateUrl("transportation-master/create");
			menu.setMenuTitle("Transportation Master");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpadmin"));
			menu.setMenuOrder(10);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		// glp admin ends

		if (menuService.findByMenuState("glpstudy") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("Study");
			menu.setMenuState("glpstudy");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("Study");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("app.GLP"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
//glp study child menus
		if (menuService.findByMenuState("glpstudy.create") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("Initiate");
			menu.setMenuState("glpstudy.create");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("Initiate");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		// Modify
		if (menuService.findByMenuState("glpstudy.modifiy") == null) {
			menu = new Menu();
			menu.setMenuOrder(2);
			menu.setMenuName("Modify");
			menu.setMenuState("glpstudy.modifiy");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("Modify");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-plan-modify") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("Study Plan Modify");
			menu.setMenuState("glpstudy.study-plan-modify");
			menu.setMenuTemplateUrl("study-plan/modify");
			menu.setMenuTitle("Study Plan Modify");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.modifiy"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.approval") == null) {
			menu = new Menu();
			menu.setMenuOrder(3);
			menu.setMenuName("Approval");
			menu.setMenuState("glpstudy.approval");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("Approval");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.reports") == null) {
			menu = new Menu();
			menu.setMenuOrder(4);
			menu.setMenuName("MIS");
			menu.setMenuState("glpstudy.reports");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("MIS");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-enquiry") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("Test Item Receipt");
			menu.setMenuState("glpstudy.study-enquiry");
			menu.setMenuTemplateUrl("study-enquiry/create");
			menu.setMenuTitle("Test Item Receipt");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.tico") == null) {
			menu = new Menu();
			menu.setMenuOrder(2);
			menu.setMenuName("TICO");
			menu.setMenuState("glpstudy.tico");
			menu.setMenuTemplateUrl("tico/create");
			menu.setMenuTitle("TICO");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		// glp study child menus ends
		// glp study create menu
		if (menuService.findByMenuState("glpstudy.study-number-generation") == null) {
			menu = new Menu();
			menu.setMenuOrder(3);
			menu.setMenuName("Study Number Generation");
			menu.setMenuState("glpstudy.study-number-generation");
			menu.setMenuTemplateUrl("study-number-generation/create");
			menu.setMenuTitle("Study Number Generation");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studydirector") == null) {
			menu = new Menu();
			menu.setMenuName("Study Allotment");
			menu.setMenuState("glpstudy.studydirector");
			menu.setMenuUrl("/study-director/create");
			menu.setMenuTemplateUrl("study-director/create");
			menu.setMenuTitle("Study Allotment");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			menu.setMenuOrder(4);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-plan") == null) {
			menu = new Menu();
			menu.setMenuOrder(5);
			menu.setMenuName("Study Plan");
			menu.setMenuState("glpstudy.study-plan");
			menu.setMenuTemplateUrl("study-plan/create");
			menu.setMenuTitle("Study Plan");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studypersonnel") == null) {
			menu = new Menu();
			menu.setMenuName("Study Personnel Allocation");
			menu.setMenuState("glpstudy.studypersonnel");
			menu.setMenuUrl("/study-personnel/create");
			menu.setMenuTemplateUrl("study-personnel/create");
			menu.setMenuTitle("Study Personnel");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			menu.setMenuOrder(6);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		if (menuService.findByMenuState("glpstudy.study-requisition") == null) {
			menu = new Menu();
			menu.setMenuOrder(7);
			menu.setMenuName("Study Requisition");
			menu.setMenuState("glpstudy.study-requisition");
			menu.setMenuTemplateUrl("study-requisition/create");
			menu.setMenuTitle("Study Requisition");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.it-folder-creation-request") == null) {
			menu = new Menu();
			menu.setMenuOrder(8);
			menu.setMenuName("Folder Creation Request");
			menu.setMenuState("glpstudy.it-folder-creation-request");
			menu.setMenuTemplateUrl("it-request-accepted/creation");
			menu.setMenuTitle("Folder Creation Request");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.qau-verification-request-by-study") == null) {
			menu = new Menu();
			menu.setMenuOrder(9);
			menu.setMenuName("QAU Verification Request By Study");
			menu.setMenuState("glpstudy.qau-verification-request-by-study");
			menu.setMenuTemplateUrl("qau-verification/request-by-study");
			menu.setMenuTitle("QAU Verification Request By Study");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		
		if (menuService.findByMenuState("glpstudy.qau-verification-entry") == null) {
			menu = new Menu();
			menu.setMenuOrder(10);
			menu.setMenuName("QAU Verification Entry");
			menu.setMenuState("glpstudy.qau-verification-entry");
			menu.setMenuTemplateUrl("qau-verification/entry");
			menu.setMenuTitle("QAU Verification Entry");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.create"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		// glp study create menu ends
		// glp study apporval menu

		if (menuService.findByMenuState("glpstudy.study-allotment-acceptance") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("Study Allotment Acceptance");
			menu.setMenuState("glpstudy.study-allotment-acceptance");
			menu.setMenuTemplateUrl("study-director/study-allotment-acceptance");
			menu.setMenuTitle("Study Allotment Acceptance");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.approval"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-plan-review") == null) {
			menu = new Menu();
			menu.setMenuOrder(2);
			menu.setMenuName("Study Plan Review");
			menu.setMenuState("glpstudy.study-plan-review");
			menu.setMenuTemplateUrl("study-plan/review");
			menu.setMenuTitle("Study Plan Review");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.approval"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-plan-approve") == null) {
			menu = new Menu();
			menu.setMenuOrder(3);
			menu.setMenuName("Study Plan Approve");
			menu.setMenuState("glpstudy.study-plan-approve");
			menu.setMenuTemplateUrl("study-plan/approve");
			menu.setMenuTitle("Study Plan Approve");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.approval"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-requisition-authorization") == null) {
			menu = new Menu();
			menu.setMenuOrder(4);
			menu.setMenuName("Study Requisition Approve");
			menu.setMenuState("glpstudy.study-requisition-authorization");
			menu.setMenuTemplateUrl("study-requisition/approve");
			menu.setMenuTitle("Study Requisition Approve");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.approval"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.it-folder-creation-request-authorized") == null) {
			menu = new Menu();
			menu.setMenuOrder(5);
			menu.setMenuName("Folder Creation Request Authorized");
			menu.setMenuState("glpstudy.it-folder-creation-request-authorized");
			menu.setMenuTemplateUrl("it-folder-creation-request/authorized");
			menu.setMenuTitle("Folder Creation Request Authorized");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.approval"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		// glp study apporval menu ends

		// GLP MIS//
		if (menuService.findByMenuState("glpadmin.monthlyMasterSchedule") == null) {
			menu = new Menu();
			menu.setMenuName("Monthly Master Schedule");
			menu.setMenuState("glpadmin.monthlyMasterSchedule");
			menu.setMenuUrl("/reports/monthly-master-schedule");
			menu.setMenuTemplateUrl("reports/monthly-master-schedule");
			menu.setMenuTitle("Monthly Master Schedule");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(1);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studyReport") == null) {
			menu = new Menu();
			menu.setMenuName("Study Report");
			menu.setMenuState("glpstudy.studyReport");
			menu.setMenuUrl("/study-number-generation/studyReport");
			menu.setMenuTemplateUrl("study-number-generation/studyReport");
			menu.setMenuTitle("Study Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(2);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studyallotmentreport") == null) {
			menu = new Menu();
			menu.setMenuName("Study Allotment Report");
			menu.setMenuState("glpstudy.studyallotmentreport");
			menu.setMenuUrl("/study-allotment/study-allotment-letter-report");
			menu.setMenuTemplateUrl("study-allotment/study-allotment-letter-report");
			menu.setMenuTitle("Study Allotment Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(3);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.study-number-report") == null) {
			menu = new Menu();
			menu.setMenuName("Study Number Report");
			menu.setMenuState("glpstudy.study-number-report");
			menu.setMenuUrl("study-number-generation/report");
			menu.setMenuTemplateUrl("study-number-generation/report");
			menu.setMenuTitle("Study Number Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(4);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.testItemReport") == null) {
			menu = new Menu();
			menu.setMenuName("Test Item Report");
			menu.setMenuState("glpstudy.testItemReport");
			menu.setMenuUrl("/reports/test-item-report");
			menu.setMenuTemplateUrl("reports/test-item-report");
			menu.setMenuTitle("Test Item Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(5);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studyAllotmentLetterPrint") == null) {
			menu = new Menu();
			menu.setMenuName("Study Allotment Letter PDF");
			menu.setMenuState("glpstudy.studyAllotmentLetterPrint");
			menu.setMenuUrl("/reports/study-allotment-letter-pdf");
			menu.setMenuTemplateUrl("reports/study-allotment-letter-pdf");
			menu.setMenuTitle("Study Allotment Letter PDF");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(6);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studyRequisitionReport") == null) {
			menu = new Menu();
			menu.setMenuName("Study Requisition");
			menu.setMenuState("glpstudy.studyRequisitionReport");
			menu.setMenuUrl("/study-requisition/study-requisition-report");
			menu.setMenuTemplateUrl("study-requisition/study-requisition-report");
			menu.setMenuTitle("Study Requisition");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(7);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpstudy.studyreportbyuser") == null) {
			menu = new Menu();
			menu.setMenuName("Study Report By User");
			menu.setMenuState("glpstudy.studyreportbyuser");
			menu.setMenuUrl("/study-director/study-report-by-user");
			menu.setMenuTemplateUrl("study-director/study-report-by-user");
			menu.setMenuTitle("Study Report By User");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(8);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		if (menuService.findByMenuState("glpstudy.studydirectorreport") == null) {
			menu = new Menu();
			menu.setMenuName("Study Director Report");
			menu.setMenuState("glpstudy.studydirectorreport");
			menu.setMenuUrl("/study-director-master/report");
			menu.setMenuTemplateUrl("study-director-master/report");
			menu.setMenuTitle("Study Director Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(9);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		if (menuService.findByMenuState("glpstudy.qau-verification-report") == null) {
			menu = new Menu();
			menu.setMenuName("QAU Verification Report");
			menu.setMenuState("glpstudy.qau-verification-report");
			menu.setMenuUrl("/qau-verification/report");
			menu.setMenuTemplateUrl("qau-verification/report");
			menu.setMenuTitle("QAU Verification Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("glpstudy.reports"));
			menu.setMenuOrder(10);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		// IT Start
		if (menuService.findByMenuState("it") == null) {
			menu = new Menu();
			menu.setMenuOrder(1);
			menu.setMenuName("IT");
			menu.setMenuState("it");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("IT");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("app.GLP"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		if (menuService.findByMenuState("glpadmin.it-folder-creation-request-accepted") == null) {
			menu = new Menu();
			menu.setMenuName("Folder Creation Request Accepted");
			menu.setMenuState("glpadmin.it-folder-creation-request-accepted");
			menu.setMenuUrl("/it-request-accepted/accepted");
			menu.setMenuTemplateUrl("it-request-accepted/accepted");
			menu.setMenuTitle("Folder Creation Request Accepted");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("it"));
			menu.setMenuOrder(1);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("glpadmin.it-folder-creation-request-filled") == null) {
			menu = new Menu();
			menu.setMenuName("Folder Creation Request Filled");
			menu.setMenuState("glpadmin.it-folder-creation-request-filled");
			menu.setMenuUrl("/it-request-accepted/filled");
			menu.setMenuTemplateUrl("it-request-accepted/filled");
			menu.setMenuTitle("Folder Creation Request Filled");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("it"));
			menu.setMenuOrder(2);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}

		if (menuService.findByMenuState("it.reports") == null) {
			menu = new Menu();
			menu.setMenuOrder(10);
			menu.setMenuName("MIS");
			menu.setMenuState("it.reports");
			menu.setMenuTemplateUrl("ui/subMenuTemplate");
			menu.setMenuTitle("MIS");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("it"));
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
		if (menuService.findByMenuState("glpadmin.it-folder-creation-request-report-by-all") == null) {
			menu = new Menu();
			menu.setMenuName("Folder Creation Request Report");
			menu.setMenuState("glpadmin.it-folder-creation-request-report-by-all");
			menu.setMenuUrl("/it-request-accepted/report-by-all");
			menu.setMenuTemplateUrl("it-request-accepted/report-by-all");
			menu.setMenuTitle("Folder Creation Request Report");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuParent(menuService.findByMenuState("it.reports"));
			menu.setMenuOrder(1);
			privilege = new Privilege();
			privilege.setAuthority("VIEW");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("sub-menu");
			menuService.addMenuInit(menu);
		}
	}
}
