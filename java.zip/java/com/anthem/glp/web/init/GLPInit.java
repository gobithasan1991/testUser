package com.anthem.glp.web.init;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.persistence.model.admin.Menu;
import com.anthem.persistence.model.admin.Privilege;
import com.anthem.util.admin.MenuType;
import com.anthem.web.service.admin.MenuService;

@Service
public class GLPInit {
	private GLPMenuInit glpMenuInit;
	private MenuService menuService;

	@Autowired
	public GLPInit(GLPMenuInit glpMenuInit, MenuService menuService) {
		super();
		this.glpMenuInit = glpMenuInit;
		this.menuService = menuService;
	}

	@PostConstruct
	@Transactional
	public void init() {

		Privilege privilege = null;
		Menu menu = null;
		if (menuService.findByMenuState("app.GLP") == null) {
			menu = new Menu();
			menu.setMenuName("GLP");
			menu.setMenuState("app.GLP");
			menu.setMenuUrl("/glp");
			menu.setMenuTemplateUrl("dashboard/dashboard");
			menu.setMenuTitle("Dashboard");
			menu.setMenuType(MenuType.MENU);
			menu.setMenuOrder(1);
			privilege = new Privilege();
			privilege.setAuthority("CREATE");
			menu.setPrivilege(privilege);
			menu.setMenuClassName("zmdi zmdi-format-color-fill");
			menuService.addMenuInit(menu);
		}
		glpMenuInit.init();

	}
}
