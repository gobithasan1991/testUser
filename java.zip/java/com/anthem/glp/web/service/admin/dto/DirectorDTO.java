package com.anthem.glp.web.service.admin.dto;

import java.util.Date;

import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class DirectorDTO {

	private Long id;
	private IdCodeName glpDepartment;
	private UserBasicDetailsDTO director;
	private Date qauEvaluation;
	private String aoe;
	private String specialNotes;
	private EnabledStatus enabledStatus;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;
	private ApproveStatus approveStatus;

	public DirectorDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UserBasicDetailsDTO getDirector() {
		return director;
	}

	public void setDirector(UserBasicDetailsDTO director) {
		this.director = director;
	}

	public Date getQauEvaluation() {
		return qauEvaluation;
	}

	public void setQauEvaluation(Date qauEvaluation) {
		this.qauEvaluation = qauEvaluation;
	}

	public String getAoe() {
		return aoe;
	}

	public void setAoe(String aoe) {
		this.aoe = aoe;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public EnabledStatus getEnabledStatus() {
		return enabledStatus;
	}

	public void setEnabledStatus(EnabledStatus enabledStatus) {
		this.enabledStatus = enabledStatus;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public IdCodeName getGlpDepartment() {
		return glpDepartment;
	}

	public void setGlpDepartment(IdCodeName glpDepartment) {
		this.glpDepartment = glpDepartment;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

}
