package com.anthem.glp.web.service.admin.dto;

import java.util.Date;

import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class NomineeDto {
	private Long id;
	private String name;
	private String description;
	private SponsorDto sponsorDto;
	private String specialNotes;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	public NomineeDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public SponsorDto getSponsorDto() {
		return sponsorDto;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setSponsorDto(SponsorDto sponsorDto) {
		this.sponsorDto = sponsorDto;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "NomineeDto [id=" + id + ", name=" + name + ", description=" + description + ", sponsorDto=" + sponsorDto
				+ ", specialNotes=" + specialNotes + ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}
}
