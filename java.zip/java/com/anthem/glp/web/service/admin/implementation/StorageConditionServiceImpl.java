package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.StorageCondition;
import com.anthem.glp.persistence.repository.admin.StorageConditionRepo;
import com.anthem.glp.web.service.admin.StorageConditionService;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;

@Service
public class StorageConditionServiceImpl implements StorageConditionService {

	private StorageConditionRepo conditionRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public StorageConditionServiceImpl(StorageConditionRepo conditionRepo, ResponseMessage responseMessage) {
		super();
		this.conditionRepo = conditionRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	public String saveSConditions(List<IdCodeName> dtos) {
		String message = "Something went wrong !.";
		Iterator<IdCodeName> iterator = dtos.iterator();
		while (iterator.hasNext()) {
			IdCodeName dto = iterator.next();
			StorageCondition condition = new StorageCondition();
			condition.setName(dto.getName());
			condition = conditionRepo.save(condition);
			responseMessage.takeAuditTrail(condition.getId(), "Storage condition creation", null,
					"Storage condition: " + dto.getName() + " created.", condition.getCreatedBy());
		}
		message = "Success";
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdCodeName> fetchAllEnabledStorageConditions() {
		List<StorageCondition> conditions = conditionRepo.findAllEnabled(EnabledStatus.OPEN);
		List<IdCodeName> codeNames = new ArrayList<IdCodeName>();
		if (conditions != null && conditions.size() > 0) {
			codeNames = conditions.stream().map(mapper -> new IdCodeName(mapper.getId(), mapper.getName()))
					.collect(Collectors.toList());
		}
		return codeNames;
	}

}
