package com.anthem.glp.web.service.admin;

import java.util.List;

import com.anthem.web.service.common.dto.IdCodeName;

public interface PackageTypeService {
	public String savePackageType(List<IdCodeName> dtos);

	public List<IdCodeName> fetchAllEnabledPackageTypes();
}
