package com.anthem.glp.web.service.admin;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.glp.web.service.admin.dto.GLPDepartmentDTO;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface GLPDepartmentService {
	ReturnStatus save(GLPDepartment glpDepartment);
	
	List<IdNameCodeDTO> findAllGLPDepartments();

	Page<GLPDepartment> findGLPDepartmentForPageTable(int page, int size, String orderBy);

	List<GLPDepartment> findGLPDepartmentForHOD();

	public GLPDepartment findOne(Long glpDepartmentId);

	List<GLPDepartmentDTO> findGLPDepartmentByDepartment(long deptId);

	GLPDepartment checkDuplicateDepartment(String deptName);

	public List<GLPDepartment> findQmsDepartmentByNotInIds(List<Long> glpDepartmentIds);

	public Set<Long> getAllQmsDepartmentIds();

	public List<IdNameCodeDTO> getQmsDepartmentByQmsDepartmentNotIn(List<Long> glpDepartmentIds);

	public Long findDepartmentIdByQmsDepartmentId(Long glpDepartmentId);

	public GLPDepartmentDTO findGLPDepartmentDTOById(Long glpDepartmentId);
}
