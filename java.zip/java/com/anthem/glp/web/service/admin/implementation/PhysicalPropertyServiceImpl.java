package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.PhysicalProperty;
import com.anthem.glp.persistence.repository.admin.PhysicalPropertyRepo;
import com.anthem.glp.web.service.admin.PhysicalPropertyService;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;

@Service
public class PhysicalPropertyServiceImpl implements PhysicalPropertyService {

	private PhysicalPropertyRepo physicalPropertyRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public PhysicalPropertyServiceImpl(PhysicalPropertyRepo physicalPropertyRepo, ResponseMessage responseMessage) {
		super();
		this.physicalPropertyRepo = physicalPropertyRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	public String saveProperties(List<IdCodeName> dtos) {
		String message = "Something went wrong !.";
		Iterator<IdCodeName> iterator = dtos.iterator();
		while (iterator.hasNext()) {
			IdCodeName dto = iterator.next();
			PhysicalProperty physicalProperty = new PhysicalProperty();
			physicalProperty.setName(dto.getName());
			physicalProperty = physicalPropertyRepo.save(physicalProperty);
			responseMessage.takeAuditTrail(physicalProperty.getId(), "Physical property creation", null,
					"Physical property: " + dto.getName() + " created.", physicalProperty.getCreatedBy());

		}
		message = "Success";
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdCodeName> fetchAllEnabledPhysicalProperties() {
		List<PhysicalProperty> physicalProperties = physicalPropertyRepo.findAllEnabled(EnabledStatus.OPEN);
		List<IdCodeName> codeNames = new ArrayList<IdCodeName>();
		if (physicalProperties != null && physicalProperties.size() > 0) {
			codeNames = physicalProperties.stream().map(mapper-> new IdCodeName(mapper.getId(), mapper.getName())).collect(Collectors.toList());
		}
		return codeNames;
	}

}
