package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.Sponsor;
import com.anthem.glp.persistence.repository.admin.SponsorRepo;
import com.anthem.glp.web.service.admin.SponsorService;
import com.anthem.glp.web.service.admin.dto.SponsorDto;
import com.anthem.persistence.model.admin.Country;
import com.anthem.persistence.model.admin.State;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class SponsorServiceImpl implements SponsorService {

	private SponsorRepo sponsorRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public SponsorServiceImpl(SponsorRepo sponsorRepo, ResponseMessage responseMessage) {
		super();
		this.sponsorRepo = sponsorRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	public String saveSponsor(SponsorDto dto) {
		String message = "Something went wrong!.";
		Sponsor sponsor = convertToObject(dto);
		sponsor = sponsorRepo.save(sponsor);

		responseMessage.takeAuditTrail(sponsor.getId(), "Sponser creation", null,
				" Sponser - " + dto.getName() + " with contact " + dto.getContactName() + "created.",
				sponsor.getCreatedBy());

		message = "Success";
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdCodeName> fetchAllSponsors() {
		List<Sponsor> sponsors = sponsorRepo.findAllEnabled(EnabledStatus.OPEN);
		List<IdCodeName> codeNames = new ArrayList<IdCodeName>();
		if (sponsors != null && sponsors.size() > 0) {
			codeNames = sponsors.stream()
					.map(mapper -> new IdCodeName(mapper.getId(), mapper.getName(), mapper.getName()))
					.collect(Collectors.toList());
		}
		return codeNames;
	}

	@Override
	@Transactional(readOnly = true)
	public SponsorDto fetchSponsorDetails(Long sponsorId) {
		Sponsor sponsor = sponsorRepo.findOne(sponsorId);
		if (sponsor != null) {
			return convertToDto(sponsor);
		}
		return null;
	}

	public Sponsor convertToObject(SponsorDto dto) {
		Sponsor obj = new Sponsor();
		obj.setName(dto.getName());
		obj.setContactName(dto.getContactName());
		obj.setAddress(dto.getAddress());
		State state = new State();
		state.setId(dto.getState().getId());
		obj.setState(state);
		obj.setPinCode(dto.getPinCode());
		obj.setPhone(dto.getPhone());
		obj.setFax(dto.getFax());
		obj.setEmail(dto.getEmail());
		return obj;
	}

	public SponsorDto convertToDto(Sponsor obj) {
		SponsorDto dto = new SponsorDto();
		String displayAddress = "";
		dto.setId(obj.getId());
		dto.setName(obj.getName());
		dto.setContactName(obj.getContactName());
		dto.setAddress(obj.getAddress());
		Country country = obj.getState().getCountry();
		dto.setCountry(new IdCodeName(country.getId(), country.getCode(), country.getName()));
		State state = obj.getState();
		dto.setState(new IdCodeName(state.getId(), state.getCode(), state.getName()));
		dto.setPinCode(obj.getPinCode());
		dto.setPhone(obj.getPhone());
		displayAddress += "<b>Contact name: </b>"+dto.getContactName() + ".<br/><b>Address: </b> " + dto.getAddress() + ", " + dto.getState().getName() + " - "
				+ dto.getPinCode() + ", " + dto.getCountry().getName() + ".<br/><b>Phone: </b>" + dto.getPhone() + ".";

		dto.setDisplayAddress(displayAddress);
		dto.setFax(obj.getFax());
		dto.setEmail(obj.getEmail());
		dto.setCreatedBy(new UserBasicDetailsDTO(obj.getCreatedBy()));
		dto.setSpecialNotes(obj.getSpecialNotes());
		dto.setCreatedDate(obj.getCreatedDate());
		return dto;
	}

}
