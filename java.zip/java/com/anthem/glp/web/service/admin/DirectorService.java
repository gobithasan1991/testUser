package com.anthem.glp.web.service.admin;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anthem.glp.web.service.admin.dto.DirectorDTO;
import com.anthem.persistence.model.user.User;

public interface DirectorService {

	public String saveDirector(List<DirectorDTO> directorDTOs, User user);

	public List<DirectorDTO> fetchAllDirectorsByDepartment(Long deptId, User user);

	public Page<DirectorDTO> fetchAllDirectorsByDepartmentAndCreatedDate(Long deptId, Date fromDate, Date toDate,
			User user, Pageable pageable);

	public List<DirectorDTO> fetchAllDirectorsByDepartmentAndCreatedDateForPDF(Long deptId, Date fromDate, Date toDate,
			User user);
}
