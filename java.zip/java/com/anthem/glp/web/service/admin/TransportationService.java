package com.anthem.glp.web.service.admin;

import java.util.List;

import com.anthem.web.service.common.dto.IdCodeName;

public interface TransportationService {
	public String saveTransportation(List<IdCodeName> dtos);

	public List<IdCodeName> fetchAllEnabledTransportations();
}
