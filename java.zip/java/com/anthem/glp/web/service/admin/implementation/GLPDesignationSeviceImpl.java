package com.anthem.glp.web.service.admin.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anthem.glp.persistence.model.admin.GLPDesignation;
import com.anthem.glp.persistence.repository.admin.GLPDesignationRepo;
import com.anthem.glp.web.service.admin.GLPDesignationService;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

@Service
public class GLPDesignationSeviceImpl implements GLPDesignationService {
	private GLPDesignationRepo glpDesignationRepo;
	private ResponseMessage responseMessage;
	
	@Autowired
	public GLPDesignationSeviceImpl(GLPDesignationRepo glpDesignationRepo, ResponseMessage responseMessage) {
		super();
		this.glpDesignationRepo = glpDesignationRepo;
		this.responseMessage = responseMessage;
	}
	
	@Override
	public ReturnStatus save(GLPDesignation glpDesignation) {
		try {
			glpDesignation.setEnabled(Boolean.TRUE);
			glpDesignationRepo.save(glpDesignation);			
			responseMessage.takeAuditTrail(glpDesignation.getId(), "Designation", null, "GLP Designation " + glpDesignation.getName() + " (" + glpDesignation.getCode() + ") has been created", responseMessage.loggedUser());
			return ReturnStatus.SUCCESS;
		} catch (Exception e) {
			return ReturnStatus.ALREADYEXISTS;
		}
	}

	@Override
	public List<IdNameCodeDTO> findAllGLPDesignations() {
		return glpDesignationRepo.findAllGLPDesignations(EnabledStatus.OPEN);
	}
}
