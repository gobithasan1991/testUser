package com.anthem.glp.web.service.admin.dto;

import java.util.Date;

import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class SponsorDto {

	private Long id;
	private String name;
	private String contactName;
	private String address;
	private IdCodeName country;
	private IdCodeName state;
	private String pinCode;
	private String phone;
	private String fax;
	private String email;
	private String specialNotes;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	private String displayAddress;

	public SponsorDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getContactName() {
		return contactName;
	}

	public String getAddress() {
		return address;
	}

	public IdCodeName getCountry() {
		return country;
	}

	public IdCodeName getState() {
		return state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public String getPhone() {
		return phone;
	}

	public String getFax() {
		return fax;
	}

	public String getEmail() {
		return email;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setCountry(IdCodeName country) {
		this.country = country;
	}

	public void setState(IdCodeName state) {
		this.state = state;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDisplayAddress() {
		return displayAddress;
	}

	public void setDisplayAddress(String displayAddress) {
		this.displayAddress = displayAddress;
	}

	@Override
	public String toString() {
		return "SponsorDto [id=" + id + ", name=" + name + ", contactName=" + contactName + ", address=" + address
				+ ", country=" + country + ", state=" + state + ", pinCode=" + pinCode + ", phone=" + phone + ", fax="
				+ fax + ", email=" + email + ", specialNotes=" + specialNotes + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + "]";
	}

}
