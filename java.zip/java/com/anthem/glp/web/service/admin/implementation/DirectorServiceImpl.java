package com.anthem.glp.web.service.admin.implementation;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.DirectorMaster;
import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.glp.persistence.repository.admin.DirectorMasterRepo;
import com.anthem.glp.web.service.admin.DirectorService;
import com.anthem.glp.web.service.admin.dto.DirectorDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class DirectorServiceImpl implements DirectorService {

	SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy");

	public static DirectorDTO convertDto(DirectorMaster obj) {
		DirectorDTO dto = new DirectorDTO();
		dto.setId(obj.getId());
		dto.setGlpDepartment(new IdCodeName(obj.getGlpDepartment().getId(), obj.getGlpDepartment().getCode(),
				obj.getGlpDepartment().getName()));
		dto.setDirector(new UserBasicDetailsDTO(obj.getDirector()));
		dto.setQauEvaluation(obj.getQauEvaluation());
		dto.setAoe(obj.getAoe());
		dto.setSpecialNotes(obj.getSpecialNotes());
		dto.setEnabledStatus(obj.getEnabledStatus());
		dto.setCreatedBy(new UserBasicDetailsDTO(obj.getCreatedBy()));
		dto.setCreatedDate(obj.getCreatedDate());
		return dto;
	}

	public static DirectorMaster convertObject(DirectorDTO dto) {
		DirectorMaster obj = new DirectorMaster();
		obj.setGlpDepartment(new GLPDepartment(dto.getGlpDepartment().getId()));
		obj.setDirector(new User(dto.getDirector().getId()));
		obj.setQauEvaluation(dto.getQauEvaluation());
		obj.setAoe(dto.getAoe());
		return obj;
	}

	static Page<DirectorDTO> converPagable(Page<DirectorMaster> pageObj, Pageable pageable) {
		Page<DirectorDTO> page = new PageImpl<>(new ArrayList<>());
		List<DirectorDTO> dtos = new ArrayList<>();
		if (pageObj.getContent() != null && pageObj.getContent().size() > 0) {
			dtos = pageObj.getContent().stream().map(mapper -> convertDto(mapper)).collect(Collectors.toList());
			page = new PageImpl<>(dtos, pageable, pageObj.getTotalElements());
		}
		return page;
	}

	private DirectorMasterRepo directorMasterRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public DirectorServiceImpl(DirectorMasterRepo directorMasterRepo, ResponseMessage responseMessage) {
		super();
		this.directorMasterRepo = directorMasterRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	@Transactional
	public String saveDirector(List<DirectorDTO> directorDTOs, User user) {
		String message = "Something went wrong!.";
		Branch branch = user.getBranches().stream().filter(predicate -> predicate.isSelectedBranch() == true)
				.findFirst().orElse(null);
		if (branch != null) {
			Iterator<DirectorDTO> iterator = directorDTOs.iterator();
			while (iterator.hasNext()) {
				DirectorDTO directorDTO = iterator.next();
				DirectorMaster master = convertObject(directorDTO);
				master.setBranch(branch);
				master = directorMasterRepo.save(master);
				responseMessage.takeAuditTrail(master.getId(), "Study Director Master", null,
						"Study director '" + directorDTO.getDirector().getDisplayName()
								+ "' added with QAU evaluation date '" + sf.format(directorDTO.getQauEvaluation())
								+ "' and area of expertise '" + directorDTO.getAoe() + "'.",
						master.getCreatedBy());
			}
			message = "Success";
		}
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public List<DirectorDTO> fetchAllDirectorsByDepartment(Long deptId, User user) {
		List<DirectorDTO> dtos = new ArrayList<DirectorDTO>();
		Branch branch = user.getBranches().stream().filter(predicate -> predicate.isSelectedBranch() == true)
				.findFirst().orElse(null);
		List<DirectorMaster> directorMasters = directorMasterRepo.findAllByDepartmentAndBranch(deptId, branch.getId(),
				EnabledStatus.OPEN);
		dtos = directorMasters.stream().map(mapper -> convertDto(mapper)).collect(Collectors.toList());
		return dtos;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<DirectorDTO> fetchAllDirectorsByDepartmentAndCreatedDate(Long deptId, Date fromDate, Date toDate,
			User user, Pageable pageable) {
		if (toDate != null) {
			toDate = Date.from(toDate.toInstant().atZone(ZoneId.systemDefault()).withHour(23).withMinute(59)
					.withSecond(59).toInstant());
		}
		Page<DirectorMaster> page = new PageImpl<>(new ArrayList<>());
		if (toDate != null) {
			toDate = Date.from(toDate.toInstant().atZone(ZoneId.systemDefault()).withHour(23).withMinute(59)
					.withSecond(59).toInstant());
		}
		Branch branch = user.getBranches().stream().filter(predicate -> predicate.isSelectedBranch() == true)
				.findFirst().orElse(null);
		if (deptId != null && deptId != 0) {
			page = directorMasterRepo.findAllByDepartmentAndCreatedDate(deptId, fromDate, toDate, branch.getId(),
					EnabledStatus.OPEN, pageable);
		} else {
			page = directorMasterRepo.findAllByCreatedDate(fromDate, toDate, branch.getId(), EnabledStatus.OPEN,
					pageable);
		}
		return converPagable(page, pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public List<DirectorDTO> fetchAllDirectorsByDepartmentAndCreatedDateForPDF(Long deptId, Date fromDate, Date toDate,
			User user) {
		if (toDate != null) {
			toDate = Date.from(toDate.toInstant().atZone(ZoneId.systemDefault()).withHour(23).withMinute(59)
					.withSecond(59).toInstant());
		}
		List<DirectorMaster> directos = new ArrayList<DirectorMaster>();
		List<DirectorDTO> directorDTOs = new ArrayList<DirectorDTO>();
		Branch branch = user.getBranches().stream().filter(predicate -> predicate.isSelectedBranch() == true)
				.findFirst().orElse(null);
		if (toDate != null) {
			toDate = Date.from(toDate.toInstant().atZone(ZoneId.systemDefault()).withHour(23).withMinute(59)
					.withSecond(59).toInstant());
		}
		if (deptId != null && deptId != 0) {
			directos = directorMasterRepo.fetchAllDirectorsByDepartmentAndCreatedDateForPDF(deptId, fromDate, toDate,
					branch.getId(), EnabledStatus.OPEN);
		} else {
			directos = directorMasterRepo.findAllByCreatedDateForPDF(fromDate, toDate, branch.getId(),
					EnabledStatus.OPEN);
		}
		directorDTOs = directos.stream().map(mapper -> convertDto(mapper)).collect(Collectors.toList());
		return directorDTOs;
	}

}
