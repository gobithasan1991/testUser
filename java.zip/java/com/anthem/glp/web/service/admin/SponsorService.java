package com.anthem.glp.web.service.admin;

import java.util.List;

import com.anthem.glp.web.service.admin.dto.SponsorDto;
import com.anthem.web.service.common.dto.IdCodeName;

public interface SponsorService {
	public String saveSponsor(SponsorDto sponsor);

	public List<IdCodeName> fetchAllSponsors();

	public SponsorDto fetchSponsorDetails(Long sponsorId);
}
