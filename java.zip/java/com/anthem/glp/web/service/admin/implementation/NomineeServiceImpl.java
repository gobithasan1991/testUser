package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.Nominee;
import com.anthem.glp.persistence.model.admin.Sponsor;
import com.anthem.glp.persistence.repository.admin.NomineeRepo;
import com.anthem.glp.persistence.repository.admin.SponsorRepo;
import com.anthem.glp.web.service.admin.NomineeService;
import com.anthem.glp.web.service.admin.dto.NomineeDto;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;

@Service
public class NomineeServiceImpl implements NomineeService {

	private NomineeRepo nomineeRepo;
	private SponsorRepo sponsorRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public NomineeServiceImpl(NomineeRepo nomineeRepo, SponsorRepo sponsorRepo, ResponseMessage responseMessage) {
		super();
		this.nomineeRepo = nomineeRepo;
		this.sponsorRepo = sponsorRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdCodeName> fetchAllEnabledBySponsor(Long sponsorId) {
		List<Nominee> nominees = nomineeRepo.findAllEnabledBySponsor(sponsorId, EnabledStatus.OPEN);
		List<IdCodeName> codeNames = new ArrayList<IdCodeName>();
		if (nominees != null && nominees.size() > 0) {
			codeNames = nominees.stream()
					.map(mapper -> new IdCodeName(mapper.getId(), mapper.getName(), mapper.getName()))
					.collect(Collectors.toList());
		}
		return codeNames;
	}

	@Override
	@Transactional
	public String saveNominee(List<NomineeDto> nomineeDtos) {
		String message = "Something went wrong !.";
		Iterator<NomineeDto> iterator = nomineeDtos.iterator();
		while (iterator.hasNext()) {
			Nominee nominee = convertToObj(iterator.next());
			Nominee savedNomine = nomineeRepo.save(nominee);
			responseMessage.takeAuditTrail(
					savedNomine.getId(), "Nominee creation", null, "Nominee with name - " + nominee.getName()
							+ " created for sponsor - " + nominee.getSponsor().getName() + ".",
					savedNomine.getCreatedBy());
		}
		message = "Success";
		return message;
	}

	public Nominee convertToObj(NomineeDto dto) {
		Nominee obj = new Nominee();
		obj.setName(dto.getName());
		obj.setDescription(dto.getDescription());
		Sponsor sponsor = sponsorRepo.findOne(dto.getSponsorDto().getId());
		obj.setSponsor(sponsor);

		return obj;
	}

	public NomineeDto convertToDto(Nominee obj) {
		return null;
	}

}
