package com.anthem.glp.web.service.admin;

import java.util.List;

import com.anthem.glp.web.service.admin.dto.NomineeDto;
import com.anthem.web.service.common.dto.IdCodeName;

public interface NomineeService {
	public List<IdCodeName> fetchAllEnabledBySponsor(Long sponsorId);

	public String saveNominee(List<NomineeDto> nomineeDtos);
}
