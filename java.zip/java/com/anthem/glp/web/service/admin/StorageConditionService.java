package com.anthem.glp.web.service.admin;

import java.util.List;

import com.anthem.web.service.common.dto.IdCodeName;

public interface StorageConditionService {
	public String saveSConditions(List<IdCodeName> dtos);

	public List<IdCodeName> fetchAllEnabledStorageConditions();
}
