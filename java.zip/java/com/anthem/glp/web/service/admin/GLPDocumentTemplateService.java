package com.anthem.glp.web.service.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.persistence.model.user.User;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface GLPDocumentTemplateService {

	public String saveGlpDocumentTemplate(GLPDocumentTemplate glpDocumentTemplate, MultipartFile file, User user,
			String convertedFile, boolean isConverted, String fileType, HttpServletRequest request,
			HttpServletResponse response) throws IOException;

	public List<IdNameCodeDTO> getAllGlpDocumentTemplates();

	public GLPDocumentTemplate getGlpDocumentTemplateById(Long id);

	public List<IdNameCodeDTO> getGlpDocumentTemplatesByCategory(String tempCategory);

}
