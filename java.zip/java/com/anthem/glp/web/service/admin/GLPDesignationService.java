package com.anthem.glp.web.service.admin;

import java.util.List;

import com.anthem.glp.persistence.model.admin.GLPDesignation;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface GLPDesignationService {
	ReturnStatus save(GLPDesignation glpDesignation);
	
	List<IdNameCodeDTO> findAllGLPDesignations();
}
