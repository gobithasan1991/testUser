package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.Transportation;
import com.anthem.glp.persistence.repository.admin.TransportationRepo;
import com.anthem.glp.web.service.admin.TransportationService;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;

@Service
public class TransportationServiceImpl implements TransportationService {

	private TransportationRepo transportationRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public TransportationServiceImpl(TransportationRepo transportationRepo, ResponseMessage responseMessage) {
		super();
		this.transportationRepo = transportationRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	public String saveTransportation(List<IdCodeName> dtos) {
		String message = "Something went wrong!.";
		Iterator<IdCodeName> iterator = dtos.iterator();
		while (iterator.hasNext()) {
			IdCodeName dto = iterator.next();
			Transportation transportation = new Transportation();
			transportation.setName(dto.getName());
			transportation = transportationRepo.save(transportation);
			responseMessage.takeAuditTrail(transportation.getId(), "Transportation Master", null,
					"Transportation: " + dto.getName() + " created.", transportation.getCreatedBy());
			message = "Success";
		}
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdCodeName> fetchAllEnabledTransportations() {
		List<Transportation> transportations = transportationRepo.findAllEnabled(EnabledStatus.OPEN);
		List<IdCodeName> codeNames = new ArrayList<>();
		if (transportations != null && transportations.size() > 0) {
			codeNames = transportations.stream().map(mapper -> new IdCodeName(mapper.getId(), mapper.getName()))
					.collect(Collectors.toList());
		}
		return codeNames;
	}

}
