package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.glp.persistence.repository.admin.GLPDepartmentRepo;
import com.anthem.glp.web.service.admin.GLPDepartmentService;
import com.anthem.glp.web.service.admin.dto.GLPDepartmentDTO;
import com.anthem.persistence.auditor.UsernameAuditorAware;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.admin.Employee;
import com.anthem.persistence.repository.admin.HODMasterRepo;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

@Service
public class GLPDepartmentSeviceImpl implements GLPDepartmentService {
	private GLPDepartmentRepo glpDepartmentRepo;
	private HODMasterRepo hodMasterRepo;
	private UsernameAuditorAware usernameAuditorAware;
	private ResponseMessage responseMessage;
	
	
	
	@Autowired
	public GLPDepartmentSeviceImpl(GLPDepartmentRepo glpDepartmentRepo, HODMasterRepo hodMasterRepo, UsernameAuditorAware usernameAuditorAware, ResponseMessage responseMessage) {
		super();
		this.glpDepartmentRepo = glpDepartmentRepo;
		this.hodMasterRepo = hodMasterRepo;
		this.usernameAuditorAware = usernameAuditorAware;
		this.responseMessage = responseMessage;
	}

	@Override
	public ReturnStatus save(GLPDepartment glpDepartment) {
		try {
			glpDepartment.setEnabled(Boolean.TRUE);
			glpDepartmentRepo.save(glpDepartment);
			responseMessage.takeAuditTrail(glpDepartment.getId(), "Department", null, "GLP Department " + glpDepartment.getName() + " (" + glpDepartment.getCode() + ") has been created", responseMessage.loggedUser());
			return ReturnStatus.SUCCESS;
		} catch (Exception e) {
			return ReturnStatus.ALREADYEXISTS;
		}
	}
	
	@Override
	public List<IdNameCodeDTO> findAllGLPDepartments() {
		return glpDepartmentRepo.findAllQDeptIsEnabled(EnabledStatus.OPEN);

	}

	@Override
	public Page<GLPDepartment> findGLPDepartmentForPageTable(int page, int size, String orderby) {
		return glpDepartmentRepo.getGLPDepartmentWithPageableData(Boolean.TRUE,
				new PageRequest(page, size, Direction.ASC, orderby));
	}

	@Override
	public List<GLPDepartment> findGLPDepartmentForHOD() {
		Employee employee = new Employee();
		List<GLPDepartment> glpDepartments = new ArrayList<>();
		employee = usernameAuditorAware.getCurrentAuditor().getEmployee();
		if (employee != null && hodMasterRepo.findHeadOfDepartment(EnabledStatus.OPEN, employee.getId()) != null) {
			// glpDepartments = glpDepartmentRepo
			// .findByDepartment(usernameAuditorAware.getCurrentAuditor().getQmsDepartment().getDepartment());

		}
		return glpDepartments;
	}

	@Override
	@Transactional(readOnly = true)
	public GLPDepartment findOne(Long glpDepartmentId) {
		return glpDepartmentRepo.findOne(glpDepartmentId);
	}

	@Override
	public List<GLPDepartmentDTO> findGLPDepartmentByDepartment(long deptId) {
		List<GLPDepartmentDTO> glpDepartmentDTOs = new ArrayList<>();
		Department department = new Department();
		department.setId(deptId);
		List<GLPDepartment> glpDepartments = glpDepartmentRepo.findByDepartment(department);
		Iterator<GLPDepartment> iterator = glpDepartments.iterator();
		while (iterator.hasNext()) {
			GLPDepartment glpDepartment = iterator.next();
			GLPDepartmentDTO glpDepartmentDTO = new GLPDepartmentDTO();
			glpDepartmentDTO.setId(glpDepartment.getId());
			glpDepartmentDTO.setCode(glpDepartment.getCode());
			glpDepartmentDTO.setName(glpDepartment.getName());
			glpDepartmentDTOs.add(glpDepartmentDTO);
		}

		return glpDepartmentDTOs;
	}

	@Override
	public GLPDepartment checkDuplicateDepartment(String deptName) {
		return glpDepartmentRepo.findByName(deptName);
	}

	@Override
	public List<GLPDepartment> findQmsDepartmentByNotInIds(List<Long> glpDepartmentIds) {
		List<GLPDepartment> glpDepartments = glpDepartmentRepo.findQmsDepartmentByNotInIds(glpDepartmentIds,
				Boolean.TRUE);
		return (glpDepartments != null ? glpDepartments : new ArrayList<>());
	}

	@Override
	public Set<Long> getAllQmsDepartmentIds() {
		return glpDepartmentRepo.findAllQmsDepartmentIds(EnabledStatus.OPEN);
	}

	@Override
	public List<IdNameCodeDTO> getQmsDepartmentByQmsDepartmentNotIn(List<Long> glpDepartmentIds) {

		return glpDepartmentRepo.findQmsDepartmentByQmsDepartmentNotIn(glpDepartmentIds, EnabledStatus.OPEN);
	}

	@Override
	public Long findDepartmentIdByQmsDepartmentId(Long glpDepartmentId) {
		return glpDepartmentRepo.findDepartmentIdByQmsDepartmentId(glpDepartmentId, EnabledStatus.OPEN);
	}

	@Override
	@Transactional(readOnly=true)
	public GLPDepartmentDTO findGLPDepartmentDTOById(Long glpDepartmentId) {
		GLPDepartmentDTO glpDepartmentDTO = null;
		GLPDepartment glpDepartment = glpDepartmentRepo.getOne(glpDepartmentId);
		if(glpDepartment != null) {
			glpDepartmentDTO = new GLPDepartmentDTO(glpDepartment.getId(), glpDepartment.getCode(), glpDepartment.getName());
		}
		return glpDepartmentDTO;
	}
}
