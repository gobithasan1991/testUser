package com.anthem.glp.web.service.admin.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.PackageType;
import com.anthem.glp.persistence.repository.admin.PackageTypeRepo;
import com.anthem.glp.web.service.admin.PackageTypeService;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.common.dto.IdCodeName;

@Service
public class PackageTypeServiceImpl implements PackageTypeService {

	private PackageTypeRepo packageTypeRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public PackageTypeServiceImpl(PackageTypeRepo packageTypeRepo, ResponseMessage responseMessage) {
		super();
		this.packageTypeRepo = packageTypeRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	public String savePackageType(List<IdCodeName> dtos) {
		String message = "Something went wrong !.";
		Iterator<IdCodeName> iterator = dtos.iterator();
		while (iterator.hasNext()) {
			IdCodeName dto = iterator.next();
			PackageType packageType = new PackageType();
			packageType.setName(dto.getName());
			packageType = packageTypeRepo.save(packageType);
			responseMessage.takeAuditTrail(packageType.getId(), "Package type creation", null,
					"Package type: " + dto.getName() + " created.", packageType.getCreatedBy());
		}
		message = "Success";
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdCodeName> fetchAllEnabledPackageTypes() {
		List<PackageType> packageTypes = packageTypeRepo.findAllEnabled(EnabledStatus.OPEN);
		List<IdCodeName> codeNames = new ArrayList<IdCodeName>();
		if (packageTypes != null && packageTypes.size() > 0) {
			codeNames = packageTypes.stream().map(mapper -> new IdCodeName(mapper.getId(), mapper.getName()))
					.collect(Collectors.toList());
		}
		return codeNames;
	}

}
