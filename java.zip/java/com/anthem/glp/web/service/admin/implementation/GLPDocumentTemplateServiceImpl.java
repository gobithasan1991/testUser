package com.anthem.glp.web.service.admin.implementation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.anthem.document.helpers.DocumentManager;
import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.glp.persistence.repository.admin.GLPDocumentTemplateRepo;
import com.anthem.glp.web.service.admin.GLPDocumentTemplateService;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.Constants;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

@Service
public class GLPDocumentTemplateServiceImpl implements GLPDocumentTemplateService {

	private GLPDocumentTemplateRepo glpDocumentTemplateRepo;

	public GLPDocumentTemplateServiceImpl(GLPDocumentTemplateRepo glpDocumentTemplateRepo) {
		super();
		this.glpDocumentTemplateRepo = glpDocumentTemplateRepo;
	}

	@Override
	@Transactional
	@Modifying(clearAutomatically = true)
	public String saveGlpDocumentTemplate(GLPDocumentTemplate glpDocumentTemplate, MultipartFile file, User user,
			String convertedFile, boolean isConverted, String fileType, HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		String ext = "", fileId = "", currentversionNo = "", hostAddress = "", path = "";
		String[] arr = { ".docx", ".xlsx", ".pptx" };
		String[] words = { "Word", "Excel", "Presentation" };
		InputStream stream = null;
		if (isConverted) {
			ext = convertedFile.substring(convertedFile.lastIndexOf("."), convertedFile.length());
		} else if (fileType != null && fileType.trim().length() > 0) {
			for (int i = 0; i < words.length; i++) {
				if (fileType.equals(words[i])) {
					ext = arr[i];
					break;
				}
			}
		} else {
			ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."),
					file.getOriginalFilename().length());
		}
		fileId = "GLP" + System.currentTimeMillis()
				+ String.format(Constants.NUMBER_FORMAT_CONSTANT_3, glpDocumentTemplateRepo.count() + 1);
		glpDocumentTemplate.setFileId(fileId + ext);
		glpDocumentTemplate.setFileUUID(fileId);
		currentversionNo = String.format(Constants.NUMBER_FORMAT_CONSTANT_3,
				Integer.parseInt(glpDocumentTemplate.getVersionNo()));
		glpDocumentTemplate.setCurrentVersion(currentversionNo);
		glpDocumentTemplate.setTemplateStatus(CustomStatus.CREATED);
		glpDocumentTemplate.setProcessIn(CustomStatus.CREATED);
		glpDocumentTemplate.setCurrentVersiontemplate(glpDocumentTemplate.getFileId());
		glpDocumentTemplate = glpDocumentTemplateRepo.save(glpDocumentTemplate);

		DocumentManager.Init(request, response);
		hostAddress = DocumentManager.CurUserHostAddress(null);
		
		if (isConverted) {
			File f = new File(DocumentManager.StoragePath(convertedFile, hostAddress));
			stream = new FileInputStream(f);
		} else if (fileType != null && fileType.trim().length() > 0) {
			stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("sample" + ext);
		} else {
			stream = file.getInputStream();
		}
		path = DocumentManager.StoragePath(glpDocumentTemplate.getFileId(), hostAddress);
		DocumentManager.createDemo(path, stream, String.valueOf(glpDocumentTemplate.getFileId()), user.getId() + "",
				user.getFullName(), true);
		glpDocumentTemplate = glpDocumentTemplateRepo.findOne(glpDocumentTemplate.getId());
		return "GLP Document Template Created Successfully";
	}

	@Override
	public List<IdNameCodeDTO> getAllGlpDocumentTemplates() {

		List<IdNameCodeDTO> idNameCodeDTOs = new ArrayList<>();
		List<GLPDocumentTemplate> glpDocumentTemplates = glpDocumentTemplateRepo
				.getAllGlpDocumentTemplates(EnabledStatus.OPEN);
		glpDocumentTemplates.forEach(glpDocumentTemplate -> {
			IdNameCodeDTO idNameCodeDTO = new IdNameCodeDTO(glpDocumentTemplate.getId(), glpDocumentTemplate.getName());
			idNameCodeDTOs.add(idNameCodeDTO);
		});
		return idNameCodeDTOs;
	}

	@Override
	public GLPDocumentTemplate getGlpDocumentTemplateById(Long id) {
		
		return glpDocumentTemplateRepo.getGlpDocumentTemplateById(id, EnabledStatus.OPEN);
	}

	@Override
	public List<IdNameCodeDTO> getGlpDocumentTemplatesByCategory(String tempCategory) {
		
		List<IdNameCodeDTO> idNameCodeDTOs = new ArrayList<>();
		List<GLPDocumentTemplate> glpDocumentTemplates = glpDocumentTemplateRepo.getGlpDocumentTemplatesByCategory(tempCategory, EnabledStatus.OPEN);
		glpDocumentTemplates.forEach(glpDocumentTemplate -> {
			IdNameCodeDTO idNameCodeDTO = new IdNameCodeDTO(glpDocumentTemplate.getId(), glpDocumentTemplate.getName());
			idNameCodeDTOs.add(idNameCodeDTO);
		});
		return idNameCodeDTOs;
	}

}
