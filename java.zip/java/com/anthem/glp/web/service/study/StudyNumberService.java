package com.anthem.glp.web.service.study;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.glp.web.service.study.dto.StudyUserRoleDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.web.service.common.dto.IdCodeName;

public interface StudyNumberService {

	public String generateStudyNumber(StudyNumber studyNumber, User user);

	public StudyDetailsDTO getStudyDetails(Long studyId);

	public Page<StudyNumberDTO> getAllStudyNumbers(Pageable pagable);

	public Page<StudyNumberDTO> getStudyNumbersForProtocolReview(Pageable pagable, User user);

	public Page<StudyNumberDTO> getStudyNumbersForProtocolApprove(Pageable pagable, User user);

	public StudyNumberDTO getStudyNumberDetailsById(Long studyNumberId);

	public Page<StudyNumberDTO> getStudyNumberDetailsBySponsorId(List<Branch> selectedBranches, Long sponsorId,
			Pageable pagable);

	public Page<StudyNumberDTO> getStudyNumberDetailsByAll(List<Branch> selectedBranches, Pageable pagable);

	public List<StudyUserRoleDTO> fetchStudyRoleDetailsByUser(Long userId);

	public Page<StudyNumberDTO> getAllStudyNumberDetailsByDate(Long from, Long to, Pageable pageable);

	public Page<StudyDetailsDTO> getStudyAllotmentLetter(Long fromDate, Long toDate, User user, Pageable pageable);

	public Page<StudyDetailsDTO> getStudyAllotmentLetterTable(User user, Pageable pageable);

	public Page<StudyNumberDTO> getStudyNumbersForProtocol(Pageable pagable);

	public List<StudyUserRoleDTO> fetchStudyDetailsByUserIdAndRole(Long userId, String studyUserRole,
			ApproveStatus approveStatus);

	public Page<StudyNumberDTO> getStudyNumbersForPlan(Pageable pagable);

	public Page<StudyNumberDTO> getStudyNumbersForPlanModify(Pageable pagable, User user);

	public Page<StudyNumberDTO> getStudyNumbersForPlanReview(Pageable pagable, User user);

	public Page<StudyNumberDTO> getStudyNumbersForPlanApprove(Pageable pagable, User user);

	public Page<StudyNumberDTO> getPlanApprovedStudyNumbers(Pageable pagable);

	public Map<String, Integer> getStudyNumberCountForDashboard();

	public Page<StudyNumberDTO> getStudyNumbersByStatus(String status, Pageable pageable);

	public Page<StudyNumberDTO> getStudyNumberByNotINStatus(String status, Pageable pageable);

	public Page<StudyNumberDTO> fetchAllStudyNumbersForPersonnelAllocation(User user, Pageable pagable);

	public StudyDetailsDTO getStudyPlanForUser(Long studyId, String reviewType, User user);

	public List<IdCodeName> getICN();

}
