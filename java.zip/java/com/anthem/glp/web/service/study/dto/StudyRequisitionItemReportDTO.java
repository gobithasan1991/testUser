package com.anthem.glp.web.service.study.dto;

import com.anthem.glp.persistence.model.study.StudyRequisitionItem;

public class StudyRequisitionItemReportDTO {
	private Long id;
	private String sopNo;
	private String sopVersionNo;
	private String annexureNo;
	private String pageNo;
	private String title;
	private Long noOfCopies;
	
	public StudyRequisitionItemReportDTO() {
		super();
	}
	
	public StudyRequisitionItemReportDTO(StudyRequisitionItem studyRequisitionItem) {
		super();
		this.id = studyRequisitionItem.getId();
		this.sopNo = studyRequisitionItem.getSopNo();
		this.sopVersionNo = studyRequisitionItem.getSopVersionNo();
		this.annexureNo = studyRequisitionItem.getAnnexureNo();
		this.pageNo = studyRequisitionItem.getPageNo();
		this.title = studyRequisitionItem.getTitle();
		this.noOfCopies = studyRequisitionItem.getNoOfCopies();
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSopNo() {
		return sopNo;
	}
	public void setSopNo(String sopNo) {
		this.sopNo = sopNo;
	}
	public String getSopVersionNo() {
		return sopVersionNo;
	}

	public void setSopVersionNo(String sopVersionNo) {
		this.sopVersionNo = sopVersionNo;
	}

	public String getAnnexureNo() {
		return annexureNo;
	}
	public void setAnnexureNo(String annexureNo) {
		this.annexureNo = annexureNo;
	}
	public String getPageNo() {
		return pageNo;
	}
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Long getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(Long noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
}
