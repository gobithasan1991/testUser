package com.anthem.glp.web.service.study.dto;

import com.anthem.glp.persistence.model.study.FolderLocationAndTitle;
import com.anthem.web.service.common.dto.DefaultsDTO;

public class FolderLocationAndTitleDTO extends DefaultsDTO {
	private Long id;

	private String folderLocation;

	private String folderTitle;

	public FolderLocationAndTitleDTO() {
		super();
	}

	public FolderLocationAndTitleDTO(FolderLocationAndTitle folderLocationAndTitle) {
		super();
		this.setId(folderLocationAndTitle.getId());
		this.setFolderLocation(folderLocationAndTitle.getFolderLocation());
		this.setFolderTitle(folderLocationAndTitle.getFolderLocation());
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the folderLocation
	 */
	public String getFolderLocation() {
		return folderLocation;
	}

	/**
	 * @param folderLocation the folderLocation to set
	 */
	public void setFolderLocation(String folderLocation) {
		this.folderLocation = folderLocation;
	}

	/**
	 * @return the folderTitle
	 */
	public String getFolderTitle() {
		return folderTitle;
	}

	/**
	 * @param folderTitle the folderTitle to set
	 */
	public void setFolderTitle(String folderTitle) {
		this.folderTitle = folderTitle;
	}

}
