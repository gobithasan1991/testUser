package com.anthem.glp.web.service.study.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.study.StudyAllotmentLetterDistributionList;
import com.anthem.glp.persistence.repository.study.StudyAllotmentLetterDistributionListRepo;
import com.anthem.glp.persistence.repository.study.StudyDirectorRepo;
import com.anthem.glp.persistence.repository.study.StudyNumberRepo;
import com.anthem.glp.persistence.repository.study.StudyPersonnelRepo;
import com.anthem.glp.persistence.repository.study.StudyProtocolRepo;
import com.anthem.glp.web.service.study.StudyAllotmentLetterDistributionListService;
import com.anthem.glp.web.service.study.dto.StudyAllotmentLetterDistributionListDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.EnabledStatus;

@Service
public class StudyAllotmentLetterDistributionListServiceImpl implements StudyAllotmentLetterDistributionListService {
	
	private StudyAllotmentLetterDistributionListRepo studyAllotmentLetterDistributionListRepo;
	private StudyNumberRepo studyNumberRepo;
	private StudyDirectorRepo directorRepo;
	private StudyPersonnelRepo personnelRepo;
	private StudyProtocolRepo protocolRepo;
	
	public StudyAllotmentLetterDistributionListServiceImpl() {
		super();
	}
	
	@Autowired
	public StudyAllotmentLetterDistributionListServiceImpl(StudyAllotmentLetterDistributionListRepo studyAllotmentLetterDistributionListRepo, StudyNumberRepo studyNumberRepo, StudyDirectorRepo directorRepo, StudyPersonnelRepo personnelRepo, StudyProtocolRepo protocolRepo) {
		super();
		this.studyAllotmentLetterDistributionListRepo = studyAllotmentLetterDistributionListRepo;
		this.studyNumberRepo = studyNumberRepo;
		this.directorRepo = directorRepo;
		this.personnelRepo = personnelRepo;
		this.protocolRepo = protocolRepo;
	}

	@Override
	public String saveStudyAllotmentDistribution(StudyAllotmentLetterDistributionList studyAllotmentLetterDistributionList, User user) {
		studyAllotmentLetterDistributionListRepo.save(studyAllotmentLetterDistributionList);
		return "Printed document for study number " + studyAllotmentLetterDistributionList.getStudyNumber().getStudyNumber();
	}

	@Override
	@Transactional(readOnly = true)
	public List<StudyAllotmentLetterDistributionListDTO> getStudyDetailsForPrint(Long studyId) {
		return studyAllotmentLetterDistributionListRepo.getByStudyNumber(studyId, EnabledStatus.OPEN);
	}
}
