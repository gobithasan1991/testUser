package com.anthem.glp.web.service.study;

public interface FolderAccessService {

}
