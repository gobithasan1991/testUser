package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.persistence.model.study.StudyAllotmentLetterDistributionList;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyAllotmentLetterDistributionListDTO {

	private Long id;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	public StudyAllotmentLetterDistributionListDTO() {
		super();
	}

	public StudyAllotmentLetterDistributionListDTO(StudyAllotmentLetterDistributionList studyNumberAllotmentLetterDistributionList) {
		super();
		this.id = studyNumberAllotmentLetterDistributionList.getId();
		this.createdBy = new UserBasicDetailsDTO(studyNumberAllotmentLetterDistributionList.getCreatedBy());
		this.createdDate = studyNumberAllotmentLetterDistributionList.getCreatedDate();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
