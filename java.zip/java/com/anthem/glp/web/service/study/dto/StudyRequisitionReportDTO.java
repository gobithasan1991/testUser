package com.anthem.glp.web.service.study.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.anthem.glp.persistence.model.study.StudyRequisition;
import com.anthem.util.common.RequestFor;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyRequisitionReportDTO {
	private Long id;
	private String number;
	private TestItemReceiptDTO testItemReceipt;
	private StudyNumberDTO studyNumber;
	private RequestFor requestFor;
	private String previousBookNoInstrumrntId;	
	private String remarks;
	private String approveRemarks;
	private UserBasicDetailsDTO approvedBy;
	private Date approvedDate;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;
	private List<StudyRequisitionItemReportDTO> studyRequisitionItems;
	
	public StudyRequisitionReportDTO() {
		super();
	}
	
	public StudyRequisitionReportDTO(StudyRequisition studyRequisition) {
		super();
		this.id = studyRequisition.getId();
		this.number = studyRequisition.getNumber();
		this.testItemReceipt = new TestItemReceiptDTO(studyRequisition.getTestItemReceipt());
		this.studyNumber = new StudyNumberDTO(studyRequisition.getStudyNumber());
		this.requestFor = studyRequisition.getRequestFor();
		this.previousBookNoInstrumrntId = studyRequisition.getPreviousBookNoInstrumrntId();
		this.remarks = studyRequisition.getRemarks();
		
		if(studyRequisition.getApprovedBy() != null) {
			this.approvedBy = new UserBasicDetailsDTO(studyRequisition.getApprovedBy());
			this.approveRemarks = studyRequisition.getApproveRemarks();
			this.approvedDate = studyRequisition.getApprovedDate();
		}
		
		if(studyRequisition.getCreatedBy() != null) {
			this.createdBy = new UserBasicDetailsDTO(studyRequisition.getCreatedBy());
			this.createdDate = studyRequisition.getCreatedDate();
		}
		
		List<StudyRequisitionItemReportDTO> studyRequisitionItemReportDTOs = new ArrayList<>();
		studyRequisition.getStudyRequisitionItems().forEach(studyRequisitionItem->{ 
			StudyRequisitionItemReportDTO studyRequisitionItemReportDTO = new StudyRequisitionItemReportDTO(studyRequisitionItem);
			studyRequisitionItemReportDTOs.add(studyRequisitionItemReportDTO);
		});
		this.studyRequisitionItems = studyRequisitionItemReportDTOs;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public TestItemReceiptDTO getTestItemReceipt() {
		return testItemReceipt;
	}
	public void setTestItemReceipt(TestItemReceiptDTO testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}
	
	public RequestFor getRequestFor() {
		return requestFor;
	}
	public void setRequestFor(RequestFor requestFor) {
		this.requestFor = requestFor;
	}
	public String getPreviousBookNoInstrumrntId() {
		return previousBookNoInstrumrntId;
	}
	public void setPreviousBookNoInstrumrntId(String previousBookNoInstrumrntId) {
		this.previousBookNoInstrumrntId = previousBookNoInstrumrntId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}	
	public String getApproveRemarks() {
		return approveRemarks;
	}
	public void setApproveRemarks(String approveRemarks) {
		this.approveRemarks = approveRemarks;
	}
	
	public Date getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}
	

	public List<StudyRequisitionItemReportDTO> getStudyRequisitionItems() {
		return studyRequisitionItems;
	}

	public void setStudyRequisitionItems(List<StudyRequisitionItemReportDTO> studyRequisitionItems) {
		this.studyRequisitionItems = studyRequisitionItems;
	}

	public StudyNumberDTO getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumberDTO studyNumber) {
		this.studyNumber = studyNumber;
	}

	public UserBasicDetailsDTO getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(UserBasicDetailsDTO approvedBy) {
		this.approvedBy = approvedBy;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
}
