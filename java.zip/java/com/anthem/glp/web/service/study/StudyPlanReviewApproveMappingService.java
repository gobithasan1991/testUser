package com.anthem.glp.web.service.study;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.anthem.document.entity.VersionDocumentWithDetails;
import com.anthem.util.common.ReturnStatus;

public interface StudyPlanReviewApproveMappingService {

	public ReturnStatus studyPlanReviewById(HttpServletRequest request);

	public ReturnStatus studyPlanRejectById(HttpServletRequest request);

	public Map<Long, String> studyPlanApproveById(VersionDocumentWithDetails versionDocumentWithDetails,
			HttpServletRequest request, HttpServletResponse response);

}
