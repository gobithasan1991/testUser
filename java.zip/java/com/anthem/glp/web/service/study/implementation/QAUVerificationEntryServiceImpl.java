package com.anthem.glp.web.service.study.implementation;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.study.FolderCreationRequest;
import com.anthem.glp.persistence.model.study.QAUVerificationRequest;
import com.anthem.glp.persistence.repository.study.FolderCreationRequestRepo;
import com.anthem.glp.persistence.repository.study.QAUVerificationEntryRepo;
import com.anthem.glp.web.service.study.QAUVerificationEntryService;
import com.anthem.glp.web.service.study.dto.QAUVerificationRequestDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.FolderCreationStatus;

@Service
public class QAUVerificationEntryServiceImpl implements QAUVerificationEntryService {
	private QAUVerificationEntryRepo qauVerificationEntryRepo;
	private FolderCreationRequestRepo folderCreationRequestRepo;

	public QAUVerificationEntryServiceImpl(QAUVerificationEntryRepo qauVerificationEntryRepo,
			FolderCreationRequestRepo folderCreationRequestRepo) {
		super();
		this.qauVerificationEntryRepo = qauVerificationEntryRepo;
		this.folderCreationRequestRepo = folderCreationRequestRepo;
	}

	@Override
	@Transactional
	public String saveQAUVerificationEntry(QAUVerificationRequest qauVerificationRequest, User user) {
		String message = "Something went wrong !.";
		if (qauVerificationRequest != null) {
			qauVerificationRequest.setQauCheckBy(user);
			qauVerificationRequest.setQauCheckDate(new Date());
			qauVerificationEntryRepo.save(qauVerificationRequest);
			FolderCreationRequest folderCreationRequest = folderCreationRequestRepo
					.getFolderCreationRequestById(qauVerificationRequest.getFolderCreationRequest().getId());
			folderCreationRequest.setFolderCreationStatus(FolderCreationStatus.QAUVERIFY);
			message = "Success";
		}
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<QAUVerificationRequestDTO> getQAUVerificationEntryDetailsByAll(Pageable pagable) {
		return qauVerificationEntryRepo.getQAUVerificationEntryDetailsByAll(EnabledStatus.OPEN, pagable);
	}

	@Override
	@Transactional(readOnly = true)
	public QAUVerificationRequestDTO getCheckListForQAUVerificationOfStudyFolderById(Long id) {
		return qauVerificationEntryRepo.getQAUVerificationEntryDetailsById(id);
	}

}
