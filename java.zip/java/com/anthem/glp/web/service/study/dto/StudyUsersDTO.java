package com.anthem.glp.web.service.study.dto;

import java.util.List;

import com.anthem.glp.web.service.admin.dto.DirectorDTO;
import com.anthem.web.service.common.dto.IdCodeName;

public class StudyUsersDTO {

	private IdCodeName department;
	private List<StudyPersonnelDTO> users;
	private List<DirectorDTO> directors;

	public StudyUsersDTO(IdCodeName department, List<DirectorDTO> directors) {
		super();
		this.department = department;
		this.directors = directors;
	}

	public StudyUsersDTO(List<StudyPersonnelDTO> users, IdCodeName department) {
		super();
		this.department = department;
		this.users = users;
	}

	public IdCodeName getDepartment() {
		return department;
	}

	public void setDepartment(IdCodeName department) {
		this.department = department;
	}

	public List<StudyPersonnelDTO> getUsers() {
		return users;
	}

	public void setUsers(List<StudyPersonnelDTO> users) {
		this.users = users;
	}

	public List<DirectorDTO> getDirectors() {
		return directors;
	}

	public void setDirectors(List<DirectorDTO> directors) {
		this.directors = directors;
	}

}
