package com.anthem.glp.web.service.study.implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.anthem.glp.persistence.model.study.FolderAccess;
import com.anthem.glp.web.service.study.FolderAccessService;
import com.anthem.glp.web.service.study.dto.FolderAccessDTO;
import com.anthem.util.common.FolderAccessType;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class FolderAccessServiceImpl implements FolderAccessService {

	public static FolderAccessDTO convertDto(FolderAccess obj) {
		List<UserBasicDetailsDTO> userBasicDetailsDTOs = new ArrayList<UserBasicDetailsDTO>();
		FolderAccessDTO dto = new FolderAccessDTO();
		dto.setId(obj.getId());
		if (obj.getFolderAccessType().equals(FolderAccessType.Read)) {
			dto.setFolderAccessType("Read");
		} else if (obj.getFolderAccessType().equals(FolderAccessType.ReadAndWrite)) {
			dto.setFolderAccessType("Read And Write");
		}
		userBasicDetailsDTOs.add(new UserBasicDetailsDTO(obj.getUser()));
		dto.setUserBasicDetailsDTOs(userBasicDetailsDTOs);
		return dto;
	}
}
