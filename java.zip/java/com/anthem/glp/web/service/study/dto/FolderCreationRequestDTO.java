package com.anthem.glp.web.service.study.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import com.anthem.glp.persistence.model.study.FolderAccess;
import com.anthem.glp.persistence.model.study.FolderCreationRequest;
import com.anthem.glp.persistence.model.study.FolderLocationAndTitle;
import com.anthem.util.common.FolderAccessType;
import com.anthem.util.common.FolderCreationStatus;
import com.anthem.util.common.FolderRelated;
import com.anthem.web.service.common.dto.DefaultsDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class FolderCreationRequestDTO extends DefaultsDTO {

	private Long id;

	private Date dateRequest;

	private FolderRelated folderRelated;

	private String folderRelatedOthers;

	private StudyNumberDTO studyNumberDTO;

	private Integer numberOfFolderRequested;

	private UserBasicDetailsDTO authorizedBy;

	private Date authorizedDate;

	private UserBasicDetailsDTO acceptedBy;

	private Date acceptedDate;

	private String folderCreationStatus;

	private UserBasicDetailsDTO folderCreatedBy;

	private Date folderCreatedDate;

	private UserBasicDetailsDTO folderCreatedEntryBy;

	private Date folderCreatedEntryDate;

	private UserBasicDetailsDTO qauVerificationRequestBy;

	private Date qauVerificationRequestDate;

	private List<FolderAccessDTO> folderAccessDTOs;

	private List<FolderLocationAndTitleDTO> folderLocationAndTitleDTOs;

	public FolderCreationRequestDTO() {
		super();
	}

	public FolderCreationRequestDTO(FolderCreationRequest folderCreationRequest) {
		super();
		this.setId(folderCreationRequest.getId());
		this.setDateRequest(folderCreationRequest.getDateRequest());
		this.setFolderRelated(folderCreationRequest.getFolderRelated());
		this.setFolderRelatedOthers(folderCreationRequest.getFolderRelatedOthers());
		this.setStudyNumberDTO(new StudyNumberDTO(folderCreationRequest.getStudyNumber()));
		this.setNumberOfFolderRequested(folderCreationRequest.getNumberOfFolderRequested());
		if (folderCreationRequest.getFolderRelatedOthers() != null) {
			this.setFolderRelatedOthers(folderCreationRequest.getFolderRelatedOthers());
		}
		Iterator<FolderLocationAndTitle> iterator = folderCreationRequest.getFolderLocationAndTitles().iterator();
		List<FolderLocationAndTitleDTO> folderLocationAndTitleDTOs = new ArrayList<>();
		while (iterator.hasNext()) {
			folderLocationAndTitleDTOs.add(new FolderLocationAndTitleDTO(iterator.next()));
		}
		this.setFolderLocationAndTitleDTOs(folderLocationAndTitleDTOs);
		Iterator<FolderAccess> iterator1 = folderCreationRequest.getFolderAccesses().iterator();
		List<FolderAccessDTO> folderAccessDTOs = new ArrayList<>();
		while (iterator1.hasNext()) {
			FolderAccess fa = iterator1.next();
			List<UserBasicDetailsDTO> userBasicDetailsDTOs = new ArrayList<UserBasicDetailsDTO>();
			FolderAccessDTO fad = new FolderAccessDTO();
			if (fa.getFolderAccessType().equals(FolderAccessType.Read)) {
				fad.setFolderAccessType("Read");
			} else if (fa.getFolderAccessType().equals(FolderAccessType.ReadAndWrite)) {
				fad.setFolderAccessType("Read And Write");
			}
			userBasicDetailsDTOs.add(new UserBasicDetailsDTO(fa.getUser()));
			fad.setUserBasicDetailsDTOs(userBasicDetailsDTOs);
			Optional<FolderAccessDTO> optional = folderAccessDTOs.stream()
					.filter(action -> action.getFolderAccessType().equals(fad.getFolderAccessType())).findFirst();
			if (optional.isPresent()) {
				FolderAccessDTO temp = optional.get();
				temp.getUserBasicDetailsDTOs().add(new UserBasicDetailsDTO(fa.getUser()));
			} else {
				folderAccessDTOs.add(fad);
			}

		}
		this.setFolderAccessDTOs(folderAccessDTOs);
		if (folderCreationRequest.getAuthorizedBy() != null) {
			this.setAuthorizedBy(new UserBasicDetailsDTO(folderCreationRequest.getAuthorizedBy()));
			this.setAuthorizedDate(folderCreationRequest.getAuthorizedDate());
		}
		if (folderCreationRequest.getAcceptedBy() != null) {
			this.setAcceptedBy(new UserBasicDetailsDTO(folderCreationRequest.getAcceptedBy()));
			this.setAcceptedDate(folderCreationRequest.getAcceptedDate());
		}
		this.setCreatedBy(new UserBasicDetailsDTO(folderCreationRequest.getCreatedBy()));
		this.setCreatedDate(folderCreationRequest.getCreatedDate());
		if (folderCreationRequest.getFolderCreationStatus().equals(FolderCreationStatus.TFMACCEPTED)) {
			this.setFolderCreationStatus("TFM Accepted");
		} else if (folderCreationRequest.getFolderCreationStatus().equals(FolderCreationStatus.ITACCEPTED)) {
			this.setFolderCreationStatus("IT Accepted");
		} else if (folderCreationRequest.getFolderCreationStatus().equals(FolderCreationStatus.TFMNOTACCEPTED)) {
			this.setFolderCreationStatus("TFM Not Accepted");
		} else if (folderCreationRequest.getFolderCreationStatus().equals(FolderCreationStatus.ITNOTACCEPTED)) {
			this.setFolderCreationStatus("IT Not Accepted");
		} else if (folderCreationRequest.getFolderCreationStatus().equals(FolderCreationStatus.FOLDERCREATED)) {
			this.setFolderCreationStatus("Folder created");
		} else if (folderCreationRequest.getFolderCreationStatus()
				.equals(FolderCreationStatus.QAUVERIFICATIONREQUESTED)) {
			this.setFolderCreationStatus("QAU Verification Requested");
		} else if (folderCreationRequest.getFolderCreationStatus().equals(FolderCreationStatus.QAUVERIFY)) {
			this.setFolderCreationStatus("QAU Verify");
		} else {
			this.setFolderCreationStatus(folderCreationRequest.getFolderCreationStatus().toString());
		}
		if (folderCreationRequest.getFolderCreatedBy() != null) {
			this.setFolderCreatedBy(new UserBasicDetailsDTO(folderCreationRequest.getFolderCreatedBy()));
			this.setFolderCreatedDate(folderCreationRequest.getFolderCreatedDate());
		}
		if (folderCreationRequest.getFolderCreatedEntryBy() != null) {
			this.setFolderCreatedEntryBy(new UserBasicDetailsDTO(folderCreationRequest.getFolderCreatedEntryBy()));
			this.setFolderCreatedEntryDate(folderCreationRequest.getFolderCreatedEntryDate());
		}
		if (folderCreationRequest.getQauVerificationRequestBy() != null) {
			this.setQauVerificationRequestBy(
					new UserBasicDetailsDTO(folderCreationRequest.getQauVerificationRequestBy()));
			this.setQauVerificationRequestDate(folderCreationRequest.getQauVerificationRequestDate());
		}
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the dateRequest
	 */
	public Date getDateRequest() {
		return dateRequest;
	}

	/**
	 * @param dateRequest the dateRequest to set
	 */
	public void setDateRequest(Date dateRequest) {
		this.dateRequest = dateRequest;
	}

	/**
	 * @return the folderRelated
	 */
	public FolderRelated getFolderRelated() {
		return folderRelated;
	}

	/**
	 * @param folderRelated the folderRelated to set
	 */
	public void setFolderRelated(FolderRelated folderRelated) {
		this.folderRelated = folderRelated;
	}

	/**
	 * @return the folderRelatedOthers
	 */
	public String getFolderRelatedOthers() {
		return folderRelatedOthers;
	}

	/**
	 * @param folderRelatedOthers the folderRelatedOthers to set
	 */
	public void setFolderRelatedOthers(String folderRelatedOthers) {
		this.folderRelatedOthers = folderRelatedOthers;
	}

	/**
	 * @return the studyNumberDTO
	 */
	public StudyNumberDTO getStudyNumberDTO() {
		return studyNumberDTO;
	}

	/**
	 * @param studyNumberDTO the studyNumberDTO to set
	 */
	public void setStudyNumberDTO(StudyNumberDTO studyNumberDTO) {
		this.studyNumberDTO = studyNumberDTO;
	}

	/**
	 * @return the numberOfFolderRequested
	 */
	public Integer getNumberOfFolderRequested() {
		return numberOfFolderRequested;
	}

	/**
	 * @param numberOfFolderRequested the numberOfFolderRequested to set
	 */
	public void setNumberOfFolderRequested(Integer numberOfFolderRequested) {
		this.numberOfFolderRequested = numberOfFolderRequested;
	}

	/**
	 * @return the authorizedBy
	 */
	public UserBasicDetailsDTO getAuthorizedBy() {
		return authorizedBy;
	}

	/**
	 * @param authorizedBy the authorizedBy to set
	 */
	public void setAuthorizedBy(UserBasicDetailsDTO authorizedBy) {
		this.authorizedBy = authorizedBy;
	}

	/**
	 * @return the authorizedDate
	 */
	public Date getAuthorizedDate() {
		return authorizedDate;
	}

	/**
	 * @param authorizedDate the authorizedDate to set
	 */
	public void setAuthorizedDate(Date authorizedDate) {
		this.authorizedDate = authorizedDate;
	}

	/**
	 * @return the acceptedBy
	 */
	public UserBasicDetailsDTO getAcceptedBy() {
		return acceptedBy;
	}

	/**
	 * @param acceptedBy the acceptedBy to set
	 */
	public void setAcceptedBy(UserBasicDetailsDTO acceptedBy) {
		this.acceptedBy = acceptedBy;
	}

	/**
	 * @return the acceptedDate
	 */
	public Date getAcceptedDate() {
		return acceptedDate;
	}

	/**
	 * @param acceptedDate the acceptedDate to set
	 */
	public void setAcceptedDate(Date acceptedDate) {
		this.acceptedDate = acceptedDate;
	}

	/**
	 * @return the folderCreationStatus
	 */
	public String getFolderCreationStatus() {
		return folderCreationStatus;
	}

	/**
	 * @param folderCreationStatus the folderCreationStatus to set
	 */
	public void setFolderCreationStatus(String folderCreationStatus) {
		this.folderCreationStatus = folderCreationStatus;
	}

	/**
	 * @return the folderCreatedBy
	 */
	public UserBasicDetailsDTO getFolderCreatedBy() {
		return folderCreatedBy;
	}

	/**
	 * @param folderCreatedBy the folderCreatedBy to set
	 */
	public void setFolderCreatedBy(UserBasicDetailsDTO folderCreatedBy) {
		this.folderCreatedBy = folderCreatedBy;
	}

	/**
	 * @return the folderCreatedDate
	 */
	public Date getFolderCreatedDate() {
		return folderCreatedDate;
	}

	/**
	 * @param folderCreatedDate the folderCreatedDate to set
	 */
	public void setFolderCreatedDate(Date folderCreatedDate) {
		this.folderCreatedDate = folderCreatedDate;
	}

	/**
	 * @return the folderCreatedEntryBy
	 */
	public UserBasicDetailsDTO getFolderCreatedEntryBy() {
		return folderCreatedEntryBy;
	}

	/**
	 * @param folderCreatedEntryBy the folderCreatedEntryBy to set
	 */
	public void setFolderCreatedEntryBy(UserBasicDetailsDTO folderCreatedEntryBy) {
		this.folderCreatedEntryBy = folderCreatedEntryBy;
	}

	/**
	 * @return the folderCreatedEntryDate
	 */
	public Date getFolderCreatedEntryDate() {
		return folderCreatedEntryDate;
	}

	/**
	 * @param folderCreatedEntryDate the folderCreatedEntryDate to set
	 */
	public void setFolderCreatedEntryDate(Date folderCreatedEntryDate) {
		this.folderCreatedEntryDate = folderCreatedEntryDate;
	}

	/**
	 * @return the folderAccessDTOs
	 */
	public List<FolderAccessDTO> getFolderAccessDTOs() {
		return folderAccessDTOs;
	}

	/**
	 * @param folderAccessDTOs the folderAccessDTOs to set
	 */
	public void setFolderAccessDTOs(List<FolderAccessDTO> folderAccessDTOs) {
		this.folderAccessDTOs = folderAccessDTOs;
	}

	/**
	 * @return the folderLocationAndTitleDTOs
	 */
	public List<FolderLocationAndTitleDTO> getFolderLocationAndTitleDTOs() {
		return folderLocationAndTitleDTOs;
	}

	/**
	 * @param folderLocationAndTitleDTOs the folderLocationAndTitleDTOs to set
	 */
	public void setFolderLocationAndTitleDTOs(List<FolderLocationAndTitleDTO> folderLocationAndTitleDTOs) {
		this.folderLocationAndTitleDTOs = folderLocationAndTitleDTOs;
	}

	/**
	 * @return the qauVerificationRequestBy
	 */
	public UserBasicDetailsDTO getQauVerificationRequestBy() {
		return qauVerificationRequestBy;
	}

	/**
	 * @param qauVerificationRequestBy the qauVerificationRequestBy to set
	 */
	public void setQauVerificationRequestBy(UserBasicDetailsDTO qauVerificationRequestBy) {
		this.qauVerificationRequestBy = qauVerificationRequestBy;
	}

	/**
	 * @return the qauVerificationRequestDate
	 */
	public Date getQauVerificationRequestDate() {
		return qauVerificationRequestDate;
	}

	/**
	 * @param qauVerificationRequestDate the qauVerificationRequestDate to set
	 */
	public void setQauVerificationRequestDate(Date qauVerificationRequestDate) {
		this.qauVerificationRequestDate = qauVerificationRequestDate;
	}

}
