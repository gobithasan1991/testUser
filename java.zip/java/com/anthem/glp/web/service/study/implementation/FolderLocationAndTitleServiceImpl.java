package com.anthem.glp.web.service.study.implementation;

import org.springframework.stereotype.Service;

import com.anthem.glp.persistence.model.study.FolderLocationAndTitle;
import com.anthem.glp.web.service.study.FolderLocationAndTitleService;
import com.anthem.glp.web.service.study.dto.FolderLocationAndTitleDTO;

@Service
public class FolderLocationAndTitleServiceImpl implements FolderLocationAndTitleService {

	public static FolderLocationAndTitleDTO convertDto(FolderLocationAndTitle obj) {
		FolderLocationAndTitleDTO dto = new FolderLocationAndTitleDTO();
		dto.setId(obj.getId());
		dto.setFolderLocation(obj.getFolderLocation());
		dto.setFolderTitle(obj.getFolderLocation());
		return dto;
	}

}
