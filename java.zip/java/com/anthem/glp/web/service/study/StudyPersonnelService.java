package com.anthem.glp.web.service.study;

import java.util.List;

import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyPersonnelDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public interface StudyPersonnelService {
	public String saveStudyPerson(List<StudyPersonnelDTO> personnel);

	public StudyDetailsDTO fetchStudyDetails(Long studyId);

	public List<UserBasicDetailsDTO> fetchPersonnelsByStudyId(Long studyId);
}
