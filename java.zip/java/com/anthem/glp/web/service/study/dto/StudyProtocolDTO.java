package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyProtocolDTO {

	private Long id;
	private StudyNumberDTO studyNumber;
	private String documentForm;
	private String fileId;
	private String fileName;

	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	private UserBasicDetailsDTO reviewedBy;
	private Date reviewedDate;

	private UserBasicDetailsDTO approvedBy;
	private Date approvedDate;

	public StudyProtocolDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyNumberDTO getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumberDTO studyNumber) {
		this.studyNumber = studyNumber;
	}

	public String getDocumentForm() {
		return documentForm;
	}

	public void setDocumentForm(String documentForm) {
		this.documentForm = documentForm;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public UserBasicDetailsDTO getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(UserBasicDetailsDTO reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public Date getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public UserBasicDetailsDTO getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(UserBasicDetailsDTO approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

}
