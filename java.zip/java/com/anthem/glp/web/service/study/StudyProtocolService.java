package com.anthem.glp.web.service.study;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.anthem.glp.persistence.model.study.StudyProtocol;
import com.anthem.glp.persistence.model.study.StudyProtocolReviewApproveMapping;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.common.dto.OnlyOfficeEditorDTO;

public interface StudyProtocolService {

	public Long saveStudyProtocol(StudyProtocol studyProtocol,
			List<StudyProtocolReviewApproveMapping> protocolReviewApproveMappings, MultipartFile file, User user,
			HttpServletRequest request, HttpServletResponse response) throws IOException, FileNotFoundException;

	public OnlyOfficeEditorDTO getDocumentById(Long uniqueId);

	public StudyProtocol getStudyProtocolByStudyNumberId(Long studyNumberId);

	public String updateStudyProtocol(Long protocolId, String protocolType, StudyStatus studyStatus, User user);

}
