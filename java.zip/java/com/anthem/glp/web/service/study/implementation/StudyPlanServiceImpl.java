package com.anthem.glp.web.service.study.implementation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.anthem.document.helpers.DocumentManager;
import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.glp.persistence.model.study.StudyPlan;
import com.anthem.glp.persistence.model.study.StudyPlanReviewApproveMapping;
import com.anthem.glp.persistence.repository.study.StudyNumberRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanReviewApproveMappingRepo;
import com.anthem.glp.web.service.admin.GLPDocumentTemplateService;
import com.anthem.glp.web.service.study.StudyPlanService;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.Constants;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.RecordStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.common.dto.OnlyOfficeEditorDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class StudyPlanServiceImpl implements StudyPlanService {

	private StudyPlanRepo studyPlanRepo;
	private StudyNumberRepo studyNumberRepo;
	private GLPDocumentTemplateService glpDocumentTemplateService;
	private StudyPlanReviewApproveMappingRepo reviewApproveMappingRepo;
	private ResponseMessage auditTrail;

	public StudyPlanServiceImpl(StudyPlanRepo studyPlanRepo, StudyNumberRepo studyNumberRepo,
			GLPDocumentTemplateService glpDocumentTemplateService,
			StudyPlanReviewApproveMappingRepo reviewApproveMappingRepo, ResponseMessage auditTrail) {
		super();
		this.studyPlanRepo = studyPlanRepo;
		this.studyNumberRepo = studyNumberRepo;
		this.glpDocumentTemplateService = glpDocumentTemplateService;
		this.reviewApproveMappingRepo = reviewApproveMappingRepo;
		this.auditTrail = auditTrail;
	}

	@Override
	@Transactional
	public Long saveStudyPlan(StudyPlan studyPlan, List<StudyPlanReviewApproveMapping> planReviewApproveMappings,
			MultipartFile file, User user, HttpServletRequest request, HttpServletResponse response)
			throws IOException, FileNotFoundException {

		String documentName = "", path = "", hostAddress = "", fileId = "", fileExtension = "";
		InputStream stream = null;
		if (studyPlan != null) {
			DocumentManager.Init(request, response);
			fileId = "PLAN" + System.currentTimeMillis() + String.format(Constants.NUMBER_FORMAT_CONSTANT_3, studyPlanRepo.count() + 1);
			if (file != null && studyPlan.getGlpDocumentTemplate() == null) {
				fileExtension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."), file.getOriginalFilename().length());
				stream = file.getInputStream();
			} else {
				GLPDocumentTemplate gdt = glpDocumentTemplateService.getGlpDocumentTemplateById(studyPlan.getGlpDocumentTemplate().getId());
				fileExtension = gdt.getFileId().substring(gdt.getFileId().lastIndexOf("."));
				stream = DocumentManager.GetGLPTemplateFile(gdt.getFileId());
			}
			documentName = fileId + fileExtension.substring(fileExtension.lastIndexOf("."));
			hostAddress = DocumentManager.CurUserHostAddress(null);
			path = DocumentManager.StoragePath(documentName, hostAddress);
			DocumentManager.createDemo(path, stream, documentName, user.getId() + "", user.getFullName(), true);
			studyPlan.setFileId(fileId);
			studyPlan.setFileName(documentName);
			studyPlan.setVersionNo("001");
			
			StudyPlan studyPlanSaved = studyPlanRepo.save(studyPlan);
			planReviewApproveMappings.forEach(action -> {
				action.setStudyPlan(studyPlanSaved);
			});
			reviewApproveMappingRepo.save(planReviewApproveMappings);
			studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_UPLOADED);
			
			StudyNumberDTO studyNumberDTO = studyNumberRepo.getStudyNumberDetailsById(studyPlan.getStudyNumber().getId(), EnabledStatus.OPEN);
			UserBasicDetailsDTO dto = new UserBasicDetailsDTO(studyPlan.getCreatedBy());
			auditTrail.takeAuditTrail(studyPlanSaved.getId(), "Study Plan", null, "Study Plan Uploaded For " + studyNumberDTO.getStudyNumber() + " By " + dto.getDisplayName(), studyPlanSaved.getCreatedBy());
			return studyPlanSaved.getId();
		}
		return 0L;
	}

	@Override
	@Transactional(readOnly=true)
	public OnlyOfficeEditorDTO getDocumentById(Long uniqueId) {

		StudyPlan studyPlan = studyPlanRepo.getStudyPlanById(uniqueId, EnabledStatus.OPEN);
		UserBasicDetailsDTO author = new UserBasicDetailsDTO(studyPlan.getCreatedBy());
		OnlyOfficeEditorDTO onlyOfficeEditorDTO = new OnlyOfficeEditorDTO(uniqueId, studyPlan.getFileName(), studyPlan.getStudyNumber().getStudyNumber(), author, studyPlan.getCreatedDate(), "");
		return onlyOfficeEditorDTO;
	}

	@Override
	@Transactional
	public Long updateStudyPlanReviewApprover(List<StudyPlanReviewApproveMapping> planReviewApproveMappings) {
		
		List<StudyPlanReviewApproveMapping> mappings = new ArrayList<>();
		planReviewApproveMappings.forEach(mapping -> {
			mapping.setRecordStatus(RecordStatus.MODIFIED);
			mapping.setEnabled(Boolean.TRUE);
			if(mapping.getRejected() != null && mapping.getRejected()) {
				mapping.setRejected(Boolean.TRUE);
				mappings.add(mapping);
			} else {
				mapping.setRejected(Boolean.FALSE);
			}
		});
		reviewApproveMappingRepo.save(planReviewApproveMappings);
		mappings.forEach(mapping -> {
			mapping.setId(null);
			mapping.setRejected(Boolean.FALSE);
			mapping.setMappingStatus(CustomStatus.MAPPED);
		});
		reviewApproveMappingRepo.save(mappings);
		
		StudyPlan studyPlan = studyPlanRepo.getStudyPlanById(planReviewApproveMappings.get(0).getStudyPlan().getId(), EnabledStatus.OPEN);
		int reviewedCount = reviewApproveMappingRepo.getReviewedCounts(studyPlan.getId(), "Review", CustomStatus.REVIEWED, EnabledStatus.OPEN);
		int reviewCount = reviewApproveMappingRepo.getReviewerCounts(studyPlan.getId(), "Review", EnabledStatus.OPEN);
		int approvedCount = reviewApproveMappingRepo.getReviewedCounts(studyPlan.getId(), "Approve", CustomStatus.APPROVED, EnabledStatus.OPEN);
		if(reviewedCount == 0) {
			studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_UPLOADED);
		} else if (reviewCount == reviewedCount) {
			if(approvedCount == 0) {
				studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_REVIEWED);
			} else {
				studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_PARTIALLY_APPROVED);
			}
		} else {
			studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_PARTIALLY_REVIEWED);
		}
		return planReviewApproveMappings.get(0).getStudyPlan().getId();
	}

}
