package com.anthem.glp.web.service.study;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import com.anthem.glp.persistence.model.study.TestItemReceipt;
import com.anthem.glp.web.service.study.dto.TestItemReceiptDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.web.service.common.dto.OnlyOfficeEditorDTO;

public interface TestItemReceiptService {

	public TestItemReceipt saveStudyEnquiry(TestItemReceipt testItemReceipt, MultipartFile coaDocument,
			MultipartFile safetyDocument, User user, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws IOException, FileNotFoundException;

	public String sendTestItemReceiptMail(Long id);

	public Page<TestItemReceiptDTO> getAllTestItemReceipts(Pageable pageable);

	public TestItemReceiptDTO getTestItemReceiptDtoById(Long testItemId);

	public TestItemReceipt getTestItemDetailsById(Long testItemId);

	public OnlyOfficeEditorDTO getCOADocumentById(Long testItemId);

	public OnlyOfficeEditorDTO getSafetyDocumentById(Long testItemId);

	public Page<TestItemReceiptDTO> getTestItemReceiptByChemicalName(String value, Pageable pageable);

	public Page<TestItemReceiptDTO> getTestItemReceiptByNominee(String value, Pageable pageable);

	public Page<TestItemReceiptDTO> getTestItemReceiptBySponsor(String value, Pageable pageable);

	public Page<TestItemReceiptDTO> getTestItemReceiptByTest(String value, Pageable pageable);

}
