package com.anthem.glp.web.service.study;

import java.util.List;

import com.anthem.glp.persistence.model.study.StudyAllotmentLetterDistributionList;
import com.anthem.glp.web.service.study.dto.StudyAllotmentLetterDistributionListDTO;
import com.anthem.persistence.model.user.User;

public interface StudyAllotmentLetterDistributionListService {
	public String saveStudyAllotmentDistribution(StudyAllotmentLetterDistributionList studyAllotmentLetterDistributionList, User user);
	
	public List<StudyAllotmentLetterDistributionListDTO> getStudyDetailsForPrint(Long studyId);
}
