package com.anthem.glp.web.service.study;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.anthem.glp.persistence.model.study.StudyPlan;
import com.anthem.glp.persistence.model.study.StudyPlanReviewApproveMapping;
import com.anthem.persistence.model.user.User;
import com.anthem.web.service.common.dto.OnlyOfficeEditorDTO;

public interface StudyPlanService {

	public Long saveStudyPlan(StudyPlan studyPlan, List<StudyPlanReviewApproveMapping> planReviewApproveMappings,
			MultipartFile file, User user, HttpServletRequest request, HttpServletResponse response)
			throws IOException, FileNotFoundException;

	public OnlyOfficeEditorDTO getDocumentById(Long uniqueId);

	public Long updateStudyPlanReviewApprover(List<StudyPlanReviewApproveMapping> planReviewApproveMappings);

}
