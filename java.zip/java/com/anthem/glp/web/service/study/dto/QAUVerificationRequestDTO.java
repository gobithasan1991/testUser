package com.anthem.glp.web.service.study.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.anthem.glp.persistence.model.study.QAUCheck;
import com.anthem.glp.persistence.model.study.QAUVerificationRequest;
import com.anthem.web.service.common.dto.DefaultsDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class QAUVerificationRequestDTO extends DefaultsDTO {

	private Long id;

	private FolderCreationRequestDTO folderCreationRequestDTO;

	private UserBasicDetailsDTO qauCheckBy;

	private Date qauCheckDate;

	private String remark;

	private List<QAUCheckDTO> qauCheckDTOs;

	public QAUVerificationRequestDTO(QAUVerificationRequest qauVerificationRequest) {
		super();
		this.setId(qauVerificationRequest.getId());
		this.setFolderCreationRequestDTO(
				new FolderCreationRequestDTO(qauVerificationRequest.getFolderCreationRequest()));
		if (qauVerificationRequest.getQauCheckBy() != null) {
			this.setQauCheckBy(new UserBasicDetailsDTO(qauVerificationRequest.getQauCheckBy()));
			this.setQauCheckDate(qauVerificationRequest.getQauCheckDate());
		}
		this.setQauCheckDate(qauVerificationRequest.getQauCheckDate());
		this.setRemark(qauVerificationRequest.getRemark());
		Iterator<QAUCheck> qauChecks = qauVerificationRequest.getQauChecks().iterator();
		List<QAUCheckDTO> qauCheckDTOs_temp = new ArrayList<QAUCheckDTO>();
		while (qauChecks.hasNext()) {
			qauCheckDTOs_temp.add(new QAUCheckDTO(qauChecks.next()));
		}
		this.qauCheckDTOs = qauCheckDTOs_temp;

		if (qauVerificationRequest.getCreatedBy() != null) {
			this.setCreatedBy(new UserBasicDetailsDTO(qauVerificationRequest.getCreatedBy()));
			this.setCreatedDate(qauVerificationRequest.getCreatedDate());
		}
		if (qauVerificationRequest.getQauCheckBy() != null) {
			this.setQauCheckBy(new UserBasicDetailsDTO(qauVerificationRequest.getQauCheckBy()));
			this.setQauCheckDate(qauVerificationRequest.getQauCheckDate());
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public FolderCreationRequestDTO getFolderCreationRequestDTO() {
		return folderCreationRequestDTO;
	}

	public void setFolderCreationRequestDTO(FolderCreationRequestDTO folderCreationRequestDTO) {
		this.folderCreationRequestDTO = folderCreationRequestDTO;
	}

	public UserBasicDetailsDTO getQauCheckBy() {
		return qauCheckBy;
	}

	public void setQauCheckBy(UserBasicDetailsDTO qauCheckBy) {
		this.qauCheckBy = qauCheckBy;
	}

	public Date getQauCheckDate() {
		return qauCheckDate;
	}

	public void setQauCheckDate(Date qauCheckDate) {
		this.qauCheckDate = qauCheckDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<QAUCheckDTO> getQauCheckDTOs() {
		return qauCheckDTOs;
	}

	public void setQauCheckDTOs(List<QAUCheckDTO> qauCheckDTOs) {
		this.qauCheckDTOs = qauCheckDTOs;
	}

}
