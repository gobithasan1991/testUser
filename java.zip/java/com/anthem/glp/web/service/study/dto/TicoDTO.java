package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.persistence.model.study.TICO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class TicoDTO {

	private Long id;
	private TestItemReceiptDTO testItemReceipt;
	private String itemName;
	private String itemValue;

	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	public TicoDTO(TICO tico) {
		super();
		this.id = tico.getId();
		this.testItemReceipt = new TestItemReceiptDTO(tico.getTestItemReceipt());
		this.itemName = tico.getItemName();
		this.itemValue = tico.getItemValue();

		this.createdBy = new UserBasicDetailsDTO(tico.getCreatedBy());
		this.createdDate = tico.getCreatedDate();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TestItemReceiptDTO getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceiptDTO testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemValue() {
		return itemValue;
	}

	public void setItemValue(String itemValue) {
		this.itemValue = itemValue;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
