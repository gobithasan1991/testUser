package com.anthem.glp.web.service.study.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.glp.persistence.model.study.StudyPersonnel;
import com.anthem.glp.persistence.repository.study.StudyPersonnelRepo;
import com.anthem.glp.web.service.study.StudyNumberService;
import com.anthem.glp.web.service.study.StudyPersonnelService;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.glp.web.service.study.dto.StudyPersonnelDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.repository.user.UserRepo;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class StudyPersonnelServiceImpl implements StudyPersonnelService {

	// private StudyNumberRepo numberRepo;
	private StudyPersonnelRepo personnelRepo;
	private StudyNumberService numberService;
	private ResponseMessage auditTrail;
	private UserRepo userRepo;

	static StudyPersonnelDTO convertToDto(StudyPersonnel obj) {
		StudyPersonnelDTO dto = new StudyPersonnelDTO();
		dto.setId(obj.getId());
		dto.setStudyNumber(new StudyNumberDTO(obj.getStudyNumber()));
		dto.setPerson(new UserBasicDetailsDTO(obj.getPerson()));
		dto.setSpecialNotes(obj.getSpecialNotes());
		dto.setCreatedBy(new UserBasicDetailsDTO(obj.getCreatedBy()));
		dto.setCreatedDate(obj.getCreatedDate());
		obj.setApproveStatus(obj.getApproveStatus());
		return null;
	}

	static StudyPersonnel convertToObj(StudyPersonnelDTO dto) {
		StudyPersonnel obj = new StudyPersonnel();
		StudyNumber studyNumber = new StudyNumber();
		studyNumber.setId(dto.getStudyNumber().getId());
		obj.setStudyNumber(studyNumber);
		obj.setPerson(new User(dto.getPerson().getId()));
		return obj;
	}

	@Autowired
	public StudyPersonnelServiceImpl(StudyPersonnelRepo personnelRepo, ResponseMessage auditTrail,
			StudyNumberService numberService, UserRepo userRepo) {
		super();
		// this.numberRepo = numberRepo;
		this.personnelRepo = personnelRepo;
		this.auditTrail = auditTrail;
		this.numberService = numberService;
		this.userRepo = userRepo;
	}

	@Override
	@Transactional
	public String saveStudyPerson(List<StudyPersonnelDTO> personnel) {
		String message = "Something went wrong !.";
		if (personnel != null && personnel.size() > 0) {
			Iterator<StudyPersonnelDTO> iterator = personnel.iterator();
			while (iterator.hasNext()) {
				StudyPersonnelDTO dto = iterator.next();
				User personObj = userRepo.findById(dto.getPerson().getId());
				UserBasicDetailsDTO basicDetailsDTO = new UserBasicDetailsDTO(personObj);
				StudyPersonnel director = convertToObj(dto);
				StudyPersonnel saved = personnelRepo.save(director);

				auditTrail.takeAuditTrail(saved.getId(), "Study Personnel Allocation", null,
						"Study person '" + basicDetailsDTO.getDisplayName() + "' allocated for study '"
								+ dto.getStudyNumber().getStudyNumber() + "'.",
						saved.getCreatedBy());
			}
			// Long studyId = personnel.get(0).getStudyNumber().getId();
			// StudyNumber number = numberRepo.findOne(studyId);
			// number.setStudyStatus(StudyStatus.PERSONNEL_ALLOCATED);
		}
		message = "Success";
		return message;
	}

	@Override
	public StudyDetailsDTO fetchStudyDetails(Long studyId) {
		StudyDetailsDTO dto = new StudyDetailsDTO();
		dto = numberService.getStudyDetails(studyId);
		return dto;
	}

	@Override
	@Transactional(readOnly = true)
	public List<UserBasicDetailsDTO> fetchPersonnelsByStudyId(Long studyId) {
		List<StudyPersonnel> personnels = personnelRepo.findAllPersonnelByStudy(studyId, EnabledStatus.OPEN);
		List<UserBasicDetailsDTO> basicDetailsDTOs = new ArrayList<UserBasicDetailsDTO>();
		if (personnels != null && personnels.size() > 0) {
			basicDetailsDTOs = personnels.stream()
					.filter(predicate -> predicate.getApproveStatus().equals(ApproveStatus.APPROVED))
					.map(mapper -> new UserBasicDetailsDTO(mapper.getPerson())).collect(Collectors.toList());
		}
		return basicDetailsDTOs;
	}

}
