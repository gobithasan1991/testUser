package com.anthem.glp.web.service.study.dto;

import com.anthem.util.common.StudyUserRole;

public class StudyUserRoleDTO {

	private Long id;
	private StudyNumberDTO studyNumber;
	private StudyUserRole role;

	public StudyUserRoleDTO(Long id, StudyNumberDTO studyNumber, StudyUserRole role) {
		super();
		this.id = id;
		this.studyNumber = studyNumber;
		this.role = role;
	}

	public StudyUserRoleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudyNumberDTO getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumberDTO studyNumber) {
		this.studyNumber = studyNumber;
	}

	public StudyUserRole getRole() {
		return role;
	}

	public void setRole(StudyUserRole role) {
		this.role = role;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
