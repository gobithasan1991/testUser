package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.web.service.admin.dto.GLPDepartmentDTO;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.RecordStatus;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyPlanReviewApproveMappingDto {

	private Long id;
	private StudyPlanDTO studyPlan;
	private GLPDepartmentDTO glpDepartment;
	private UserBasicDetailsDTO user;
	private String reviewType;
	private String specialNotes;
	private CustomStatus mappingStatus;

	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	private UserBasicDetailsDTO updatedBy;
	private Date updatedDate;

	private EnabledStatus enabledStatus;
	private RecordStatus recordStatus;

	public StudyPlanReviewApproveMappingDto() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyPlanDTO getStudyPlan() {
		return studyPlan;
	}

	public void setStudyPlan(StudyPlanDTO studyPlan) {
		this.studyPlan = studyPlan;
	}

	public GLPDepartmentDTO getGlpDepartment() {
		return glpDepartment;
	}

	public void setGlpDepartment(GLPDepartmentDTO glpDepartment) {
		this.glpDepartment = glpDepartment;
	}

	public UserBasicDetailsDTO getUser() {
		return user;
	}

	public void setUser(UserBasicDetailsDTO user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public CustomStatus getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(CustomStatus mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public UserBasicDetailsDTO getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserBasicDetailsDTO updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public EnabledStatus getEnabledStatus() {
		return enabledStatus;
	}

	public void setEnabledStatus(EnabledStatus enabledStatus) {
		this.enabledStatus = enabledStatus;
	}

	public RecordStatus getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(RecordStatus recordStatus) {
		this.recordStatus = recordStatus;
	}

}
