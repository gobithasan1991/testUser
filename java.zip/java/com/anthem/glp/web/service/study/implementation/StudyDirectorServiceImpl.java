package com.anthem.glp.web.service.study.implementation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.study.StudyDirector;
import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.glp.persistence.model.study.StudyPersonnel;
import com.anthem.glp.persistence.repository.study.StudyDirectorRepo;
import com.anthem.glp.persistence.repository.study.StudyNumberRepo;
import com.anthem.glp.persistence.repository.study.StudyPersonnelRepo;
import com.anthem.glp.web.service.admin.implementation.DirectorServiceImpl;
import com.anthem.glp.web.service.study.StudyDirectorService;
import com.anthem.glp.web.service.study.StudyNumberService;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyDirectorDTO;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.repository.user.UserRepo;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.StudyStatus;
import com.anthem.util.common.StudyUserRole;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class StudyDirectorServiceImpl implements StudyDirectorService {

	private StudyDirectorRepo directorRepo;
	private StudyNumberRepo numberRepo;
	private ResponseMessage auditTrail;
	private StudyNumberService numberService;
	private StudyPersonnelRepo personnelRepo;
	private UserRepo userRepo;

	static StudyDirectorDTO convertToDto(StudyDirector obj) {
		StudyDirectorDTO dto = new StudyDirectorDTO();
		dto.setId(obj.getId());
		dto.setStudyNumber(new StudyNumberDTO(obj.getStudyNumber()));
		dto.setDirector(DirectorServiceImpl.convertDto(obj.getDirector()));
		dto.setSpecialNotes(obj.getSpecialNotes());
		dto.setCreatedBy(new UserBasicDetailsDTO(obj.getCreatedBy()));
		dto.setCreatedDate(obj.getCreatedDate());
		return null;
	}

	static StudyDirector convertToObj(StudyDirectorDTO dto) {
		StudyDirector obj = new StudyDirector();
		StudyNumber studyNumber = new StudyNumber();
		studyNumber.setId(dto.getStudyNumber().getId());
		obj.setStudyNumber(studyNumber);
		obj.setDirector(DirectorServiceImpl.convertObject(dto.getDirector()));
		return obj;
	}

	@Autowired
	public StudyDirectorServiceImpl(StudyDirectorRepo studyDirectorRepo, StudyNumberRepo studyNumberRepo,
			ResponseMessage responseMessage, StudyNumberService numberService, StudyPersonnelRepo personnelRepo,
			UserRepo userRepo) {
		this.directorRepo = studyDirectorRepo;
		this.numberRepo = studyNumberRepo;
		this.auditTrail = responseMessage;
		this.numberService = numberService;
		this.personnelRepo = personnelRepo;
		this.userRepo = userRepo;
	}

	@Override
	@Transactional
	public String saveStudyDirector(List<StudyDirector> directors, User user) {
		String message = "Something went wrong !.", allotmentNo = "";
		List<String> directos = new ArrayList<String>();
		if (directors != null && directors.size() > 0) {
			Iterator<StudyDirector> iterator = directors.iterator();
			while (iterator.hasNext()) {
				StudyDirector director = iterator.next();
				// System.out.println("director obj:" + director.toString());
				User directorObj = userRepo.findById(director.getDirector().getDirector().getId());
				// System.out.println("test***" + directorObj.getFullName());
				UserBasicDetailsDTO dto = new UserBasicDetailsDTO(directorObj);
				// System.out.println("test***"+dto.toString());
				directos.add(dto.getDisplayName());
				StudyDirector saved = directorRepo.save(director);
				StudyNumber number = numberRepo.findOne(director.getStudyNumber().getId());
				StudyNumberDTO studyNumberDTO = new StudyNumberDTO(number);

				auditTrail.takeAuditTrail(
						saved.getId(), "Study Director Allocation", null, "Study director '" + dto.getDisplayName()
								+ "' allocated for study '" + studyNumberDTO.getStudyNumber() + "'.",
						saved.getCreatedBy());

			}
			Long studyId = directors.get(0).getStudyNumber().getId();
			StudyNumber number = numberRepo.findOne(studyId);

			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			String systemYear = df.format(date).substring(8);
			if (number.getStudyCategory().equalsIgnoreCase("glp")) {
				allotmentNo = "SAL" + systemYear + String.format("%05d", studyId);
			} else {
				allotmentNo = "SALN" + systemYear + String.format("%05d", studyId);
			}
			number.setAllotmentNumber(allotmentNo);
			number.setAllottedBy(user);
			number.setAllottedDate(date);
			number.setStudyStatus(StudyStatus.DIRECTOR_ALLOCATED);

			auditTrail.takeAuditTrail(number.getId(), "Study Allotement", null,
					"Study alloted '" + allotmentNo + "' with directos '" + String.join(",", directos) + "' for study '"
							+ number.getStudyNumber() + "'.",
					user);
		}
		message = "Study allotted, Reference No :" + allotmentNo;
		return message;
	}

	@Override
	public StudyDetailsDTO fetchStudyDetails(Long studyId) {
		StudyDetailsDTO dto = new StudyDetailsDTO();
		dto = numberService.getStudyDetails(studyId);
		return dto;
	}

	@Override
	@Transactional
	public String updateStudyAllotmentAcceptanceStatus(Long id, ApproveStatus approveStatus,
			StudyUserRole studyUserRole, String studyNumber) {
		String message = "Something went wrong !.";
		if (studyUserRole.equals(StudyUserRole.DIRECTOR)) {
			StudyDirector director = directorRepo.findOne(id);
			if (approveStatus.equals(ApproveStatus.APPROVED)) {
				director.setApproveStatus(ApproveStatus.APPROVED);
			} else if (approveStatus.equals(ApproveStatus.REJECTED)) {
				director.setApproveStatus(ApproveStatus.REJECTED);
			}
			director.setApprovedDate(new Date());
			message = "Success";
			StudyDirector savedStudyDirector = directorRepo.save(director);
			auditTrail
					.takeAuditTrail(savedStudyDirector.getId(), "Study Director Allotment Acceptance ", null,
							"Study director allotment acceptance " + savedStudyDirector.getApproveStatus()
									+ " for studyNumber " + studyNumber + ".",
							savedStudyDirector.getDirector().getDirector());
		} else if (studyUserRole.equals(StudyUserRole.PERSONNEL)) {
			StudyPersonnel personnel = personnelRepo.findOne(id);
			if (approveStatus.equals(ApproveStatus.APPROVED)) {
				personnel.setApproveStatus(ApproveStatus.APPROVED);
			} else if (approveStatus.equals(ApproveStatus.REJECTED)) {
				personnel.setApproveStatus(ApproveStatus.REJECTED);
			}
			personnel.setApprovedDate(new Date());
			StudyPersonnel savedStudyPersonnel = personnelRepo.save(personnel);
			message = "Success";
			auditTrail.takeAuditTrail(savedStudyPersonnel.getId(), "Study Personnel Allotment Acceptance", null,
					"Study personnel allotment acceptance " + savedStudyPersonnel.getApproveStatus()
							+ " for studyNumber " + studyNumber + ".",
					savedStudyPersonnel.getPerson());
		}
		return message;
	}

}
