package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyNumberDTO {

	private Long id;
	private TestItemReceiptDTO testItemReceipt;
	private String studyCategory;
	private String studyNumber;
	private StudyStatus studyStatus;

	private String allotmentNumber;
	private UserBasicDetailsDTO allottedBy;
	private Date allottedDate;

	private String specialNotes;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	private IdCodeName branch;

	public StudyNumberDTO() {
		super();
	}

	public StudyNumberDTO(StudyNumber studyNumber) {
		super();
		this.id = studyNumber.getId();
		this.testItemReceipt = new TestItemReceiptDTO(studyNumber.getTestItemReceipt());
		this.studyCategory = studyNumber.getStudyCategory();
		this.studyNumber = studyNumber.getStudyNumber();
		this.studyStatus = studyNumber.getStudyStatus();
		this.allotmentNumber = studyNumber.getAllotmentNumber();
		if (studyNumber.getAllottedBy() != null) {
			this.allottedBy = new UserBasicDetailsDTO(studyNumber.getAllottedBy());
		}
		this.allottedDate = studyNumber.getAllottedDate();
		this.specialNotes = studyNumber.getSpecialNotes();
		this.createdBy = new UserBasicDetailsDTO(studyNumber.getCreatedBy());
		this.createdDate = studyNumber.getCreatedDate();
		this.branch = new IdCodeName(studyNumber.getBranch().getId(), studyNumber.getBranch().getName());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TestItemReceiptDTO getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceiptDTO testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public String getStudyCategory() {
		return studyCategory;
	}

	public void setStudyCategory(String studyCategory) {
		this.studyCategory = studyCategory;
	}

	public String getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(String studyNumber) {
		this.studyNumber = studyNumber;
	}

	public StudyStatus getStudyStatus() {
		return studyStatus;
	}

	public void setStudyStatus(StudyStatus studyStatus) {
		this.studyStatus = studyStatus;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public IdCodeName getBranch() {
		return branch;
	}

	public void setBranch(IdCodeName branch) {
		this.branch = branch;
	}

	public String getAllotmentNumber() {
		return allotmentNumber;
	}

	public void setAllotmentNumber(String allotmentNumber) {
		this.allotmentNumber = allotmentNumber;
	}

	public UserBasicDetailsDTO getAllottedBy() {
		return allottedBy;
	}

	public void setAllottedBy(UserBasicDetailsDTO allottedBy) {
		this.allottedBy = allottedBy;
	}

	public Date getAllottedDate() {
		return allottedDate;
	}

	public void setAllottedDate(Date allottedDate) {
		this.allottedDate = allottedDate;
	}
}
