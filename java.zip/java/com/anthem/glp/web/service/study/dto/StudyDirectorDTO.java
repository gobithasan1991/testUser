package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.web.service.admin.dto.DirectorDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyDirectorDTO {

	public StudyDirectorDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	private Long id;
	private StudyNumberDTO studyNumber;
	private DirectorDTO director;
	private String specialNotes;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyNumberDTO getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumberDTO studyNumber) {
		this.studyNumber = studyNumber;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public DirectorDTO getDirector() {
		return director;
	}

	public void setDirector(DirectorDTO director) {
		this.director = director;
	}

}
