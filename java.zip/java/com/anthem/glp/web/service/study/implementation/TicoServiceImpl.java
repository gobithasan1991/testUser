package com.anthem.glp.web.service.study.implementation;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.anthem.glp.persistence.model.study.TICO;
import com.anthem.glp.persistence.repository.study.TestItemReceiptRepo;
import com.anthem.glp.persistence.repository.study.TicoRepo;
import com.anthem.glp.web.service.study.TicoService;
import com.anthem.glp.web.service.study.dto.TicoDTO;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.TestItemStatus;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class TicoServiceImpl implements TicoService {

	private TicoRepo ticoRepo;
	private TestItemReceiptRepo testItemReceiptRepo;
	private ResponseMessage auditTrail;

	public TicoServiceImpl(TicoRepo ticoRepo, TestItemReceiptRepo testItemReceiptRepo, ResponseMessage auditTrail) {
		super();
		this.ticoRepo = ticoRepo;
		this.testItemReceiptRepo = testItemReceiptRepo;
		this.auditTrail = auditTrail;
	}

	@Override
	public String saveTico(TICO tico) {

		String message = "Something went wrong";
		if (tico != null) {
			TICO ticoSaved = ticoRepo.save(tico);
			testItemReceiptRepo.updateStudyNumberStatus(tico.getTestItemReceipt().getId(), TestItemStatus.TICO_ENTERED);

			UserBasicDetailsDTO dto = new UserBasicDetailsDTO(tico.getCreatedBy());
			auditTrail.takeAuditTrail(ticoSaved.getId(), "TICO", null, "TICO " + ticoSaved.getItemValue() + " Entered By " + dto.getDisplayName(), ticoSaved.getCreatedBy());
			message = "Success";
		}
		return message;
	}

	@Override
	public Page<TicoDTO> getAllTico(Pageable pagable) {

		return ticoRepo.getAllTico(EnabledStatus.OPEN, pagable);
	}

	@Override
	public TicoDTO getTicoByTestItemReceipt(Long testItemId) {

		return ticoRepo.getTicoByTestItemReceipt(testItemId, EnabledStatus.OPEN);
	}

}
