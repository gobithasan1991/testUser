package com.anthem.glp.web.service.study.dto;

import com.anthem.glp.persistence.model.study.QAUCheck;
import com.anthem.util.common.QAUAnswer;
import com.anthem.web.service.common.dto.DefaultsDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class QAUCheckDTO extends DefaultsDTO {
	private Long id;

	private String question;

	private QAUAnswer qauAnswer;

	private String remark;

	public QAUCheckDTO(QAUCheck qauCheck) {
		super();
		this.id = qauCheck.getId();
		this.question = qauCheck.getQuestion();
		this.qauAnswer = qauCheck.getQauAnswer();
		this.remark = qauCheck.getRemark();
		if (qauCheck.getCreatedBy() != null) {
			this.setCreatedBy(new UserBasicDetailsDTO(qauCheck.getCreatedBy()));
			this.setCreatedDate(qauCheck.getCreatedDate());
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public QAUAnswer getQauAnswer() {
		return qauAnswer;
	}

	public void setQauAnswer(QAUAnswer qauAnswer) {
		this.qauAnswer = qauAnswer;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
