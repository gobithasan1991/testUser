package com.anthem.glp.web.service.study.implementation;

import java.io.InputStream;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.document.entity.FileType;
import com.anthem.document.entity.VersionDocumentWithDetails;
import com.anthem.document.helpers.DocumentManager;
import com.anthem.document.helpers.FileUtility;
import com.anthem.glp.persistence.model.study.StudyPlan;
import com.anthem.glp.persistence.model.study.StudyPlanDocumentVersion;
import com.anthem.glp.persistence.model.study.StudyPlanReviewApproveMapping;
import com.anthem.glp.persistence.repository.study.StudyNumberRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanDocumentVersionRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanReviewApproveMappingRepo;
import com.anthem.glp.web.service.study.StudyPlanReviewApproveMappingService;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.Constants;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.ReturnStatus;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.user.UserService;

@Service
public class StudyPlanReviewApproveMappingServiceImpl implements StudyPlanReviewApproveMappingService {

	private StudyPlanReviewApproveMappingRepo studyPlanReviewApproveMappingRepo;
	private StudyPlanRepo studyPlanRepo;
	private StudyNumberRepo studyNumberRepo;
	private StudyPlanDocumentVersionRepo studyPlanDocumentVersionRepo;
	private UserService userService;
	private ResponseMessage responseMessage;

	@Autowired
	public StudyPlanReviewApproveMappingServiceImpl(StudyPlanReviewApproveMappingRepo studyPlanReviewApproveMappingRepo,
			UserService userService, StudyNumberRepo studyNumberRepo, StudyPlanRepo studyPlanRepo,
			ResponseMessage responseMessage, StudyPlanDocumentVersionRepo studyPlanDocumentVersionRepo) {
		super();
		this.studyPlanReviewApproveMappingRepo = studyPlanReviewApproveMappingRepo;
		this.studyNumberRepo = studyNumberRepo;
		this.studyPlanRepo = studyPlanRepo;
		this.userService = userService;
		this.responseMessage = responseMessage;
		this.studyPlanDocumentVersionRepo = studyPlanDocumentVersionRepo;
	}

	@Override
	@Transactional
	public ReturnStatus studyPlanReviewById(HttpServletRequest request) {

		int reviewCount = 0, reviewedCount = 0;
		try {
			User user = null;
			String userId = request.getParameter("userId");
			if (userId != null && !userId.isEmpty()) {
				user = userService.findOne(new Long(userId));
			} else {
				user = userService.checkUsername(request.getParameter("user"));
			}
			Long mappingId = Long.valueOf(request.getParameter("id"));
			StudyPlanReviewApproveMapping planReviewApproveMapping = studyPlanReviewApproveMappingRepo.findOne(mappingId);
			planReviewApproveMapping.setMappingStatus(CustomStatus.REVIEWED);
			planReviewApproveMapping.setModifiedBy(user);
			planReviewApproveMapping.setUpdatedBy(user);
			planReviewApproveMapping.setUpdatedDate(new Date());
			studyPlanReviewApproveMappingRepo.save(planReviewApproveMapping);

			reviewCount = studyPlanReviewApproveMappingRepo.getReviewerCounts(planReviewApproveMapping.getStudyPlan().getId(), "Review", EnabledStatus.OPEN);
			reviewedCount = studyPlanReviewApproveMappingRepo.getReviewedCounts(planReviewApproveMapping.getStudyPlan().getId(), "Review", CustomStatus.REVIEWED, EnabledStatus.OPEN);

			if (reviewCount == reviewedCount) {
				studyNumberRepo.updateStudyStatus(planReviewApproveMapping.getStudyPlan().getStudyNumber().getId(), StudyStatus.PLAN_REVIEWED);
			} else {
				studyNumberRepo.updateStudyStatus(planReviewApproveMapping.getStudyPlan().getStudyNumber().getId(), StudyStatus.PLAN_PARTIALLY_REVIEWED);
			}
			return ReturnStatus.SUCCESS;
		} catch (Exception e) {
			return ReturnStatus.FAILURE;
		}
	}

	@Override
	public ReturnStatus studyPlanRejectById(HttpServletRequest request) {
		
		try {
			User user = null;
			String userId = request.getParameter("userId");
			String documentUserType = request.getParameter("documentUserType");
			if (userId != null && !userId.isEmpty()) {
				user = userService.findOne(new Long(userId));
			} else {
				user = userService.checkUsername(request.getParameter("user"));
			}
						
			Long mappingId = Long.valueOf(request.getParameter("id"));
			StudyPlanReviewApproveMapping planReviewApproveMapping = studyPlanReviewApproveMappingRepo.findOne(mappingId);
			planReviewApproveMapping.setMappingStatus(CustomStatus.REJECTED);
			planReviewApproveMapping.setModifiedBy(user);
			planReviewApproveMapping.setUpdatedBy(user);
			planReviewApproveMapping.setUpdatedDate(new Date());
			studyPlanReviewApproveMappingRepo.save(planReviewApproveMapping);
			if(documentUserType.equalsIgnoreCase("Reviewer")) {
				studyNumberRepo.updateStudyStatus(planReviewApproveMapping.getStudyPlan().getStudyNumber().getId(), StudyStatus.PLAN_REVIEW_REJECTED);
			} else if(documentUserType.equalsIgnoreCase("Approver")) {
				studyNumberRepo.updateStudyStatus(planReviewApproveMapping.getStudyPlan().getStudyNumber().getId(), StudyStatus.PLAN_APPROVE_REJECTED);
			}
			return ReturnStatus.SUCCESS;
		} catch (Exception e) {
			return ReturnStatus.FAILURE;
		}
	}

	@Override
	@Transactional
	public Map<Long, String> studyPlanApproveById(VersionDocumentWithDetails versionDocumentWithDetails,
			HttpServletRequest request, HttpServletResponse response) {
				
		String result = "";
		String docCaption = "", docName = "", docVersionName = "", currentversionNo = "", hostAddress = "", path = "";
		long version = 0;
		int approveCount = 0, approvedCount = 0;
		Map<Long, String> resultMap = new HashMap<Long, String>();
		
		try {
			User user = null;
			String userId = versionDocumentWithDetails.getUserId();
			if (userId != null && !userId.isEmpty()) {
				user = userService.findOne(new Long(userId));
			} else {
				user = userService.checkUsername(versionDocumentWithDetails.getUser());
			}
			Long mappingId = Long.valueOf(request.getParameter("id"));
			StudyPlanReviewApproveMapping planReviewApproveMapping = studyPlanReviewApproveMappingRepo.findOne(mappingId);
			planReviewApproveMapping.setMappingStatus(CustomStatus.APPROVED);
			planReviewApproveMapping.setModifiedBy(user);
			planReviewApproveMapping.setUpdatedBy(user);
			planReviewApproveMapping.setUpdatedDate(new Date());
			studyPlanReviewApproveMappingRepo.save(planReviewApproveMapping);
			
			docCaption = versionDocumentWithDetails.getDocCap();
			docName = docCaption.substring(0, docCaption.lastIndexOf("."));
			
			DocumentManager.Init(request, response);
			hostAddress = DocumentManager.CurUserHostAddress(null);
			path = DocumentManager.GetApprovedVersionPath(docCaption, null);
			URL url = new URL(versionDocumentWithDetails.getFile());
			java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
			InputStream is = connection.getInputStream();
			StudyPlan studyPlan = studyPlanRepo.getStudyPlanById(planReviewApproveMapping.getStudyPlan().getId(), EnabledStatus.OPEN);
						
			approveCount = studyPlanReviewApproveMappingRepo.getReviewerCounts(studyPlan.getId(), "Approve", EnabledStatus.OPEN);
			approvedCount = studyPlanReviewApproveMappingRepo.getReviewedCounts(studyPlan.getId(), "Approve", CustomStatus.APPROVED, EnabledStatus.OPEN);
						
			if (approveCount == approvedCount) {
				version = Long.valueOf(studyPlan.getVersionNo());
				currentversionNo = String.format(Constants.NUMBER_FORMAT_CONSTANT_3, (version));
				if (FileUtility.GetFileType(docCaption).equals(FileType.Text)) {
					docVersionName = docName + Constants.DOCUMENT_VERSION_PREFIX + currentversionNo + ".docx";
				} else if (FileUtility.GetFileType(docCaption).equals(FileType.Spreadsheet)) {
					docVersionName = docName + Constants.DOCUMENT_VERSION_PREFIX + currentversionNo + ".xlsx";
				} else if (FileUtility.GetFileType(docCaption).equals(FileType.Presentation)) {
					docVersionName = docName + Constants.DOCUMENT_VERSION_PREFIX + currentversionNo + ".pptx";
				} else {
					result = responseMessage.genarateMessage(ReturnStatus.FAILURE, "Document type not matched with File Type for create version");
					resultMap.put(0L, result);
				}
				studyPlan.setVersionNo(currentversionNo);
				studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_APPROVED);
				
				DocumentManager.createDemo(path + "\\" + docVersionName, is, docVersionName, user.getId() + "", user.getFullName(), false);
				// for new Version
				StudyPlanDocumentVersion studyPlanDocumentVersion = new StudyPlanDocumentVersion();
				studyPlanDocumentVersion.setCreatedDate(new Date());
				studyPlanDocumentVersion.setCreatedBy(user);
				studyPlanDocumentVersion.setVersionno(currentversionNo);
				studyPlanDocumentVersion.setStudyPlan(studyPlan);
				studyPlanDocumentVersion.setVersionUUID(UUID.randomUUID().toString() + System.currentTimeMillis());
				studyPlanDocumentVersion.setVersionFileName(docVersionName);
				studyPlanDocumentVersionRepo.save(studyPlanDocumentVersion);
				
				result = responseMessage.genarateMessage(ReturnStatus.SUCCESS, "Study Plan Approved");
			} else {
				studyNumberRepo.updateStudyStatus(studyPlan.getStudyNumber().getId(), StudyStatus.PLAN_PARTIALLY_APPROVED);
				result = responseMessage.genarateMessage(ReturnStatus.SUCCESS, "Study Plan Partially Approved");
			}
			resultMap.put(planReviewApproveMapping.getId(), result);
			
		} catch (Exception e) {
			result = responseMessage.genarateMessage(ReturnStatus.FAILURE, "Unable to Approve Template, Please Contact IT");
			resultMap.put(0L, result);
		}
		return resultMap;
	}

}
