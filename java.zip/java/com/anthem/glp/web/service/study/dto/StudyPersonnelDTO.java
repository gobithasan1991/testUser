package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.persistence.model.study.StudyPersonnel;
import com.anthem.util.common.ApproveStatus;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyPersonnelDTO {

	public StudyPersonnelDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	private Long id;
	private StudyNumberDTO studyNumber;
	private UserBasicDetailsDTO person;
	private String specialNotes;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;
	private ApproveStatus approveStatus;

	public StudyPersonnelDTO(StudyPersonnel obj) {
		super();
		this.id = obj.getId();
		this.studyNumber = new StudyNumberDTO(obj.getStudyNumber());
		this.person = new UserBasicDetailsDTO(obj.getPerson());
		this.specialNotes = obj.getSpecialNotes();
		this.createdBy = new UserBasicDetailsDTO(obj.getCreatedBy());
		this.createdDate = obj.getCreatedDate();
		this.approveStatus = obj.getApproveStatus();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyNumberDTO getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumberDTO studyNumber) {
		this.studyNumber = studyNumber;
	}

	public UserBasicDetailsDTO getPerson() {
		return person;
	}

	public void setPerson(UserBasicDetailsDTO person) {
		this.person = person;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

}
