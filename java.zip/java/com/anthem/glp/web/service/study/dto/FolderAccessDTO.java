package com.anthem.glp.web.service.study.dto;

import java.util.List;

import com.anthem.web.service.common.dto.DefaultsDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class FolderAccessDTO extends DefaultsDTO {
	private Long id;

	private String folderAccessType;

	private List<UserBasicDetailsDTO> userBasicDetailsDTOs;

	public FolderAccessDTO() {
		super();
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the folderAccessType
	 */
	public String getFolderAccessType() {
		return folderAccessType;
	}

	/**
	 * @param folderAccessType the folderAccessType to set
	 */
	public void setFolderAccessType(String folderAccessType) {
		this.folderAccessType = folderAccessType;
	}

	/**
	 * @return the userBasicDetailsDTOs
	 */
	public List<UserBasicDetailsDTO> getUserBasicDetailsDTOs() {
		return userBasicDetailsDTOs;
	}

	/**
	 * @param userBasicDetailsDTOs the userBasicDetailsDTOs to set
	 */
	public void setUserBasicDetailsDTOs(List<UserBasicDetailsDTO> userBasicDetailsDTOs) {
		this.userBasicDetailsDTOs = userBasicDetailsDTOs;
	}

}
