package com.anthem.glp.web.service.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anthem.glp.persistence.model.study.QAUVerificationRequest;
import com.anthem.glp.web.service.study.dto.QAUVerificationRequestDTO;
import com.anthem.persistence.model.user.User;

public interface QAUVerificationEntryService {

	public String saveQAUVerificationEntry(QAUVerificationRequest qauVerificationRequest, User user);

	public Page<QAUVerificationRequestDTO> getQAUVerificationEntryDetailsByAll(Pageable pagable);

	public QAUVerificationRequestDTO getCheckListForQAUVerificationOfStudyFolderById(Long id);

}
