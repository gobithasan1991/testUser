package com.anthem.glp.web.service.study.dto;

import java.util.Date;
import java.util.List;

import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyPlanDTO {

	private Long id;
	private StudyNumberDTO studyNumber;
	private String documentForm;
	private String fileId;
	private String fileName;

	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	private List<StudyPlanReviewApproveMappingDto> studyPlanReviewApproveMapping;

	public StudyPlanDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyNumberDTO getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumberDTO studyNumber) {
		this.studyNumber = studyNumber;
	}

	public String getDocumentForm() {
		return documentForm;
	}

	public void setDocumentForm(String documentForm) {
		this.documentForm = documentForm;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public List<StudyPlanReviewApproveMappingDto> getStudyPlanReviewApproveMapping() {
		return studyPlanReviewApproveMapping;
	}

	public void setStudyPlanReviewApproveMapping(List<StudyPlanReviewApproveMappingDto> studyPlanReviewApproveMapping) {
		this.studyPlanReviewApproveMapping = studyPlanReviewApproveMapping;
	}

}
