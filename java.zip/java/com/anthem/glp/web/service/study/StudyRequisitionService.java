package com.anthem.glp.web.service.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anthem.glp.persistence.model.study.StudyRequisition;
import com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO;
import com.anthem.persistence.model.user.User;

public interface StudyRequisitionService {
	String save(StudyRequisition studyRequisition, User user);
	public Page<StudyRequisitionReportDTO> getStudyRequisitionReportTable(User user, Pageable pageable);
	public Page<StudyRequisitionReportDTO> getStudyRequisitionByPendingStatus(User user, Pageable pageable);
	public StudyRequisitionReportDTO getStudyRequisitionDetails(Long studyRequisitionId);
}
