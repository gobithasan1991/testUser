package com.anthem.glp.web.service.study.implementation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.anthem.document.helpers.DocumentManager;
import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.glp.persistence.model.study.StudyProtocol;
import com.anthem.glp.persistence.model.study.StudyProtocolReviewApproveMapping;
import com.anthem.glp.persistence.repository.study.StudyNumberRepo;
import com.anthem.glp.persistence.repository.study.StudyProtocolRepo;
import com.anthem.glp.persistence.repository.study.StudyProtocolReviewApproveMappingRepo;
import com.anthem.glp.web.service.admin.GLPDocumentTemplateService;
import com.anthem.glp.web.service.study.StudyProtocolService;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.Constants;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.common.dto.OnlyOfficeEditorDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class StudyProtocolServiceImpl implements StudyProtocolService {

	private StudyProtocolRepo studyProtocolRepo;
	private StudyNumberRepo studyNumberRepo;
	private GLPDocumentTemplateService glpDocumentTemplateService;
	private StudyProtocolReviewApproveMappingRepo reviewApproveMappingRepo;
	private ResponseMessage auditTrail;
	
	Branch branch;

	public StudyProtocolServiceImpl(StudyProtocolRepo studyProtocolRepo, StudyNumberRepo studyNumberRepo,
			GLPDocumentTemplateService glpDocumentTemplateService,
			StudyProtocolReviewApproveMappingRepo reviewApproveMappingRepo, ResponseMessage auditTrail) {
		super();
		this.studyProtocolRepo = studyProtocolRepo;
		this.studyNumberRepo = studyNumberRepo;
		this.glpDocumentTemplateService = glpDocumentTemplateService;
		this.reviewApproveMappingRepo = reviewApproveMappingRepo;
		this.auditTrail = auditTrail;
	}

	@Override
	@Transactional
	public Long saveStudyProtocol(StudyProtocol studyProtocol,
			List<StudyProtocolReviewApproveMapping> protocolReviewApproveMappings, MultipartFile file, User user,
			HttpServletRequest request, HttpServletResponse response) throws IOException, FileNotFoundException {

		String documentName = "", path = "", hostAddress = "", fileId = "", fileExtension = "";
		InputStream stream = null;
		if (studyProtocol != null) {
			DocumentManager.Init(request, response);
			fileId = "PROTOCOL" + System.currentTimeMillis() + String.format(Constants.NUMBER_FORMAT_CONSTANT_3, studyProtocolRepo.count() + 1);
			if (file != null && studyProtocol.getGlpDocumentTemplate() == null) {
				fileExtension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."),
						file.getOriginalFilename().length()); 
				stream = file.getInputStream();
			} else {
				GLPDocumentTemplate gdt = glpDocumentTemplateService
						.getGlpDocumentTemplateById(studyProtocol.getGlpDocumentTemplate().getId());
				fileExtension = gdt.getFileId().substring(gdt.getFileId().lastIndexOf(".")); 
				stream = DocumentManager.GetGLPTemplateFile(gdt.getFileId());
			}			
			documentName = fileId + fileExtension.substring(fileExtension.lastIndexOf("."));
			hostAddress = DocumentManager.CurUserHostAddress(null);
			path = DocumentManager.StoragePath(documentName, hostAddress);
			DocumentManager.createDemo(path, stream, documentName, user.getId() + "", user.getFullName(), true);
			studyProtocol.setFileId(fileId);
			studyProtocol.setFileName(documentName);
			StudyProtocol studyProtocolSaved = studyProtocolRepo.save(studyProtocol);
			protocolReviewApproveMappings.forEach(action -> {
				action.setStudyProtocol(studyProtocolSaved);
			});
			reviewApproveMappingRepo.save(protocolReviewApproveMappings);
			studyNumberRepo.updateStudyStatus(studyProtocol.getStudyNumber().getId(), StudyStatus.PROTOCOL_UPLOADED);
			
			StudyNumberDTO studyNumberDTO = studyNumberRepo.getStudyNumberDetailsById(studyProtocol.getStudyNumber().getId(), EnabledStatus.OPEN);
			UserBasicDetailsDTO dto = new UserBasicDetailsDTO(studyProtocol.getCreatedBy());
			auditTrail.takeAuditTrail(studyProtocolSaved.getId(), "Study Protocol", null, "Study Protocol Uploaded For " + studyNumberDTO.getStudyNumber() + " By " + dto.getDisplayName(), studyProtocolSaved.getCreatedBy());
			return studyProtocolSaved.getId();
		}
		return 0L;
	}

	@Override
	public OnlyOfficeEditorDTO getDocumentById(Long studyProtocolId) {

		StudyProtocol studyProtocol = studyProtocolRepo.getStudyProtocolById(studyProtocolId, EnabledStatus.OPEN);
		UserBasicDetailsDTO author = new UserBasicDetailsDTO(studyProtocol.getCreatedBy());
		OnlyOfficeEditorDTO onlyOfficeEditorDTO = new OnlyOfficeEditorDTO(studyProtocolId, studyProtocol.getFileName(), studyProtocol.getStudyNumber().getStudyNumber(), author, studyProtocol.getCreatedDate(), "");
		return onlyOfficeEditorDTO;
	}

	@Override
	public StudyProtocol getStudyProtocolByStudyNumberId(Long studyNumberId) {

		return studyProtocolRepo.getStudyProtocolByStudyNumberId(studyNumberId, EnabledStatus.OPEN);
	}

	@Override
	@Transactional
	public String updateStudyProtocol(Long protocolId, String protocolType, StudyStatus studyStatus, User user) {

		StudyProtocol studyProtocol = studyProtocolRepo.getStudyProtocolById(protocolId, EnabledStatus.OPEN);
		UserBasicDetailsDTO dto = new UserBasicDetailsDTO(studyProtocol.getCreatedBy());
		if (protocolType.equalsIgnoreCase("Review")) {
			studyProtocol.setReviewedBy(user);
			studyProtocol.setReviewedDate(new Date());
			auditTrail.takeAuditTrail(studyProtocol.getId(), "Study Protocol", null, "Study Protocol Reviewed For " + studyProtocol.getStudyNumber().getStudyNumber() + " By " + dto.getDisplayName(), studyProtocol.getCreatedBy());
		} else if (protocolType.equalsIgnoreCase("Approve")) {
			studyProtocol.setApprovedBy(user);
			studyProtocol.setApprovedDate(new Date());
			auditTrail.takeAuditTrail(studyProtocol.getId(), "Study Protocol", null, "Study Protocol Approved For " + studyProtocol.getStudyNumber().getStudyNumber() + " By " + dto.getDisplayName(), studyProtocol.getCreatedBy());
		}
		studyNumberRepo.updateStudyStatus(studyProtocol.getStudyNumber().getId(), studyStatus);
		return "Success";
	}
}
