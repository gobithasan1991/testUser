package com.anthem.glp.web.service.study.dto;

import java.util.Date;

import com.anthem.glp.persistence.model.admin.Nominee;
import com.anthem.glp.persistence.model.admin.Sponsor;
import com.anthem.glp.persistence.model.study.TestItemReceipt;
import com.anthem.util.common.TestItemStatus;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.common.dto.IdNameCodeDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class TestItemReceiptDTO {

	private Long id;
	private SponsorDto sponsorName;
	private IdNameCodeDTO nominee;
	private String itemName;
	private String itemValue;

	private String chemicalName;
	private String casNo;
	private String gravity;
	private String batchType;
	private String batchOrLotValue;
	private String mWeight;
	private String mFormula;
	private String mWeightSalt;
	private String mFormulaSalt;
	private String purity;
	private IdNameCodeDTO batchProducedBy;
	private Date manufactureDate;
	private String dateType;
	private Date expiryDate;
	private IdNameCodeDTO packageType;
	private Double totalQty;
	private IdNameCodeDTO totalQtyUom;
	private Double noOfPackeges;
	private Double grossWeight;
	private IdNameCodeDTO grossWeightUom;
	private Double tareWeight;
	private IdNameCodeDTO tareWeightUom;
	private String modeOfDispatch;
	private IdNameCodeDTO storageCondition;
	private String safetyPrecautions;
	private String materialSafety;
	private String analysisCertificate;
	private String additionalInformations;
	private IdNameCodeDTO sponsorRepresentative;
	private String remarks;
	private String coaDocument;
	private String safetyDocument;
	private String color;
	private String density;
	private String nature;
	private String meltingpoint;
	private String boilingpoint;
	private TestItemStatus testItemStatus;

	private UserBasicDetailsDTO createdBy;
	private Date createdDate;
	private IdCodeName branch;

	public TestItemReceiptDTO() {
		super();
	}

	public TestItemReceiptDTO(Long id, Sponsor sponsor, Nominee nominee, String itemName, String itemValue) {
		super();
		this.id = id;
		this.sponsorName = new SponsorDto(sponsor.getId(), sponsor.getName(), sponsor.getAddress());
		this.nominee = new IdNameCodeDTO(nominee.getId(), nominee.getName());
		this.itemName = itemName;
		this.itemValue = itemValue;
	}

	public TestItemReceiptDTO(TestItemReceipt testItemReceipt) {
		this.id = testItemReceipt.getId();
		this.sponsorName = new SponsorDto(testItemReceipt.getSponsorName().getId(),
				testItemReceipt.getSponsorName().getName(), testItemReceipt.getSponsorName().getAddress());
		this.nominee = new IdNameCodeDTO(testItemReceipt.getNominee().getId(), testItemReceipt.getNominee().getName());
		this.itemName = testItemReceipt.getItemName();
		this.itemValue = testItemReceipt.getItemValue();
		this.chemicalName = testItemReceipt.getChemicalName();
		this.casNo = testItemReceipt.getCasNo();
		this.gravity = testItemReceipt.getGravity();
		this.batchType = testItemReceipt.getBatchType();
		this.batchOrLotValue = testItemReceipt.getBatchOrLotValue();
		this.mWeight = testItemReceipt.getmWeight();
		this.mFormula = testItemReceipt.getmFormula();
		this.mWeightSalt = testItemReceipt.getmWeightSalt();
		this.mFormulaSalt = testItemReceipt.getmFormulaSalt();
		this.purity = testItemReceipt.getPurity();
		this.batchProducedBy = new IdNameCodeDTO(testItemReceipt.getBatchProducedBy().getId(),
				testItemReceipt.getBatchProducedBy().getName());
		this.manufactureDate = testItemReceipt.getManufactureDate();
		this.dateType = testItemReceipt.getDateType();
		this.expiryDate = testItemReceipt.getExpiryDate();
		this.packageType = new IdNameCodeDTO(testItemReceipt.getPackageType().getId(),
				testItemReceipt.getPackageType().getName());
		this.totalQty = testItemReceipt.getTotalQty();
		if(testItemReceipt.getTotalQtyUom() != null) {
			this.totalQtyUom = new IdNameCodeDTO(testItemReceipt.getTotalQtyUom().getId(),
					testItemReceipt.getTotalQtyUom().getCode(), testItemReceipt.getTotalQtyUom().getName());
		}
		this.noOfPackeges = testItemReceipt.getNoOfPackeges();
		this.grossWeight = testItemReceipt.getGrossWeight();
		this.grossWeightUom = new IdNameCodeDTO(testItemReceipt.getGrossWeightUom().getId(),
				testItemReceipt.getGrossWeightUom().getCode(), testItemReceipt.getGrossWeightUom().getName());
		this.tareWeight = testItemReceipt.getTareWeight();
		this.tareWeightUom = new IdNameCodeDTO(testItemReceipt.getTareWeightUom().getId(),
				testItemReceipt.getTareWeightUom().getCode(), testItemReceipt.getTareWeightUom().getName());
		this.modeOfDispatch = testItemReceipt.getModeOfDispatch();
		this.storageCondition = new IdNameCodeDTO(testItemReceipt.getStorageCondition().getId(),
				testItemReceipt.getStorageCondition().getName());
		this.safetyPrecautions = testItemReceipt.getSafetyPrecautions();
		this.materialSafety = testItemReceipt.getMaterialSafety();
		this.analysisCertificate = testItemReceipt.getAnalysisCertificate();
		this.sponsorRepresentative = new IdNameCodeDTO(testItemReceipt.getSponsorRepresentative().getId(),
				testItemReceipt.getSponsorRepresentative().getName());
		this.remarks = testItemReceipt.getRemarks();
		this.coaDocument = testItemReceipt.getCoaDocument();
		this.safetyDocument = testItemReceipt.getSafetyDocument();
		this.color = testItemReceipt.getColor();
		this.density = testItemReceipt.getDensity();
		this.nature = testItemReceipt.getNature();
		this.meltingpoint = testItemReceipt.getMeltingpoint();
		this.boilingpoint = testItemReceipt.getBoilingpoint();
		this.testItemStatus = testItemReceipt.getTestItemStatus();

		this.createdDate = testItemReceipt.getCreatedDate();
		this.createdBy = new UserBasicDetailsDTO(testItemReceipt.getCreatedBy());
		this.branch = new IdCodeName(testItemReceipt.getBranch().getId(), testItemReceipt.getBranch().getName());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public IdNameCodeDTO getNominee() {
		return nominee;
	}

	public void setNominee(IdNameCodeDTO nominee) {
		this.nominee = nominee;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemValue() {
		return itemValue;
	}

	public void setItemValue(String itemValue) {
		this.itemValue = itemValue;
	}

	public String getChemicalName() {
		return chemicalName;
	}

	public void setChemicalName(String chemicalName) {
		this.chemicalName = chemicalName;
	}

	public String getCasNo() {
		return casNo;
	}

	public void setCasNo(String casNo) {
		this.casNo = casNo;
	}

	public String getGravity() {
		return gravity;
	}

	public void setGravity(String gravity) {
		this.gravity = gravity;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public String getBatchOrLotValue() {
		return batchOrLotValue;
	}

	public void setBatchOrLotValue(String batchOrLotValue) {
		this.batchOrLotValue = batchOrLotValue;
	}

	public String getmWeight() {
		return mWeight;
	}

	public void setmWeight(String mWeight) {
		this.mWeight = mWeight;
	}

	public String getmFormula() {
		return mFormula;
	}

	public void setmFormula(String mFormula) {
		this.mFormula = mFormula;
	}

	public String getmWeightSalt() {
		return mWeightSalt;
	}

	public void setmWeightSalt(String mWeightSalt) {
		this.mWeightSalt = mWeightSalt;
	}

	public String getmFormulaSalt() {
		return mFormulaSalt;
	}

	public void setmFormulaSalt(String mFormulaSalt) {
		this.mFormulaSalt = mFormulaSalt;
	}

	public String getPurity() {
		return purity;
	}

	public void setPurity(String purity) {
		this.purity = purity;
	}

	public IdNameCodeDTO getBatchProducedBy() {
		return batchProducedBy;
	}

	public void setBatchProducedBy(IdNameCodeDTO batchProducedBy) {
		this.batchProducedBy = batchProducedBy;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public String getDateType() {
		return dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public IdNameCodeDTO getPackageType() {
		return packageType;
	}

	public void setPackageType(IdNameCodeDTO packageType) {
		this.packageType = packageType;
	}

	public Double getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}

	public IdNameCodeDTO getTotalQtyUom() {
		return totalQtyUom;
	}

	public void setTotalQtyUom(IdNameCodeDTO totalQtyUom) {
		this.totalQtyUom = totalQtyUom;
	}

	public Double getNoOfPackeges() {
		return noOfPackeges;
	}

	public void setNoOfPackeges(Double noOfPackeges) {
		this.noOfPackeges = noOfPackeges;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public IdNameCodeDTO getGrossWeightUom() {
		return grossWeightUom;
	}

	public void setGrossWeightUom(IdNameCodeDTO grossWeightUom) {
		this.grossWeightUom = grossWeightUom;
	}

	public SponsorDto getSponsorName() {
		return sponsorName;
	}

	public void setSponsorName(SponsorDto sponsorName) {
		this.sponsorName = sponsorName;
	}

	public Double getTareWeight() {
		return tareWeight;
	}

	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}

	public IdNameCodeDTO getTareWeightUom() {
		return tareWeightUom;
	}

	public void setTareWeightUom(IdNameCodeDTO tareWeightUom) {
		this.tareWeightUom = tareWeightUom;
	}

	public String getModeOfDispatch() {
		return modeOfDispatch;
	}

	public void setModeOfDispatch(String modeOfDispatch) {
		this.modeOfDispatch = modeOfDispatch;
	}

	public IdNameCodeDTO getStorageCondition() {
		return storageCondition;
	}

	public void setStorageCondition(IdNameCodeDTO storageCondition) {
		this.storageCondition = storageCondition;
	}

	public String getSafetyPrecautions() {
		return safetyPrecautions;
	}

	public void setSafetyPrecautions(String safetyPrecautions) {
		this.safetyPrecautions = safetyPrecautions;
	}

	public String getMaterialSafety() {
		return materialSafety;
	}

	public void setMaterialSafety(String materialSafety) {
		this.materialSafety = materialSafety;
	}

	public String getAnalysisCertificate() {
		return analysisCertificate;
	}

	public void setAnalysisCertificate(String analysisCertificate) {
		this.analysisCertificate = analysisCertificate;
	}

	public String getAdditionalInformations() {
		return additionalInformations;
	}

	public void setAdditionalInformations(String additionalInformations) {
		this.additionalInformations = additionalInformations;
	}

	public IdNameCodeDTO getSponsorRepresentative() {
		return sponsorRepresentative;
	}

	public void setSponsorRepresentative(IdNameCodeDTO sponsorRepresentative) {
		this.sponsorRepresentative = sponsorRepresentative;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCoaDocument() {
		return coaDocument;
	}

	public void setCoaDocument(String coaDocument) {
		this.coaDocument = coaDocument;
	}

	public String getSafetyDocument() {
		return safetyDocument;
	}

	public void setSafetyDocument(String safetyDocument) {
		this.safetyDocument = safetyDocument;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getDensity() {
		return density;
	}

	public void setDensity(String density) {
		this.density = density;
	}

	public String getNature() {
		return nature;
	}

	public void setNature(String nature) {
		this.nature = nature;
	}

	public String getMeltingpoint() {
		return meltingpoint;
	}

	public void setMeltingpoint(String meltingpoint) {
		this.meltingpoint = meltingpoint;
	}

	public String getBoilingpoint() {
		return boilingpoint;
	}

	public void setBoilingpoint(String boilingpoint) {
		this.boilingpoint = boilingpoint;
	}

	public TestItemStatus getTestItemStatus() {
		return testItemStatus;
	}

	public void setTestItemStatus(TestItemStatus testItemStatus) {
		this.testItemStatus = testItemStatus;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public IdCodeName getBranch() {
		return branch;
	}

	public void setBranch(IdCodeName branch) {
		this.branch = branch;
	}

}
