package com.anthem.glp.web.service.study.implementation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.study.StudyRequisition;
import com.anthem.glp.persistence.repository.study.StudyRequisitionRepo;
import com.anthem.glp.web.service.study.StudyRequisitionService;
import com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;

@Service
public class StudyRequisitionServiceImpl implements StudyRequisitionService{
	private StudyRequisitionRepo studyRequisitionRepo;
	private ResponseMessage responseMessage;

	@Autowired
	public StudyRequisitionServiceImpl(StudyRequisitionRepo studyRequisitionRepo, ResponseMessage responseMessage) {
		super();
		this.studyRequisitionRepo = studyRequisitionRepo;
		this.responseMessage = responseMessage;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyRequisitionReportDTO> getStudyRequisitionReportTable(User user, Pageable pageable) {
		return studyRequisitionRepo.getStudyRequisitionReportTable(EnabledStatus.OPEN, pageable);
	}

	@Override
	@Transactional
	public String save(StudyRequisition studyRequisition, User user) {
		String message="Something went wrong!.";
		Date date = new Date();
		StudyRequisition studyRequisitionResult = new StudyRequisition();
		if(studyRequisition.getId() != null) {
			StudyRequisition requisition = studyRequisitionRepo.findOne(studyRequisition.getId());
			requisition.setApproveStatus(studyRequisition.getApproveStatus());
			requisition.setApprovedBy(user);
			requisition.setApprovedDate(date);
			requisition.setApproveRemarks(studyRequisition.getApproveRemarks());
			studyRequisitionResult = studyRequisitionRepo.save(requisition);	
			String description = "Study requisition no : " + studyRequisitionResult.getNumber() + " approved by " + getUserDetailText(studyRequisitionResult.getApprovedBy());
			responseMessage.takeAuditTrail(studyRequisitionResult.getId(), "Study Number Requisition Approve", "0", description, studyRequisitionResult.getCreatedBy());
			message = "Study Requisition Approved";
			if(studyRequisitionResult.getApproveStatus().equals(ApproveStatus.APPROVED)) {
				message = "Study Requisition Approved";
			}else if(studyRequisitionResult.getApproveStatus().equals(ApproveStatus.REJECTED)) {
				message = "Study Requisition Rejected";
			}
		} else {
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			String systemYear = df.format(date).substring(8);
			String sReqNo = "SREQ"  + systemYear;
			int count = (int) (studyRequisitionRepo.findAvailableSeriesCount(sReqNo) + 1);
			sReqNo = "SREQ" + systemYear + String.format("%05d", count);
			studyRequisition.setNumber(sReqNo);
			studyRequisitionResult = studyRequisitionRepo.save(studyRequisition);			
			String description = "Study requisition no : " + studyRequisitionResult.getNumber() + " created by " + getUserDetailText(studyRequisitionResult.getCreatedBy());
			responseMessage.takeAuditTrail(studyRequisitionResult.getId(), "Study Number Requisition Create", "0", description, studyRequisitionResult.getCreatedBy());
			message = "Success";
		}		
		return message;
	}

	@Override
	public StudyRequisitionReportDTO getStudyRequisitionDetails(Long studyRequisitionId) {
		return studyRequisitionRepo.getStudyRequisitionDetails(EnabledStatus.OPEN, studyRequisitionId);
	}
	
	@Override
	public Page<StudyRequisitionReportDTO> getStudyRequisitionByPendingStatus(User user, Pageable pageable) {
		return studyRequisitionRepo.getStudyRequisitionByPendingStatus(EnabledStatus.OPEN,  ApproveStatus.PENDING, pageable);
	}
	
	public String getUserDetailText(User user) {
		String userDetail = user.getFullName(), userDetailSufix = null;
		if (user.getEmployee() != null) {
			userDetailSufix = user.getEmployee().getEmpId();
		}
		if (user.getDepartment() != null) {
			userDetailSufix = (userDetailSufix != null ? userDetailSufix + " / " : "") + user.getDepartment().getCode();
		}
		if (userDetailSufix != null) {
			userDetail += " (" + userDetailSufix + ")";
		}
		return userDetail;
	}	
}
