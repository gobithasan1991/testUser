package com.anthem.glp.web.service.study;

import java.util.List;

import com.anthem.glp.persistence.model.study.StudyDirector;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.StudyUserRole;

public interface StudyDirectorService {
	public String saveStudyDirector(List<StudyDirector> directors, User user);
	
	public String updateStudyAllotmentAcceptanceStatus(Long id, ApproveStatus approveStatus, StudyUserRole studyUserRole, String studyNumber);

	public StudyDetailsDTO fetchStudyDetails(Long studyId);
}
