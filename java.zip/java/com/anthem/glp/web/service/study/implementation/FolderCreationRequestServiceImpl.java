package com.anthem.glp.web.service.study.implementation;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.study.FolderAccess;
import com.anthem.glp.persistence.model.study.FolderCreationRequest;
import com.anthem.glp.persistence.model.study.FolderLocationAndTitle;
import com.anthem.glp.persistence.repository.study.FolderCreationRequestRepo;
import com.anthem.glp.web.service.study.FolderCreationRequestService;
import com.anthem.glp.web.service.study.dto.FolderAccessDTO;
import com.anthem.glp.web.service.study.dto.FolderCreationRequestDTO;
import com.anthem.glp.web.service.study.dto.FolderLocationAndTitleDTO;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.FolderAccessType;
import com.anthem.util.common.FolderCreationStatus;
import com.anthem.web.service.user.UserService;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class FolderCreationRequestServiceImpl implements FolderCreationRequestService {
	private FolderCreationRequestRepo folderCreationRequestRepo;
	private UserService userService;

	@Autowired
	public FolderCreationRequestServiceImpl(FolderCreationRequestRepo folderCreationRequestRepo,
			UserService userService) {
		super();
		this.folderCreationRequestRepo = folderCreationRequestRepo;
		this.userService = userService;
	}

	static FolderCreationRequestDTO convertToDto(FolderCreationRequest obj) {
		FolderCreationRequestDTO dto = new FolderCreationRequestDTO();
		dto.setId(obj.getId());
		dto.setDateRequest(obj.getDateRequest());
		dto.setFolderRelated(obj.getFolderRelated());
		dto.setFolderRelatedOthers(obj.getFolderRelatedOthers());
		dto.setStudyNumberDTO(new StudyNumberDTO(obj.getStudyNumber()));
		dto.setNumberOfFolderRequested(obj.getNumberOfFolderRequested());

		Iterator<FolderLocationAndTitle> iterator = obj.getFolderLocationAndTitles().iterator();
		List<FolderLocationAndTitleDTO> folderLocationAndTitleDTOs = new ArrayList<>();
		while (iterator.hasNext()) {
			folderLocationAndTitleDTOs.add(FolderLocationAndTitleServiceImpl.convertDto(iterator.next()));
		}
		dto.setFolderLocationAndTitleDTOs(folderLocationAndTitleDTOs);
		Iterator<FolderAccess> iterator1 = obj.getFolderAccesses().iterator();
		List<FolderAccessDTO> folderAccessDTOs = new ArrayList<>();
		while (iterator1.hasNext()) {
			FolderAccess fa = iterator1.next();
			List<UserBasicDetailsDTO> userBasicDetailsDTOs = new ArrayList<UserBasicDetailsDTO>();
			FolderAccessDTO fad = new FolderAccessDTO();
			if (fa.getFolderAccessType().equals(FolderAccessType.Read)) {
				fad.setFolderAccessType("Read");
			} else if (fa.getFolderAccessType().equals(FolderAccessType.ReadAndWrite)) {
				fad.setFolderAccessType("Read And Write");
			}
			userBasicDetailsDTOs.add(new UserBasicDetailsDTO(fa.getUser()));
			fad.setUserBasicDetailsDTOs(userBasicDetailsDTOs);
			Optional<FolderAccessDTO> optional = folderAccessDTOs.stream()
					.filter(action -> action.getFolderAccessType().equals(fad.getFolderAccessType())).findFirst();
			if (optional.isPresent()) {
				FolderAccessDTO temp = optional.get();
				temp.getUserBasicDetailsDTOs().add(new UserBasicDetailsDTO(fa.getUser()));
			} else {
				folderAccessDTOs.add(fad);
			}

		}
		dto.setFolderAccessDTOs(folderAccessDTOs);
		if (obj.getAuthorizedBy() != null) {
			dto.setAuthorizedBy(new UserBasicDetailsDTO(obj.getAuthorizedBy()));
			dto.setAuthorizedDate(obj.getAuthorizedDate());
		}
		if (obj.getAcceptedBy() != null) {
			dto.setAcceptedBy(new UserBasicDetailsDTO(obj.getAcceptedBy()));
			dto.setAcceptedDate(obj.getAcceptedDate());
		}
		if (obj.getFolderCreationStatus().equals(FolderCreationStatus.TFMACCEPTED)) {
			dto.setFolderCreationStatus("TFM Accepted");
		} else if (obj.getFolderCreationStatus().equals(FolderCreationStatus.ITACCEPTED)) {
			dto.setFolderCreationStatus("IT Accepted");
		} else if (obj.getFolderCreationStatus().equals(FolderCreationStatus.TFMNOTACCEPTED)) {
			dto.setFolderCreationStatus("TFM Not Accepted");
		} else if (obj.getFolderCreationStatus().equals(FolderCreationStatus.ITNOTACCEPTED)) {
			dto.setFolderCreationStatus("IT Not Accepted");
		} else if (obj.getFolderCreationStatus().equals(FolderCreationStatus.FOLDERCREATED)) {
			dto.setFolderCreationStatus("Folder Created");
		} else if (obj.getFolderCreationStatus().equals(FolderCreationStatus.QAUVERIFICATIONREQUESTED)) {
			dto.setFolderCreationStatus("QAU Verification Requested");
		} else if (obj.getFolderCreationStatus().equals(FolderCreationStatus.QAUVERIFY)) {
			dto.setFolderCreationStatus("QAU Verify");
		} else {
			dto.setFolderCreationStatus(obj.getFolderCreationStatus().toString());
		}
		if (obj.getFolderCreatedBy() != null) {
			dto.setFolderCreatedBy(new UserBasicDetailsDTO(obj.getFolderCreatedBy()));
			dto.setFolderCreatedDate(obj.getFolderCreatedDate());
		}
		if (obj.getFolderCreatedEntryBy() != null) {
			dto.setFolderCreatedEntryBy(new UserBasicDetailsDTO(obj.getFolderCreatedEntryBy()));
			dto.setFolderCreatedEntryDate(obj.getFolderCreatedEntryDate());
		}
		if (obj.getQauVerificationRequestBy() != null) {
			dto.setQauVerificationRequestBy(new UserBasicDetailsDTO(obj.getQauVerificationRequestBy()));
			dto.setQauVerificationRequestDate(obj.getQauVerificationRequestDate());
		}
		dto.setCreatedBy(new UserBasicDetailsDTO(obj.getCreatedBy()));
		dto.setCreatedDate(obj.getCreatedDate());
		return dto;
	}

	@Override
	@Transactional
	public String saveFolderCreationRequest(FolderCreationRequest folderCreationRequest, User user) {
		String message = "Something went wrong !.";
		if (folderCreationRequest != null) {
			folderCreationRequest.setDateRequest(new Date());
			folderCreationRequestRepo.save(folderCreationRequest);
			message = "Success";
		}
		return message;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<FolderCreationRequestDTO> getFolderCreationRequestByFolderCreationStatus(String folderCreationStatus,
			Pageable pagable) {
		if (folderCreationStatus.equalsIgnoreCase("ALL")) {
			return folderCreationRequestRepo.getFolderCreationRequestByAll(EnabledStatus.OPEN, pagable);
		} else {
			return folderCreationRequestRepo.getFolderCreationRequestByFolderCreationStatus(
					FolderCreationStatus.valueOf(folderCreationStatus), EnabledStatus.OPEN, pagable);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public FolderCreationRequestDTO getFolderCreationRequestById(Long folderCreationId) {
		FolderCreationRequestDTO folderCreationRequestDTO = convertToDto(
				folderCreationRequestRepo.getFolderCreationRequestById(folderCreationId, EnabledStatus.OPEN));
		return folderCreationRequestDTO;
	}

	@Override
	public String updateFolderCreationRequestStatusByIdAndStatus(FolderCreationRequest folderCreationRequest1,
			User user) {
		FolderCreationRequest folderCreationRequest = folderCreationRequestRepo
				.getFolderCreationRequestById(folderCreationRequest1.getId());
		String message = "Something went wrong !.";
		String folderCreationStatus = folderCreationRequest1.getFolderCreationStatus().toString();
		if (folderCreationRequest != null) {
			if (folderCreationStatus.equalsIgnoreCase("TFMACCEPTED")
					|| folderCreationStatus.equalsIgnoreCase("TFMNOTACCEPTED")) {
				folderCreationRequest.setAuthorizedBy(user);
				folderCreationRequest.setAuthorizedDate(new Date());
			} else if (folderCreationStatus.equalsIgnoreCase("ITACCEPTED")
					|| folderCreationStatus.equalsIgnoreCase("ITNOTACCEPTED")) {
				folderCreationRequest.setAcceptedBy(user);
				folderCreationRequest.setAcceptedDate(new Date());
			}
			folderCreationRequest.setFolderCreationStatus(FolderCreationStatus.valueOf(folderCreationStatus));
			folderCreationRequestRepo.save(folderCreationRequest);
			message = "Success";
		}
		return message;
	}

	@Override
	public String updateFolderCreationRequestFilledById(FolderCreationRequest folderCreationRequest1, User user) {
		FolderCreationRequest folderCreationRequest = folderCreationRequestRepo
				.getFolderCreationRequestById(folderCreationRequest1.getId());
		String message = "Something went wrong !.";
		if (folderCreationRequest != null) {
			folderCreationRequest
					.setFolderCreatedBy(userService.findOne(folderCreationRequest1.getFolderCreatedBy().getId()));
			folderCreationRequest.setFolderCreatedDate(folderCreationRequest1.getFolderCreatedDate());
			folderCreationRequest.setFolderCreatedEntryBy(user);
			folderCreationRequest.setFolderCreatedEntryDate(new Date());
			folderCreationRequest.setFolderCreationStatus(FolderCreationStatus.FOLDERCREATED);
			folderCreationRequestRepo.save(folderCreationRequest);
			message = "Success";
		}
		return message;
	}

	@Override
	public String QAUVerificationRequestByStudy(Long folderCreationId, User user) {
		FolderCreationRequest folderCreationRequest = folderCreationRequestRepo
				.getFolderCreationRequestById(folderCreationId);
		String message = "Something went wrong !.";
		if (folderCreationRequest != null) {
			folderCreationRequest.setQauVerificationRequestBy(user);
			folderCreationRequest.setQauVerificationRequestDate(new Date());
			folderCreationRequest.setFolderCreationStatus(FolderCreationStatus.QAUVERIFICATIONREQUESTED);
			folderCreationRequestRepo.save(folderCreationRequest);
			message = "Success";
		}
		return message;
	}

}
