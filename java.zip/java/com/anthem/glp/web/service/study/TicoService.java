package com.anthem.glp.web.service.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anthem.glp.persistence.model.study.TICO;
import com.anthem.glp.web.service.study.dto.TicoDTO;

public interface TicoService {

	public String saveTico(TICO tico);

	public Page<TicoDTO> getAllTico(Pageable pagable);

	public TicoDTO getTicoByTestItemReceipt(Long testItemId);

}
