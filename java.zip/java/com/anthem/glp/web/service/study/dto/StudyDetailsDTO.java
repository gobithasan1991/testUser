package com.anthem.glp.web.service.study.dto;

import java.util.Date;
import java.util.Set;

import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

public class StudyDetailsDTO {

	private Long id;
	private TestItemReceiptDTO testItemReceipt;
	private String studyCategory;
	private String studyNumber;
	private StudyStatus studyStatus;

	private String allotmentNumber;
	private UserBasicDetailsDTO allottedBy;
	private Date allottedDate;
	private String specialNotes;
	private UserBasicDetailsDTO createdBy;
	private Date createdDate;

	private Set<StudyUsersDTO> directors;
	private Set<StudyUsersDTO> personnel;
	private UserBasicDetailsDTO personnelAllocatedBy;
	private Date personnelAllocatedDate;

	private UserBasicDetailsDTO personnelReviewdBy;
	private Date personnelReviewdDate;

	private UserBasicDetailsDTO personnelApprovedBy;
	private Date personnelApprovedDate;

	private StudyProtocolDTO protocol;

	private StudyPlanDTO plan;

	private IdCodeName branch;

	public StudyDetailsDTO() {
		super();
	}

	public StudyDetailsDTO(StudyNumber studyNumber) {
		super();
		this.id = studyNumber.getId();
		this.testItemReceipt = new TestItemReceiptDTO(studyNumber.getTestItemReceipt());
		this.studyCategory = studyNumber.getStudyCategory();
		this.studyNumber = studyNumber.getStudyNumber();
		this.studyStatus = studyNumber.getStudyStatus();
		this.allotmentNumber = studyNumber.getAllotmentNumber();
		if (studyNumber.getAllottedBy() != null) {
			this.allottedBy = new UserBasicDetailsDTO(studyNumber.getAllottedBy());
		}
		this.allottedDate = studyNumber.getAllottedDate();
		this.specialNotes = studyNumber.getSpecialNotes();
		this.createdBy = new UserBasicDetailsDTO(studyNumber.getCreatedBy());
		this.createdDate = studyNumber.getCreatedDate();
		this.branch = new IdCodeName(studyNumber.getBranch().getId(), studyNumber.getBranch().getName());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TestItemReceiptDTO getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceiptDTO testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public String getStudyCategory() {
		return studyCategory;
	}

	public void setStudyCategory(String studyCategory) {
		this.studyCategory = studyCategory;
	}

	public String getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(String studyNumber) {
		this.studyNumber = studyNumber;
	}

	public StudyStatus getStudyStatus() {
		return studyStatus;
	}

	public void setStudyStatus(StudyStatus studyStatus) {
		this.studyStatus = studyStatus;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public UserBasicDetailsDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserBasicDetailsDTO createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public IdCodeName getBranch() {
		return branch;
	}

	public void setBranch(IdCodeName branch) {
		this.branch = branch;
	}

	public Set<StudyUsersDTO> getDirectors() {
		return directors;
	}

	public void setDirectors(Set<StudyUsersDTO> directors) {
		this.directors = directors;
	}

	public Set<StudyUsersDTO> getPersonnel() {
		return personnel;
	}

	public void setPersonnel(Set<StudyUsersDTO> personnel) {
		this.personnel = personnel;
	}

	public String getAllotmentNumber() {
		return allotmentNumber;
	}

	public void setAllotmentNumber(String allotmentNumber) {
		this.allotmentNumber = allotmentNumber;
	}

	public UserBasicDetailsDTO getAllottedBy() {
		return allottedBy;
	}

	public void setAllottedBy(UserBasicDetailsDTO allottedBy) {
		this.allottedBy = allottedBy;
	}

	public Date getAllottedDate() {
		return allottedDate;
	}

	public void setAllottedDate(Date allottedDate) {
		this.allottedDate = allottedDate;
	}

	public StudyProtocolDTO getProtocol() {
		return protocol;
	}

	public void setProtocol(StudyProtocolDTO protocol) {
		this.protocol = protocol;
	}

	public StudyPlanDTO getPlan() {
		return plan;
	}

	public void setPlan(StudyPlanDTO plan) {
		this.plan = plan;
	}

	public UserBasicDetailsDTO getPersonnelAllocatedBy() {
		return personnelAllocatedBy;
	}

	public void setPersonnelAllocatedBy(UserBasicDetailsDTO personnelAllocatedBy) {
		this.personnelAllocatedBy = personnelAllocatedBy;
	}

	public Date getPersonnelAllocatedDate() {
		return personnelAllocatedDate;
	}

	public void setPersonnelAllocatedDate(Date personnelAllocatedDate) {
		this.personnelAllocatedDate = personnelAllocatedDate;
	}

	public UserBasicDetailsDTO getPersonnelReviewdBy() {
		return personnelReviewdBy;
	}

	public void setPersonnelReviewdBy(UserBasicDetailsDTO personnelReviewdBy) {
		this.personnelReviewdBy = personnelReviewdBy;
	}

	public Date getPersonnelReviewdDate() {
		return personnelReviewdDate;
	}

	public void setPersonnelReviewdDate(Date personnelReviewdDate) {
		this.personnelReviewdDate = personnelReviewdDate;
	}

	public UserBasicDetailsDTO getPersonnelApprovedBy() {
		return personnelApprovedBy;
	}

	public void setPersonnelApprovedBy(UserBasicDetailsDTO personnelApprovedBy) {
		this.personnelApprovedBy = personnelApprovedBy;
	}

	public Date getPersonnelApprovedDate() {
		return personnelApprovedDate;
	}

	public void setPersonnelApprovedDate(Date personnelApprovedDate) {
		this.personnelApprovedDate = personnelApprovedDate;
	}

}
