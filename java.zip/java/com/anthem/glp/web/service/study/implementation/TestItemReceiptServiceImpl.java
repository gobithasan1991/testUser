package com.anthem.glp.web.service.study.implementation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.anthem.document.helpers.DocumentManager;
import com.anthem.glp.persistence.model.study.TestItemReceipt;
import com.anthem.glp.persistence.repository.study.TestItemReceiptRepo;
import com.anthem.glp.web.service.study.TestItemReceiptService;
import com.anthem.glp.web.service.study.dto.TestItemReceiptDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.Constants;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.TestItemStatus;
import com.anthem.util.mail.MailSenderUtil;
import com.anthem.web.service.admin.MailModuleService;
import com.anthem.web.service.common.dto.Mail;
import com.anthem.web.service.common.dto.OnlyOfficeEditorDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class TestItemReceiptServiceImpl implements TestItemReceiptService {

	private TestItemReceiptRepo testItemReceiptRepo;
	
	private ResponseMessage auditTrail;
	private MailSenderUtil mailSenderutil;
	private MailModuleService mailModuleService;
	Branch branch;

	@Autowired
	public TestItemReceiptServiceImpl(TestItemReceiptRepo testItemReceiptRepo, ResponseMessage auditTrail,
			MailSenderUtil mailSenderutil, MailModuleService mailModuleService) {
		super();
		this.testItemReceiptRepo = testItemReceiptRepo;
		this.auditTrail = auditTrail;
		this.mailSenderutil = mailSenderutil;
		this.mailModuleService = mailModuleService;
	}

	@Override
	public TestItemReceipt saveStudyEnquiry(TestItemReceipt testItemReceipt, MultipartFile coaDocument,
			MultipartFile safetyDocument, User user, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws IOException, FileNotFoundException {
		if (user.getBranches() != null) {
			user.getBranches().forEach(obj -> {
				if (obj.isSelectedBranch())
					branch = obj;
			});
		}
		TestItemReceipt testItem = null;
		if (testItemReceipt != null) {
			if (coaDocument != null) {
				String ext = "", fileId = "", hostAddress = "", path = "";
				InputStream stream = null;
				ext = coaDocument.getOriginalFilename().substring(coaDocument.getOriginalFilename().lastIndexOf("."), coaDocument.getOriginalFilename().length());
				fileId = "STUDY_COA" + System.currentTimeMillis() + String.format(Constants.NUMBER_FORMAT_CONSTANT_3, testItemReceiptRepo.count() + 1);
				testItemReceipt.setCoaDocument(fileId + ext);

				DocumentManager.Init(httpServletRequest, httpServletResponse);
				hostAddress = DocumentManager.CurUserHostAddress(null);
				stream = coaDocument.getInputStream();
				path = DocumentManager.StoragePath(fileId + ext, hostAddress);
				DocumentManager.createDemo(path, stream, fileId + ext, user.getId() + "", user.getFullName(), true);
			}
			if (safetyDocument != null) {
				String ext = "", fileId = "", hostAddress = "", path = "";
				InputStream stream = null;
				ext = safetyDocument.getOriginalFilename().substring(safetyDocument.getOriginalFilename().lastIndexOf("."), safetyDocument.getOriginalFilename().length());
				fileId = "STUDY_SAFETY" + System.currentTimeMillis() + String.format(Constants.NUMBER_FORMAT_CONSTANT_3, testItemReceiptRepo.count() + 1);
				testItemReceipt.setSafetyDocument(fileId + ext);

				DocumentManager.Init(httpServletRequest, httpServletResponse);
				hostAddress = DocumentManager.CurUserHostAddress(null);
				stream = safetyDocument.getInputStream();
				path = DocumentManager.StoragePath(fileId + ext, hostAddress);
				DocumentManager.createDemo(path, stream, fileId + ext, user.getId() + "", user.getFullName(), true);
			}
			testItemReceipt.setBranch(branch);
			testItem = testItemReceiptRepo.save(testItemReceipt);
			
			UserBasicDetailsDTO dto = new UserBasicDetailsDTO(testItem.getCreatedBy());
			auditTrail.takeAuditTrail(testItem.getId(),
					"Test Item Receipt", null, "Test Item Receipt " + testItem.getItemValue() + " Created By " + dto.getDisplayName(),
					testItem.getCreatedBy());
		}
		return testItem;
	}
	
	@Transactional(readOnly = true)
	public String sendTestItemReceiptMail(Long id) {
		String message = "Error";
		if (mailModuleService.findModuleByCode("GLP-TEST_ITEM_RECEIPT").equals(EnabledStatus.OPEN)) {
			TestItemReceipt testItemReceipt = testItemReceiptRepo.findOne(id);
			TestItemReceiptDTO mailPrep = new TestItemReceiptDTO(testItemReceipt);
			Mail mail = new Mail();
			mail.setMailFrom("sudhanesan.k@anthembio.com");
			mail.setMailTo("sudhanesan.k@anthembio.com");
			// mail.setMailTo("kalaiselvan.a@anthembio.com");
			//mail.setMailCc("vigneshwaran.b@anthembio.com");
			mail.setTemplateName("glp/TestItemReceiptMail.ftl");
			mail.setMailSubject("Test Item Receipt");
			mail.setDataaccess("data");
			Map<String, Object> map = new HashMap<>();
			map.put("subject", "Please note that below test item receipt is created. ");
			map.put("testItemReceipt", mailPrep);
			//map.put("type", "request");
			mail.setDatalist(map);
			// mail = emailConfigurationService.getEmailAdressByModule("EA-EMAIL", mail);
			//mailSenderutil.sendTextMail(mail);
		}
		message = "Success";
		return message;
	}

	@Override
	public Page<TestItemReceiptDTO> getAllTestItemReceipts(Pageable pageable) {

		return testItemReceiptRepo.getAllTestItemReceipts(EnabledStatus.OPEN, TestItemStatus.PENDING, pageable);
	}

	@Override
	public TestItemReceiptDTO getTestItemReceiptDtoById(Long testItemId) {

		return testItemReceiptRepo.getTestItemReceiptDtoById(testItemId, EnabledStatus.OPEN);
	}

	@Override
	public TestItemReceipt getTestItemDetailsById(Long testItemId) {

		return testItemReceiptRepo.getTestItemDetailsById(testItemId, EnabledStatus.OPEN);
	}

	@Override
	public OnlyOfficeEditorDTO getCOADocumentById(Long testItemId) {
		TestItemReceipt testItemReceipt = testItemReceiptRepo.getTestItemDetailsById(testItemId, EnabledStatus.OPEN);
		UserBasicDetailsDTO author = new UserBasicDetailsDTO(testItemReceipt.getCreatedBy());
		OnlyOfficeEditorDTO onlyOfficeEditorDTO = new OnlyOfficeEditorDTO(testItemId, testItemReceipt.getCoaDocument(),
				testItemReceipt.getItemValue(), author, testItemReceipt.getCreatedDate(), "");
		return onlyOfficeEditorDTO;
	}
	
	@Override
	public OnlyOfficeEditorDTO getSafetyDocumentById(Long testItemId) {
		TestItemReceipt testItemReceipt = testItemReceiptRepo.getTestItemDetailsById(testItemId, EnabledStatus.OPEN);
		UserBasicDetailsDTO author = new UserBasicDetailsDTO(testItemReceipt.getCreatedBy());
		OnlyOfficeEditorDTO onlyOfficeEditorDTO = new OnlyOfficeEditorDTO(testItemId, testItemReceipt.getSafetyDocument(),
				testItemReceipt.getItemValue(), author, testItemReceipt.getCreatedDate(), "");
		return onlyOfficeEditorDTO;
	}
	

	@Override
	public Page<TestItemReceiptDTO> getTestItemReceiptByChemicalName(String value, Pageable pageable) {
		return testItemReceiptRepo.getTestItemReceiptByChemicalName(value, EnabledStatus.OPEN, pageable);
	}

	@Override
	public Page<TestItemReceiptDTO> getTestItemReceiptByNominee(String value, Pageable pageable) {
		return testItemReceiptRepo.getTestItemReceiptByNominee(value, EnabledStatus.OPEN, pageable);
	}

	@Override
	public Page<TestItemReceiptDTO> getTestItemReceiptBySponsor(String value, Pageable pageable) {
		return testItemReceiptRepo.getTestItemReceiptBySponsor(value, EnabledStatus.OPEN, pageable);
	}

	@Override
	public Page<TestItemReceiptDTO> getTestItemReceiptByTest(String value, Pageable pageable) {
		return testItemReceiptRepo.getTestItemReceiptByTest(value, EnabledStatus.OPEN, pageable);
	}

}
