package com.anthem.glp.web.service.study;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anthem.glp.persistence.model.study.FolderCreationRequest;
import com.anthem.glp.web.service.study.dto.FolderCreationRequestDTO;
import com.anthem.persistence.model.user.User;

public interface FolderCreationRequestService {

	public String saveFolderCreationRequest(FolderCreationRequest folderCreationRequest, User user);

	public Page<FolderCreationRequestDTO> getFolderCreationRequestByFolderCreationStatus(String folderCreationStatus,
			Pageable pagable);

	public FolderCreationRequestDTO getFolderCreationRequestById(Long folderCreationId);

	public String updateFolderCreationRequestStatusByIdAndStatus(FolderCreationRequest folderCreationRequest,
			User user);

	public String updateFolderCreationRequestFilledById(FolderCreationRequest folderCreationRequest, User user);

	public String QAUVerificationRequestByStudy(Long folderCreationId, User user);

}
