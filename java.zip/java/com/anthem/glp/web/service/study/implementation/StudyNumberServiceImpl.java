package com.anthem.glp.web.service.study.implementation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.glp.persistence.model.study.StudyDirector;
import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.glp.persistence.model.study.StudyPersonnel;
import com.anthem.glp.persistence.model.study.StudyPlan;
import com.anthem.glp.persistence.model.study.StudyPlanReviewApproveMapping;
import com.anthem.glp.persistence.repository.study.StudyDirectorRepo;
import com.anthem.glp.persistence.repository.study.StudyNumberRepo;
import com.anthem.glp.persistence.repository.study.StudyPersonnelRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanRepo;
import com.anthem.glp.persistence.repository.study.StudyPlanReviewApproveMappingRepo;
import com.anthem.glp.persistence.repository.study.StudyProtocolReviewApproveMappingRepo;
import com.anthem.glp.persistence.repository.study.TestItemReceiptRepo;
import com.anthem.glp.web.service.admin.dto.DirectorDTO;
import com.anthem.glp.web.service.admin.dto.GLPDepartmentDTO;
import com.anthem.glp.web.service.admin.implementation.DirectorServiceImpl;
import com.anthem.glp.web.service.study.StudyNumberService;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.glp.web.service.study.dto.StudyPersonnelDTO;
import com.anthem.glp.web.service.study.dto.StudyPlanDTO;
import com.anthem.glp.web.service.study.dto.StudyPlanReviewApproveMappingDto;
import com.anthem.glp.web.service.study.dto.StudyUserRoleDTO;
import com.anthem.glp.web.service.study.dto.StudyUsersDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.ResponseMessage;
import com.anthem.util.common.StudyStatus;
import com.anthem.util.common.StudyUserRole;
import com.anthem.util.common.TestItemStatus;
import com.anthem.web.service.admin.dto.DepartmentBasicDTO;
import com.anthem.web.service.common.dto.IdCodeName;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@Service
public class StudyNumberServiceImpl implements StudyNumberService {

	private StudyNumberRepo studyNumberRepo;
	private TestItemReceiptRepo testItemReceiptRepo;
	private StudyDirectorRepo directorRepo;
	private StudyPersonnelRepo personnelRepo;
	private StudyPlanRepo studyPlanRepo;
	private StudyProtocolReviewApproveMappingRepo protocolReviewApproveMappingRepo;
	private StudyPlanReviewApproveMappingRepo planReviewApproveMappingRepo;
	private ResponseMessage auditTrail;
	Branch branch;

	public StudyNumberServiceImpl(StudyNumberRepo studyNumberRepo, TestItemReceiptRepo testItemReceiptRepo,
			StudyDirectorRepo directorRepo, StudyPersonnelRepo personnelRepo, StudyPlanRepo studyPlanRepo,
			StudyProtocolReviewApproveMappingRepo protocolReviewApproveMappingRepo,
			StudyPlanReviewApproveMappingRepo planReviewApproveMappingRepo, ResponseMessage auditTrail) {
		super();
		this.studyNumberRepo = studyNumberRepo;
		this.testItemReceiptRepo = testItemReceiptRepo;
		this.directorRepo = directorRepo;
		this.personnelRepo = personnelRepo;
		this.studyPlanRepo = studyPlanRepo;
		this.protocolReviewApproveMappingRepo = protocolReviewApproveMappingRepo;
		this.planReviewApproveMappingRepo = planReviewApproveMappingRepo;
		this.auditTrail = auditTrail;
	}

	@Override
	@Transactional(readOnly = true)
	public StudyDetailsDTO getStudyDetails(Long studyId) {
		StudyNumber number = studyNumberRepo.getOne(studyId);
		if (number != null) {
			StudyDetailsDTO dto = new StudyDetailsDTO(number);

			List<StudyDirector> directors = directorRepo.findAllStudyDirectorsByStudyId(studyId, EnabledStatus.OPEN);
			if (directors != null && directors.size() > 0) {
				Set<StudyUsersDTO> studyUsersDTOs = new HashSet<>();
				Map<IdCodeName, List<DirectorDTO>> map = new HashMap<>();
				Iterator<StudyDirector> iterator = directors.iterator();
				while (iterator.hasNext()) {
					StudyDirector director = iterator.next();
					DirectorDTO directorDto = DirectorServiceImpl.convertDto(director.getDirector());
					directorDto.setApproveStatus(director.getApproveStatus());
					GLPDepartment department = director.getDirector().getGlpDepartment();
					IdCodeName dept = new IdCodeName(department.getId(), department.getCode(), department.getName());
					if (map.get(dept) != null) {
						map.get(dept).add(directorDto);
					} else {
						ArrayList<DirectorDTO> arrayList = new ArrayList<>();
						arrayList.add(directorDto);
						map.put(dept, arrayList);
					}
				}
				studyUsersDTOs = map.entrySet().stream()
						.map(mapper -> new StudyUsersDTO(mapper.getKey(), mapper.getValue()))
						.collect(Collectors.toSet());
				dto.setDirectors(studyUsersDTOs);
			}

			List<StudyPersonnel> personnels = personnelRepo.findAllPersonnelByStudy(studyId, EnabledStatus.OPEN);
			if (personnels != null && personnels.size() > 0) {
				Set<StudyUsersDTO> studyUsersDTOs = new HashSet<>();
				Map<IdCodeName, List<StudyPersonnelDTO>> map = new HashMap<>();
				Iterator<StudyPersonnel> iterator = personnels.iterator();
				while (iterator.hasNext()) {
					StudyPersonnel director = iterator.next();
					StudyPersonnelDTO basicDetailsDTO = new StudyPersonnelDTO(director);
					DepartmentBasicDTO department = basicDetailsDTO.getPerson().getEmployee().getDepartment();
					IdCodeName dept = new IdCodeName(department.getId(), department.getCode(), department.getName());
					if (map.get(dept) != null) {
						map.get(dept).add(basicDetailsDTO);
					} else {
						ArrayList<StudyPersonnelDTO> arrayList = new ArrayList<>();
						arrayList.add(basicDetailsDTO);
						map.put(dept, arrayList);
					}
				}
				studyUsersDTOs = map.entrySet().stream()
						.map(mapper -> new StudyUsersDTO(mapper.getValue(), mapper.getKey()))
						.collect(Collectors.toSet());
				dto.setPersonnel(studyUsersDTOs);
				dto.setPersonnelAllocatedBy(new UserBasicDetailsDTO(personnels.get(0).getCreatedBy()));
				dto.setPersonnelAllocatedDate(personnels.get(0).getCreatedDate());
			}

			StudyPlan plan = studyPlanRepo.getStudyPlanByStudyId(studyId, EnabledStatus.OPEN);
			if (plan != null) {
				StudyPlanDTO planDto = new StudyPlanDTO();
				planDto.setId(plan.getId());
				planDto.setStudyNumber(new StudyNumberDTO(plan.getStudyNumber()));
				planDto.setDocumentForm(plan.getDocumentForm());
				planDto.setFileId(plan.getFileId());
				planDto.setFileName(plan.getFileName());
				if (plan.getCreatedBy() != null) {
					planDto.setCreatedBy(new UserBasicDetailsDTO(plan.getCreatedBy()));
					planDto.setCreatedDate(plan.getCreatedDate());
				}
				dto.setPlan(planDto);
				
				List<StudyPlanReviewApproveMapping> studyPlanReviewApproveMappings = planReviewApproveMappingRepo.getStudyPlanReviewApproveMappingByPlanId(plan.getId(), EnabledStatus.OPEN);
				List<StudyPlanReviewApproveMappingDto> studyPlanReviewApproveMappingDtos = new ArrayList<>();
				if(studyPlanReviewApproveMappings != null) {
					studyPlanReviewApproveMappings.forEach(reviewer -> {
						StudyPlanReviewApproveMappingDto planReviewApproveMappingDto = new StudyPlanReviewApproveMappingDto();
						planReviewApproveMappingDto.setId(reviewer.getId());
						planReviewApproveMappingDto.setGlpDepartment(new GLPDepartmentDTO(reviewer.getGlpDepartment().getId(), reviewer.getGlpDepartment().getCode(), reviewer.getGlpDepartment().getName()));
						planReviewApproveMappingDto.setUser(new UserBasicDetailsDTO(reviewer.getUser()));
						planReviewApproveMappingDto.setReviewType(reviewer.getReviewType());
						planReviewApproveMappingDto.setSpecialNotes(reviewer.getSpecialNotes());
						planReviewApproveMappingDto.setMappingStatus(reviewer.getMappingStatus());
						planReviewApproveMappingDto.setCreatedBy(new UserBasicDetailsDTO(reviewer.getCreatedBy()));
						planReviewApproveMappingDto.setCreatedDate(reviewer.getCreatedDate());
						if(reviewer.getUpdatedBy() != null) {
							planReviewApproveMappingDto.setUpdatedBy(new UserBasicDetailsDTO(reviewer.getUpdatedBy()));
							planReviewApproveMappingDto.setUpdatedDate(reviewer.getUpdatedDate());
						}
						planReviewApproveMappingDto.setEnabledStatus(reviewer.getEnabledStatus());
						planReviewApproveMappingDto.setRecordStatus(reviewer.getRecordStatus());
						studyPlanReviewApproveMappingDtos.add(planReviewApproveMappingDto);
					});
				}
				planDto.setStudyPlanReviewApproveMapping(studyPlanReviewApproveMappingDtos);
			}
			return dto;
		}
		return null;
	}

	@Override
	@Transactional
	public String generateStudyNumber(StudyNumber studyNumber, User user) {
		
		Branch branch = user.getBranches().stream().filter(predicate -> predicate.isSelectedBranch()).findAny().orElse(null);
		if (studyNumber != null) {
			int len = getLastStudyNumber(studyNumber.getStudyCategory());
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			String systemYear = df.format(date).substring(8);
			String sNumber = studyNumber.getStudyCategory() + systemYear + String.format("%05d", 1);
			if (len > 0) {
				sNumber = studyNumber.getStudyCategory() + systemYear + String.format("%05d", (len + 1));
			}
			studyNumber.setStudyNumber(sNumber);
			studyNumber.setBranch(branch);
			
			StudyNumber studyNumberSaved = studyNumberRepo.save(studyNumber);
			testItemReceiptRepo.updateStudyNumberStatus(studyNumber.getTestItemReceipt().getId(), TestItemStatus.STUDY_NO_GENERATED);
			
			UserBasicDetailsDTO dto = new UserBasicDetailsDTO(studyNumberSaved.getCreatedBy());
			auditTrail.takeAuditTrail(studyNumberSaved.getId(), "Study Number", null, "Study Number Generated (" + studyNumberSaved.getStudyNumber() + ") By " + dto.getDisplayName(), studyNumberSaved.getCreatedBy());
			return "Study Number Generated. " + studyNumber.getStudyNumber();
		}
		return "Something went wrong.";	
	}

	public int getLastStudyNumber(String studyCategory) {
		return studyNumberRepo.getLastStudyNumber(studyCategory, EnabledStatus.OPEN);
	}

	@Override
	public Page<StudyNumberDTO> getAllStudyNumbers(Pageable pagable) {
		return studyNumberRepo.getAllStudyNumbers(StudyStatus.PENDING, EnabledStatus.OPEN, pagable);
	}
	
	@Override
	public StudyNumberDTO getStudyNumberDetailsById(Long studyNumberId) {
		return studyNumberRepo.getStudyNumberDetailsById(studyNumberId, EnabledStatus.OPEN);
	}
	
	@Override
	@Deprecated
	public Page<StudyNumberDTO> getStudyNumbersForProtocol(Pageable pagable) {

		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.DIRECTOR_ALLOCATED);
		studyStatus.add(StudyStatus.PERSONNEL_ALLOCATED);
		studyStatus.add(StudyStatus.PERSONNEL_APPROVED);
		studyStatus.add(StudyStatus.PERSONNEL_REJECTED);
		return studyNumberRepo.getStudyNumbersForProtocol(studyStatus, EnabledStatus.OPEN, pagable);
	}

	@Override
	@Deprecated
	public Page<StudyNumberDTO> getStudyNumbersForProtocolReview(Pageable pagable, User user) {
		return protocolReviewApproveMappingRepo.getStudyNumbersForMappedUsers(user.getId(), "Review", StudyStatus.PROTOCOL_UPLOADED, EnabledStatus.OPEN, pagable);
	}

	@Override
	@Deprecated
	public Page<StudyNumberDTO> getStudyNumbersForProtocolApprove(Pageable pagable, User user) {
		return protocolReviewApproveMappingRepo.getStudyNumbersForMappedUsers(user.getId(), "Approve", StudyStatus.PROTOCOL_REVIEWED, EnabledStatus.OPEN, pagable);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyNumberDTO> fetchAllStudyNumbersForPersonnelAllocation(User user, Pageable pagable) {
		if (user.getBranches() != null) {
			user.getBranches().forEach(obj -> {
				if (obj.isSelectedBranch())
					branch = obj;
			});
		}
		Long userId = user.getId();
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.DIRECTOR_ALLOCATED);
		studyStatus.add(StudyStatus.PROTOCOL_UPLOADED);
		studyStatus.add(StudyStatus.PROTOCOL_APPROVED);
		studyStatus.add(StudyStatus.PROTOCOL_REVIEWED);
		studyStatus.add(StudyStatus.PLAN_UPLOADED);
		studyStatus.add(StudyStatus.PLAN_REVIEWED);
		studyStatus.add(StudyStatus.PLAN_APPROVED);

		return directorRepo.getStudyNumbersForPersonnel(userId, studyStatus, EnabledStatus.OPEN, branch.getId(), pagable);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyNumberDTO> getStudyNumberDetailsBySponsorId(List<Branch> selectedBranches, Long sponsorId, Pageable pagable) {
		return studyNumberRepo.getStudyNumberDetailsBySponsorId(selectedBranches, sponsorId, EnabledStatus.OPEN, pagable);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyNumberDTO> getStudyNumberDetailsByAll(List<Branch> selectedBranches, Pageable pagable) {
		return studyNumberRepo.getStudyNumberDetailsByAll(EnabledStatus.OPEN, selectedBranches, pagable);
	}

	@Override
	@Transactional(readOnly = true)
	public List<StudyUserRoleDTO> fetchStudyRoleDetailsByUser(Long userId) {
		List<StudyUserRoleDTO> dtos = new ArrayList<>();
		List<StudyDirector> directors = directorRepo.findAllStudyDirectorsByDirectorId(userId, EnabledStatus.OPEN, ApproveStatus.APPROVED);

		Iterator<StudyDirector> iterator = directors.iterator();
		while (iterator.hasNext()) {
			StudyDirector director = iterator.next();
			dtos.add(new StudyUserRoleDTO(director.getId(), new StudyNumberDTO(director.getStudyNumber()), StudyUserRole.DIRECTOR));
		}

		List<StudyPersonnel> personnel = personnelRepo.findAllPersonnelByPersonId(userId, EnabledStatus.OPEN, ApproveStatus.APPROVED);
		Iterator<StudyPersonnel> iterator2 = personnel.iterator();
		while (iterator2.hasNext()) {
			StudyPersonnel person = iterator2.next();
			dtos.add(new StudyUserRoleDTO(person.getId(), new StudyNumberDTO(person.getStudyNumber()), StudyUserRole.PERSONNEL));
		}
		return dtos;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyNumberDTO> getAllStudyNumberDetailsByDate(Long from, Long to, Pageable pageable) {
		Date fromDate = new Date(from), toDate = new Date(to);
		if (toDate != null) {
			toDate = Date.from(toDate.toInstant().atZone(ZoneId.systemDefault()).withHour(23).withMinute(59).withSecond(59).toInstant());
		}
		return studyNumberRepo.getAllStudyNumberDetailsByDate(fromDate, toDate, EnabledStatus.OPEN, pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyDetailsDTO> getStudyAllotmentLetter(Long fromDate, Long toDate, User user, Pageable pageable) {
		Date fDate = new Date(fromDate), tDate = new Date(toDate);
		if (user.getBranches() != null) {
			user.getBranches().forEach(obj -> {
				if (obj.isSelectedBranch())
					branch = obj;
			});
		}

		tDate = Date.from(tDate.toInstant().atZone(ZoneId.systemDefault()).withHour(23).withMinute(59).withSecond(59).toInstant());
		Page<StudyDetailsDTO> page = new PageImpl<>(new ArrayList<>());
		List<StudyDetailsDTO> dtos = new ArrayList<>();
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.PENDING);
		Page<StudyNumber> studyIds = studyNumberRepo.getStudyAllotmentLetter(fDate, tDate, branch.getId(), EnabledStatus.OPEN, studyStatus, pageable);
		for (StudyNumber studyNumber : studyIds.getContent()) {
			dtos.add(getStudyDetails(studyNumber.getId()));
		}
		page = new PageImpl<>(dtos, pageable, studyIds.getTotalElements());
		return page;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyDetailsDTO> getStudyAllotmentLetterTable(User user, Pageable pageable) {
		if (user.getBranches() != null) {
			user.getBranches().forEach(obj -> {
				if (obj.isSelectedBranch())
					branch = obj;
			});
		}

		Page<StudyDetailsDTO> page = new PageImpl<>(new ArrayList<>());
		List<StudyDetailsDTO> dtos = new ArrayList<>();
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.PENDING);
		Page<StudyNumber> studyIds = studyNumberRepo.getStudyAllotmentLetterTable(branch.getId(), EnabledStatus.OPEN, pageable);
		for (StudyNumber studyNumber : studyIds.getContent()) {
			dtos.add(getStudyDetails(studyNumber.getId()));
		}
		page = new PageImpl<>(dtos, pageable, studyIds.getTotalElements());
		return page;
	}

	@Override
	@Transactional(readOnly = true)
	public List<StudyUserRoleDTO> fetchStudyDetailsByUserIdAndRole(Long userId, String studyUserRole, ApproveStatus approveStatus) {
		List<StudyUserRoleDTO> dtos = new ArrayList<>();
		if (StudyUserRole.DIRECTOR.toString().equals(studyUserRole)) {
			List<StudyDirector> directors = directorRepo.findAllStudyDirectorsByDirectorId(userId, EnabledStatus.OPEN, approveStatus);
			Iterator<StudyDirector> iterator = directors.iterator();
			while (iterator.hasNext()) {
				StudyDirector director = iterator.next();
				dtos.add(new StudyUserRoleDTO(director.getId(), new StudyNumberDTO(director.getStudyNumber()), StudyUserRole.DIRECTOR));
			}
		} else if (StudyUserRole.PERSONNEL.toString().equals(studyUserRole)) {
			List<StudyPersonnel> personnel = personnelRepo.findAllPersonnelByPersonId(userId, EnabledStatus.OPEN, approveStatus);
			Iterator<StudyPersonnel> iterator2 = personnel.iterator();
			while (iterator2.hasNext()) {
				StudyPersonnel person = iterator2.next();
				dtos.add(new StudyUserRoleDTO(person.getId(), new StudyNumberDTO(person.getStudyNumber()), StudyUserRole.PERSONNEL));
			}
		} else {
			List<StudyDirector> directors = directorRepo.findAllStudyDirectorsByDirectorId(userId, EnabledStatus.OPEN, approveStatus);
			Iterator<StudyDirector> iterator = directors.iterator();
			while (iterator.hasNext()) {
				StudyDirector director = iterator.next();
				dtos.add(new StudyUserRoleDTO(director.getId(), new StudyNumberDTO(director.getStudyNumber()), StudyUserRole.DIRECTOR));
			}
			List<StudyPersonnel> personnel = personnelRepo.findAllPersonnelByPersonId(userId, EnabledStatus.OPEN, approveStatus);
			Iterator<StudyPersonnel> iterator2 = personnel.iterator();
			while (iterator2.hasNext()) {
				StudyPersonnel person = iterator2.next();
				dtos.add(new StudyUserRoleDTO(person.getId(), new StudyNumberDTO(person.getStudyNumber()), StudyUserRole.PERSONNEL));
			}
		}
		return dtos;
	}

	@Override
	public Page<StudyNumberDTO> getStudyNumbersForPlan(Pageable pagable) {
		
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.DIRECTOR_ALLOCATED);
		studyStatus.add(StudyStatus.PERSONNEL_ALLOCATED);
		studyStatus.add(StudyStatus.PERSONNEL_APPROVED);
		studyStatus.add(StudyStatus.PERSONNEL_REJECTED);
		return studyNumberRepo.getStudyNumbersForPlan(studyStatus, EnabledStatus.OPEN, pagable);
	}
	
	@Override
	public Page<StudyNumberDTO> getStudyNumbersForPlanModify(Pageable pagable, User user) {
		
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.PLAN_UPLOADED);
		studyStatus.add(StudyStatus.PLAN_REVIEWED);
		studyStatus.add(StudyStatus.PLAN_PARTIALLY_REVIEWED);
		studyStatus.add(StudyStatus.PLAN_REVIEW_REJECTED);
		studyStatus.add(StudyStatus.PLAN_PARTIALLY_APPROVED);
		return studyPlanRepo.getStudyNumbersForPlanModify(user.getId(), studyStatus, EnabledStatus.OPEN, pagable);
	}

	@Override
	public Page<StudyNumberDTO> getStudyNumbersForPlanReview(Pageable pagable, User user) {
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.PLAN_UPLOADED);
		studyStatus.add(StudyStatus.PLAN_PARTIALLY_REVIEWED);
		return planReviewApproveMappingRepo.getStudyNumbersForMappedUsers(user.getId(), "Review", studyStatus, CustomStatus.MAPPED, EnabledStatus.OPEN, pagable);
	}

	@Override
	public Page<StudyNumberDTO> getStudyNumbersForPlanApprove(Pageable pagable, User user) {
		List<StudyStatus> studyStatus = new ArrayList<>();
		studyStatus.add(StudyStatus.PLAN_REVIEWED);
		studyStatus.add(StudyStatus.PLAN_PARTIALLY_APPROVED);
		return planReviewApproveMappingRepo.getStudyNumbersForMappedUsers(user.getId(), "Approve", studyStatus, CustomStatus.MAPPED, EnabledStatus.OPEN, pagable);
	}

	@Override
	public Page<StudyNumberDTO> getPlanApprovedStudyNumbers(Pageable pagable) {
		return studyNumberRepo.getAllStudyNumbers(StudyStatus.PLAN_APPROVED, EnabledStatus.OPEN, pagable);
	}

	@Override
	public Map<String, Integer> getStudyNumberCountForDashboard() {
		Map<String, Integer> counts = new HashMap<>();
		counts.put("Pending", studyNumberRepo.getStudyNumberCountByStatus(StudyStatus.PENDING, EnabledStatus.OPEN));
		counts.put("Allocated", studyNumberRepo.getStudyNumberCountByAllAndNotInStatus(EnabledStatus.OPEN, StudyStatus.PENDING));
		return counts;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyNumberDTO> getStudyNumbersByStatus(String status, Pageable pageable) {
		return studyNumberRepo.getStudyNumbersByStatus(StudyStatus.valueOf(status), EnabledStatus.OPEN, pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<StudyNumberDTO> getStudyNumberByNotINStatus(String status, Pageable pageable) {
		return studyNumberRepo.getStudyNumberByNotINStatus(StudyStatus.valueOf(status), EnabledStatus.OPEN, pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public StudyDetailsDTO getStudyPlanForUser(Long studyId, String reviewType, User user) {
		
		StudyNumber number = studyNumberRepo.getOne(studyId);
		if (number != null) {
			StudyDetailsDTO dto = new StudyDetailsDTO(number);
			List<StudyDirector> directors = directorRepo.findAllStudyDirectorsByStudyId(studyId, EnabledStatus.OPEN);
			if (directors != null && directors.size() > 0) {
				Set<StudyUsersDTO> studyUsersDTOs = new HashSet<>();
				Map<IdCodeName, List<DirectorDTO>> map = new HashMap<>();
				Iterator<StudyDirector> iterator = directors.iterator();
				while (iterator.hasNext()) {
					StudyDirector director = iterator.next();
					DirectorDTO directorDto = DirectorServiceImpl.convertDto(director.getDirector());
					directorDto.setApproveStatus(director.getApproveStatus());
					GLPDepartment department = director.getDirector().getGlpDepartment();
					IdCodeName dept = new IdCodeName(department.getId(), department.getCode(), department.getName());
					if (map.get(dept) != null) {
						map.get(dept).add(directorDto);
					} else {
						ArrayList<DirectorDTO> arrayList = new ArrayList<>();
						arrayList.add(directorDto);
						map.put(dept, arrayList);
					}
				}
				studyUsersDTOs = map.entrySet().stream()
						.map(mapper -> new StudyUsersDTO(mapper.getKey(), mapper.getValue()))
						.collect(Collectors.toSet());
				dto.setDirectors(studyUsersDTOs);
			}

			List<StudyPersonnel> personnels = personnelRepo.findAllPersonnelByStudy(studyId, EnabledStatus.OPEN);
			if (personnels != null && personnels.size() > 0) {
				Set<StudyUsersDTO> studyUsersDTOs = new HashSet<>();
				Map<IdCodeName, List<StudyPersonnelDTO>> map = new HashMap<>();
				Iterator<StudyPersonnel> iterator = personnels.iterator();
				while (iterator.hasNext()) {
					StudyPersonnel director = iterator.next();
					StudyPersonnelDTO basicDetailsDTO = new StudyPersonnelDTO(director);
					DepartmentBasicDTO department = basicDetailsDTO.getPerson().getEmployee().getDepartment();
					IdCodeName dept = new IdCodeName(department.getId(), department.getCode(), department.getName());
					if (map.get(dept) != null) {
						map.get(dept).add(basicDetailsDTO);
					} else {
						ArrayList<StudyPersonnelDTO> arrayList = new ArrayList<>();
						arrayList.add(basicDetailsDTO);
						map.put(dept, arrayList);
					}
				}
				studyUsersDTOs = map.entrySet().stream()
						.map(mapper -> new StudyUsersDTO(mapper.getValue(), mapper.getKey()))
						.collect(Collectors.toSet());
				dto.setPersonnel(studyUsersDTOs);
				dto.setPersonnelAllocatedBy(new UserBasicDetailsDTO(personnels.get(0).getCreatedBy()));
				dto.setPersonnelAllocatedDate(personnels.get(0).getCreatedDate());
			}

			StudyPlan plan = studyPlanRepo.getStudyPlanByStudyId(studyId, EnabledStatus.OPEN);
			if (plan != null) {
				StudyPlanDTO planDto = new StudyPlanDTO();
				planDto.setId(plan.getId());
				planDto.setStudyNumber(new StudyNumberDTO(plan.getStudyNumber()));
				planDto.setDocumentForm(plan.getDocumentForm());
				planDto.setFileId(plan.getFileId());
				planDto.setFileName(plan.getFileName());
				if (plan.getCreatedBy() != null) {
					planDto.setCreatedBy(new UserBasicDetailsDTO(plan.getCreatedBy()));
					planDto.setCreatedDate(plan.getCreatedDate());
				}
				dto.setPlan(planDto);
				
				StudyPlanReviewApproveMapping studyPlanReviewApproveMapping = planReviewApproveMappingRepo.getReviewApproverByUserAndPlandId(plan.getId(), reviewType, user.getId(), EnabledStatus.OPEN);
				List<StudyPlanReviewApproveMappingDto> studyPlanReviewApproveMappingDtos = new ArrayList<>();
				if(studyPlanReviewApproveMapping != null) {
					StudyPlanReviewApproveMappingDto planReviewApproveMappingDto = new StudyPlanReviewApproveMappingDto();
					planReviewApproveMappingDto.setId(studyPlanReviewApproveMapping.getId());
					planReviewApproveMappingDto.setGlpDepartment(new GLPDepartmentDTO(studyPlanReviewApproveMapping.getGlpDepartment().getId(), studyPlanReviewApproveMapping.getGlpDepartment().getCode(), studyPlanReviewApproveMapping.getGlpDepartment().getName()));
					planReviewApproveMappingDto.setUser(new UserBasicDetailsDTO(studyPlanReviewApproveMapping.getUser()));
					planReviewApproveMappingDto.setReviewType(studyPlanReviewApproveMapping.getReviewType());
					planReviewApproveMappingDto.setSpecialNotes(studyPlanReviewApproveMapping.getSpecialNotes());
					planReviewApproveMappingDto.setMappingStatus(studyPlanReviewApproveMapping.getMappingStatus());
					planReviewApproveMappingDto.setCreatedBy(new UserBasicDetailsDTO(studyPlanReviewApproveMapping.getCreatedBy()));
					planReviewApproveMappingDto.setCreatedDate(studyPlanReviewApproveMapping.getCreatedDate());
					if(studyPlanReviewApproveMapping.getUpdatedBy() != null) {
						planReviewApproveMappingDto.setUpdatedBy(new UserBasicDetailsDTO(studyPlanReviewApproveMapping.getUpdatedBy()));
						planReviewApproveMappingDto.setUpdatedDate(studyPlanReviewApproveMapping.getUpdatedDate());
					}
					planReviewApproveMappingDto.setEnabledStatus(studyPlanReviewApproveMapping.getEnabledStatus());
					planReviewApproveMappingDto.setRecordStatus(studyPlanReviewApproveMapping.getRecordStatus());
					
					studyPlanReviewApproveMappingDtos.add(planReviewApproveMappingDto);
				}
				planDto.setStudyPlanReviewApproveMapping(studyPlanReviewApproveMappingDtos);
			}
			return dto;
		}
		return null;
	}

	@Override
	public List<IdCodeName> getICN() {
		
		return studyNumberRepo.getStudyNumbersICN(EnabledStatus.OPEN);
	}

	
}
