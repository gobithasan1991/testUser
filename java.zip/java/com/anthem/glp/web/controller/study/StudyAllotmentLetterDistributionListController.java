package com.anthem.glp.web.controller.study;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.StudyAllotmentLetterDistributionList;
import com.anthem.glp.web.service.study.StudyAllotmentLetterDistributionListService;
import com.anthem.glp.web.service.study.StudyNumberService;
import com.anthem.glp.web.service.study.dto.StudyAllotmentLetterDistributionListDTO;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.persistence.model.user.User;

@RestController
@RequestMapping("study-allotment")
public class StudyAllotmentLetterDistributionListController {
	
	private StudyNumberService studyNumberService;
	private StudyAllotmentLetterDistributionListService studyAllotmentDistributionListService;
	
	public StudyAllotmentLetterDistributionListController() {
		super();
	}
	
	@Autowired
	public StudyAllotmentLetterDistributionListController(StudyNumberService studyNumberService, StudyAllotmentLetterDistributionListService studyAllotmentDistributionListService) {
		super();
		this.studyNumberService = studyNumberService;
		this.studyAllotmentDistributionListService = studyAllotmentDistributionListService;
	}
	
	@GetMapping("/study-allotment-letter-distribution-list/{studyNumberId}")
	public ModelAndView studyAllotmentLetterDistributionList(ModelMap modelMap, @PathVariable("studyNumberId") Long studyNumberId) {
		StudyDetailsDTO studyNumber = studyNumberService.getStudyDetails(studyNumberId);
		List<StudyAllotmentLetterDistributionListDTO> studyAllotmentLetterDistributionList = studyAllotmentDistributionListService.getStudyDetailsForPrint(studyNumberId);		
		modelMap.addAttribute("studyNumber", studyNumber);
		modelMap.addAttribute("issuedList", studyAllotmentLetterDistributionList);
		return new ModelAndView("glp/pdf/study/study_allotment_letter_distribution_list");
	}
	
	@GetMapping("/study-allotment-letter-sponsor/{studyNumberId}")
	public ModelAndView studyAllotmentLetterSponsor(ModelMap modelMap, @PathVariable("studyNumberId") Long studyNumberId) {
		StudyDetailsDTO studyNumber = studyNumberService.getStudyDetails(studyNumberId);
		modelMap.addAttribute("studyNumber", studyNumber);
		return new ModelAndView("glp/pdf/study/study_allotment_letter_sponsor");
	}
	
	@GetMapping("/study-allotment-letter-self-sponsor/{studyNumberId}")
	public ModelAndView studyAllotmentLetterSelfSponsor(ModelMap modelMap, @PathVariable("studyNumberId") Long studyNumberId) {
		StudyDetailsDTO studyNumber = studyNumberService.getStudyDetails(studyNumberId);
		modelMap.addAttribute("studyNumber", studyNumber);
		return new ModelAndView("glp/pdf/study/study_allotment_letter_self_sponsor");
	}
	
	@GetMapping("/study-allotment-letter-report")
	public ModelAndView studyAllotmentLetterReport() {
		return new ModelAndView("glp/reports/study/study_allotment_letter_report");
	}
	
	@GetMapping("/study-allotment-letter-report-detail/{fromDate}/{toDate}")
	public Page<StudyDetailsDTO> studyAllotmentLetterReportDetails(@PathVariable(value = "fromDate") Long fromDate,@PathVariable(value = "toDate") Long toDate, @AuthenticationPrincipal User user, Pageable pageable) {		
		return studyNumberService.getStudyAllotmentLetter(fromDate, toDate, user, pageable);
	}
	
	@GetMapping("/study-allotment-letter-pdf")
	public ModelAndView studyAllotmentLetterPDFReport() {
		return new ModelAndView("glp/reports/study/study_allotment_letter_pdf_report");
	}
	
	@GetMapping("/study-allotment-letter-table")
	public Page<StudyDetailsDTO> studyAllotmentLetterTable(@AuthenticationPrincipal User user, Pageable pageable) {		
		return studyNumberService.getStudyAllotmentLetterTable(user, pageable);
	}
	
	@PostMapping(value = "/save")
	public String saveStudyAllotmentDistribution(@RequestBody StudyAllotmentLetterDistributionList studyAllotmentLetterDistributionList, @AuthenticationPrincipal User user) {
		return studyAllotmentDistributionListService.saveStudyAllotmentDistribution(studyAllotmentLetterDistributionList, user);
	}
}
