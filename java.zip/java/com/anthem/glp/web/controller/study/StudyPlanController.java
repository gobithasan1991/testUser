package com.anthem.glp.web.controller.study;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.StudyPlan;
import com.anthem.glp.persistence.model.study.StudyPlanReviewApproveMapping;
import com.anthem.glp.web.service.study.StudyPlanService;
import com.anthem.persistence.model.user.User;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("study-plan")
public class StudyPlanController {

	private StudyPlanService studyPlanService;
	private ObjectMapper objectMapper;

	public StudyPlanController(StudyPlanService studyPlanService, ObjectMapper objectMapper) {
		super();
		this.studyPlanService = studyPlanService;
		this.objectMapper = objectMapper;
	}

	@GetMapping(value = "/create")
	public ModelAndView studyPlanCreate() {
		return new ModelAndView("glp/study/study_plan");
	}

	@GetMapping(value = "/upload-modal")
	public ModelAndView studyPlanUploadModal() {
		return new ModelAndView("glp/study/modal/study_plan_upload_modal");
	}

	@PostMapping(value = "/save")
	public Long saveStudyPlan(@RequestParam("studyPlan") String studyPlanStr,
			@RequestParam(value = "studyPlanDoc", required = false) MultipartFile file,
			@RequestParam("studyPlanReviewApproveMapping") String studyPlanReviewApproveMappingStr,
			@AuthenticationPrincipal User user, HttpServletRequest request, HttpServletResponse response)
			throws JsonParseException, JsonMappingException, IOException {

		StudyPlan studyPlan = objectMapper.readValue(studyPlanStr, StudyPlan.class);
		List<StudyPlanReviewApproveMapping> planReviewApproveMappings = objectMapper.readValue(studyPlanReviewApproveMappingStr, 
				new TypeReference<List<StudyPlanReviewApproveMapping>>() {});
		return studyPlanService.saveStudyPlan(studyPlan, planReviewApproveMappings, file, user, request, response);
	}

	@GetMapping(value = "/modify")
	public ModelAndView studyPlanModify() {
		return new ModelAndView("glp/study/study_plan_modify");
	}
	
	@PostMapping(value = "/review-approve-update")
	public Long updateStudyPlanReviewApprover(@RequestBody List<StudyPlanReviewApproveMapping> planReviewApproveMappings) {
		return studyPlanService.updateStudyPlanReviewApprover(planReviewApproveMappings);
	}

	@GetMapping(value = "/review")
	public ModelAndView studyPlanReview() {
		return new ModelAndView("glp/study/study_plan_review");
	}

	@GetMapping(value = "/approve")
	public ModelAndView studyPlanApprove() {
		return new ModelAndView("glp/study/study_plan_approve");
	}
	
	@GetMapping(value = "/modal/view-study-plan-review-approve")
	public ModelAndView studyPlanReviewApproveView() {
		return new ModelAndView("glp/study/modal/study_plan_review_approve_view");
	}

}
