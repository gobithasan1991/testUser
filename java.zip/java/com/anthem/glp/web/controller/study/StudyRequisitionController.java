package com.anthem.glp.web.controller.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.StudyRequisition;
import com.anthem.glp.web.service.study.StudyRequisitionService;
import com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO;
import com.anthem.persistence.model.user.User;

@RestController
@RequestMapping("study-requisition")
public class StudyRequisitionController {

	private StudyRequisitionService studyRequisitionService;
		
	public StudyRequisitionController(StudyRequisitionService studyRequisitionService) {
		super();
		this.studyRequisitionService = studyRequisitionService;
	}


	@GetMapping(value = "/create")
	public ModelAndView StudyRequisitionCreate() {
		return new ModelAndView("glp/study/study_requisition");
	}
	
	@GetMapping(value = "/study-requisition-modal")
	public ModelAndView studyRequisitionModal() {
		return new ModelAndView("glp/study/modal/study_requisition_modal");
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveStudyRequisition(@Validated @RequestBody StudyRequisition studyRequisition, BindingResult bindingResult, @AuthenticationPrincipal User user) {
		return studyRequisitionService.save(studyRequisition, user);
	}
	
	@GetMapping(value = "/approve")
	public ModelAndView StudyRequisitionApprove() {
		return new ModelAndView("glp/study/study_requisition_authorization");
	}
	
	@GetMapping(value = "/study-requisition-authorization-modal")
	public ModelAndView studyRequisitionAuthorizationModal() {
		return new ModelAndView("glp/study/modal/study_requisition_authorization_modal");
	}
	
	@GetMapping(value = "/study-requisition-report")
	public ModelAndView StudyRequisitionReport() {
		return new ModelAndView("glp/reports/study/study_requisition_report");
	}
	
	@GetMapping("/study-requisition-by-pending-status")
	public Page<StudyRequisitionReportDTO> getStudyRequisitionByPendingStatus(@AuthenticationPrincipal User user, Pageable pageable) {		
		return studyRequisitionService.getStudyRequisitionByPendingStatus(user, pageable);
	}
	
	@GetMapping("/study-requisition-report-table")
	public Page<StudyRequisitionReportDTO> studyRequisitionReportTable(@AuthenticationPrincipal User user, Pageable pageable) {		
		return studyRequisitionService.getStudyRequisitionReportTable(user, pageable);
	}
	
	@GetMapping("/requisition-form-pdf/{studyRequisitionId}")
	public ModelAndView StudyRequisitionPDF(ModelMap modelMap, @PathVariable("studyRequisitionId") Long studyRequisitionId) {
		StudyRequisitionReportDTO studyRequisition = studyRequisitionService.getStudyRequisitionDetails(studyRequisitionId);
		modelMap.addAttribute("studyRequisition", studyRequisition);
		return new ModelAndView("glp/pdf/study/study_requisition_form");
	}
	
	@GetMapping("/study-requisition-by-studyRequisitionId/{studyRequisitionId}")
	public StudyRequisitionReportDTO getStudyRequisitionByRequisitionId(@PathVariable("studyRequisitionId") Long studyRequisitionId) {		
		return studyRequisitionService.getStudyRequisitionDetails(studyRequisitionId);
	}
}
