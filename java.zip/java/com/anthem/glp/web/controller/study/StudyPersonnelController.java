package com.anthem.glp.web.controller.study;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.study.StudyPersonnelService;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyPersonnelDTO;
import com.anthem.web.service.user.dto.UserBasicDetailsDTO;

@RestController
@RequestMapping(value = "/study-personnel")
public class StudyPersonnelController {

	private StudyPersonnelService personnelService;

	@Autowired
	public StudyPersonnelController(StudyPersonnelService personnelService) {
		super();
		this.personnelService = personnelService;
	}

	@GetMapping("/create")
	public ModelAndView createPage() {
		return new ModelAndView("glp/study/study_personnel");
	}

	@GetMapping("/modal/allocation")
	public ModelAndView allocation() {
		return new ModelAndView("glp/study/modal/study_personnel_allocation");
	}

	@GetMapping("/modal/view-personnels")
	public ModelAndView viewAll() {
		return new ModelAndView("glp/study/modal/study_personnel_view");
	}

	@PostMapping(value = "/save")
	public String saveStudyDirector(@RequestBody List<StudyPersonnelDTO> personnel) {
		return personnelService.saveStudyPerson(personnel);
	}

	@GetMapping(value = "/get-personnel-details-by-study-id/{studyId}")
	public StudyDetailsDTO getStudyDetailsById(@PathVariable("studyId") Long studyId) {
		return personnelService.fetchStudyDetails(studyId);
	}

	@GetMapping(value = "/get-personnels-by-study-id/{studyId}")
	public List<UserBasicDetailsDTO> getStudyPersonnelsByStudyId(@PathVariable("studyId") Long studyId) {
		return personnelService.fetchPersonnelsByStudyId(studyId);
	}
}
