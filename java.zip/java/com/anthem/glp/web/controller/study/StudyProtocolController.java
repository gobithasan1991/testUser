package com.anthem.glp.web.controller.study;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.StudyProtocol;
import com.anthem.glp.persistence.model.study.StudyProtocolReviewApproveMapping;
import com.anthem.glp.web.service.study.StudyProtocolService;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.StudyStatus;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("study-protocol")
public class StudyProtocolController {

	private StudyProtocolService studyProtocolService;
	private ObjectMapper objectMapper;

	public StudyProtocolController(StudyProtocolService studyProtocolService, ObjectMapper objectMapper) {
		super();
		this.studyProtocolService = studyProtocolService;
		this.objectMapper = objectMapper;
	}

	@GetMapping(value = "/create")
	public ModelAndView studyProtocolCreate() {
		return new ModelAndView("glp/study/study_protocol");
	}

	@PostMapping(value = "/save")
	public Long saveStudyEnquiry(@RequestParam("studyProtocol") String studyProtocolStr,
			@RequestParam(value = "studyProtocolDoc", required = false) MultipartFile file,
			@RequestParam("studyProtocolReviewApproveMapping") String studyProtocolReviewApproveMappingStr,
			@AuthenticationPrincipal User user, HttpServletRequest request, HttpServletResponse response)
			throws JsonParseException, JsonMappingException, IOException {

		StudyProtocol studyProtocol = objectMapper.readValue(studyProtocolStr, StudyProtocol.class);
		List<StudyProtocolReviewApproveMapping> protocolReviewApproveMappings = objectMapper.readValue(studyProtocolReviewApproveMappingStr, new TypeReference<List<StudyProtocolReviewApproveMapping>>(){});
		return studyProtocolService.saveStudyProtocol(studyProtocol, protocolReviewApproveMappings, file, user, request, response);
	}

	@GetMapping(value = "/upload-modal")
	public ModelAndView studyProtocolUploadModal() {
		return new ModelAndView("glp/study/modal/study_protocol_upload_modal");
	}

	@GetMapping(value = "/review")
	public ModelAndView studyProtocolReview() {
		return new ModelAndView("glp/study/study_protocol_review");
	}

	@GetMapping(value = "/approve")
	public ModelAndView studyProtocolApprove() {
		return new ModelAndView("glp/study/study_protocol_approve");
	}

	@PostMapping(value = "/update")
	public String updateStudyEnquiry(@RequestParam("protocolId") Long protocolId,
			@RequestParam("protocolType") String protocolType, @RequestParam("studyStatus") String studyStatus,
			@AuthenticationPrincipal User user) {

		return studyProtocolService.updateStudyProtocol(protocolId, protocolType, StudyStatus.valueOf(StudyStatus.class, studyStatus), user);
	}

	@GetMapping(value = "/get-study-protocol-by-study-number-id/{studyNumberId}")
	public StudyProtocol getStudyProtocolByStudyNumberId(@PathVariable Long studyNumberId) {

		return studyProtocolService.getStudyProtocolByStudyNumberId(studyNumberId);
	}
}
