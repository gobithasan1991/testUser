
package com.anthem.glp.web.controller.study;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.StudyDirector;
import com.anthem.glp.web.service.study.StudyDirectorService;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.StudyUserRole;

@RestController
@RequestMapping(value = "/study-director")
public class StudyDirectorController {

	private StudyDirectorService directorService;

	@Autowired
	public StudyDirectorController(StudyDirectorService studyDirectorService) {
		this.directorService = studyDirectorService;
	}

	@GetMapping("/create")
	public ModelAndView createPage() {
		return new ModelAndView("glp/study/study_director");
	}

	@GetMapping("/modal/allocation")
	public ModelAndView allocation() {
		return new ModelAndView("glp/study/modal/study_director_allocation");
	}

	@PostMapping(value = "/save")
	public String saveStudyDirector(@RequestBody List<StudyDirector> directors, @AuthenticationPrincipal User user) {
		return directorService.saveStudyDirector(directors, user);
	}

	@GetMapping(value = "/get-director-details-by-study-id/{studyId}")
	public StudyDetailsDTO getStudyDetailsById(@PathVariable("studyId") Long studyId) {
		return directorService.fetchStudyDetails(studyId);
	}

	@GetMapping("/study-report-by-user")
	public ModelAndView studyReportByDirector() {
		return new ModelAndView("glp/reports/study/study_report_by_user");
	}
	
	@GetMapping("/study-allotment-acceptance")
	public ModelAndView studyAllotmentAcceptance() {
		return new ModelAndView("glp/study/study_allotment_acceptance");
	}
	
	@GetMapping(value = "/study_allotment_acceptance_upload_modal")
	public ModelAndView studyAllotmentAcceptanceUploadModal() {
		return new ModelAndView("glp/study/modal/study_allotment_acceptance_upload_modal");
	}
	
	@PostMapping(value = "/study-allotment-acceptance-status-update")
	public String updateStudyAllotmentAcceptanceStatus(@RequestParam("id") Long id, @RequestParam("approveStatus") ApproveStatus approveStatus, @RequestParam("studyUserRole") StudyUserRole studyUserRole, @RequestParam("studyNumber") String studyNumber)  {
		return directorService.updateStudyAllotmentAcceptanceStatus(id, approveStatus, studyUserRole, studyNumber);
	}

}
