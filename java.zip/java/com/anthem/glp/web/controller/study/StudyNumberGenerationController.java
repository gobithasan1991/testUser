package com.anthem.glp.web.controller.study;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.glp.web.service.study.StudyNumberService;
import com.anthem.glp.web.service.study.dto.StudyDetailsDTO;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.glp.web.service.study.dto.StudyUserRoleDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.StudyUserRole;
import com.anthem.web.service.common.dto.IdCodeName;

@RestController
@RequestMapping("study-number-generation")
public class StudyNumberGenerationController {

	private StudyNumberService studyNumberService;

	public StudyNumberGenerationController(StudyNumberService studyNumberService) {
		super();
		this.studyNumberService = studyNumberService;
	}

	@GetMapping(value = "/create")
	public ModelAndView studyNumberGeneration() {

		return new ModelAndView("glp/study/study_number_generation");
	}

	@GetMapping(value = "/report")
	public ModelAndView studyNumberGenerationReport() {

		return new ModelAndView("glp/reports/study/study_number_generation_report");
	}

	@GetMapping(value = "/report-by-status")
	public ModelAndView studyNumberGenerationReportByStatus() {

		return new ModelAndView("glp/reports/study/study_report_by_status");
	}

	@GetMapping(value = "/modal")
	public ModelAndView studyNumberGenerationModal() {

		return new ModelAndView("glp/study/modal/study_number_generation_modal");
	}

	@PostMapping(value = "/save")
	public String generateStudyNumber(@RequestBody StudyNumber studyNumber, @AuthenticationPrincipal User user) {

		return studyNumberService.generateStudyNumber(studyNumber, user);
	}
	
	@GetMapping(value = "/get-all-study-numbers")
	public Page<StudyNumberDTO> getAllStudyNumbers(Pageable pagable) {

		return studyNumberService.getAllStudyNumbers(pagable);
	}

	@GetMapping(value = "/get-icn")
	public List<IdCodeName> getICN() {

		return studyNumberService.getICN();
	}

	@GetMapping(value = "/get-study-numbers-for-protocol")
	@Deprecated
	public Page<StudyNumberDTO> getStudyNumbersForProtocol(Pageable pagable) {

		return studyNumberService.getStudyNumbersForProtocol(pagable);
	}

	@GetMapping(value = "/get-study-numbers-for-protocol-review")
	@Deprecated
	public Page<StudyNumberDTO> getStudyNumbersForProtocolReview(Pageable pagable, @AuthenticationPrincipal User user) {

		return studyNumberService.getStudyNumbersForProtocolReview(pagable, user);
	}

	@GetMapping(value = "/get-study-numbers-for-protocol-approve")
	@Deprecated
	public Page<StudyNumberDTO> getStudyNumbersForProtocolApprove(Pageable pagable,
			@AuthenticationPrincipal User user) {

		return studyNumberService.getStudyNumbersForProtocolApprove(pagable, user);
	}

	@GetMapping(value = "/get-study-number-by-id/{studyNumberId}")
	public StudyNumberDTO getStudyNumberDetailsById(@PathVariable Long studyNumberId) {

		return studyNumberService.getStudyNumberDetailsById(studyNumberId);
	}

	@GetMapping(value = "/get-all-director-allocated-study-numbers")
	public Page<StudyNumberDTO> getAllEnabldAndDirectorAllocated(@AuthenticationPrincipal User user, Pageable pagable) {
		return studyNumberService.fetchAllStudyNumbersForPersonnelAllocation(user, pagable);
	}

	@GetMapping(value = "/get-study-numbers-by-sponsorId/{sponsorId}")
	public Page<StudyNumberDTO> getStudyNumberDetailsBySponsorId(@AuthenticationPrincipal User user,
			@PathVariable Long sponsorId, Pageable pagable) {
		List<Branch> branches = new ArrayList<>(user.getBranches());
		if (branches != null && !branches.isEmpty()) {
			List<Branch> selectedBranches = new ArrayList<>();
			for (Branch branch : branches) {
				if (branch.isSelectedBranch()) {
					selectedBranches.add(branch);
				}
			}
			if (!selectedBranches.isEmpty()) {
				return studyNumberService.getStudyNumberDetailsBySponsorId(selectedBranches, sponsorId, pagable);
			}
		}
		return null;
	}

	@GetMapping(value = "/get-study-numbers-by-all")
	public Page<StudyNumberDTO> getStudyNumberDetailsByAll(@AuthenticationPrincipal User user, Pageable pagable) {
		List<Branch> branches = new ArrayList<>(user.getBranches());
		if (branches != null && !branches.isEmpty()) {
			List<Branch> selectedBranches = new ArrayList<>();
			for (Branch branch : branches) {
				if (branch.isSelectedBranch()) {
					selectedBranches.add(branch);
				}
			}
			if (!selectedBranches.isEmpty()) {
				return studyNumberService.getStudyNumberDetailsByAll(selectedBranches, pagable);
			}
		}
		return null;
	}

	@GetMapping(value = "/get-study-user-role-view")
	public ModelAndView showStudyUserRolesView() {
		return new ModelAndView("glp/study/modal/study_user_role_view");
	}

	@GetMapping(value = "/get-study-user-roles-by-user-id/{userId}")
	public List<StudyUserRoleDTO> getStudyUserRolesByUserId(@PathVariable("userId") Long userId) {
		return studyNumberService.fetchStudyRoleDetailsByUser(userId);
	}

	@GetMapping(value = "/get-study-details-by-user-id-role/{userId}/{studyUserRole}")
	public List<StudyUserRoleDTO> getStudyDetailsByUserIdAndRole(@PathVariable("userId") Long userId,
			@PathVariable("studyUserRole") String studyUserRole) {
		return studyNumberService.fetchStudyDetailsByUserIdAndRole(userId, studyUserRole, ApproveStatus.APPROVED);
	}

	@GetMapping("/studyReport")
	public ModelAndView complaintRegisterDateReportPage() {
		return new ModelAndView("glp/reports/study/study_report");
	}

	@GetMapping("/get-study-numbers-by-date/{fromDate}/{toDate}")
	public Page<StudyNumberDTO> getAllStudyNumberDetailsByDate(@PathVariable(value = "fromDate") Long fromDate,
			@PathVariable(value = "toDate") Long toDate, Pageable pageable) {
		return studyNumberService.getAllStudyNumberDetailsByDate(fromDate, toDate, pageable);
	}

	@GetMapping("/study_detail_timeline_view")
	public ModelAndView studyStatusView() {
		return new ModelAndView("glp/study/modal/study_detail_timeline_view");
	}

	@GetMapping(value = "/get-study-details-by-id/{studyId}")
	public StudyDetailsDTO getStudyDetails(@PathVariable("studyId") Long studyId) {
		return studyNumberService.getStudyDetails(studyId);
	}

	@GetMapping(value = "/get-study-users-roles")
	public List<StudyUserRole> getAllStudyUserRoles() {
		List<StudyUserRole> list = Arrays.asList(StudyUserRole.values());
		return list;
	}

	@GetMapping(value = "/get-study-numbers-for-plan")
	public Page<StudyNumberDTO> getStudyNumbersForPlan(Pageable pagable) {

		return studyNumberService.getStudyNumbersForPlan(pagable);
	}
	
	@GetMapping(value = "/get-study-numbers-for-plan-modify")
	public Page<StudyNumberDTO> getStudyNumbersForPlanModify(Pageable pagable, @AuthenticationPrincipal User user) {

		return studyNumberService.getStudyNumbersForPlanModify(pagable, user);
	}

	@GetMapping(value = "/get-study-numbers-for-plan-review")
	public Page<StudyNumberDTO> getStudyNumbersForPlanReview(Pageable pagable, @AuthenticationPrincipal User user) {

		return studyNumberService.getStudyNumbersForPlanReview(pagable, user);
	}

	@GetMapping(value = "/get-study-numbers-for-plan-approve")
	public Page<StudyNumberDTO> getStudyNumbersForPlanApprove(Pageable pagable, @AuthenticationPrincipal User user) {

		return studyNumberService.getStudyNumbersForPlanApprove(pagable, user);
	}

	@GetMapping(value = "/get-plan-approved-study-numbers")
	public Page<StudyNumberDTO> getPlanApprovedStudyNumbers(Pageable pagable) {

		return studyNumberService.getPlanApprovedStudyNumbers(pagable);
	}

	@GetMapping(value = "/get-study-details-by-session-user-id")
	public List<StudyUserRoleDTO> getStudyDetailsBySessionUserId(@AuthenticationPrincipal User user) {
		
		return studyNumberService.fetchStudyDetailsByUserIdAndRole(user.getId(), "All", ApproveStatus.PENDING);
	}

	@GetMapping(value = "/get-study-number-count-for-dashboard")
	public Map<String, Integer> getStudyNumberCountForDashboard() {
		
		return studyNumberService.getStudyNumberCountForDashboard();
	}

	@GetMapping("/get-study-numbers-by-status/{status}")
	public Page<StudyNumberDTO> getStudyNumbersByStatus(@PathVariable(value = "status") String status, Pageable pageable) {
		
		return studyNumberService.getStudyNumbersByStatus(status, pageable);
	}

	@GetMapping("/get-study-numbers-by-not-in-status/{status}")
	public Page<StudyNumberDTO> getStudyNumberByNotINStatus(@PathVariable(value = "status") String status, Pageable pageable) {
		
		return studyNumberService.getStudyNumberByNotINStatus(status, pageable);
	}
	
	@GetMapping(value = "/get-study-plan-for-user/{studyId}/{reviewType}")
	public StudyDetailsDTO getStudyPlanForUser(@PathVariable("studyId") Long studyId, @PathVariable("reviewType") String reviewType, @AuthenticationPrincipal User user) {
		
		return studyNumberService.getStudyPlanForUser(studyId, reviewType, user);
	}
	
}
