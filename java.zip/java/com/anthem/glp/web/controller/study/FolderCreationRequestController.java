package com.anthem.glp.web.controller.study;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.FolderCreationRequest;
import com.anthem.glp.web.service.study.FolderCreationRequestService;
import com.anthem.glp.web.service.study.dto.FolderCreationRequestDTO;
import com.anthem.persistence.model.user.User;

@RestController
@RequestMapping("it-folder-creation-request")
public class FolderCreationRequestController {

	private FolderCreationRequestService folderCreationRequestService;

	@Autowired
	public FolderCreationRequestController(FolderCreationRequestService folderCreationRequestService) {
		super();
		this.folderCreationRequestService = folderCreationRequestService;
	}

	@GetMapping("/creation")
	public ModelAndView creationPage() {
		return new ModelAndView("glp/study/folder_creation_request");
	}

	@GetMapping("/accepted")
	public ModelAndView requestAcceptedPage() {
		return new ModelAndView("glp/it/folder_creation_request_accepted");
	}

	@GetMapping("/authorized")
	public ModelAndView requestAuthorizedPage() {
		return new ModelAndView("glp/study/folder_creation_request_authorized");
	}

	@GetMapping(value = "/folder_creation_request_authorized_modal")
	public ModelAndView folderCreationRequestAuthorizedModal() {
		return new ModelAndView("glp/study/modal/folder_creation_request_authorized_modal");
	}

	@GetMapping(value = "/folder_creation_request_accepted_modal")
	public ModelAndView folderCreationRequestAcceptedModal() {
		return new ModelAndView("glp/it/modal/folder_creation_request_accepted_modal");
	}

	@GetMapping(value = "/folder_creation_request_report_modal")
	public ModelAndView folderCreationRequestReportModal() {
		return new ModelAndView("glp/reports/it/folder_creation_request_report_modal");
	}

	@GetMapping("/filled")
	public ModelAndView filledPage() {
		return new ModelAndView("glp/it/folder_creation_request_filled");
	}

	@GetMapping(value = "/folder_creation_request_filled_modal")
	public ModelAndView folderCreationRequestFilledModal() {
		return new ModelAndView("glp/it/modal/folder_creation_request_filled_modal");
	}

	@GetMapping("/report-by-all")
	public ModelAndView reportPage() {
		return new ModelAndView("glp/reports/it/folder_creation_request_report_by_all");
	}

	@PostMapping(value = "/save")
	public String saveFolderCreationRequest(@RequestBody FolderCreationRequest folderCreationRequest,
			@AuthenticationPrincipal User user) {
		return folderCreationRequestService.saveFolderCreationRequest(folderCreationRequest, user);
	}

	@GetMapping(value = "/get-folder-creation-request-by-folder-creation-status/{folderCreationStatus}")
	public Page<FolderCreationRequestDTO> getFolderCreationRequestByFolderCreationStatus(
			@PathVariable String folderCreationStatus, Pageable pagable) {
		return folderCreationRequestService.getFolderCreationRequestByFolderCreationStatus(folderCreationStatus,
				pagable);
	}

	@GetMapping(value = "/get-folder-creation-request-by-id/{folderCreationId}")
	public FolderCreationRequestDTO getFolderCreationRequestById(@PathVariable Long folderCreationId,
			@AuthenticationPrincipal User user) {
		return folderCreationRequestService.getFolderCreationRequestById(folderCreationId);
	}

	@PostMapping(value = "/update-folder-creation-request-status-by-id-and-status")
	public String updateFolderCreationRequestStatusByIdAndStatus(
			@RequestBody FolderCreationRequest FolderCreationRequest, @AuthenticationPrincipal User user) {
		return folderCreationRequestService.updateFolderCreationRequestStatusByIdAndStatus(FolderCreationRequest, user);
	}

	@PostMapping(value = "/update-folder-creation-request-filled-by-id")
	public String updateFolderCreationRequestFilledById(@RequestBody FolderCreationRequest FolderCreationRequest,
			@AuthenticationPrincipal User user) {
		return folderCreationRequestService.updateFolderCreationRequestFilledById(FolderCreationRequest, user);
	}

	@GetMapping("/pdf/folder-creation-request-pdf/{id}")
	public ModelAndView studyRequisitionPDF(ModelMap modelMap, @PathVariable("id") Long id) {
		modelMap.addAttribute("data", folderCreationRequestService.getFolderCreationRequestById(id));
		return new ModelAndView("glp/pdf/it/folder_creation_request_pdf");
	}

	@GetMapping("/pdf/electronic-media-submission-form-pdf/{id}")
	public ModelAndView electronicMediaSubmissionFormPDF(ModelMap modelMap, @PathVariable("id") Long id) {
		modelMap.addAttribute("request", "");
		return new ModelAndView("glp/it/electronic_media_submission_form_pdf");
	}

	@PostMapping(value = "/qau-verification-request-by-study")
	public String qauVerificationRequestByStudy(@RequestBody FolderCreationRequest FolderCreationRequest,
			@AuthenticationPrincipal User user) {
		return folderCreationRequestService.QAUVerificationRequestByStudy(FolderCreationRequest.getId(), user);
	}
}
