package com.anthem.glp.web.controller.study;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.TestItemReceipt;
import com.anthem.glp.web.service.study.TestItemReceiptService;
import com.anthem.glp.web.service.study.dto.TestItemReceiptDTO;
import com.anthem.persistence.model.user.User;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("study-enquiry")
public class TestItemReceiptController {

	private ObjectMapper objectMapper;
	private TestItemReceiptService testItemReceiptService;

	@Autowired
	public TestItemReceiptController(ObjectMapper objectMapper, TestItemReceiptService testItemReceiptService) {
		super();
		this.objectMapper = objectMapper;
		this.testItemReceiptService = testItemReceiptService;
	}

	@GetMapping(value = "/create")
	public ModelAndView studyEnquiryCreate() {
		
		return new ModelAndView("glp/study/study_enquiry");
	}

	@GetMapping(value = "/study-enquiry-view")
	public ModelAndView studyEnquiry() {
		return new ModelAndView("glp/study/modal/study_enquiry_details_modal");
	}

	@PostMapping(value = "/save")
	public String saveStudyEnquiry(@RequestParam("studyEnquiry") String studyEnquiryStr,
			@RequestParam(value = "coaDocument", required = false) MultipartFile coaDocument,
			@RequestParam(value = "safetyDocument", required = false) MultipartFile safetyDocument,
			@AuthenticationPrincipal User user, HttpServletRequest request, HttpServletResponse response)
			throws JsonParseException, JsonMappingException, IOException {

		TestItemReceipt testItemReceipt = objectMapper.readValue(studyEnquiryStr, TestItemReceipt.class);
		TestItemReceipt testItemSaved = testItemReceiptService.saveStudyEnquiry(testItemReceipt, coaDocument, safetyDocument, user, request, response);
		return testItemReceiptService.sendTestItemReceiptMail(testItemSaved.getId());
	}

	@GetMapping(value = "/get-all-test-item")
	public Page<TestItemReceiptDTO> getAllTestItemReceipts(Pageable pagable) {

		return testItemReceiptService.getAllTestItemReceipts(pagable);
	}

	@GetMapping(value = "/test-item-receipt-dto-by-id/{testItemId}")
	public TestItemReceiptDTO getTestItemReceiptDtoById(@PathVariable Long testItemId) {

		return testItemReceiptService.getTestItemReceiptDtoById(testItemId);
	}

	@GetMapping(value = "/test-item-receipt-by-id/{testItemId}")
	public TestItemReceipt getTestItemDetailsById(@PathVariable Long testItemId) {

		return testItemReceiptService.getTestItemDetailsById(testItemId);
	}

	// Test Item Report by Type
	@GetMapping(value = "/test-item-report-by-chemical-name/{value}")
	public Page<TestItemReceiptDTO> getTestItemReceiptByChemicalName(@PathVariable String value, Pageable pageable) {
		return testItemReceiptService.getTestItemReceiptByChemicalName(value, pageable);
	}

	@GetMapping(value = "/test-item-receipt-by-nominee/{value}")
	public Page<TestItemReceiptDTO> getTestItemReceiptByNominee(@PathVariable String value, Pageable pageable) {
		return testItemReceiptService.getTestItemReceiptByNominee(value, pageable);
	}

	@GetMapping(value = "/test-item-receipt-by-sponsor/{value}")
	public Page<TestItemReceiptDTO> getTestItemReceiptBySponsor(@PathVariable String value, Pageable pageable) {
		return testItemReceiptService.getTestItemReceiptBySponsor(value, pageable);
	}

	@GetMapping(value = "/test-item-receipt-by-test/{value}")
	public Page<TestItemReceiptDTO> getTestItemReceiptByTest(@PathVariable String value, Pageable pageable) {
		return testItemReceiptService.getTestItemReceiptByTest(value, pageable);
	}
}
