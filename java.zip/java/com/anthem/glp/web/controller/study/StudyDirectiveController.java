package com.anthem.glp.web.controller.study;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.TestItemReceipt;
import com.anthem.glp.web.service.study.TestItemReceiptService;

@RestController
@RequestMapping(value = "/study-directive/")
public class StudyDirectiveController {

	private TestItemReceiptService testItemReceiptService;

	@Autowired
	public StudyDirectiveController(TestItemReceiptService testItemReceiptService) {
		super();
		this.testItemReceiptService = testItemReceiptService;
	}

	@GetMapping(value = "test-item-receipt/{studyId}")
	public TestItemReceipt showTestItemReceipt(@PathVariable("studyId") Long studyId) {
		return testItemReceiptService.getTestItemDetailsById(studyId);
	}

	@GetMapping(value = "test-item-receipt.htm")
	public ModelAndView showTestItemReceiptd() {
		ModelAndView mav = new ModelAndView("glp/study/directive/template/test_item_receipt");
		return mav;
	}

	@GetMapping(value = "study-director-template")
	public ModelAndView showStudyDirector() {
		return new ModelAndView("glp/study/directive/template/study_director_directive");
	}

	@GetMapping(value = "study-personnel-template")
	public ModelAndView showStudyPersonnel() {
		return new ModelAndView("glp/study/directive/template/study_personnel_directive");
	}
	
	@GetMapping(value = "study-protocol-template")
	public ModelAndView showStudyProtocol() {
		return new ModelAndView("glp/study/directive/template/study_protocol_template");
	}
	
	@GetMapping(value = "study-plan-template")
	public ModelAndView showStudyPlan() {
		return new ModelAndView("glp/study/directive/template/study_plan_template");
	}

}
