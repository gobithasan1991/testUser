package com.anthem.glp.web.controller.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.QAUVerificationRequest;
import com.anthem.glp.web.service.study.QAUVerificationEntryService;
import com.anthem.glp.web.service.study.dto.QAUVerificationRequestDTO;
import com.anthem.persistence.model.user.User;

@RestController
@RequestMapping("qau-verification")
public class QAUVerificationEntryController {
	private QAUVerificationEntryService qauVerificationEntryService;

	public QAUVerificationEntryController(QAUVerificationEntryService qauVerificationEntryService) {
		super();
		this.qauVerificationEntryService = qauVerificationEntryService;
	}

	@GetMapping("/entry")
	public ModelAndView entryPage() {
		return new ModelAndView("glp/study/qau_verification_entry");
	}

	@GetMapping("/request-by-study")
	public ModelAndView requestByStudyPage() {
		return new ModelAndView("glp/study/qau_verification_request_by_study");
	}

	@GetMapping("/report")
	public ModelAndView reportPage() {
		return new ModelAndView("glp/reports/it/qau_verification_entry_report_by_all");
	}

	@GetMapping(value = "/qau_verification_entry_modal")
	public ModelAndView folderCreationRequestReportModal() {
		return new ModelAndView("glp/study/modal/qau_verification_entry_modal");
	}

	@PostMapping(value = "/save")
	public String saveQAUVerificationEntry(@RequestBody QAUVerificationRequest qauVerificationRequest,
			@AuthenticationPrincipal User user) {
		return qauVerificationEntryService.saveQAUVerificationEntry(qauVerificationRequest, user);
	}

	@GetMapping(value = "/get-qau-verification-entry-details-by-all")
	public Page<QAUVerificationRequestDTO> getQAUVerificationEntryDetailsByAll(Pageable pagable) {
		return qauVerificationEntryService.getQAUVerificationEntryDetailsByAll(pagable);
	}

	@GetMapping("/pdf/check-list-for-qau-verification-of-study-folder-pdf/{id}")
	public ModelAndView getCheckListForQAUVerificationOfStudyFolderPDF(ModelMap modelMap, @PathVariable("id") Long id) {
		modelMap.addAttribute("data", qauVerificationEntryService.getCheckListForQAUVerificationOfStudyFolderById(id));
		return new ModelAndView("glp/pdf/it/check_list_for_qau_verification_of_study_folder_pdf");
	}
}
