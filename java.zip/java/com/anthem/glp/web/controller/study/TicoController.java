package com.anthem.glp.web.controller.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.study.TICO;
import com.anthem.glp.web.service.study.TicoService;
import com.anthem.glp.web.service.study.dto.TicoDTO;

@RestController
@RequestMapping("tico")
public class TicoController {

	private TicoService ticoService;

	public TicoController(TicoService ticoService) {
		super();
		this.ticoService = ticoService;
	}

	@GetMapping(value = "/create")
	public ModelAndView studyTicoSelect() {
		return new ModelAndView("glp/study/tico");
	}

	@GetMapping(value = "/modal")
	public ModelAndView studyTicoCreate() {
		return new ModelAndView("glp/study/modal/tico_modal");
	}

	@PostMapping(value = "/save")
	public String saveTico(@RequestBody TICO tico) {
		return ticoService.saveTico(tico);
	}

	@GetMapping(value = "/get-all-tico")
	public Page<TicoDTO> getAllTico(Pageable pagable) {

		return ticoService.getAllTico(pagable);
	}

	@GetMapping(value = "/get-tico-by-test-item-receipt/{testItemId}")
	public TicoDTO getTicoByTestItemReceipt(@PathVariable Long testItemId) {

		return ticoService.getTicoByTestItemReceipt(testItemId);
	}
}
