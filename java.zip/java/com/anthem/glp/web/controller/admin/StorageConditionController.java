package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.admin.StorageConditionService;
import com.anthem.web.service.common.dto.IdCodeName;

@RestController
@RequestMapping(value = "/storage-condition")
public class StorageConditionController {

	private StorageConditionService storageConditionService;

	@Autowired
	public StorageConditionController(StorageConditionService storageConditionService) {
		super();
		this.storageConditionService = storageConditionService;
	}

	@GetMapping(value = "/create")
	public ModelAndView storageConditionCreate() {
		return new ModelAndView("glp/admin/storage_condition");
	}

	@PostMapping(value = "/save")
	public String saveSponsor(@RequestBody List<IdCodeName> dtos) {
		return storageConditionService.saveSConditions(dtos);
	}

	@GetMapping(value = "get-all-enabled-storage-conditions")
	public List<IdCodeName> getAllEnabled() {
		return storageConditionService.fetchAllEnabledStorageConditions();
	}
}
