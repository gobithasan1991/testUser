package com.anthem.glp.web.controller.admin;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.glp.web.service.admin.GLPDepartmentService;
import com.anthem.glp.web.service.admin.dto.GLPDepartmentDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;
import com.anthem.web.view.View;
import com.fasterxml.jackson.annotation.JsonView;

@RestController
@RequestMapping(value = "/glp-department")
public class GLPDepartmentController {
	private GLPDepartmentService glpDepartmentService;
	
	@Autowired
	public GLPDepartmentController(GLPDepartmentService glpDepartmentService) {
		super();
		this.glpDepartmentService = glpDepartmentService;
	}

	@GetMapping(value = "/glpdepartment")
	public ModelAndView glpDepartment() {
		return new ModelAndView("glp/admin/glp_department_creation");
	}
	
	@PostMapping(value = "/department-store")
	public ReturnStatus storeGLPDepartment(@Validated @RequestBody GLPDepartment glpDepartment, BindingResult bindingResult) {
		return glpDepartmentService.save(glpDepartment);
	}
	
	@GetMapping("/list-all-basic-glp-department-details")
	public List<IdNameCodeDTO> getDepartmentforBasicView() {
		return glpDepartmentService.findAllGLPDepartments();
	}

	@GetMapping("/list-glp-department-by-deparmtnet-id/{deptId}")
	public List<GLPDepartmentDTO> getGLPDepartmentByDepartment(@PathVariable long deptId) {
		return glpDepartmentService.findGLPDepartmentByDepartment(deptId);

	}

	@GetMapping("/basicview/hodGLPDepartment")
	@JsonView(View.BasicView.class)
	public ResponseEntity<List<GLPDepartment>> getHODDepartmentforBasicView() {
		return new ResponseEntity<List<GLPDepartment>>(glpDepartmentService.findGLPDepartmentForHOD(), HttpStatus.OK);
	}

	@GetMapping("/report/GLPDepartmentReport")
	public String getDepartmentReport() {
		return "admin/reports/GLPDepartmentReport";
	}

	@GetMapping("/report/GLPDepartmentReport/{type}/{page}/{size}")
	public Page<GLPDepartment> getDepartmentByType(@PathVariable String type, @PathVariable int page,
			@PathVariable int size) {
		String orderby = "";
		if (type.equalsIgnoreCase("Name")) {
			orderby = "glpDeptName";
		} else if (type.equalsIgnoreCase("Date")) {
			orderby = "createdDate";
		}
		return glpDepartmentService.findGLPDepartmentForPageTable(page, size, orderby);
	}

	@GetMapping("/validation/duplicateGLPDepartment")
	@ResponseBody
	public Boolean checkDocumentDuplicate(@RequestParam(name = "glpDeptName") String deptName) {
		if (glpDepartmentService.checkDuplicateDepartment(deptName) != null) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	@GetMapping(value = "/fetch-glp-departments-for-current-user")
	public List<GLPDepartmentDTO> fetchGLPDepartmentsForCurrentUser(@AuthenticationPrincipal User user) {
		List<GLPDepartment> glpDepartments = user.getGlpDepartments();
		List<GLPDepartmentDTO> glpDepartmentDTOs = new ArrayList<>();
		for (GLPDepartment glpDepartment : glpDepartments) {
			GLPDepartmentDTO glpDepartmentDTO = new GLPDepartmentDTO();
			glpDepartmentDTO.setCode(glpDepartment.getCode());
			glpDepartmentDTO.setName(glpDepartment.getName());
			glpDepartmentDTO.setId(glpDepartment.getId());
			glpDepartmentDTOs.add(glpDepartmentDTO);
		}

		return glpDepartmentDTOs;
	}
}
