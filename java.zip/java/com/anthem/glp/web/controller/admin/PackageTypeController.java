package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.admin.PackageTypeService;
import com.anthem.web.service.common.dto.IdCodeName;

@RestController
@RequestMapping(value = "/package-type")
public class PackageTypeController {

	private PackageTypeService packageTypeService;

	@Autowired
	public PackageTypeController(PackageTypeService packageTypeService) {
		super();
		this.packageTypeService = packageTypeService;
	}

	@GetMapping(value = "/create")
	public ModelAndView packageTypeCreate() {
		return new ModelAndView("glp/admin/package_type");
	}

	@PostMapping(value = "/save")
	public String saveSponsor(@RequestBody List<IdCodeName> dtos) {
		return packageTypeService.savePackageType(dtos);
	}

	@GetMapping(value = "get-all-enabled-package-types")
	public List<IdCodeName> getAllEnabled() {
		return packageTypeService.fetchAllEnabledPackageTypes();
	}
}
