package com.anthem.glp.web.controller.admin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping(value = "/reports")
public class ReportsController {
	@GetMapping(value = "/monthly-master-schedule")
	public ModelAndView monthlyMasterSchedule() {
		return new ModelAndView("glp/reports/monthly-master-schedule/monthly_master_schedule");
	}
	
	@GetMapping("/monthly-master-schedule-pdf")
	public ModelAndView monthlyMasterSchedulePDF() {
		return new ModelAndView("glp/pdf/monthly-master-schedule/monthly_master_schedule_pdf");
	}
	
	@GetMapping(value = "/test-item-report")
	public ModelAndView testItemReport() {
		return new ModelAndView("glp/reports/study/test_item_report");
	}
}
