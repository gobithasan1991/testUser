package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.user.UserService;

@RestController
@RequestMapping(value = "/glp-designation-employee")
public class GLPEmployeeDesignationMappingController {
	private UserService userService;
	
	@Autowired
	public GLPEmployeeDesignationMappingController(UserService userService) {
		super();
		this.userService = userService;
	}
	
	@GetMapping(value = "/mapping")
	public ModelAndView glpEmpoyeeDesignationMapping() {
		return new ModelAndView("glp/admin/glp_employee_designation_mapping");
	}
	
	@PostMapping("/userDesignationMappingStore")
	public ReturnStatus storeDesignationEmpMapping(@Validated @RequestBody List<User> users, BindingResult bindingResult) {
		return userService.mapGLPDesignationsToGLPDeptEmployees(users);
	}
}
