package com.anthem.glp.web.controller.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.glp.web.service.admin.GLPDocumentTemplateService;
import com.anthem.persistence.model.user.User;
import com.anthem.web.service.common.dto.IdNameCodeDTO;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value = "glp-document-template")
public class GLPDocumentTemplateController {

	private ObjectMapper objectMapper;
	private GLPDocumentTemplateService glpDocumentTemplateService;

	public GLPDocumentTemplateController(ObjectMapper objectMapper,
			GLPDocumentTemplateService glpDocumentTemplateService) {
		super();
		this.objectMapper = objectMapper;
		this.glpDocumentTemplateService = glpDocumentTemplateService;
	}

	@GetMapping(value = "/create")
	public ModelAndView createGlpDocumentTemplate() {

		return new ModelAndView("glp/admin/glp_document_template");
	}

	@PostMapping(value = "/save")
	public String saveGlpDocumentTemplate(@RequestParam("glpDocumentTemplate") String glpDocumentTemplate,
			@RequestParam(value = "file", required = false) MultipartFile file,
			@RequestParam(value = "fileType", required = false) String fileType,
			@RequestParam(value = "isConverted") boolean isConverted,
			@RequestParam(value = "convertedFile") String convertedFile, @AuthenticationPrincipal User user,
			HttpServletRequest request, HttpServletResponse response)
			throws JsonParseException, JsonMappingException, IOException {

		GLPDocumentTemplate glpDocTemplate = objectMapper.readValue(glpDocumentTemplate, GLPDocumentTemplate.class);
		return glpDocumentTemplateService.saveGlpDocumentTemplate(glpDocTemplate, file, user, convertedFile,
				isConverted, fileType, request, response);
	}

	@GetMapping(value = "/get-all-glp-document-templates")
	public List<IdNameCodeDTO> getAllGlpDocumentTemplates() {

		return glpDocumentTemplateService.getAllGlpDocumentTemplates();
	}
	
	@GetMapping(value = "/get-glp-document-templates-by-category/{tempCategory}")
	public List<IdNameCodeDTO> getGlpDocumentTemplatesByCategory(@PathVariable("tempCategory") String tempCategory) {

		return glpDocumentTemplateService.getGlpDocumentTemplatesByCategory(tempCategory);
	}
}
