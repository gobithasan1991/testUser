package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.user.UserService;

@RestController
@RequestMapping("/glp-user-mapping")
public class GLPUserMappingController {
	private UserService userService;

	@Autowired
	public GLPUserMappingController(UserService userService) {
		this.userService = userService;
	}

	@GetMapping("/creation")
	public ModelAndView glpEmployeeMapping() {
		return new ModelAndView("glp/admin/glp_user_mapping");
	}

	@PostMapping("/userMappingStore")
	public ReturnStatus storeEmpMapping(@Validated @RequestBody List<User> users, BindingResult bindingResult) {
		return userService.mapGLPToUser(users);
	}

	@GetMapping("/basicview/employeeByQmsDepartment/{glpDepartments}")
	public ResponseEntity<List<User>> getBasicViewOfGLPEmployee(@PathVariable long glpDepartments) {
		return new ResponseEntity<List<User>>(userService.findByQmsDepartment(glpDepartments), HttpStatus.OK);
	}

}
