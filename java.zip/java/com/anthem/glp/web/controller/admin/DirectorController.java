package com.anthem.glp.web.controller.admin;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.admin.DirectorService;
import com.anthem.glp.web.service.admin.dto.DirectorDTO;
import com.anthem.persistence.model.user.User;
import com.anthem.web.service.admin.DepartmentService;

@RestController
@RequestMapping(value = "/study-director-master")
public class DirectorController {

	private DirectorService directorService;


	@Autowired
	public DirectorController(DirectorService directorService) {
		this.directorService = directorService;
		
	}

	@GetMapping(value = "/create")
	public ModelAndView studyDirectorCreate() {
		return new ModelAndView("glp/admin/study_director_creation");
	}

	@PostMapping(value = "/save")
	public String saveDirector(@RequestBody List<DirectorDTO> dtos, @AuthenticationPrincipal User user) {
		return directorService.saveDirector(dtos, user);
	}

	@GetMapping(value = "/get-all-by-department-and-session-branch/{departmentId}")
	public List<DirectorDTO> getAllDirectorsByDepartmentAndSessionBranch(
			@PathVariable("departmentId") Long departmentId, @AuthenticationPrincipal User user) {
		return directorService.fetchAllDirectorsByDepartment(departmentId, user);
	}
	
	@GetMapping("/report")
	public ModelAndView reportPage() {
		return new ModelAndView("glp/reports/study/study_director_report");
	}

	@GetMapping(value = "/get-all-directors-by-department-and-createdDate/{deptId}/{fromDate}/{toDate}")
	public Page<DirectorDTO> fetchAllDirectorsByDepartmentAndCreatedDate(@PathVariable("deptId") Long deptId,
			@PathVariable("fromDate") Long fromDate, @PathVariable("toDate") Long toDate,
			@AuthenticationPrincipal User user, Pageable pageable) {
		return directorService.fetchAllDirectorsByDepartmentAndCreatedDate(deptId, new Date(fromDate), new Date(toDate),
				user, pageable);
	}

	@GetMapping(value = "pdf/view-study-director-pdf/{deptId}/{fromDate}/{toDate}")
	public ModelAndView viewIAForecastPDF(Model map, @PathVariable(value = "deptId") Long deptId,
			@PathVariable(value = "fromDate") Long fromDate, @PathVariable(value = "toDate") Long toDate,
			@AuthenticationPrincipal User user) {
		Date startDate = new Date(fromDate);
		Date endDate = new Date(toDate);
		List<DirectorDTO> directorDTOs = directorService.fetchAllDirectorsByDepartmentAndCreatedDateForPDF(deptId,
				new Date(fromDate), new Date(toDate), user);

		map.addAttribute("deptcheck", deptId);
		if (deptId != 0) {
			map.addAttribute("dept", directorDTOs.get(0).getGlpDepartment());
		} else {
			map.addAttribute("dept", deptId);
		}
		map.addAttribute("periodStart", startDate);
		map.addAttribute("periodEnd", endDate);
		map.addAttribute("data", directorDTOs);
		return new ModelAndView("glp/pdf/study_director_pdf");
	}
}
