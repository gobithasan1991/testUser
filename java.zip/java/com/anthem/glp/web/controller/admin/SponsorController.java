package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.admin.SponsorService;
import com.anthem.glp.web.service.admin.dto.SponsorDto;
import com.anthem.web.service.common.dto.IdCodeName;

@RestController
@RequestMapping(value = "/sponsor")
public class SponsorController {

	private SponsorService sponsorService;

	@Autowired
	public SponsorController(SponsorService sponsorService) {
		this.sponsorService = sponsorService;
	}

	@GetMapping(value = "/create")
	public ModelAndView sponsorCreate() {
		return new ModelAndView("glp/admin/sponsor_master");
	}

	@PostMapping(value = "/save")
	public String saveSponsor(@RequestBody SponsorDto dto) {
		return sponsorService.saveSponsor(dto);
	}

	@GetMapping(value = "/get-all-enabled-sponsors")
	public List<IdCodeName> getAllEnabled() {
		return sponsorService.fetchAllSponsors();
	}

	@GetMapping(value = "/get-sponsor-details-by-id/{sponsorId}")
	public SponsorDto getSponsorDetailsById(@PathVariable("sponsorId") Long sponsorId) {
		return sponsorService.fetchSponsorDetails(sponsorId);
	}
}
