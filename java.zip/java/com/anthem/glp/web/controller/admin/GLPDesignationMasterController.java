package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.persistence.model.admin.GLPDesignation;
import com.anthem.glp.web.service.admin.GLPDesignationService;
import com.anthem.util.common.ReturnStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

@RestController
@RequestMapping(value = "/glp-designation")
public class GLPDesignationMasterController {
	private GLPDesignationService glpDesignationService;
	
	@Autowired
	public GLPDesignationMasterController(GLPDesignationService glpDesignationService) {
		super();
		this.glpDesignationService = glpDesignationService;
	}

	@GetMapping(value = "/master")
	public ModelAndView glpDesignationMaster() {
		return new ModelAndView("glp/admin/glp_designation_master");
	}
	
	@PostMapping(value = "/designation-store")
	public ReturnStatus storeGLPDesignation(@Validated @RequestBody GLPDesignation glpDesignation, BindingResult bindingResult) {
		return glpDesignationService.save(glpDesignation);
	}
	
	@GetMapping("/list-all-basic-glp-designation-details")
	public List<IdNameCodeDTO> getDesignationforBasicView() {
		return glpDesignationService.findAllGLPDesignations();
	}
}
