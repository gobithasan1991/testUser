package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.admin.PhysicalPropertyService;
import com.anthem.web.service.common.dto.IdCodeName;

@RestController
@RequestMapping(value = "/physical-property")
public class PhysicalPropertyController {

	private PhysicalPropertyService physicalPropertyService;

	@Autowired
	public PhysicalPropertyController(PhysicalPropertyService physicalPropertyService) {
		super();
		this.physicalPropertyService = physicalPropertyService;
	}

	@GetMapping(value = "/create")
	public ModelAndView physicalPropertyCreate() {
		return new ModelAndView("glp/admin/physical_property");
	}

	@PostMapping(value = "/save")
	public String saveSponsor(@RequestBody List<IdCodeName> dtos) {
		return physicalPropertyService.saveProperties(dtos);
	}

	@GetMapping(value = "get-all-enabled-physical-properties")
	public List<IdCodeName> getAllEnabled() {
		return physicalPropertyService.fetchAllEnabledPhysicalProperties();
	}
}
