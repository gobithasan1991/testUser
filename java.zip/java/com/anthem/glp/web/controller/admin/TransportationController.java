package com.anthem.glp.web.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anthem.glp.web.service.admin.TransportationService;
import com.anthem.web.service.common.dto.IdCodeName;

@RestController
@RequestMapping(value = "/transportation-master")
public class TransportationController {

	private TransportationService transportationService;

	@Autowired
	public TransportationController(TransportationService transportationService) {
		super();
		this.transportationService = transportationService;
	}

	@GetMapping(value = "/create")
	public ModelAndView transportationCreate() {
		return new ModelAndView("glp/admin/transportation_master");
	}

	@PostMapping(value = "/save")
	public String saveTransportation(@RequestBody List<IdCodeName> dtos) {
		return transportationService.saveTransportation(dtos);
	}

	@GetMapping(value = "get-all-enabled-transportations")
	public List<IdCodeName> getAllEnabledTransportation() {
		return transportationService.fetchAllEnabledTransportations();

	}

}
