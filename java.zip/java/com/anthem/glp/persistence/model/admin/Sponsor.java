package com.anthem.glp.persistence.model.admin;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.State;
import com.anthem.persistence.model.common.Default;

@Entity
public class Sponsor extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -312764480886613466L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true)
	private String name;

	@Column(nullable = false)
	private String contactName;

	@Column(nullable = false)
	@Lob
	private String address;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private State state;

	@Column(nullable = false)
	private String pinCode;

	@Column(nullable = false)
	private String phone;

	private String fax;

	@Lob
	private String email;

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getContactName() {
		return contactName;
	}

	public String getAddress() {
		return address;
	}

	public State getState() {
		return state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public String getPhone() {
		return phone;
	}

	public String getFax() {
		return fax;
	}

	public String getEmail() {
		return email;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setState(State state) {
		this.state = state;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
