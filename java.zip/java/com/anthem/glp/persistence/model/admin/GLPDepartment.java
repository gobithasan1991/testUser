package com.anthem.glp.persistence.model.admin;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.admin.Company;
import com.anthem.persistence.model.admin.Department;
import com.anthem.persistence.model.common.Default;

@Entity
//@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "department_id", "code", "name" }),
//		@UniqueConstraint(columnNames = { "code" }), @UniqueConstraint(columnNames = { "name" }) })
public class GLPDepartment extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2922518044344026404L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Department department;

	@Column(unique = true)
	private String code;
	@Column(unique = true)
	private String name;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Company company;

	public GLPDepartment() {
		super();
	}

	public GLPDepartment(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GLPDepartment other = (GLPDepartment) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
