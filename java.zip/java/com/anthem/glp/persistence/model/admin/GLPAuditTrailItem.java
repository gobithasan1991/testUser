package com.anthem.glp.persistence.model.admin;

import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

public class GLPAuditTrailItem extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6662886516583352139L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;

	private Long auditMapId;

	private String auditType;

	@ManyToOne(fetch = FetchType.LAZY)
	private GLPAuditTrail glpAuditTrail;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Long getAuditMapId() {
		return auditMapId;
	}

	public void setAuditMapId(Long auditMapId) {
		this.auditMapId = auditMapId;
	}

	public String getAuditType() {
		return auditType;
	}

	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	public GLPAuditTrail getGlpAuditTrail() {
		return glpAuditTrail;
	}

	public void setGlpAuditTrail(GLPAuditTrail glpAuditTrail) {
		this.glpAuditTrail = glpAuditTrail;
	}

}
