package com.anthem.glp.persistence.model.admin;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "director_id" }))
public class DirectorMaster extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1652255698496202777L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private GLPDepartment glpDepartment;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User director;

	@Temporal(TemporalType.TIMESTAMP)
	private Date qauEvaluation;

	@Lob
	private String aoe;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Branch branch;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getDirector() {
		return director;
	}

	public void setDirector(User director) {
		this.director = director;
	}

	public Date getQauEvaluation() {
		return qauEvaluation;
	}

	public void setQauEvaluation(Date qauEvaluation) {
		this.qauEvaluation = qauEvaluation;
	}

	public String getAoe() {
		return aoe;
	}

	public void setAoe(String aoe) {
		this.aoe = aoe;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public GLPDepartment getGlpDepartment() {
		return glpDepartment;
	}

	public void setGlpDepartment(GLPDepartment glpDepartment) {
		this.glpDepartment = glpDepartment;
	}

}
