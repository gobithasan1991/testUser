package com.anthem.glp.persistence.model.study;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.glp.persistence.model.admin.DirectorMaster;
import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.ApproveStatus;

@Entity
public class StudyDirector extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5284013635107663944L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private StudyNumber studyNumber;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private DirectorMaster director;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ApproveStatus approveStatus;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approvedDate;

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyNumber getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumber studyNumber) {
		this.studyNumber = studyNumber;
	}

	public DirectorMaster getDirector() {
		return director;
	}

	public void setDirector(DirectorMaster director) {
		this.director = director;
	}

}
