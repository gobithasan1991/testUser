package com.anthem.glp.persistence.model.study;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.RequestFor;

@Entity
public class StudyRequisition extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6058937582512352064L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String number;

	@ManyToOne(fetch = FetchType.LAZY)
	private TestItemReceipt testItemReceipt;

	@ManyToOne(fetch = FetchType.LAZY)
	private StudyNumber studyNumber;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('LAB_NOTEBOOK', 'LOG_BOOK', 'ANNEXURES') DEFAULT 'LAB_NOTEBOOK'", insertable = false)
	private RequestFor requestFor;
	
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING'", insertable = false)
	private ApproveStatus approveStatus;
	
	private String previousBookNoInstrumrntId;
	
	@Lob
	private String remarks;
	
	@Lob
	private String approveRemarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private User approvedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approvedDate;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "studyRequisition_id")
	private List<StudyRequisitionItem> studyRequisitionItems;

	public StudyRequisition() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public TestItemReceipt getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceipt testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public StudyNumber getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumber studyNumber) {
		this.studyNumber = studyNumber;
	}

	public RequestFor getRequestFor() {
		return requestFor;
	}

	public void setRequestFor(RequestFor requestFor) {
		this.requestFor = requestFor;
	}

	public ApproveStatus getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(ApproveStatus approveStatus) {
		this.approveStatus = approveStatus;
	}

	public String getPreviousBookNoInstrumrntId() {
		return previousBookNoInstrumrntId;
	}

	public void setPreviousBookNoInstrumrntId(String previousBookNoInstrumrntId) {
		this.previousBookNoInstrumrntId = previousBookNoInstrumrntId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getApproveRemarks() {
		return approveRemarks;
	}

	public void setApproveRemarks(String approveRemarks) {
		this.approveRemarks = approveRemarks;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public List<StudyRequisitionItem> getStudyRequisitionItems() {
		return studyRequisitionItems;
	}

	public void setStudyRequisitionItems(List<StudyRequisitionItem> studyRequisitionItems) {
		this.studyRequisitionItems = studyRequisitionItems;
	}	
}
