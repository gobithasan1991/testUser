package com.anthem.glp.persistence.model.study;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.FolderCreationStatus;
import com.anthem.util.common.FolderRelated;

@Entity
public class FolderCreationRequest extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8693818305016085857L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dateRequest;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('Study','QAU','Facility') DEFAULT 'Study'", insertable = false)
	private FolderRelated folderRelated;

	private String folderRelatedOthers;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private StudyNumber studyNumber;

	private Integer numberOfFolderRequested;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User authorizedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date authorizedDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User acceptedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date acceptedDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User folderCreatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date folderCreatedDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User folderCreatedEntryBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date folderCreatedEntryDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User qauVerificationRequestBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date qauVerificationRequestDate;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'AUTHORIZED','TFMACCEPTED','ITACCEPTED','TFMNOTACCEPTED','ITNOTACCEPTED','FOLDERCREATED','QAUVERIFICATIONREQUESTED','QAUVERIFY') DEFAULT 'PENDING'", insertable = false)
	private FolderCreationStatus folderCreationStatus;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = FolderLocationAndTitle.class)
	@JoinColumn(name = "foldercreationrequest_id")
	private List<FolderLocationAndTitle> folderLocationAndTitles;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = FolderAccess.class)
	@JoinColumn(name = "foldercreationrequest_id")
	private List<FolderAccess> folderAccesses;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the dateRequest
	 */
	public Date getDateRequest() {
		return dateRequest;
	}

	/**
	 * @param dateRequest the dateRequest to set
	 */
	public void setDateRequest(Date dateRequest) {
		this.dateRequest = dateRequest;
	}

	/**
	 * @return the folderRelated
	 */
	public FolderRelated getFolderRelated() {
		return folderRelated;
	}

	/**
	 * @param folderRelated the folderRelated to set
	 */
	public void setFolderRelated(FolderRelated folderRelated) {
		this.folderRelated = folderRelated;
	}

	/**
	 * @return the folderRelatedOthers
	 */
	public String getFolderRelatedOthers() {
		return folderRelatedOthers;
	}

	/**
	 * @param folderRelatedOthers the folderRelatedOthers to set
	 */
	public void setFolderRelatedOthers(String folderRelatedOthers) {
		this.folderRelatedOthers = folderRelatedOthers;
	}

	/**
	 * @return the studyNumber
	 */
	public StudyNumber getStudyNumber() {
		return studyNumber;
	}

	/**
	 * @param studyNumber the studyNumber to set
	 */
	public void setStudyNumber(StudyNumber studyNumber) {
		this.studyNumber = studyNumber;
	}

	/**
	 * @return the numberOfFolderRequested
	 */
	public Integer getNumberOfFolderRequested() {
		return numberOfFolderRequested;
	}

	/**
	 * @param numberOfFolderRequested the numberOfFolderRequested to set
	 */
	public void setNumberOfFolderRequested(Integer numberOfFolderRequested) {
		this.numberOfFolderRequested = numberOfFolderRequested;
	}

	/**
	 * @return the authorizedBy
	 */
	public User getAuthorizedBy() {
		return authorizedBy;
	}

	/**
	 * @param authorizedBy the authorizedBy to set
	 */
	public void setAuthorizedBy(User authorizedBy) {
		this.authorizedBy = authorizedBy;
	}

	/**
	 * @return the authorizedDate
	 */
	public Date getAuthorizedDate() {
		return authorizedDate;
	}

	/**
	 * @param authorizedDate the authorizedDate to set
	 */
	public void setAuthorizedDate(Date authorizedDate) {
		this.authorizedDate = authorizedDate;
	}

	/**
	 * @return the acceptedBy
	 */
	public User getAcceptedBy() {
		return acceptedBy;
	}

	/**
	 * @param acceptedBy the acceptedBy to set
	 */
	public void setAcceptedBy(User acceptedBy) {
		this.acceptedBy = acceptedBy;
	}

	/**
	 * @return the acceptedDate
	 */
	public Date getAcceptedDate() {
		return acceptedDate;
	}

	/**
	 * @param acceptedDate the acceptedDate to set
	 */
	public void setAcceptedDate(Date acceptedDate) {
		this.acceptedDate = acceptedDate;
	}

	/**
	 * @return the folderCreatedBy
	 */
	public User getFolderCreatedBy() {
		return folderCreatedBy;
	}

	/**
	 * @param folderCreatedBy the folderCreatedBy to set
	 */
	public void setFolderCreatedBy(User folderCreatedBy) {
		this.folderCreatedBy = folderCreatedBy;
	}

	/**
	 * @return the folderCreatedDate
	 */
	public Date getFolderCreatedDate() {
		return folderCreatedDate;
	}

	/**
	 * @param folderCreatedDate the folderCreatedDate to set
	 */
	public void setFolderCreatedDate(Date folderCreatedDate) {
		this.folderCreatedDate = folderCreatedDate;
	}

	/**
	 * @return the folderCreatedEntryBy
	 */
	public User getFolderCreatedEntryBy() {
		return folderCreatedEntryBy;
	}

	/**
	 * @param folderCreatedEntryBy the folderCreatedEntryBy to set
	 */
	public void setFolderCreatedEntryBy(User folderCreatedEntryBy) {
		this.folderCreatedEntryBy = folderCreatedEntryBy;
	}

	/**
	 * @return the folderCreatedEntryDate
	 */
	public Date getFolderCreatedEntryDate() {
		return folderCreatedEntryDate;
	}

	/**
	 * @param folderCreatedEntryDate the folderCreatedEntryDate to set
	 */
	public void setFolderCreatedEntryDate(Date folderCreatedEntryDate) {
		this.folderCreatedEntryDate = folderCreatedEntryDate;
	}

	/**
	 * @return the qauVerificationRequestBy
	 */
	public User getQauVerificationRequestBy() {
		return qauVerificationRequestBy;
	}

	/**
	 * @param qauVerificationRequestBy the qauVerificationRequestBy to set
	 */
	public void setQauVerificationRequestBy(User qauVerificationRequestBy) {
		this.qauVerificationRequestBy = qauVerificationRequestBy;
	}

	/**
	 * @return the qauVerificationRequestDate
	 */
	public Date getQauVerificationRequestDate() {
		return qauVerificationRequestDate;
	}

	/**
	 * @param qauVerificationRequestDate the qauVerificationRequestDate to set
	 */
	public void setQauVerificationRequestDate(Date qauVerificationRequestDate) {
		this.qauVerificationRequestDate = qauVerificationRequestDate;
	}

	/**
	 * @return the folderCreationStatus
	 */
	public FolderCreationStatus getFolderCreationStatus() {
		return folderCreationStatus;
	}

	/**
	 * @param folderCreationStatus the folderCreationStatus to set
	 */
	public void setFolderCreationStatus(FolderCreationStatus folderCreationStatus) {
		this.folderCreationStatus = folderCreationStatus;
	}

	/**
	 * @return the folderLocationAndTitles
	 */
	public List<FolderLocationAndTitle> getFolderLocationAndTitles() {
		return folderLocationAndTitles;
	}

	/**
	 * @param folderLocationAndTitles the folderLocationAndTitles to set
	 */
	public void setFolderLocationAndTitles(List<FolderLocationAndTitle> folderLocationAndTitles) {
		this.folderLocationAndTitles = folderLocationAndTitles;
	}

	/**
	 * @return the folderAccesses
	 */
	public List<FolderAccess> getFolderAccesses() {
		return folderAccesses;
	}

	/**
	 * @param folderAccesses the folderAccesses to set
	 */
	public void setFolderAccesses(List<FolderAccess> folderAccesses) {
		this.folderAccesses = folderAccesses;
	}

}
