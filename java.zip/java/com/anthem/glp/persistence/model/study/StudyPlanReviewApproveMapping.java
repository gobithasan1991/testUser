package com.anthem.glp.persistence.model.study;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.persistence.status.CustomStatus;

@Entity
public class StudyPlanReviewApproveMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5328609634404794997L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private StudyPlan studyPlan;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private GLPDepartment glpDepartment;

	@ManyToOne(fetch = FetchType.EAGER)
	private User user;

	private String reviewType;

	@Lob
	private String specialNotes;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('MAPPED', 'REMAPPED', 'REVIEWED', 'APPROVED', 'REJECTED','RECALLED') DEFAULT 'MAPPED'", insertable = false)
	private CustomStatus mappingStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private User updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;

	@Column(columnDefinition = "boolean default false", insertable = false)
	private Boolean rejected;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyPlan getStudyPlan() {
		return studyPlan;
	}

	public void setStudyPlan(StudyPlan studyPlan) {
		this.studyPlan = studyPlan;
	}

	public GLPDepartment getGlpDepartment() {
		return glpDepartment;
	}

	public void setGlpDepartment(GLPDepartment glpDepartment) {
		this.glpDepartment = glpDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	public CustomStatus getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(CustomStatus mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Boolean getRejected() {
		return rejected;
	}

	public void setRejected(Boolean rejected) {
		this.rejected = rejected;
	}

}
