package com.anthem.glp.persistence.model.study;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class FolderLocationAndTitle extends Default {

	private static final long serialVersionUID = 6603683124158302301L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private FolderCreationRequest folderCreationRequest;

	private String folderLocation;

	private String folderTitle;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the folderCreationRequest
	 */
	public FolderCreationRequest getFolderCreationRequest() {
		return folderCreationRequest;
	}

	/**
	 * @param folderCreationRequest the folderCreationRequest to set
	 */
	public void setFolderCreationRequest(FolderCreationRequest folderCreationRequest) {
		this.folderCreationRequest = folderCreationRequest;
	}

	/**
	 * @return the folderLocation
	 */
	public String getFolderLocation() {
		return folderLocation;
	}

	/**
	 * @param folderLocation the folderLocation to set
	 */
	public void setFolderLocation(String folderLocation) {
		this.folderLocation = folderLocation;
	}

	/**
	 * @return the folderTitle
	 */
	public String getFolderTitle() {
		return folderTitle;
	}

	/**
	 * @param folderTitle the folderTitle to set
	 */
	public void setFolderTitle(String folderTitle) {
		this.folderTitle = folderTitle;
	}

}
