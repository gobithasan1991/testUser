package com.anthem.glp.persistence.model.study;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class StudyRequisitionItem extends Default{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6657504945004150880L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private StudyRequisition studyRequisition;
	
	private String sopNo;
	
	private String sopVersionNo;
	
	private String annexureNo;
	
	private String pageNo;
	
	@Lob
	private String title;
	
	private Long noOfCopies;

	public StudyRequisitionItem() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyRequisition getStudyRequisition() {
		return studyRequisition;
	}

	public void setStudyRequisition(StudyRequisition studyRequisition) {
		this.studyRequisition = studyRequisition;
	}

	public String getSopNo() {
		return sopNo;
	}

	public void setSopNo(String sopNo) {
		this.sopNo = sopNo;
	}

	public String getSopVersionNo() {
		return sopVersionNo;
	}

	public void setSopVersionNo(String sopVersionNo) {
		this.sopVersionNo = sopVersionNo;
	}

	public String getAnnexureNo() {
		return annexureNo;
	}

	public void setAnnexureNo(String annexureNo) {
		this.annexureNo = annexureNo;
	}

	public String getPageNo() {
		return pageNo;
	}

	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getNoOfCopies() {
		return noOfCopies;
	}

	public void setNoOfCopies(Long noOfCopies) {
		this.noOfCopies = noOfCopies;
	}	
	
}
