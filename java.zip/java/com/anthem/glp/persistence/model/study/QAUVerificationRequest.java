package com.anthem.glp.persistence.model.study;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
public class QAUVerificationRequest extends Default {

	private static final long serialVersionUID = 3077891280693124697L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private FolderCreationRequest folderCreationRequest;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User qauCheckBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date qauCheckDate;

	@Column(columnDefinition = "TEXT")
	private String remark;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "qauVerificationRequest_id")
	private List<QAUCheck> qauChecks;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the folderCreationRequest
	 */
	public FolderCreationRequest getFolderCreationRequest() {
		return folderCreationRequest;
	}

	/**
	 * @param folderCreationRequest the folderCreationRequest to set
	 */
	public void setFolderCreationRequest(FolderCreationRequest folderCreationRequest) {
		this.folderCreationRequest = folderCreationRequest;
	}

	/**
	 * @return the qauCheckBy
	 */
	public User getQauCheckBy() {
		return qauCheckBy;
	}

	/**
	 * @param qauCheckBy the qauCheckBy to set
	 */
	public void setQauCheckBy(User qauCheckBy) {
		this.qauCheckBy = qauCheckBy;
	}

	/**
	 * @return the qauCheckDate
	 */
	public Date getQauCheckDate() {
		return qauCheckDate;
	}

	/**
	 * @param qauCheckDate the qauCheckDate to set
	 */
	public void setQauCheckDate(Date qauCheckDate) {
		this.qauCheckDate = qauCheckDate;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the qauChecks
	 */
	public List<QAUCheck> getQauChecks() {
		return qauChecks;
	}

	/**
	 * @param qauChecks the qauChecks to set
	 */
	public void setQauChecks(List<QAUCheck> qauChecks) {
		this.qauChecks = qauChecks;
	}

	@Override
	public String toString() {
		return "QAUVerificationRequest [id=" + id + ", folderCreationRequest=" + folderCreationRequest + ", qauCheckBy="
				+ qauCheckBy + ", qauCheckDate=" + qauCheckDate + ", remark=" + remark + ", qauChecks=" + qauChecks
				+ "]";
	}

}
