package com.anthem.glp.persistence.model.study;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
public class StudyProtocolReviewApproveMapping extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8085051292451988133L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private StudyProtocol studyProtocol;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private GLPDepartment glpDepartment;

	@ManyToOne(fetch = FetchType.EAGER)
	private User user;

	private String reviewType;

	@Lob
	private String specialNotes;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyProtocol getStudyProtocol() {
		return studyProtocol;
	}

	public void setStudyProtocol(StudyProtocol studyProtocol) {
		this.studyProtocol = studyProtocol;
	}

	public GLPDepartment getGlpDepartment() {
		return glpDepartment;
	}

	public void setGlpDepartment(GLPDepartment glpDepartment) {
		this.glpDepartment = glpDepartment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getSpecialNotes() {
		return specialNotes;
	}

	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

}
