package com.anthem.glp.persistence.model.study;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.FolderAccessType;

@Entity
public class FolderAccess extends Default {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4062056070722222872L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('Read','ReadAndWrite') DEFAULT 'Read'", insertable = false)
	private FolderAccessType folderAccessType;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private FolderCreationRequest folderCreationRequest;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User user;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the folderAccessType
	 */
	public FolderAccessType getFolderAccessType() {
		return folderAccessType;
	}

	/**
	 * @param folderAccessType the folderAccessType to set
	 */
	public void setFolderAccessType(FolderAccessType folderAccessType) {
		this.folderAccessType = folderAccessType;
	}

	/**
	 * @return the folderCreationRequest
	 */
	public FolderCreationRequest getFolderCreationRequest() {
		return folderCreationRequest;
	}

	/**
	 * @param folderCreationRequest the folderCreationRequest to set
	 */
	public void setFolderCreationRequest(FolderCreationRequest folderCreationRequest) {
		this.folderCreationRequest = folderCreationRequest;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

}
