package com.anthem.glp.persistence.model.study;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.QAUAnswer;

@Entity
public class QAUCheck extends Default {

	private static final long serialVersionUID = 9115889048489164768L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private QAUVerificationRequest qauVerificationRequest;

	@Column(columnDefinition = "TEXT")
	private String question;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('Yes','No','NA') DEFAULT 'NA'")
	private QAUAnswer qauAnswer;

	@Column(columnDefinition = "TEXT")
	private String remark;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public QAUVerificationRequest getQauVerificationRequest() {
		return qauVerificationRequest;
	}

	public void setQauVerificationRequest(QAUVerificationRequest qauVerificationRequest) {
		this.qauVerificationRequest = qauVerificationRequest;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public QAUAnswer getQauAnswer() {
		return qauAnswer;
	}

	public void setQauAnswer(QAUAnswer qauAnswer) {
		this.qauAnswer = qauAnswer;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "QAUCheck [id=" + id + ", qauVerificationRequest=" + qauVerificationRequest + ", question=" + question
				+ ", qauAnswer=" + qauAnswer + ", remark=" + remark + "]";
	}

}
