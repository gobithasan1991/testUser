package com.anthem.glp.persistence.model.study;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.persistence.model.common.Default;

@Entity
public class StudyPlan extends Default {

	private static final long serialVersionUID = -7306042096991790161L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TestItemReceipt testItemReceipt;

	@ManyToOne(fetch = FetchType.LAZY)
	private StudyNumber studyNumber;

	private String documentForm;

	@ManyToOne(fetch = FetchType.LAZY)
	private GLPDocumentTemplate glpDocumentTemplate;

	private String fileId;

	@Lob
	private String fileName;

	private String versionNo;

	public StudyPlan() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TestItemReceipt getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceipt testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public StudyNumber getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumber studyNumber) {
		this.studyNumber = studyNumber;
	}

	public String getDocumentForm() {
		return documentForm;
	}

	public void setDocumentForm(String documentForm) {
		this.documentForm = documentForm;
	}

	public GLPDocumentTemplate getGlpDocumentTemplate() {
		return glpDocumentTemplate;
	}

	public void setGlpDocumentTemplate(GLPDocumentTemplate glpDocumentTemplate) {
		this.glpDocumentTemplate = glpDocumentTemplate;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

}
