package com.anthem.glp.persistence.model.study;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;

@Entity
public class StudyProtocol extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1147503400710465726L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TestItemReceipt testItemReceipt;

	@ManyToOne(fetch = FetchType.LAZY)
	private StudyNumber studyNumber;

	private String documentForm;

	@ManyToOne(fetch = FetchType.LAZY)
	private GLPDocumentTemplate glpDocumentTemplate;

	private String fileId;

	@Lob
	private String fileName;

	@Lob
	private String reviewRemarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private User reviewedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date reviewedDate;

	@Lob
	private String approveRemarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private User approvedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date approvedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TestItemReceipt getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceipt testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public StudyNumber getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumber studyNumber) {
		this.studyNumber = studyNumber;
	}

	public String getDocumentForm() {
		return documentForm;
	}

	public void setDocumentForm(String documentForm) {
		this.documentForm = documentForm;
	}

	public GLPDocumentTemplate getGlpDocumentTemplate() {
		return glpDocumentTemplate;
	}

	public void setGlpDocumentTemplate(GLPDocumentTemplate glpDocumentTemplate) {
		this.glpDocumentTemplate = glpDocumentTemplate;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public User getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(User reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public Date getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public String getReviewRemarks() {
		return reviewRemarks;
	}

	public void setReviewRemarks(String reviewRemarks) {
		this.reviewRemarks = reviewRemarks;
	}

	public String getApproveRemarks() {
		return approveRemarks;
	}

	public void setApproveRemarks(String approveRemarks) {
		this.approveRemarks = approveRemarks;
	}

}
