package com.anthem.glp.persistence.model.study;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.anthem.persistence.model.common.Default;

@Entity
public class StudyAllotmentLetterDistributionList extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6529224405954077808L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private StudyNumber studyNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudyNumber getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(StudyNumber studyNumber) {
		this.studyNumber = studyNumber;
	}	
}
