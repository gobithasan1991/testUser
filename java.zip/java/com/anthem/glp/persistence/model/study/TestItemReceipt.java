package com.anthem.glp.persistence.model.study;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.glp.persistence.model.admin.Nominee;
import com.anthem.glp.persistence.model.admin.PackageType;
import com.anthem.glp.persistence.model.admin.Sponsor;
import com.anthem.glp.persistence.model.admin.StorageCondition;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.admin.UOM;
import com.anthem.persistence.model.common.Default;
import com.anthem.util.common.TestItemStatus;

@Entity
public class TestItemReceipt extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8981845720529055575L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Sponsor sponsorName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Nominee nominee;

	private String itemName;

	private String itemValue;

	private String chemicalName;

	private String casNo;

	private String gravity;

	private String batchType;

	private String batchOrLotValue;

	private String mWeight;

	private String mFormula;

	private String mWeightSalt;

	private String mFormulaSalt;

	private String purity;

	@ManyToOne(fetch = FetchType.LAZY)
	private Sponsor batchProducedBy;

	@Temporal(TemporalType.DATE)
	private Date manufactureDate;

	private String dateType;

	@Temporal(TemporalType.DATE)
	private Date expiryDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private PackageType packageType;

	private Double totalQty;

	@ManyToOne(fetch = FetchType.LAZY)
	private UOM totalQtyUom;

	private Double noOfPackeges;

	private Double grossWeight;

	@ManyToOne(fetch = FetchType.LAZY)
	private UOM grossWeightUom;

	private Double tareWeight;

	@ManyToOne(fetch = FetchType.LAZY)
	private UOM tareWeightUom;

	private String modeOfDispatch;

	@ManyToOne(fetch = FetchType.LAZY)
	private StorageCondition storageCondition;

	@Lob
	private String safetyPrecautions;

	private String materialSafety;

	private String analysisCertificate;
	@Lob
	private String additionalInformations;

	@ManyToOne(fetch = FetchType.LAZY)
	private Nominee sponsorRepresentative;

	@Lob
	private String remarks;

	@Lob
	private String coaDocument;

	@Lob
	private String safetyDocument;

	private String color;

	private String density;

	private String nature;

	private String meltingpoint;

	private String boilingpoint;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'TICO_ENTERED', 'STUDY_NO_GENERATED') DEFAULT 'PENDING'", insertable = false)
	private TestItemStatus testItemStatus;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Branch branch;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Sponsor getSponsorName() {
		return sponsorName;
	}

	public void setSponsorName(Sponsor sponsorName) {
		this.sponsorName = sponsorName;
	}

	public Nominee getNominee() {
		return nominee;
	}

	public void setNominee(Nominee nominee) {
		this.nominee = nominee;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemValue() {
		return itemValue;
	}

	public void setItemValue(String itemValue) {
		this.itemValue = itemValue;
	}

	public String getChemicalName() {
		return chemicalName;
	}

	public void setChemicalName(String chemicalName) {
		this.chemicalName = chemicalName;
	}

	public String getCasNo() {
		return casNo;
	}

	public void setCasNo(String casNo) {
		this.casNo = casNo;
	}

	public String getGravity() {
		return gravity;
	}

	public void setGravity(String gravity) {
		this.gravity = gravity;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public String getBatchOrLotValue() {
		return batchOrLotValue;
	}

	public void setBatchOrLotValue(String batchOrLotValue) {
		this.batchOrLotValue = batchOrLotValue;
	}

	public String getmWeight() {
		return mWeight;
	}

	public void setmWeight(String mWeight) {
		this.mWeight = mWeight;
	}

	public String getmFormula() {
		return mFormula;
	}

	public void setmFormula(String mFormula) throws UnsupportedEncodingException {
		this.mFormula = new String(mFormula.getBytes(), "UTF-8");
	}

	public String getmWeightSalt() {
		return mWeightSalt;
	}

	public void setmWeightSalt(String mWeightSalt) {
		this.mWeightSalt = mWeightSalt;
	}

	public String getmFormulaSalt() {
		return mFormulaSalt;
	}

	public void setmFormulaSalt(String mFormulaSalt) throws UnsupportedEncodingException {
		this.mFormulaSalt = new String(mFormulaSalt.getBytes(), "UTF-8");
	}

	public String getPurity() {
		return purity;
	}

	public void setPurity(String purity) {
		this.purity = purity;
	}

	public Sponsor getBatchProducedBy() {
		return batchProducedBy;
	}

	public void setBatchProducedBy(Sponsor batchProducedBy) {
		this.batchProducedBy = batchProducedBy;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public String getDateType() {
		return dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public PackageType getPackageType() {
		return packageType;
	}

	public void setPackageType(PackageType packageType) {
		this.packageType = packageType;
	}

	public Double getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}

	public UOM getTotalQtyUom() {
		return totalQtyUom;
	}

	public void setTotalQtyUom(UOM totalQtyUom) {
		this.totalQtyUom = totalQtyUom;
	}

	public Double getNoOfPackeges() {
		return noOfPackeges;
	}

	public void setNoOfPackeges(Double noOfPackeges) {
		this.noOfPackeges = noOfPackeges;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getTareWeight() {
		return tareWeight;
	}

	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}

	public UOM getGrossWeightUom() {
		return grossWeightUom;
	}

	public void setGrossWeightUom(UOM grossWeightUom) {
		this.grossWeightUom = grossWeightUom;
	}

	public UOM getTareWeightUom() {
		return tareWeightUom;
	}

	public void setTareWeightUom(UOM tareWeightUom) {
		this.tareWeightUom = tareWeightUom;
	}

	public String getModeOfDispatch() {
		return modeOfDispatch;
	}

	public void setModeOfDispatch(String modeOfDispatch) {
		this.modeOfDispatch = modeOfDispatch;
	}

	public StorageCondition getStorageCondition() {
		return storageCondition;
	}

	public void setStorageCondition(StorageCondition storageCondition) {
		this.storageCondition = storageCondition;
	}

	public String getSafetyPrecautions() {
		return safetyPrecautions;
	}

	public void setSafetyPrecautions(String safetyPrecautions) {
		this.safetyPrecautions = safetyPrecautions;
	}

	public String getMaterialSafety() {
		return materialSafety;
	}

	public void setMaterialSafety(String materialSafety) {
		this.materialSafety = materialSafety;
	}

	public String getAnalysisCertificate() {
		return analysisCertificate;
	}

	public void setAnalysisCertificate(String analysisCertificate) {
		this.analysisCertificate = analysisCertificate;
	}

	public String getAdditionalInformations() {
		return additionalInformations;
	}

	public void setAdditionalInformations(String additionalInformations) {
		this.additionalInformations = additionalInformations;
	}

	public Nominee getSponsorRepresentative() {
		return sponsorRepresentative;
	}

	public void setSponsorRepresentative(Nominee sponsorRepresentative) {
		this.sponsorRepresentative = sponsorRepresentative;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCoaDocument() {
		return coaDocument;
	}

	public void setCoaDocument(String coaDocument) {
		this.coaDocument = coaDocument;
	}

	public String getSafetyDocument() {
		return safetyDocument;
	}

	public void setSafetyDocument(String safetyDocument) {
		this.safetyDocument = safetyDocument;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getDensity() {
		return density;
	}

	public void setDensity(String density) {
		this.density = density;
	}

	public String getNature() {
		return nature;
	}

	public void setNature(String nature) {
		this.nature = nature;
	}

	public String getMeltingpoint() {
		return meltingpoint;
	}

	public void setMeltingpoint(String meltingpoint) {
		this.meltingpoint = meltingpoint;
	}

	public String getBoilingpoint() {
		return boilingpoint;
	}

	public void setBoilingpoint(String boilingpoint) {
		this.boilingpoint = boilingpoint;
	}

	public TestItemStatus getTestItemStatus() {
		return testItemStatus;
	}

	public void setTestItemStatus(TestItemStatus testItemStatus) {
		this.testItemStatus = testItemStatus;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

}
