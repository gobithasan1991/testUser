package com.anthem.glp.persistence.model.study;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.anthem.persistence.model.admin.Branch;
import com.anthem.persistence.model.common.Default;
import com.anthem.persistence.model.user.User;
import com.anthem.util.common.StudyStatus;

@Entity
public class StudyNumber extends Default {

	/**
	 * 
	 */
	private static final long serialVersionUID = -644557514066396849L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne(fetch = FetchType.LAZY)
	private TestItemReceipt testItemReceipt;
	private String studyCategory;
	private String studyNumber;

	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "ENUM('PENDING', 'DIRECTOR_ALLOCATED', 'PERSONNEL_ALLOCATED','PERSONNEL_APPROVED','PERSONNEL_REJECTED',"
			+ "'PROTOCOL_UPLOADED','PROTOCOL_REVIEWED','PROTOCOL_REVIEW_REJECTED','PROTOCOL_APPROVED','PROTOCOL_APPROVE_REJECTED',"
			+ "'PLAN_UPLOADED','PLAN_PARTIALLY_REVIEWED','PLAN_REVIEWED','PLAN_REVIEW_REJECTED','PLAN_PARTIALLY_APPROVED','PLAN_APPROVED','PLAN_APPROVE_REJECTED') DEFAULT 'PENDING'", insertable = false)
	private StudyStatus studyStatus;

	private String allotmentNumber;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private User allottedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date allottedDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Branch branch;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TestItemReceipt getTestItemReceipt() {
		return testItemReceipt;
	}

	public void setTestItemReceipt(TestItemReceipt testItemReceipt) {
		this.testItemReceipt = testItemReceipt;
	}

	public String getStudyCategory() {
		return studyCategory;
	}

	public void setStudyCategory(String studyCategory) {
		this.studyCategory = studyCategory;
	}

	public String getStudyNumber() {
		return studyNumber;
	}

	public void setStudyNumber(String studyNumber) {
		this.studyNumber = studyNumber;
	}

	public StudyStatus getStudyStatus() {
		return studyStatus;
	}

	public void setStudyStatus(StudyStatus studyStatus) {
		this.studyStatus = studyStatus;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public String getAllotmentNumber() {
		return allotmentNumber;
	}

	public void setAllotmentNumber(String allotmentNumber) {
		this.allotmentNumber = allotmentNumber;
	}

	public User getAllottedBy() {
		return allottedBy;
	}

	public void setAllottedBy(User allottedBy) {
		this.allottedBy = allottedBy;
	}

	public Date getAllottedDate() {
		return allottedDate;
	}

	public void setAllottedDate(Date allottedDate) {
		this.allottedDate = allottedDate;
	}

}
