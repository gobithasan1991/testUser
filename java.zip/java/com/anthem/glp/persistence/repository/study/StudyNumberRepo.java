package com.anthem.glp.persistence.repository.study;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.StudyNumber;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.persistence.model.admin.Branch;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.StudyStatus;
import com.anthem.web.service.common.dto.IdCodeName;

public interface StudyNumberRepo extends JpaRepository<StudyNumber, Long> {

	@Query("select COUNT(s) from StudyNumber s where s.studyCategory =:studyCategory AND s.enabledStatus=:enabledStatus")
	public int getLastStudyNumber(@Param("studyCategory") String studyCategory,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyNumber s where s.studyStatus =:studyStatus AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getAllStudyNumbers(@Param("studyStatus") StudyStatus studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyNumber s where s.id =:studyNumberId AND s.enabledStatus=:enabledStatus")
	public StudyNumberDTO getStudyNumberDetailsById(@Param("studyNumberId") Long studyNumberId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Transactional
	@Modifying
	@Query(value = "UPDATE StudyNumber sn SET sn.studyStatus =:studyStatus WHERE sn.id =:studyNumberId")
	public void updateStudyStatus(@Param("studyNumberId") Long studyNumberId,
			@Param("studyStatus") StudyStatus studyStatus);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) FROM StudyNumber s JOIN s.testItemReceipt t WHERE  s.createdDate BETWEEN :fromDate AND :toDate AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getAllStudyNumberDetailsByDate(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) FROM StudyNumber s JOIN s.testItemReceipt t WHERE s.branch IN (:branches) AND t.sponsorName.id =:sponsorId AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getStudyNumberDetailsBySponsorId(@Param("branches") List<Branch> branches,
			@Param("sponsorId") Long sponsorId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) FROM StudyNumber s  WHERE s.branch IN (:branches) AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getStudyNumberDetailsByAll(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("branches") List<Branch> branches, Pageable pageable);

	@Query("SELECT s FROM StudyNumber s JOIN s.branch sb WHERE (s.allottedDate BETWEEN :fromDate AND :toDate) "
			+ "AND sb.id=:branchId AND s.studyStatus NOT IN (:studyStatus) AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumber> getStudyAllotmentLetter(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("studyStatus") List<StudyStatus> studyStatus, Pageable pageable);

	@Query("SELECT s FROM StudyNumber s JOIN s.branch sb WHERE sb.id=:branchId AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumber> getStudyAllotmentLetterTable(@Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyNumber s where s.studyStatus IN(:studyStatus) AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getStudyNumbersForProtocol(@Param("studyStatus") List<StudyStatus> studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pagable);

	//@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyNumber s,StudyProtocol sp JOIN sp.studyNumber sps where s.id = sps.id AND s.studyStatus IN(:studyStatus) AND s.enabledStatus=:enabledStatus AND sp.enabledStatus=:enabledStatus")
	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyNumber s where s.studyStatus IN(:studyStatus) AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getStudyNumbersForPlan(@Param("studyStatus") List<StudyStatus> studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pagable);

	@Query("SELECT Count(s) FROM StudyNumber s WHERE s.studyStatus=:studyStatus AND s.enabledStatus=:enabledStatus")
	public Integer getStudyNumberCountByStatus(@Param("studyStatus") StudyStatus studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT Count(s) FROM StudyNumber s WHERE s.enabledStatus=:enabledStatus AND s.studyStatus NOT IN(:studyStatus)")
	public Integer getStudyNumberCountByAllAndNotInStatus(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("studyStatus") StudyStatus studyStatus);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) FROM StudyNumber s WHERE s.enabledStatus=:enabledStatus AND s.studyStatus IN(:studyStatus)")
	public Page<StudyNumberDTO> getStudyNumbersByStatus(@Param("studyStatus") StudyStatus studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) FROM StudyNumber s WHERE s.enabledStatus=:enabledStatus AND s.studyStatus NOT IN(:studyStatus)")
	public Page<StudyNumberDTO> getStudyNumberByNotINStatus(@Param("studyStatus") StudyStatus studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.web.service.common.dto.IdCodeName(s.id, s.studyNumber) FROM StudyNumber s WHERE s.enabledStatus=:enabledStatus")
	public List<IdCodeName> getStudyNumbersICN(@Param("enabledStatus") EnabledStatus enabledStatus);
	
}
