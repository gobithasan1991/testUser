package com.anthem.glp.persistence.repository.study;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.StudyPlan;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.StudyStatus;

public interface StudyPlanRepo extends JpaRepository<StudyPlan, Long> {

	@Query("select sp from StudyPlan sp where sp.studyNumber.id =:studyId AND sp.enabledStatus=:enabledStatus")
	public StudyPlan getStudyPlanByStudyId(@Param("studyId") Long studyId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select sp from StudyPlan sp where sp.id =:planId AND sp.enabledStatus=:enabledStatus")
	public StudyPlan getStudyPlanById(@Param("planId") Long planId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyPlan plan JOIN plan.studyNumber s JOIN plan.createdBy user  where user.id =:userId AND s.studyStatus IN(:studyStatus) AND plan.enabledStatus=:enabledStatus AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getStudyNumbersForPlanModify(@Param("userId") Long userId, @Param("studyStatus") List<StudyStatus> studyStatus, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pagable);

}
