package com.anthem.glp.persistence.repository.study;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.study.StudyPersonnel;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface StudyPersonnelRepo extends JpaRepository<StudyPersonnel, Long> {

	@Query(value = "SELECT SP FROM StudyPersonnel SP JOIN SP.studyNumber SPS WHERE SPS.id=:studyId AND SP.enabledStatus=:enabledStatus")
	public List<StudyPersonnel> findAllPersonnelByStudy(@Param("studyId") Long studyId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT SP FROM StudyPersonnel SP JOIN SP.person SPU WHERE SPU.id=:personId AND SP.enabledStatus=:enabledStatus AND SP.approveStatus=:approveStatus")
	public List<StudyPersonnel> findAllPersonnelByPersonId(@Param("personId") Long personId, @Param("enabledStatus") EnabledStatus enabledStatus, @Param("approveStatus") ApproveStatus approveStatus);
}
