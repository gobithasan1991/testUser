package com.anthem.glp.persistence.repository.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.study.FolderCreationRequest;
import com.anthem.glp.web.service.study.dto.FolderCreationRequestDTO;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.FolderCreationStatus;

@Repository
public interface FolderCreationRequestRepo extends JpaRepository<FolderCreationRequest, Long> {

	@Query("SELECT new com.anthem.glp.web.service.study.dto.FolderCreationRequestDTO(f)  FROM FolderCreationRequest f WHERE f.folderCreationStatus=:folderCreationStatus AND f.enabledStatus=:enabledStatus")
	public Page<FolderCreationRequestDTO> getFolderCreationRequestByFolderCreationStatus(
			@Param("folderCreationStatus") FolderCreationStatus folderCreationStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT f  FROM FolderCreationRequest f WHERE f.id=:folderCreationId AND f.enabledStatus=:enabledStatus")
	public FolderCreationRequest getFolderCreationRequestById(@Param("folderCreationId") Long folderCreationId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT f FROM FolderCreationRequest f WHERE f.id=:folderCreationId")
	public FolderCreationRequest getFolderCreationRequestById(@Param("folderCreationId") Long folderCreationId);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.FolderCreationRequestDTO(f)  FROM FolderCreationRequest f WHERE f.enabledStatus=:enabledStatus")
	public Page<FolderCreationRequestDTO> getFolderCreationRequestByAll(
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pagable);

}
