package com.anthem.glp.persistence.repository.study;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.StudyPlanReviewApproveMapping;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.persistence.status.CustomStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.StudyStatus;

public interface StudyPlanReviewApproveMappingRepo extends JpaRepository<StudyPlanReviewApproveMapping, Long> {

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyPlanReviewApproveMapping mapping JOIN mapping.user user JOIN mapping.studyPlan plan JOIN plan.studyNumber s where user.id =:userId AND mapping.reviewType =:reviewType AND mapping.mappingStatus=:mappedStatus AND s.studyStatus IN(:studyStatus) AND s.enabledStatus=:enabledStatus")
	public Page<StudyNumberDTO> getStudyNumbersForMappedUsers(@Param("userId") Long userId,
			@Param("reviewType") String reviewType, @Param("studyStatus") List<StudyStatus> studyStatus,
			@Param("mappedStatus") CustomStatus mappedStatus, @Param("enabledStatus") EnabledStatus enabledStatus,
			Pageable pagable);

	@Query("select mapping from StudyPlanReviewApproveMapping mapping JOIN mapping.studyPlan plan where plan.id =:planId AND mapping.rejected = FALSE AND mapping.enabledStatus=:enabledStatus AND plan.enabledStatus=:enabledStatus ORDER BY mapping.modifiedDate DESC")
	public List<StudyPlanReviewApproveMapping> getStudyPlanReviewApproveMappingByPlanId(@Param("planId") Long planId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select mapping from StudyPlanReviewApproveMapping mapping JOIN mapping.user user JOIN mapping.studyPlan plan where plan.id =:planId AND user.id =:userId AND mapping.reviewType =:reviewType AND mapping.rejected = FALSE AND mapping.enabledStatus=:enabledStatus AND plan.enabledStatus=:enabledStatus")
	public StudyPlanReviewApproveMapping getReviewApproverByUserAndPlandId(@Param("planId") Long planId,
			@Param("reviewType") String reviewType, @Param("userId") Long userId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(mapping) from StudyPlanReviewApproveMapping mapping JOIN mapping.studyPlan plan where plan.id =:planId AND mapping.reviewType =:reviewType AND mapping.mappingStatus=:mappedStatus AND mapping.rejected = FALSE AND mapping.enabledStatus=:enabledStatus AND plan.enabledStatus=:enabledStatus")
	public int getReviewedCounts(@Param("planId") Long planId, @Param("reviewType") String reviewType, @Param("mappedStatus") CustomStatus mappedStatus, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select count(mapping) from StudyPlanReviewApproveMapping mapping JOIN mapping.studyPlan plan where plan.id =:planId AND mapping.reviewType =:reviewType AND mapping.rejected = FALSE AND mapping.enabledStatus=:enabledStatus AND plan.enabledStatus=:enabledStatus")
	public int getReviewerCounts(@Param("planId") Long planId, @Param("reviewType") String reviewType, @Param("enabledStatus") EnabledStatus enabledStatus);
	
}
