package com.anthem.glp.persistence.repository.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.TICO;
import com.anthem.glp.web.service.study.dto.TicoDTO;
import com.anthem.util.common.EnabledStatus;

public interface TicoRepo extends JpaRepository<TICO, Long> {

	@Query("select new com.anthem.glp.web.service.study.dto.TicoDTO(tico) from TICO tico where tico.enabledStatus=:enabledStatus")
	public Page<TicoDTO> getAllTico(@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("select new com.anthem.glp.web.service.study.dto.TicoDTO(tico) from TICO tico JOIN tico.testItemReceipt testItem where testItem.id =:testItemId AND tico.enabledStatus=:enabledStatus")
	public TicoDTO getTicoByTestItemReceipt(@Param("testItemId") Long testItemId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

}
