package com.anthem.glp.persistence.repository.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.StudyProtocolReviewApproveMapping;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.StudyStatus;

public interface StudyProtocolReviewApproveMappingRepo extends JpaRepository<StudyProtocolReviewApproveMapping, Long> {

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyProtocolReviewApproveMapping mapping JOIN mapping.user user JOIN mapping.studyProtocol protocol JOIN protocol.studyNumber s where user.id =:userId AND mapping.reviewType =:reviewType AND s.studyStatus =:studyStatus AND s.enabledStatus=:enabledStatus")
	Page<StudyNumberDTO> getStudyNumbersForMappedUsers(@Param("userId") Long userId,
			@Param("reviewType") String reviewType, @Param("studyStatus") StudyStatus studyStatus,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pagable);

}
