package com.anthem.glp.persistence.repository.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.StudyRequisition;
import com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;

public interface StudyRequisitionRepo extends JpaRepository<StudyRequisition, Long>{
	@Query(value = "SELECT COUNT(sr) FROM StudyRequisition sr WHERE sr.number LIKE :prefixLike%")
	public int findAvailableSeriesCount(@Param("prefixLike") String prefixLike);
	
	@Query(value="SELECT new com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO(s) from StudyRequisition s WHERE s.enabledStatus=:enabledStatus")
	public Page<StudyRequisitionReportDTO> getStudyRequisitionReportTable(@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
	
	@Query(value="SELECT new com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO(s) from StudyRequisition s WHERE s.enabledStatus=:enabledStatus AND s.approveStatus=:approveStatus")
	public Page<StudyRequisitionReportDTO> getStudyRequisitionByPendingStatus(@Param("enabledStatus") EnabledStatus enabledStatus, @Param("approveStatus") ApproveStatus approveStatus, Pageable pageable);
	
	@Query(value="SELECT new com.anthem.glp.web.service.study.dto.StudyRequisitionReportDTO(s) from StudyRequisition s WHERE s.id =:requisitionId AND s.enabledStatus=:enabledStatus")
	public StudyRequisitionReportDTO getStudyRequisitionDetails(@Param("enabledStatus") EnabledStatus enabledStatus, @Param("requisitionId") Long requisitionId);
}
