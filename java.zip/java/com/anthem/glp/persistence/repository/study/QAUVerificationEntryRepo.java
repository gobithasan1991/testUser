package com.anthem.glp.persistence.repository.study;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.study.QAUVerificationRequest;
import com.anthem.glp.web.service.study.dto.QAUVerificationRequestDTO;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface QAUVerificationEntryRepo extends JpaRepository<QAUVerificationRequest, Long> {

	@Query("SELECT new com.anthem.glp.web.service.study.dto.QAUVerificationRequestDTO(f)  FROM QAUVerificationRequest f WHERE f.enabledStatus=:enabledStatus")
	public Page<QAUVerificationRequestDTO> getQAUVerificationEntryDetailsByAll(
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pagable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.QAUVerificationRequestDTO(f)  FROM QAUVerificationRequest f WHERE f.id=:id")
	public QAUVerificationRequestDTO getQAUVerificationEntryDetailsById(@Param("id") Long id);

}
