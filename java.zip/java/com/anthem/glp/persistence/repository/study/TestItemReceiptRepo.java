package com.anthem.glp.persistence.repository.study;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.TestItemReceipt;
import com.anthem.glp.web.service.study.dto.TestItemReceiptDTO;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.TestItemStatus;

public interface TestItemReceiptRepo extends JpaRepository<TestItemReceipt, Long> {

	@Query("select new com.anthem.glp.web.service.study.dto.TestItemReceiptDTO(t) from TestItemReceipt t "
			+ "JOIN t.sponsorName s JOIN t.nominee n where t.enabledStatus=:enabledStatus AND t.testItemStatus=:testItemStatus")
	public Page<TestItemReceiptDTO> getAllTestItemReceipts(@Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("testItemStatus") TestItemStatus testItemStatus, Pageable pageable);

	@Query("select new com.anthem.glp.web.service.study.dto.TestItemReceiptDTO(t) from TestItemReceipt t JOIN t.sponsorName s JOIN t.nominee n "
			+ "JOIN t.packageType JOIN t.storageCondition JOIN t.batchProducedBy "
			+ "JOIN t.grossWeightUom JOIN t.tareWeightUom JOIN t.totalQtyUom "
			+ "JOIN  t.sponsorRepresentative where t.id =:testItemId AND t.enabledStatus=:enabledStatus")
	public TestItemReceiptDTO getTestItemReceiptDtoById(@Param("testItemId") Long testItemId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select t from TestItemReceipt t JOIN FETCH t.sponsorName s JOIN FETCH t.nominee n "
			+ "JOIN FETCH t.packageType JOIN FETCH t.storageCondition JOIN FETCH t.batchProducedBy "
			+ "JOIN FETCH t.grossWeightUom JOIN FETCH t.tareWeightUom JOIN FETCH t.totalQtyUom "
			+ "JOIN FETCH t.sponsorRepresentative where t.id =:testItemId AND t.enabledStatus=:enabledStatus")
	public TestItemReceipt getTestItemDetailsById(@Param("testItemId") Long testItemId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Transactional
	@Modifying
	@Query(value = "UPDATE TestItemReceipt tir SET tir.testItemStatus =:testItemStatus WHERE tir.id =:testItemId")
	public void updateStudyNumberStatus(@Param("testItemId") Long testItemId,
			@Param("testItemStatus") TestItemStatus testItemStatus);

	// Test Item Report By Type
	@Query("SELECT new com.anthem.glp.web.service.study.dto.TestItemReceiptDTO(t) from TestItemReceipt t WHERE t.chemicalName LIKE %:value% AND t.enabledStatus=:enabledStatus")
	public Page<TestItemReceiptDTO> getTestItemReceiptByChemicalName(@Param("value") String value,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.TestItemReceiptDTO(t) from TestItemReceipt t JOIN t.nominee n WHERE n.name LIKE %:value% AND t.enabledStatus=:enabledStatus")
	public Page<TestItemReceiptDTO> getTestItemReceiptByNominee(@Param("value") String value,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.TestItemReceiptDTO(t) from TestItemReceipt t JOIN t.sponsorName s WHERE s.name LIKE %:value% AND t.enabledStatus=:enabledStatus")
	public Page<TestItemReceiptDTO> getTestItemReceiptBySponsor(@Param("value") String value,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query("SELECT new com.anthem.glp.web.service.study.dto.TestItemReceiptDTO(t) from TestItemReceipt t WHERE t.itemValue LIKE %:value% AND t.enabledStatus=:enabledStatus")
	public Page<TestItemReceiptDTO> getTestItemReceiptByTest(@Param("value") String value,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);
}
