package com.anthem.glp.persistence.repository.study;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anthem.glp.persistence.model.study.StudyPlanDocumentVersion;

public interface StudyPlanDocumentVersionRepo extends JpaRepository<StudyPlanDocumentVersion, Long> {

}
