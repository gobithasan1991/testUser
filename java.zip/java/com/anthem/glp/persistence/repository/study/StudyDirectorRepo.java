package com.anthem.glp.persistence.repository.study;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.study.StudyDirector;
import com.anthem.glp.web.service.study.dto.StudyNumberDTO;
import com.anthem.util.common.ApproveStatus;
import com.anthem.util.common.EnabledStatus;
import com.anthem.util.common.StudyStatus;

@Repository
public interface StudyDirectorRepo extends JpaRepository<StudyDirector, Long> {

	@Query(value = "SELECT STDR FROM StudyDirector STDR JOIN STDR.studyNumber STDN WHERE STDN.id=:studyId AND STDR.enabledStatus=:enabledStatus")
	public List<StudyDirector> findAllStudyDirectorsByStudyId(@Param("studyId") Long studyId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT STDR FROM StudyDirector STDR JOIN STDR.director STDU JOIN STDU.director STDUD WHERE STDUD.id=:directorId AND STDR.enabledStatus=:enabledStatus AND STDR.approveStatus=:approveStatus")
	public List<StudyDirector> findAllStudyDirectorsByDirectorId(@Param("directorId") Long directorId,
			@Param("enabledStatus") EnabledStatus enabledStatus, @Param("approveStatus") ApproveStatus approveStatus);

	@Query("select new com.anthem.glp.web.service.study.dto.StudyNumberDTO(s) from StudyDirector sd JOIN sd.studyNumber s JOIN s.branch sb JOIN sd.director sdd JOIN sdd.director sdu "
			+ "where sdu.id=:userId AND sd.approveStatus = 'APPROVED' AND s.studyStatus IN(:studyStatus) "
			+ "AND s.enabledStatus=:enabledStatus AND sb.id=:branchId")
	public Page<StudyNumberDTO> getStudyNumbersForPersonnel(@Param("userId") Long userId,
			@Param("studyStatus") List<StudyStatus> studyStatus, @Param("enabledStatus") EnabledStatus enabledStatus,
			@Param("branchId") Long branchId, Pageable pagable);
}
