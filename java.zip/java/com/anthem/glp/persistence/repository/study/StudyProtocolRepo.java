package com.anthem.glp.persistence.repository.study;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.study.StudyProtocol;
import com.anthem.util.common.EnabledStatus;

public interface StudyProtocolRepo extends JpaRepository<StudyProtocol, Long> {

	@Query("select sp from StudyProtocol sp where sp.id =:studyProtocolId AND sp.enabledStatus=:enabledStatus")
	StudyProtocol getStudyProtocolById(@Param("studyProtocolId") Long studyProtocolId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("select sp from StudyProtocol sp where sp.studyNumber.id =:studyNumberId AND sp.enabledStatus=:enabledStatus")
	StudyProtocol getStudyProtocolByStudyNumberId(@Param("studyNumberId") Long studyNumberId,
			@Param("enabledStatus") EnabledStatus enabledStatus);

}
