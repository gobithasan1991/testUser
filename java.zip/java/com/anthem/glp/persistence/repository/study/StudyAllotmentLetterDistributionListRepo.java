package com.anthem.glp.persistence.repository.study;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.study.StudyAllotmentLetterDistributionList;
import com.anthem.glp.web.service.study.dto.StudyAllotmentLetterDistributionListDTO;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface StudyAllotmentLetterDistributionListRepo extends JpaRepository<StudyAllotmentLetterDistributionList, Long>{
	@Query("SELECT new com.anthem.glp.web.service.study.dto.StudyAllotmentLetterDistributionListDTO(s) from StudyAllotmentLetterDistributionList s WHERE s.studyNumber.id=:studyId AND s.enabledStatus=:enabledStatus")
	public List<StudyAllotmentLetterDistributionListDTO> getByStudyNumber(@Param("studyId") Long studyId, @Param("enabledStatus") EnabledStatus enabledStatus);
}