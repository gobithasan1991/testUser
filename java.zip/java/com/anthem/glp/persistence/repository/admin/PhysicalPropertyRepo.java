package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.PhysicalProperty;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface PhysicalPropertyRepo extends JpaRepository<PhysicalProperty, Long> {
	@Query(value = "SELECT PP FROM PhysicalProperty PP WHERE PP.enabledStatus=:enabledStatus ORDER BY PP.name")
	public List<PhysicalProperty> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
}
