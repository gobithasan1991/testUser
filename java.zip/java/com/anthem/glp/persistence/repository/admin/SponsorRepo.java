package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.Sponsor;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface SponsorRepo extends JpaRepository<Sponsor, Long> {

	@Query(value = "SELECT S FROM Sponsor S WHERE S.enabledStatus=:enabledStatus ORDER By S.name")
	public List<Sponsor> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);

}
