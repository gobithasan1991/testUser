package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.StorageCondition;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface StorageConditionRepo extends JpaRepository<StorageCondition, Long> {

	@Query(value = "SELECT SC FROM StorageCondition SC WHERE SC.enabledStatus=:enabledStatus ORDER BY SC.name")
	public List<StorageCondition> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);
}
