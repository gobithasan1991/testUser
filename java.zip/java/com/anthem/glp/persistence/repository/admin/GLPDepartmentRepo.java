package com.anthem.glp.persistence.repository.admin;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.anthem.glp.persistence.model.admin.GLPDepartment;
import com.anthem.persistence.model.admin.Department;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface GLPDepartmentRepo extends JpaRepository<GLPDepartment, Long> {
	@Query("select new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.code,q.name) from GLPDepartment q where q.enabledStatus=:enabledStatus ORDER BY q.name")
	List<IdNameCodeDTO> findAllQDeptIsEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);

	@Transactional
	@Query("select qd from GLPDepartment qd where qd.enabled=?1 ")
	Page<GLPDepartment> getGLPDepartmentWithPageableData(Boolean true1, Pageable pageable);

	List<GLPDepartment> findByDepartment(Department department);

	GLPDepartment findByName(String deptName);

	@Query(value = "SELECT q.id FROM GLPDepartment q WHERE q.enabled=true")
	Set<Long> finAllQmsDepartmentId();

	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.name) FROM GLPDepartment q WHERE q.id IN(:glpDepartmentIds) AND q.enabledStatus=:enabledStatus ORDER BY q.name")
	public Set<IdNameCodeDTO> findQmsDepartmentByIds(@Param("glpDepartmentIds") Set<Long> glpDepartmentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query("SELECT q FROM GLPDepartment q WHERE q.id NOT IN(:glpDepartmentIds) AND q.enabled=:enabledStatus ORDER BY q.name")
	public List<GLPDepartment> findQmsDepartmentByNotInIds(@Param("glpDepartmentIds") List<Long> glpDepartmentIds,
			@Param("enabledStatus") Boolean enabledStatus);

	@Query(value = "SELECT q.id FROM GLPDepartment q WHERE q.enabledStatus=:enabledStatus")
	public Set<Long> findAllQmsDepartmentIds(@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.name) FROM GLPDepartment q WHERE q.id NOT IN(:glpDepartmentIds) AND q.enabledStatus=:enabledStatus ORDER BY q.name")
	public List<IdNameCodeDTO> findQmsDepartmentByQmsDepartmentNotIn(
			@Param("glpDepartmentIds") List<Long> glpDepartmentIds,
			@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT d.id FROM GLPDepartment q JOIN q.department d WHERE q.id=:glpDepartmentId AND q.enabledStatus =:enabledStatus")
	public Long findDepartmentIdByQmsDepartmentId(@Param("glpDepartmentId") Long glpDepartmentId,
			@Param("enabledStatus") EnabledStatus enabledStatus);
}
