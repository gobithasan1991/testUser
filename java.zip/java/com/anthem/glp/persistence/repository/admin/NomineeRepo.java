package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.Nominee;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface NomineeRepo extends JpaRepository<Nominee, Long> {

	@Query(value = "SELECT N FROM Nominee N JOIN N.sponsor S WHERE S.id =:sponsorId AND N.enabledStatus=:enabledStatus ORDER BY N.name ")
	public List<Nominee> findAllEnabledBySponsor(@Param("sponsorId") Long sponsorId,
			@Param("enabledStatus") EnabledStatus enabledStatus);
}
