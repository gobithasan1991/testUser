package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.glp.persistence.model.admin.GLPDesignation;
import com.anthem.util.common.EnabledStatus;
import com.anthem.web.service.common.dto.IdNameCodeDTO;

public interface GLPDesignationRepo extends JpaRepository<GLPDesignation, Long> {
	@Query("select new com.anthem.web.service.common.dto.IdNameCodeDTO(q.id,q.code,q.name) from GLPDesignation q where q.enabledStatus=:enabledStatus ORDER BY q.name")
	List<IdNameCodeDTO> findAllGLPDesignations(@Param("enabledStatus") EnabledStatus enabledStatus);
}
