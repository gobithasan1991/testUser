package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.GLPDocumentTemplate;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface GLPDocumentTemplateRepo extends JpaRepository<GLPDocumentTemplate, Long> {

	@Query(value = "SELECT glpdoc FROM GLPDocumentTemplate glpdoc WHERE glpdoc.enabledStatus=:enabledStatus ORDER BY glpdoc.name")
	List<GLPDocumentTemplate> getAllGlpDocumentTemplates(@Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT glpdoc FROM GLPDocumentTemplate glpdoc WHERE glpdoc.id =:id AND glpdoc.enabledStatus=:enabledStatus")
	GLPDocumentTemplate getGlpDocumentTemplateById(@Param("id") Long id, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT glpdoc FROM GLPDocumentTemplate glpdoc WHERE glpdoc.templateCategory=:tempCategory AND glpdoc.enabledStatus=:enabledStatus ORDER BY glpdoc.name")
	List<GLPDocumentTemplate> getGlpDocumentTemplatesByCategory(@Param("tempCategory") String tempCategory, @Param("enabledStatus") EnabledStatus enabledStatus);

}
