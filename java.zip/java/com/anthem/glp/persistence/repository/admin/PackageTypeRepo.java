package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.PackageType;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface PackageTypeRepo extends JpaRepository<PackageType, Long> {

	@Query(value = "SELECT PT FROM PackageType PT WHERE PT.enabledStatus=:enabledStatus ORDER BY PT.name")
	public List<PackageType> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);

}
