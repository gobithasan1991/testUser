package com.anthem.glp.persistence.repository.admin;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.DirectorMaster;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface DirectorMasterRepo extends JpaRepository<DirectorMaster, Long> {
	@Query(value = "SELECT dm FROM DirectorMaster dm JOIN dm.director dmu JOIN dm.glpDepartment dmud JOIN dm.branch dmb WHERE dmud.id=:departmentId AND dmb.id=:branchId AND dm.enabledStatus=:enabledStatus ORDER BY dmu.fullName")
	public List<DirectorMaster> findAllByDepartmentAndBranch(@Param("departmentId") Long departmentId,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DirectorMaster dm JOIN dm.director dmu JOIN dm.glpDepartment dmud JOIN dm.branch dmb WHERE dmud.id=:departmentId AND dm.createdDate BETWEEN :fromDate AND :toDate AND dmb.id=:branchId AND dm.enabledStatus=:enabledStatus ORDER BY dmu.fullName ")
	public Page<DirectorMaster> findAllByDepartmentAndCreatedDate(@Param("departmentId") Long departmentId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT dm FROM DirectorMaster dm JOIN dm.branch dmb WHERE dm.createdDate BETWEEN :fromDate AND :toDate AND dmb.id=:branchId AND dm.enabledStatus=:enabledStatus")
	public Page<DirectorMaster> findAllByCreatedDate(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus, Pageable pageable);

	@Query(value = "SELECT dm FROM DirectorMaster dm JOIN dm.director dmu JOIN dm.glpDepartment  dmud JOIN dm.branch dmb WHERE dmud.id=:departmentId"
			+ " AND dm.createdDate BETWEEN :fromDate AND :toDate AND dmb.id=:branchId AND dm.enabledStatus=:enabledStatus ORDER BY dmu.fullName ")
	public List<DirectorMaster> fetchAllDirectorsByDepartmentAndCreatedDateForPDF(
			@Param("departmentId") Long departmentId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("branchId") Long branchId, @Param("enabledStatus") EnabledStatus enabledStatus);

	@Query(value = "SELECT dm FROM DirectorMaster dm JOIN dm.branch dmb WHERE dm.createdDate BETWEEN :fromDate AND :toDate AND dmb.id=:branchId AND dm.enabledStatus=:enabledStatus")
	public List<DirectorMaster> findAllByCreatedDateForPDF(@Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("branchId") Long branchId,
			@Param("enabledStatus") EnabledStatus enabledStatus);
}
