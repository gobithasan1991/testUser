package com.anthem.glp.persistence.repository.admin;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.glp.persistence.model.admin.Transportation;
import com.anthem.util.common.EnabledStatus;

@Repository
public interface TransportationRepo extends JpaRepository<Transportation, Long> {

	@Query(value = "SELECT T FROM Transportation T WHERE T.enabledStatus=:enabledStatus ORDER BY T.name")
	public List<Transportation> findAllEnabled(@Param("enabledStatus") EnabledStatus enabledStatus);

}
