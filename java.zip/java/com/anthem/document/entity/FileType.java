package com.anthem.document.entity;

public enum FileType {
    Text,
    Spreadsheet,
    Presentation
}