/**
 * 
 */
package com.anthem.document.entity;

/**
 * @author kalaiselvan.a
 *
 */
public class VersionDocumentWithDetails {
	private String id;
	//private MultipartFile file;
	private String file;
	private String userId;
	private String noOfPages;
	private String docCap;
	private String user;
	private String documentType;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
//	public MultipartFile getFile() {
//		return file;
//	}
//	public void setFile(MultipartFile file) {
//		this.file = file;
//	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNoOfPages() {
		return noOfPages;
	}
	public void setNoOfPages(String noOfPages) {
		this.noOfPages = noOfPages;
	}
	public String getDocCap() {
		return docCap;
	}
	public void setDocCap(String docCap) {
		this.docCap = docCap;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}	
}
