package com.anthem.document.helpers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.anthem.document.entity.FileType;
import com.anthem.persistence.model.document.Document;

@SuppressWarnings({ "unchecked", "unused" })
public class DocumentManager {

	private static HttpServletRequest request;
	private static HttpServletResponse response;

	public static boolean ExistsSync(String path) {
		boolean res = true;
		try {
			File file = new File(path);
			if (!file.exists()) {
				res = false;
			}
		} catch (Exception e) {
			res = false;
		}
		return res;
	}

	public static void CreateDirectory(String path) {
		if (!DocumentManager.ExistsSync(path)) {
			File f = new File(path);
			f.mkdir();
		}
	}

	public static void Init(HttpServletRequest req, HttpServletResponse resp) {
		request = req;
		response = resp;
	}

	public static String getLang() {
		if (null != request.getParameter("lang")) {
			return request.getParameter("lang");
		} else {
			return "en";
		}
	}

	public static String getCustomParams() {
		String params = "", userid = "", name = "", lang = "", fileName = "", mode = "", type = "";
		try {
			userid = request.getParameter("userid");
			if (userid != null) {
				params += "&userid=" + userid;
			}
			name = request.getParameter("name");
			if (name != null) {
				params += "&name=" + name;
			}
			lang = request.getParameter("lang");
			if (lang != null) {
				params += "&lang=" + lang;
			}
			fileName = request.getParameter("fileName");
			if (fileName != null) {
				params += "&fileName=" + fileName;
			}
			mode = request.getParameter("mode");
			if (mode != null) {
				params += "&mode=" + mode;
			}
			type = request.getParameter("type");
			if (type != null) {
				params += "&type=" + type;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return params;
	}

	public static String GetCorrectName(String fileName) {
		String baseName = FileUtility.GetFileNameWithoutExtension(fileName);
		String ext = FileUtility.GetFileExtension(fileName);
		String name = baseName + ext;
		File file = new File(StoragePath(name, null));
		for (int i = 1; file.exists(); i++) {
			name = baseName + " (" + i + ")" + ext;
			file = new File(StoragePath(name, null));
		}
		return name;
	}

	public static String CreateDemo(String fileExt, String userid, String username) {
		String demoName = "sample." + fileExt;
		String fileName = System.currentTimeMillis() + "." + fileExt;
		try {
			InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(demoName);
			File file = new File(StoragePath(fileName, null));
			try (FileOutputStream out = new FileOutputStream(file)) {
				int read;
				final byte[] bytes = new byte[1024];
				while ((read = stream.read(bytes)) != -1) {
					out.write(bytes, 0, read);
				}
				out.flush();
				out.close();
			}
			DocumentManager.SaveFileData(fileName, userid, username);
		} catch (Exception e) {

		}
		return fileName;
	}

	public static void SaveFileData(String fileName, String userid, String username) {
		String userAddress = "", date = "", file_info = "";
		userAddress = CurUserHostAddress(null);
		Path p = Paths.get(DocumentManager.StoragePath(fileName, userAddress));
		try {
			BasicFileAttributes view = Files.getFileAttributeView(p, BasicFileAttributeView.class).readAttributes();
			FileTime date_created = view.creationTime();
			SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
			date = df.format(date_created.toMillis());
			file_info = DocumentManager.HistoryPath(fileName, userAddress, true);
			DocumentManager.CreateDirectory(file_info);
			file_info += fileName + ".txt";
			Path path = Paths.get(file_info);
			List<String> lines = Arrays.asList(date.toString() + "," + userid + "," + username, "");
			Files.write(path, lines, Charset.forName("UTF-8"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String GetFileData(String fileName, String userAddress) {
		String history = DocumentManager.HistoryPath(fileName, userAddress, true) + fileName + ".txt";
		if (!DocumentManager.ExistsSync(history)) {
			StringBuilder sb = new StringBuilder();
			sb.append(new Date()).append(",");
			sb.append("1").append(",");
			sb.append("kalaiselvan.a");
			return sb.toString();
		}
		try {
			List<String> lines = Files.readAllLines(Paths.get(history));
			StringBuilder sb = new StringBuilder();
			for (String line : lines) {
				sb.append(line);
			}
			return sb.toString();
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}

	public static String GetFileUri(String fileName) throws Exception {
		/*
		 * try { String serverPath = request.getScheme() + "://" +
		 * request.getServerName() + ":" + request.getServerPort() +
		 * request.getContextPath(); String storagePath =
		 * ConfigManager.GetProperty("storage-folder"); String hostAddress =
		 * CurUserHostAddress(null);
		 * 
		 * String filePath = serverPath + "/" + storagePath + "/" + hostAddress + "/" +
		 * URLEncoder.encode(fileName,
		 * java.nio.charset.StandardCharsets.UTF_8.toString());
		 * 
		 * return filePath; } catch (UnsupportedEncodingException e) { throw new
		 * AssertionError("UTF-8 is unknown"); } catch (Exception ex) { throw ex; }
		 */
		return DocumentManager.GetLocalFileUri(fileName, 0, true);
	}

	public static String GetLocalFileUri(String fileName, int version, boolean forDocumentServer) throws Exception {
		String serverPath = "", storagePath = "", hostAddress = "", filePath = "";
		try {
			serverPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ request.getContextPath();
			storagePath = ConfigManager.GetProperty("storage-folder");
			hostAddress = DocumentManager.CurUserHostAddress(null);
			filePath = serverPath + "/" + storagePath + "/" + hostAddress + "/";
			if (fileName != null) {
				filePath += URLEncoder.encode(fileName, java.nio.charset.StandardCharsets.UTF_8.toString());
			}
			if (version == 0) {
				return filePath;
			}
			return filePath + "-history/" + version;

		} catch (UnsupportedEncodingException e) {
			throw new AssertionError("UTF-8 is unknown");
		} catch (Exception ex) {
			throw ex;
		}
	}

	public static String GetServerUrl() {
		return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
	}

	public static String GetCallback(String fileName) {
		String serverPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
				+ request.getContextPath();
		String hostAddress = CurUserHostAddress(null);
		try {
			String query = "?type=track&fileName="
					+ URLEncoder.encode(fileName, java.nio.charset.StandardCharsets.UTF_8.toString()) + "&userAddress="
					+ URLEncoder.encode(hostAddress, java.nio.charset.StandardCharsets.UTF_8.toString());

			return serverPath + "/IndexServlet" + query;
		} catch (UnsupportedEncodingException e) {
			throw new AssertionError("UTF-8 is unknown");
		}
	}
	public static String approveCallbackURL(String fileName,String module,Long fileRefId) {
		String serverPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
			String hostAddress = CurUserHostAddress(null);
			try {
				String query = "?type=track&fileName="
						+ URLEncoder.encode(fileName, java.nio.charset.StandardCharsets.UTF_8.toString()) + "&userAddress="
						+ URLEncoder.encode(hostAddress, java.nio.charset.StandardCharsets.UTF_8.toString())+ "&forType="
						+ URLEncoder.encode("approve", java.nio.charset.StandardCharsets.UTF_8.toString())+ "&module="
						+ URLEncoder.encode(module, java.nio.charset.StandardCharsets.UTF_8.toString())+ "&fileRefId="
						+ URLEncoder.encode(fileRefId+"", java.nio.charset.StandardCharsets.UTF_8.toString());
			
				return serverPath + "/IndexServlet" + query;
			} catch (UnsupportedEncodingException e) {
				throw new AssertionError("UTF-8 is unknown");
			}
	}
	public static String StoragePath(String fileName, String userAddress) {
		String serverPath = request.getSession().getServletContext().getRealPath("");
		String storagePath = ConfigManager.GetProperty("storage-folder");
		String hostAddress = CurUserHostAddress(userAddress);

		String directory = serverPath + "\\" + storagePath + "\\";
		File file = new File(directory);

		if (!file.exists()) {
			file.mkdir();
		}

		directory = directory + hostAddress + "\\";
		file = new File(directory);

		if (!file.exists()) {
			file.mkdir();
		}

		return directory + fileName;
	}

	public static String ForceSavePath(String fileName, String userAddress, boolean create) {
		String filePath = "";
		try {
			filePath = DocumentManager.StoragePath(fileName, userAddress);
			if (!DocumentManager.ExistsSync(filePath)) {
				return "";
			}
			filePath = DocumentManager.HistoryPath(fileName, userAddress, false);
			if (!create && !DocumentManager.ExistsSync(filePath)) {
				return "";
			}
			DocumentManager.CreateDirectory(filePath);
			filePath = filePath + fileName;
			if (!create && !DocumentManager.ExistsSync(filePath)) {
				return "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return filePath;
	}

	public static String HistoryPath(String fileName, String userAddress, boolean create) {
		String serverPath = "", storagePath = "", hostAddress = "", filePath = "";
		try {
			serverPath = request.getSession().getServletContext().getRealPath("");
			storagePath = ConfigManager.GetProperty("storage-folder");
			hostAddress = CurUserHostAddress(DocumentManager.CurUserHostAddress(null));
			filePath = serverPath + "\\" + storagePath + "\\";
			if (fileName != null) {
				File file = new File(filePath);
				// for checking storage path
				if (!file.exists()) {
					file.mkdir();
				}
				filePath = filePath + hostAddress + "\\";
				file = new File(filePath);
				// for checking host ip
				if (!file.exists()) {
					file.mkdir();
				}

				filePath = filePath + fileName + "-history" + "\\";
				file = new File(filePath);
				// for checking history
				if (!file.exists()) {
					file.mkdir();
				}
				if (!create && !DocumentManager.ExistsSync(filePath + "1" + "\\")) {
					return "";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return filePath;
	}

	public static String VersionPath(String fileName, String userAddress, int version) {
		String historyPath = DocumentManager.HistoryPath(fileName, userAddress, true);
		return historyPath + version;
	}

	public static String PrevFilePath(String fileName, String userAddress, int version) {
		return DocumentManager.VersionPath(fileName, userAddress, version) + "\\" + "prev"
				+ FileUtility.GetFileExtension(fileName);
	}

	public static String DiffPath(String fileName, String userAddress, int version) {
		return DocumentManager.VersionPath(fileName, userAddress, version) + "\\" + "diff.zip";
	}

	public static String ChangesPath(String fileName, String userAddress, int version) {
		return DocumentManager.VersionPath(fileName, userAddress, version) + "\\" + "changes.txt";
	}

	public static String KeyPath(String fileName, String userAddress, int version) {
		return DocumentManager.VersionPath(fileName, userAddress, version) + "\\" + "key.txt";
	}

	public static String ChangesUser(String fileName, String userAddress, String version) {
		return "";
	}

	public static void getProtocol() {

	}

	public static String CurUserHostAddress(String userAddress) {
		if (userAddress == null) {
			try {
				userAddress = InetAddress.getLocalHost().getHostAddress();
			} catch (Exception ex) {
				userAddress = "";
			}
		}

		return userAddress.replaceAll("[^0-9a-zA-Z.=]", "_");
	}

	public static String GetInternalExtension(FileType fileType) {
		if (fileType.equals(FileType.Text))
			return ".docx";

		if (fileType.equals(FileType.Spreadsheet))
			return ".xlsx";

		if (fileType.equals(FileType.Presentation))
			return ".pptx";

		return ".docx";
	}

	public static String Getkey(String fileName) {
		String userAddress = DocumentManager.CurUserHostAddress(null);
		String key = null;
		try {
			key = userAddress + DocumentManager.GetLocalFileUri(fileName, 0, true);
			String historyPath = DocumentManager.HistoryPath(fileName, userAddress, true);
			if (historyPath != "") {
				key += DocumentManager.CountVersion(historyPath);
			}
			BasicFileAttributes view = Files
					.getFileAttributeView(Paths.get(DocumentManager.StoragePath(fileName, userAddress)),
							BasicFileAttributeView.class)
					.readAttributes();
			FileTime date_created = view.creationTime();
			DateFormat df = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
			key += df.format(date_created.toMillis());
			return ServiceConverter.GenerateRevisionId(key);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public static long GetMaxFileSize() {
		long size;

		try {
			size = Long.parseLong(ConfigManager.GetProperty("filesize-max"));
		} catch (Exception ex) {
			size = 0;
		}

		return size > 0 ? size : 5 * 1024 * 1024;
	}

	public static List<String> GetFileExts() {
		List<String> res = new ArrayList<>();

		res.addAll(GetViewedExts());
		res.addAll(GetEditedExts());
		res.addAll(GetConvertExts());

		return res;
	}

	public static List<String> GetViewedExts() {
		String exts = ConfigManager.GetProperty("files.docservice.viewed-docs");
		return Arrays.asList(exts.split("\\|"));
	}

	public static List<String> GetEditedExts() {
		String exts = ConfigManager.GetProperty("files.docservice.edited-docs");
		return Arrays.asList(exts.split("\\|"));
	}

	public static List<String> GetConvertExts() {
		String exts = ConfigManager.GetProperty("files.docservice.convert-docs");
		return Arrays.asList(exts.split("\\|"));
	}

	public static int CountVersion(String directory) {
		int i = 0;
		while (DocumentManager.ExistsSync(directory + "\\" + (i + 1))) {
			i++;
		}
		return i;
	}

	public static JSONObject GetHistory(String fileName, JSONObject content, String keyVersion, int version) {
		boolean oldVersion = false;
		JSONObject contentJson = null;
		JSONObject res = new JSONObject();
		String userAddress = "", username = "", userid = "", created = "";
		JSONObject user = null;
		try {
			if (content != null && !content.isEmpty()) {
				if (content.containsKey("changes")) {
					JSONArray arr = (JSONArray) content.get("changes");
					contentJson = (JSONObject) arr.get(0);
				} else {
					contentJson = (JSONObject) content.get(0);
					oldVersion = true;
				}
			}
			userAddress = DocumentManager.CurUserHostAddress(null);
			if (!content.isEmpty()) {
				user = (JSONObject) contentJson.get("user");
				if (oldVersion) {
					username = (String) user.get("username");
					userid = (String) user.get("userid");
					created = (String) contentJson.get("date");
				} else {
					username = (String) user.get("name");
					userid = (String) user.get("id");
					created = (String) contentJson.get("created");
				}
			} else {
				String[] fileData = DocumentManager.GetFileData(fileName, userAddress).split(",");
				username = fileData[2];
				userid = fileData[1];
				created = fileData[0];
			}
			if (!content.isEmpty() && oldVersion) {
				res.put("changes", content);
			} else {
				if (content.containsKey("serverVersion")) {
					res.put("serverVersion", content.get("serverVersion"));
				}
				res.put("changes", content.get("changes"));
			}
			JSONObject temp = new JSONObject();
			temp.put("id", userid);
			temp.put("name", username);
			res.put("key", keyVersion);
			res.put("version", version);
			res.put("created", created);
			res.put("user", temp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;

	}

	public static JSONObject GetChanges(String changesFile) {
		JSONObject res = null;
		try {
			BufferedReader bf = new BufferedReader(new FileReader(changesFile));
			String json = bf.readLine().toString();
			res = (JSONObject) new JSONParser().parse(json);
			bf.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	public static void createDemo(String path, InputStream stream, String fileid, String userid, String username,
			boolean createHistory) {

		try {
			File file = new File(path);
			try (FileOutputStream out = new FileOutputStream(file)) {
				int read;
				final byte[] bytes = new byte[1024];
				while ((read = stream.read(bytes)) != -1) {
					out.write(bytes, 0, read);
				}
				out.flush();
				out.close();
				// stream.close();
			}
			if (createHistory) {
				DocumentManager.SaveFileData(fileid, userid, username);
			}
		} catch (Exception e) {

		}
	}

	public static InputStream GetTemplateFile(String fileName, String versionFileName) {

		InputStream stream = null;
		try {
			String serverPath = request.getSession().getServletContext().getRealPath("");
			String storagePath = ConfigManager.GetProperty("storage-folder");
			String hostAddress = CurUserHostAddress(null);
			String directory = serverPath + "\\" + storagePath + "\\" + hostAddress + "\\" + fileName
					+ "-approvedversion\\" + versionFileName;
			File f = new File(directory);
			stream = new FileInputStream(f);
		} catch (Exception e) {
			return null;
		}
		return stream;
	}
	
	
	public static InputStream GetGLPTemplateFile(String fileName) {

		InputStream stream = null;
		try {
			String serverPath = request.getSession().getServletContext().getRealPath("");
			String storagePath = ConfigManager.GetProperty("storage-folder");
			String hostAddress = CurUserHostAddress(null);
			String directory = serverPath + "\\" + storagePath + "\\" + hostAddress + "\\" + fileName;
			File f = new File(directory);
			stream = new FileInputStream(f);
		} catch (Exception e) {
			return null;
		}
		return stream;
	}

	public static String GetApprovedVersionPath(String fileName, String userAddress) {

		String path = DocumentManager.StoragePath(fileName, userAddress);
		path = path + "-approvedversion";
		File f = new File(path);
		if (!f.exists()) {
			f.mkdir();
		}
		return path;
	}

	public static String GetUploadFileUri(String fileName) {
		String serverPath = "", storagePath = "", hostAddress = "", filePath = "";
		try {
			serverPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ request.getContextPath();
			storagePath = ConfigManager.GetProperty("storage-folder");
			hostAddress = DocumentManager.CurUserHostAddress(null);
			filePath = serverPath + "/" + storagePath + "/" + hostAddress + "/";
			if (fileName != null) {
				filePath += URLEncoder.encode(fileName, java.nio.charset.StandardCharsets.UTF_8.toString());
				filePath = filePath + "-upload";
				filePath = filePath + "/" + fileName;
			} else {
				return "";
			}
			return filePath;

		} catch (UnsupportedEncodingException e) {
			throw new AssertionError("UTF-8 is unknown");
		} catch (Exception ex) {
			throw ex;
		}
	}

	public static void RemoveUploadFileUri(String fileName) {

		String serverPath = "", storagePath = "", hostAddress = "", filePath = "", folderpath = "";
		try {
			serverPath = request.getSession().getServletContext().getRealPath("");
			storagePath = ConfigManager.GetProperty("storage-folder");
			hostAddress = CurUserHostAddress(DocumentManager.CurUserHostAddress(null));
			folderpath = serverPath + "\\" + storagePath + "\\" + hostAddress + "\\" + fileName + "-upload";
			filePath = folderpath + "\\" + fileName;
			File f = new File(filePath);
			if (f.exists()) {
				f.delete();
			}
			f = new File(folderpath);
			if (f.exists()) {
				f.delete();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void writeAFileFromURl(String path_url, String file_path) {
		URL url = null;
		try {
			url = new URL(path_url);
			java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
			InputStream stream = connection.getInputStream();
			File savedFile = new File(file_path);
			try (FileOutputStream out = new FileOutputStream(savedFile)) {
				int read;
				final byte[] bytes = new byte[1024];
				while ((read = stream.read(bytes)) != -1) {
					out.write(bytes, 0, read);
				}
				out.flush();
				out.close();
			}
			connection.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void DeleteConvertedDocument(String convertedFile) {

		try {
			String filePath = DocumentManager.StoragePath(convertedFile, null);
			File f = new File(filePath);
			if (f.exists()) {
				f.delete();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static String GetApprovedVersionPathURI(String versionFileName, String documentFileName) {
	
		String serverPath = "", storagePath = "", hostAddress = "", filePath = "";
		try {
			serverPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ request.getContextPath();
			storagePath = ConfigManager.GetProperty("storage-folder");
			hostAddress = DocumentManager.CurUserHostAddress(null);
			filePath = serverPath + "/" + storagePath + "/" + hostAddress + "/" + documentFileName + "-approvedversion/"
					+ versionFileName;
			return filePath;
		} catch (Exception ex) {
			throw ex;
		}
	}

}
